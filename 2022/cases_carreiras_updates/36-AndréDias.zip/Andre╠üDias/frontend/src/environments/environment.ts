export const environment = {
  production: false,
  api: 'http://localhost:9000'
};
