# Embarcadero Conference 2022

Faça do download da biblioteca Quicklib: https://github.com/exilon/QuickLib