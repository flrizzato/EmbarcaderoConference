# ec2022
Palestra "Saia do básico para turbinar sua API" apresentada na Embarcadero Conference 2022
