# DGoogleAnalytics
Classe criada para facilitar a integração do Delphi com Google Analytics
