## Win11Corners

This shows that a Delphi 11 VCL application automatically gets rounded corners, even when using a custom titlebar. (Note: This also works with C++Builder 11 and FireMonkey, but FMX doesn't have the custom title bar).

It further demonstrates how to turn rounded corners on and off if desired.
