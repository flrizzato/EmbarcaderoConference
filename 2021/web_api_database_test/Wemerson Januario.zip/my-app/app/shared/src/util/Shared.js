Ext.define('MyExtGenApp.util.Shared', {
	alternateClassName: ['Shared'],
	singleton: true,

	log: function(msg) {
		console.log(msg);
	}
});