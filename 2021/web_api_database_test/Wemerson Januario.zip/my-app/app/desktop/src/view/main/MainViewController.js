Ext.define('MyExtGenApp.view.main.MainViewController', {
	extend: 'Ext.app.ViewController',
	alias: 'controller.mainviewcontroller',

	routes: { 
		':xtype': {action: 'mainRoute'}
	},

	initViewModel: function(vm){
		vm.getStore('menu').on({
			load: 'onMenuDataLoad',
			single: true,
			scope: this
		});
	},

	onMenuDataLoad: function(store){
		this.mainRoute(Ext.util.History.getHash());
	},



	addView: function (node, target) {
		var me = this,
			xtype = node.get('xtype'),
			exists = Ext.ClassManager.getByAlias('widget.' + xtype),
			menuview = me.lookup('navview').lookup('menuview'),
			vm = me.getViewModel();

		if (exists === undefined) {
			console.log(xtype + ' does not exist');
			return;
		}

		if (!target.getComponent(xtype)) {
			target.add({xtype: xtype, itemId: xtype, heading: node.get('text')});
		}

		target.setActiveItem(xtype);
		menuview.setSelection(node);
		vm.set('heading', node.get('text'));
	},

	mainRoute: function (xtype) {
		var me = this,
			navview = this.lookup('navview'),
			menuview = navview.lookup('menuview'),
			centerview = this.lookup('centerview'),
			node;


		if (!menuview.getStore()) {
			console.log('Store not yet avalable from viewModel binding');
			return;
		}

		node = menuview.getStore().findNode('xtype', xtype);

		if (node == null) {
			console.log('unmatchedRoute: ' + xtype);
			return;
		}

		if (node.get('pkg')) {
			if (Ext.Package.isLoaded(node.get('pkg'))) {
				me.addView(node, centerview);
			} else {
				Ext.Package.load(node.get('pkg')).then(function () {
					me.addView(node, centerview);
				});
			}
		} else {
			this.addView(node, centerview);
		}
	},

	onMenuViewSelectionChange: function (tree, node) {
		if (node == null) { return }

		var vm = this.getViewModel();

		if (node.get('xtype') != undefined) {
			this.redirectTo( node.get('xtype') );
		}
	},

	onTopViewNavToggle: function () {
		var vm = this.getViewModel();

		vm.set('navCollapsed', !vm.get('navCollapsed'));
	},

	onHeaderViewDetailToggle: function (button) {
		var vm = this.getViewModel();

		vm.set('detailCollapsed', !vm.get('detailCollapsed'));

		if(vm.get('detailCollapsed')===true) {
			button.setIconCls('x-fa fa-arrow-left');
		}
		else {
			button.setIconCls('x-fa fa-arrow-right');
		}
	},

	onBottomViewlogout: function () {
		localStorage.setItem("LoggedIn", false);
		this.getView().destroy();
		Ext.Viewport.add([{ xtype: 'loginview'}]);
	}
});
