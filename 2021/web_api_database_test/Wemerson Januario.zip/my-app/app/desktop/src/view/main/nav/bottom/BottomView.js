Ext.define('MyExtGenApp.view.main.nav.bottom.BottomView', {
	extend: 'Ext.Toolbar',
	xtype: 'bottomview',
	cls: 'bottomview',
	shadow: false,
//	items: [
//		{
//			xtype: 'button',
//			ui: 'bottomviewbutton',
//			iconCls: 'x-fa fa-angle-double-left',
//			text: 'Logout',
//			handler: 'onBottomViewlogout'
//		}
//	]
});
