Ext.define('MyExtGenApp.view.auth.Login',{
    extend: 'Ext.Panel',
    alias: 'widget.authlogin',
    html: 'Essa é uma tela login'
});