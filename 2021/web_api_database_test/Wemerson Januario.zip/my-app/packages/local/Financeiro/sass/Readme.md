# Financeiro/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    Financeiro/sass/etc
    Financeiro/sass/src
    Financeiro/sass/var
