Ext.define('Financeiro.Main',{
    extend: 'Ext.Panel',
    alias: 'widget.financeiromain',
    html: 'Aqui é a tela principal do Financeiro'
});