# Comercial/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    Comercial/sass/etc
    Comercial/sass/src
    Comercial/sass/var
