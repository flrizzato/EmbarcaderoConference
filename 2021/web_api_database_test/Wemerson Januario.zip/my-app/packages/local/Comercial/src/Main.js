Ext.define('Comercial.Main',{
    extend: 'Ext.Panel',
    alias: 'widget.comercialmain',
    html: 'Aqui é a tela principal do Comercial'
});