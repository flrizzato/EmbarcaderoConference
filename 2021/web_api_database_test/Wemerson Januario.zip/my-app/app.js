Ext.application({
	extend: 'MyExtGenApp.Application',
	name: 'MyExtGenApp'
});