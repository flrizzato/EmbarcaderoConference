# Loading
Classe para exibir carregamento em tempo de execução.
