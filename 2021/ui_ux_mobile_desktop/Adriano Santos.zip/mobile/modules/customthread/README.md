# CustomThread
Classe para facilitar o trabalho de criação de Threads
