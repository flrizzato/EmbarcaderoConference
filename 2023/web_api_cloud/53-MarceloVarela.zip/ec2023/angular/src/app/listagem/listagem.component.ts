import { UsuarioService } from './../usuario.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cliente } from '../cliente';

@Component({
  selector: 'app-listagem',
  templateUrl: './listagem.component.html',
  styleUrls: ['./listagem.component.css'],
})
export class ListagemComponent implements OnInit {
  clientes: Cliente[] = [];
  clienteSelecionado!: Cliente;

  constructor(private usuarioServico: UsuarioService, private router: Router) {

  }

  ngOnInit(): void {
    this.onListar();
  }

  onListar(): void {
    // inicializar uma animação...
    this.usuarioServico.listarClientes().subscribe({
      next: (resultado: any) => (this.clientes = resultado)
      //error:,
      //complete:
    });
  }

  onRowSelect(): void {
    this.router.navigate(['/detalhes', this.clienteSelecionado.codigoid]);
  }
}
