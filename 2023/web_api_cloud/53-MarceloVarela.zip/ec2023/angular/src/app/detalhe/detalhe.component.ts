import { Cliente } from './../cliente';
import { UsuarioService } from './../usuario.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-detalhe',
  templateUrl: './detalhe.component.html',
  styleUrls: ['./detalhe.component.css'],
})
export class DetalheComponent implements OnInit {
  cliente: Cliente = { codigoid: 0, nome: '', email: ''};
  id = 0;
  nome = '';
  email = '';
  carregando = true;

  constructor(
    private activaRoute: ActivatedRoute,
    private usuarioServico: UsuarioService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.activaRoute.paramMap.subscribe({
      next: (rota: any) => {
        this.id = rota.params.id;
        this.usuarioServico.listarClientesById(this.id).subscribe({
          next: (retorno: Cliente) => {
            this.cliente = retorno;
            this.nome = retorno.nome;
            this.email = retorno.email;
          },
          error: (erro: any) => console.log(erro),
          complete: () => this.carregando = false
        });
      },
    });
  }

  apagar(): void{
    this.usuarioServico.apagarClientesById(this.cliente.codigoid).subscribe({
      next: (retorno: any) => {
        this.router.navigate(['/listagem']);
      },
      error: (erro: any) => console.log(erro)
    });
  }

  salvar(): void{
    this.usuarioServico.salvarClientesById(this.cliente).subscribe({
      next: (retorno: any) => {
        this.router.navigate(['/listagem']);
      },
      error: (erro: any) => console.log(erro)
    });
  }

}
