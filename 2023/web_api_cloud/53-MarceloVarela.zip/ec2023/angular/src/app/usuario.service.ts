import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, delay } from 'rxjs';
import { Cliente } from './cliente';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  constructor(private http: HttpClient) { }

  listarClientes(): Observable<Cliente[]>{
    return this.http.get<Cliente[]>('http://localhost:8080/cliente');
  }

  listarClientesById(id: number): Observable<Cliente>{
    return this.http.get<Cliente>(`http://localhost:8080/cliente/${id}`);
  }

  apagarClientesById(id: number): Observable<any>{
    return this.http.delete(`http://localhost:8080/cliente/${id}`);
  }

  salvarClientesById(cliente: Cliente): Observable<any>{
    return this.http.put(`http://localhost:8080/cliente/${cliente.codigoid}`, cliente);
  }

  salvarNovoCliente(cliente: Cliente): Observable<any>{
    return this.http.post(`http://localhost:8080/cliente`, cliente);
  }
}
