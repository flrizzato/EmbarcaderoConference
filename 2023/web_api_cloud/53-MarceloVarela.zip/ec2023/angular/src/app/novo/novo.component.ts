import { Cliente } from './../cliente';
import { UsuarioService } from './../usuario.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-novo',
  templateUrl: './novo.component.html',
  styleUrls: ['./novo.component.css']
})
export class NovoComponent implements OnInit {
  cliente: Cliente = { codigoid: 0, nome: '', email: ''};


  constructor(
    private activaRoute: ActivatedRoute,
    private usuarioServico: UsuarioService,
    private router: Router
  ) {}

  ngOnInit(): void {
    
  }

  salvar(): void{
    this.usuarioServico.salvarNovoCliente(this.cliente).subscribe({
      next: (retorno: any) => {
        this.router.navigate(['/listagem']);
      },
      error: (erro: any) => console.log(erro)
    });
  }

}
