import { DetalheComponent } from './detalhe/detalhe.component';
import { ListagemComponent } from './listagem/listagem.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NovoComponent } from './novo/novo.component';

const routes: Routes = [
  { path: 'listagem', component: ListagemComponent },
  { path: 'detalhes/:id', component: DetalheComponent },
  { path: 'novo', component: NovoComponent },
  { path: '', redirectTo: '/listagem', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
