export interface Cliente {
  codigoid: number
  nome: string
  email: string
}
