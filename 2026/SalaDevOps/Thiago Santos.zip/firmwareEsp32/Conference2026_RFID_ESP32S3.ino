/*
  Conference2026 RFID - ESP32-S3 + MFRC522
  
  Ligacoes RC522:
    ESP32-S3       RC522
    3V3            3.3V
    GND            GND
    GPIO 12        SCK
    GPIO 13        MISO
    GPIO 11        MOSI
    GPIO 10        SDA/SS
    GPIO 9         RST

  Serial: 115200

  Comandos JSON:
    {"proto":"TSX-RFID/1.0","type":"command","command":"reader_recover"}
    {"proto":"TSX-RFID/1.0","type":"command","command":"system_restart"}
    {"proto":"TSX-RFID/1.0","type":"command","command":"status"}

  (teste no Monitor Serial):
    READER_RECOVER
    SYSTEM_RESTART
    STATUS
*/

#include <Arduino.h>
#include <SPI.h>
#include <MFRC522.h>

// -----------------------------------------------------------------------------
// Hardware
// -----------------------------------------------------------------------------
static constexpr uint8_t PIN_RFID_SCK  = 12;
static constexpr uint8_t PIN_RFID_MISO = 13;
static constexpr uint8_t PIN_RFID_MOSI = 11;
static constexpr uint8_t PIN_RFID_SS   = 10;
static constexpr uint8_t PIN_RFID_RST  = 9;

// -----------------------------------------------------------------------------
// Identificacao / protocolo
// -----------------------------------------------------------------------------
static const char* PROTOCOL_VERSION = "TSX-RFID/1.0";
static const char* DEVICE_ID        = "TSX-RFID-001";
static const char* FIRMWARE_VERSION = "0.4.0";

MFRC522 rfid(PIN_RFID_SS, PIN_RFID_RST);

// -----------------------------------------------------------------------------
// Estado
// -----------------------------------------------------------------------------
bool readerOnline = false;

String lastUid;
unsigned long lastUidAt = 0;
unsigned long lastReaderHealthAt = 0;
unsigned long lastHeartbeatAt = 0;
unsigned long lastAutoRecoverAt = 0;

String serialLine;

// Impede duplicacao acidental se uma TAG oscilar na borda do campo.
// Nao atrasa a PRIMEIRA leitura.
static constexpr unsigned long SAME_UID_GUARD_MS       = 900;
static constexpr unsigned long READER_HEALTH_INTERVAL  = 3000;
static constexpr unsigned long DEVICE_HEARTBEAT_MS     = 2000;
static constexpr unsigned long OFFLINE_RECOVER_MS      = 1500;

// -----------------------------------------------------------------------------
// Utilitarios
// -----------------------------------------------------------------------------
String uidToString(const MFRC522::Uid& uid)
{
  String value;
  value.reserve(uid.size * 3);

  for (byte i = 0; i < uid.size; ++i)
  {
    if (i > 0)
      value += ':';

    if (uid.uidByte[i] < 0x10)
      value += '0';

    value += String(uid.uidByte[i], HEX);
  }

  value.toUpperCase();
  return value;
}

byte readReaderVersion()
{
  return rfid.PCD_ReadRegister(MFRC522::VersionReg);
}

bool versionLooksValid(byte version)
{
  return version != 0x00 && version != 0xFF;
}

void sendDeviceStatus(const char* status)
{
  Serial.print(F("{\"proto\":\""));
  Serial.print(PROTOCOL_VERSION);
  Serial.print(F("\",\"type\":\"device\",\"deviceId\":\""));
  Serial.print(DEVICE_ID);
  Serial.print(F("\",\"firmware\":\""));
  Serial.print(FIRMWARE_VERSION);
  Serial.print(F("\",\"status\":\""));
  Serial.print(status);
  Serial.print(F("\",\"reader\":\""));
  Serial.print(readerOnline ? F("online") : F("offline"));
  Serial.println(F("\",\"latched\":false}"));
}

void sendTagRead(const String& uid)
{
  Serial.print(F("{\"proto\":\""));
  Serial.print(PROTOCOL_VERSION);
  Serial.print(F("\",\"type\":\"rfid\",\"event\":\"tag_read\",\"uid\":\""));
  Serial.print(uid);
  Serial.println(F("\"}"));
}

void sendReaderError(const char* message)
{
  Serial.print(F("{\"proto\":\""));
  Serial.print(PROTOCOL_VERSION);
  Serial.print(F("\",\"type\":\"rfid\",\"event\":\"reader_error\",\"message\":\""));
  Serial.print(message);
  Serial.println(F("\"}"));
}

void sendCommandResult(const char* command, const char* status)
{
  Serial.print(F("{\"proto\":\""));
  Serial.print(PROTOCOL_VERSION);
  Serial.print(F("\",\"type\":\"command_result\",\"command\":\""));
  Serial.print(command);
  Serial.print(F("\",\"status\":\""));
  Serial.print(status);
  Serial.println(F("\"}"));
}

// -----------------------------------------------------------------------------
// Inicializacao / recovery do RC522
// -----------------------------------------------------------------------------
bool initializeReader(bool announce)
{
  // Garante SS desmarcado antes da inicializacao.
  pinMode(PIN_RFID_SS, OUTPUT);
  digitalWrite(PIN_RFID_SS, HIGH);

  rfid.PCD_Init();

  // Tags chaveiro normalmente possuem antena menor que cartoes.
  // Ganho maximo melhora a margem de leitura, especialmente dentro da caixa.
  rfid.PCD_SetAntennaGain(MFRC522::RxGain_max);
  rfid.PCD_AntennaOn();

  delay(8);

  const byte version = readReaderVersion();
  readerOnline = versionLooksValid(version);

  if (announce)
  {
    Serial.print(F("[RFID] MFRC522 VersionReg: 0x"));
    if (version < 0x10)
      Serial.print('0');
    Serial.println(version, HEX);

    Serial.print(F("[RFID] RxGain configurado: 0x"));
    byte gain = rfid.PCD_GetAntennaGain();
    if (gain < 0x10)
      Serial.print('0');
    Serial.println(gain, HEX);
  }

  if (!readerOnline)
  {
    sendReaderError("reader_not_responding");
    return false;
  }

  return true;
}

bool recoverReader(const char* reason)
{
  Serial.print(F("[RFID] Recovery por software: "));
  Serial.println(reason != nullptr ? reason : "sem motivo");

  readerOnline = false;

  // Limpa estado de protocolo antes do reset.
  rfid.PCD_StopCrypto1();

  // Reset eletrico do RC522 pelo proprio ESP32.
  // Nao exige acesso fisico ao botao/reset da caixa.
  pinMode(PIN_RFID_RST, OUTPUT);
  digitalWrite(PIN_RFID_RST, LOW);
  delay(3);
  digitalWrite(PIN_RFID_RST, HIGH);
  delay(35);

  const bool ok = initializeReader(false);

  if (ok)
  {
    lastUid = "";
    lastUidAt = 0;
    lastReaderHealthAt = millis();
    lastAutoRecoverAt = millis();

    Serial.println(F("[RFID] RC522 recuperado e pronto."));
    sendDeviceStatus("ready");
  }
  else
  {
    lastAutoRecoverAt = millis();
    Serial.println(F("[RFID] RC522 continua indisponivel."));
    sendDeviceStatus("error");
  }

  return ok;
}

// -----------------------------------------------------------------------------
// Leitura RFID - caminho curto e rapido
// -----------------------------------------------------------------------------
void processRFID()
{
  if (!readerOnline)
    return;

  // O caminho normal fica propositalmente simples:
  // detecta -> le UID -> envia -> HALT.
  // Sem latch, sem probe de presenca e sem espera por varias amostras.
  if (!rfid.PICC_IsNewCardPresent())
    return;

  if (!rfid.PICC_ReadCardSerial())
    return;

  const unsigned long now = millis();
  const String uid = uidToString(rfid.uid);

  // Primeiro finaliza a comunicacao com a PICC.
  // Uma TAG mantida sobre o leitor fica em HALT e nao deve gerar
  // eventos continuamente. Ao retirar/reaproximar, ela volta a responder.
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();

  // Protecao extra contra oscilacao de campo / leituras duplicadas.
  const bool repeatedTooSoon =
    (uid == lastUid) &&
    ((now - lastUidAt) < SAME_UID_GUARD_MS);

  if (repeatedTooSoon)
    return;

  lastUid = uid;
  lastUidAt = now;

  Serial.print(F("[RFID] TAG: "));
  Serial.println(uid);

  // Evento enviado imediatamente ao C++Builder.
  sendTagRead(uid);
}

// -----------------------------------------------------------------------------
// Health check / autorrecuperacao
// -----------------------------------------------------------------------------
void processReaderHealth()
{
  const unsigned long now = millis();

  if ((now - lastReaderHealthAt) < READER_HEALTH_INTERVAL)
    return;

  lastReaderHealthAt = now;

  const byte version = readReaderVersion();

  if (versionLooksValid(version))
  {
    readerOnline = true;
    return;
  }

  readerOnline = false;

  if ((now - lastAutoRecoverAt) >= OFFLINE_RECOVER_MS)
  {
    lastAutoRecoverAt = now;
    recoverReader("health_check");
  }
}

void processOfflineRecovery()
{
  if (readerOnline)
    return;

  const unsigned long now = millis();

  if ((now - lastAutoRecoverAt) < OFFLINE_RECOVER_MS)
    return;

  lastAutoRecoverAt = now;
  recoverReader("reader_offline");
}

void processHeartbeat()
{
  const unsigned long now = millis();

  if ((now - lastHeartbeatAt) < DEVICE_HEARTBEAT_MS)
    return;

  lastHeartbeatAt = now;
  sendDeviceStatus(readerOnline ? "ready" : "error");
}

// -----------------------------------------------------------------------------
// Comandos seriais
// -----------------------------------------------------------------------------
bool isJsonCommand(const String& line, const char* command)
{
  if (line.indexOf("\"proto\":\"TSX-RFID/1.0\"") < 0)
    return false;

  if (line.indexOf("\"type\":\"command\"") < 0)
    return false;

  String key = "\"command\":\"";
  key += command;
  key += "\"";

  return line.indexOf(key) >= 0;
}

void processCommandLine(String line)
{
  line.trim();

  if (line.length() == 0)
    return;

  // Recovery apenas do RC522. Mantem o ESP32/porta serial vivos.
  if (line == "READER_RECOVER" ||
      isJsonCommand(line, "reader_recover"))
  {
    const bool ok = recoverReader("comando_serial");
    sendCommandResult("reader_recover", ok ? "ok" : "error");
    return;
  }

  // Reinicio total do ESP32-S3, equivalente ao reset logico da placa.
  if (line == "SYSTEM_RESTART" ||
      isJsonCommand(line, "system_restart"))
  {
    sendCommandResult("system_restart", "restarting");
    Serial.flush();
    delay(80);
    ESP.restart();
    return;
  }

  if (line == "STATUS" ||
      isJsonCommand(line, "status"))
  {
    sendDeviceStatus(readerOnline ? "ready" : "error");
    sendCommandResult("status", "ok");
    return;
  }

  // So responde erro para comandos do nosso protocolo.
  if (line.indexOf("\"proto\":\"TSX-RFID/1.0\"") >= 0 &&
      line.indexOf("\"type\":\"command\"") >= 0)
  {
    sendCommandResult("unknown", "error");
  }
}

void processSerialCommands()
{
  while (Serial.available() > 0)
  {
    const char ch = static_cast<char>(Serial.read());

    if (ch == '\n')
    {
      processCommandLine(serialLine);
      serialLine = "";
      continue;
    }

    if (ch == '\r')
      continue;

    if (serialLine.length() < 384)
      serialLine += ch;
    else
      serialLine = "";
  }
}

// -----------------------------------------------------------------------------
// Arduino
// -----------------------------------------------------------------------------
void setup()
{
  Serial.begin(115200);

  // Pequena janela apenas para estabilizacao do USB/serial.
  // Menor que a versao anterior para acelerar a entrada em operacao.
  delay(350);

  Serial.println();
  Serial.println(F("=========================================="));
  Serial.println(F(" TSX RFID - ESP32-S3 + RC522"));
  Serial.println(F(" Firmware 0.4.0"));
  Serial.println(F(" FAST RFID + SOFTWARE RECOVERY"));
  Serial.println(F("=========================================="));

  SPI.begin(
    PIN_RFID_SCK,
    PIN_RFID_MISO,
    PIN_RFID_MOSI,
    PIN_RFID_SS
  );

  if (initializeReader(true))
  {
    Serial.println(F("[RFID] Leitor detectado."));
    Serial.println(F("[RFID] Ganho maximo habilitado."));
    Serial.println(F("[RFID] Aproxime uma TAG/cartao."));
    sendDeviceStatus("ready");
  }
  else
  {
    Serial.println(F("[RFID] ERRO: leitor nao respondeu."));
    sendDeviceStatus("error");
  }

  lastReaderHealthAt = millis();
  lastHeartbeatAt = millis();
  lastAutoRecoverAt = millis();
}

void loop()
{
  // Ordem intencional:
  // 1) comandos de recovery/reset sempre disponiveis;
  // 2) RFID recebe prioridade;
  // 3) health/heartbeat executam em baixa frequencia.
  processSerialCommands();

  if (readerOnline)
    processRFID();
  else
    processOfflineRecovery();

  processReaderHealth();
  processHeartbeat();

  // Mantem o ESP32 responsivo sem introduzir atraso perceptivel na leitura.
  delay(1);
}
