﻿#include <vcl.h>
#pragma hdrstop

#include "MainForm.h"

#include "BleManager.h"
#include "CameraManager.h"
#include "AccessEventRepository.h"
#include "EmployeeRepository.h"
#include "EmployeeSyncClient.h"
#include "IdentificationManager.h"
#include "IntegrationClient.h"

#include <System.SysUtils.hpp>
#include <System.IOUtils.hpp>
#include <System.IniFiles.hpp>
#include <System.Net.HttpClient.hpp>
#include <System.JSON.hpp>
#include <IdHTTP.hpp>
#include <Vcl.Dialogs.hpp>
#include <Winapi.Windows.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

#include "ObservabilityHeartbeat.h"
#include "RfidSerialReader.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------

namespace
{
    const int FaceDetectedRequiredFrames = 2;
    const int FaceMissingRequiredFrames = 5;
    const int FaceDetectionIntervalFrames = 2;
    const int FaceRecognitionIntervalMs = 300;
    const int FaceRecognitionRequiredHits = 3;
    const int FaceEnrollmentRequiredSamples = 8;

    // v0.7.4.1 - qualidade da imagem facial.
    // O limite foi calibrado com a webcam real para separar melhor
    // pouca iluminação de perda de nitidez.
    // v0.7.4.1 - calibrado após teste real com webcam.
    // A câmera ainda produzia brilho médio acima de 55 mesmo em ambiente
    // visualmente escuro, fazendo o frame cair no filtro de nitidez.
    const double FaceMinimumBrightness = 90.0;
    // Distance tuning:
    // - Enter/exit thresholds intentionally differ to create hysteresis.
    // - This prevents the UI from oscillating between "too far / good / too close".
    const int RecentFaceToleranceMs = 1500;
    const double TooFarEnterRatio = 0.18;
    const double TooFarExitRatio = 0.22;
    const double TooCloseEnterRatio = 0.58;
    const double TooCloseExitRatio = 0.52;
    const double LargeFaceNearEdgeRatio = 0.45;
    const double GrowingFaceRatioDelta = 0.04;

    // =========================================================
    // CANAL OPERACIONAL DIRETO ERP DELPHI <-> PORTARIA
    // =========================================================
    // O WebServer :8080 permanece exclusivamente para observabilidade.
    // Cadastro facial remoto usa diretamente a API operacional do ERP.
    const UnicodeString ErpOperationalApiBase =
        L"http://127.0.0.1:3101/api";

    struct TErpEnrollmentCommand
    {
        bool Pending;
        int EmployeeId;
        UnicodeString EmployeeName;
        UnicodeString RequestId;
        UnicodeString Terminal;

        TErpEnrollmentCommand()
            : Pending(false),
              EmployeeId(0)
        {
        }
    };

    struct TPendingEnrollmentResultRetry
    {
        bool Active;
        UnicodeString RequestId;
        UnicodeString Status;
        UnicodeString Message;
        int Samples;

        TPendingEnrollmentResultRetry()
            : Active(false),
              Samples(0)
        {
        }
    };

    TPendingEnrollmentResultRetry GPendingEnrollmentResultRetry;

    struct TErpRevokeCommand
    {
        bool Pending;
        int EmployeeId;
        UnicodeString EmployeeName;
        UnicodeString RequestId;
        UnicodeString Terminal;

        TErpRevokeCommand()
            : Pending(false),
              EmployeeId(0)
        {
        }
    };

    struct TPendingRevokeResultRetry
    {
        bool Active;
        UnicodeString RequestId;
        UnicodeString Status;
        UnicodeString Message;

        TPendingRevokeResultRetry()
            : Active(false)
        {
        }
    };

    TPendingRevokeResultRetry GPendingRevokeResultRetry;

    UnicodeString JsonFieldText(
        TJSONObject* Root,
        const UnicodeString& Name)
    {
        if (Root == nullptr)
            return L"";

        TJSONValue* Value = Root->GetValue(Name);
        return Value != nullptr ? Value->Value() : UnicodeString();
    }

    // =========================================================
    // ETAPA 5 - ERP COMO AUTORIDADE DA DECISAO DE ACESSO
    // =========================================================
    // ERP online: /api/access/authorize e a fonte oficial da decisao.
    // ERP indisponivel: a Portaria preserva a regra local como contingencia.
    // FACE/RFID continuam apenas identificando; a Portaria executa a decisao.
    struct TErpAccessDecision
    {
        bool Available;
        bool Authorized;
        UnicodeString Reason;
        UnicodeString EmployeeName;
        UnicodeString WorkStart;
        UnicodeString WorkEnd;

        TErpAccessDecision()
            : Available(false),
              Authorized(false)
        {
        }
    };

    bool TryGetErpAccessDecision(
        int EmployeeId,
        const UnicodeString& Credential,
        TErpAccessDecision& Decision)
    {
        Decision = TErpAccessDecision();

        if (EmployeeId <= 0)
            return false;

        try
        {
            std::unique_ptr<TIdHTTP> Http(new TIdHTTP(nullptr));
            Http->ConnectTimeout = 350;
            Http->ReadTimeout = 650;
            Http->Request->ContentType = L"application/json";
            Http->Request->CharSet = L"utf-8";

            std::unique_ptr<TJSONObject> Payload(new TJSONObject());
            Payload->AddPair(L"employeeId", new TJSONNumber(EmployeeId));
            Payload->AddPair(L"terminal", L"PORTARIA-01");
            Payload->AddPair(L"credential", Credential);

            std::unique_ptr<TStringStream> Body(
                new TStringStream(
                    Payload->ToJSON(),
                    TEncoding::UTF8,
                    false));

            Body->Position = 0;

            const UnicodeString ResponseText =
                Http->Post(
                    ErpOperationalApiBase +
                    L"/access/authorize",
                    Body.get());

            if (Http->ResponseCode < 200 ||
                Http->ResponseCode >= 300)
            {
                return false;
            }

            std::unique_ptr<TJSONValue> JsonValue(
                TJSONObject::ParseJSONValue(
                    ResponseText,
                    true,
                    false));

            TJSONObject* Root =
                dynamic_cast<TJSONObject*>(JsonValue.get());

            if (Root == nullptr)
                return false;

            Decision.Available = true;
            Decision.Authorized = SameText(
                Trim(JsonFieldText(Root, L"authorized")),
                L"true");
            Decision.Reason =
                Trim(JsonFieldText(Root, L"reason"));
            Decision.EmployeeName =
                JsonFieldText(Root, L"employeeName");
            Decision.WorkStart =
                JsonFieldText(Root, L"workStart");
            Decision.WorkEnd =
                JsonFieldText(Root, L"workEnd");

            return true;
        }
        catch (...)
        {
            // ERP indisponivel: o chamador aplicara a contingencia local.
            return false;
        }
    }

    UnicodeString ErpAccessReasonToDisplay(
        const UnicodeString& Reason)
    {
        if (SameText(Reason, L"EMPLOYEE_BLOCKED"))
            return L"Bloqueado pelo ERP";

        if (SameText(Reason, L"OUTSIDE_WORK_HOURS"))
            return L"Fora do horário de expediente";

        if (SameText(Reason, L"INVALID_WORK_SCHEDULE"))
            return L"Horário de expediente inválido no ERP";

        if (SameText(Reason, L"EMPLOYEE_NOT_FOUND"))
            return L"Funcionário não encontrado no ERP";

        if (!Trim(Reason).IsEmpty())
            return Reason;

        return L"Acesso negado pelo ERP";
    }

    void LogAccessDecisionComparison(
        const UnicodeString& Credential,
        const TEmployee& Employee,
        bool LocalAuthorized,
        const TErpAccessDecision& ErpDecision)
    {
        UnicodeString Line;

        if (!ErpDecision.Available)
        {
            Line =
                L"[ACCESS][COMPARE] credential=" + Credential +
                L" employeeId=" + IntToStr(Employee.Id) +
                L" employee=" + Employee.Name +
                L" local=" +
                (LocalAuthorized ? UnicodeString(L"GRANTED") : UnicodeString(L"DENIED")) +
                L" erp=UNAVAILABLE reason=ERP_UNAVAILABLE match=NA";
        }
        else
        {
            const bool Match =
                LocalAuthorized == ErpDecision.Authorized;

            Line =
                L"[ACCESS][COMPARE] credential=" + Credential +
                L" employeeId=" + IntToStr(Employee.Id) +
                L" employee=" + Employee.Name +
                L" local=" +
                (LocalAuthorized ? UnicodeString(L"GRANTED") : UnicodeString(L"DENIED")) +
                L" erp=" +
                (ErpDecision.Authorized ? UnicodeString(L"GRANTED") : UnicodeString(L"DENIED")) +
                L" reason=" + ErpDecision.Reason +
                L" schedule=" + ErpDecision.WorkStart + L"-" + ErpDecision.WorkEnd +
                L" match=" +
                (Match ? UnicodeString(L"1") : UnicodeString(L"0"));
        }

        OutputDebugStringW((Line + L"\r\n").c_str());

        // ETAPA 4.1: registra a comparacao em arquivo para permitir testes
        // com Run Without Debugging, evitando interrupcoes first-chance do Indy.
        try
        {
            const UnicodeString DataDir =
                TPath::Combine(ExtractFilePath(Application->ExeName), L"data");

            if (!TDirectory::Exists(DataDir))
                TDirectory::CreateDirectory(DataDir);

            const UnicodeString LogPath =
                TPath::Combine(DataDir, L"access_compare.log");

            const UnicodeString FileLine =
                FormatDateTime(L"yyyy-mm-dd hh:nn:ss.zzz", Now()) +
                L" | " + Line + L"\r\n";

            TFile::AppendAllText(
                LogPath,
                FileLine,
                TEncoding::UTF8);
        }
        catch (...)
        {
            // Log diagnostico nunca pode interferir na operacao da Portaria.
        }
    }

    bool TryGetPendingEnrollmentFromErp(
        TErpEnrollmentCommand& Command)
    {
        Command = TErpEnrollmentCommand();

        try
        {
            std::unique_ptr<TIdHTTP> Http(new TIdHTTP(nullptr));
            Http->ConnectTimeout = 350;
            Http->ReadTimeout = 650;

            const UnicodeString ResponseText =
                Http->Get(
                    ErpOperationalApiBase +
                    L"/enrollment/pending");

            std::unique_ptr<TJSONValue> JsonValue(
                TJSONObject::ParseJSONValue(
                    ResponseText,
                    true,
                    false));

            TJSONObject* Root =
                dynamic_cast<TJSONObject*>(JsonValue.get());

            if (Root == nullptr)
                return false;

            const bool Pending =
                SameText(
                    Trim(JsonFieldText(Root, L"pending")),
                    L"true");

            if (!Pending)
                return false;

            Command.Pending = true;
            Command.RequestId =
                Trim(JsonFieldText(Root, L"requestId"));

            Command.EmployeeId =
                StrToIntDef(
                    JsonFieldText(Root, L"employeeId"),
                    0);

            Command.EmployeeName =
                JsonFieldText(Root, L"employeeName");

            Command.Terminal =
                JsonFieldText(Root, L"terminal");

            return !Command.RequestId.IsEmpty() &&
                Command.EmployeeId > 0;
        }
        catch (...)
        {
            // ERP indisponível não interrompe câmera, RFID ou acesso local.
            return false;
        }
    }

    bool PostOperationalJson(
        const UnicodeString& RelativePath,
        TJSONObject* Payload)
    {
        if (Payload == nullptr)
            return false;

        try
        {
            std::unique_ptr<TIdHTTP> Http(new TIdHTTP(nullptr));
            Http->ConnectTimeout = 350;
            Http->ReadTimeout = 650;
            Http->Request->ContentType = L"application/json";
            Http->Request->CharSet = L"utf-8";

            std::unique_ptr<TStringStream> Body(
                new TStringStream(
                    Payload->ToJSON(),
                    TEncoding::UTF8,
                    false));

            Body->Position = 0;

            Http->Post(
                ErpOperationalApiBase + RelativePath,
                Body.get());

            return Http->ResponseCode >= 200 &&
                Http->ResponseCode < 300;
        }
        catch (...)
        {
            // A falha de comunicação não pode travar o terminal.
            return false;
        }
    }

    bool SendDirectEnrollmentProgress(
        const UnicodeString& RequestId,
        const UnicodeString& Message,
        int Samples)
    {
        if (Trim(RequestId).IsEmpty())
            return false;

        std::unique_ptr<TJSONObject> Payload(
            new TJSONObject());

        Payload->AddPair(
            L"requestId",
            RequestId);

        Payload->AddPair(
            L"samples",
            new TJSONNumber(Samples));

        Payload->AddPair(
            L"message",
            Message);

        return PostOperationalJson(
            L"/enrollment/progress",
            Payload.get());
    }

    bool SendDirectEnrollmentResult(
        const UnicodeString& RequestId,
        const UnicodeString& Status,
        const UnicodeString& Message,
        int Samples)
    {
        if (Trim(RequestId).IsEmpty())
            return false;

        std::unique_ptr<TJSONObject> Payload(
            new TJSONObject());

        Payload->AddPair(
            L"requestId",
            RequestId);

        Payload->AddPair(
            L"status",
            Status);

        Payload->AddPair(
            L"samples",
            new TJSONNumber(Samples));

        Payload->AddPair(
            L"message",
            Message);

        return PostOperationalJson(
            L"/enrollment/result",
            Payload.get());
    }

    void QueueEnrollmentResultForRetry(
        const UnicodeString& RequestId,
        const UnicodeString& Status,
        const UnicodeString& Message,
        int Samples)
    {
        GPendingEnrollmentResultRetry.Active = true;
        GPendingEnrollmentResultRetry.RequestId = RequestId;
        GPendingEnrollmentResultRetry.Status = Status;
        GPendingEnrollmentResultRetry.Message = Message;
        GPendingEnrollmentResultRetry.Samples = Samples;
    }

    void SendEnrollmentResultToErp(
        const UnicodeString& RequestId,
        const UnicodeString& Status,
        const UnicodeString& Message,
        int Samples)
    {
        if (Trim(RequestId).IsEmpty())
            return;

        if (!SendDirectEnrollmentResult(
                RequestId,
                Status,
                Message,
                Samples))
        {
            QueueEnrollmentResultForRetry(
                RequestId,
                Status,
                Message,
                Samples);
        }
    }

    bool FlushPendingEnrollmentResultToErp()
    {
        if (!GPendingEnrollmentResultRetry.Active)
            return true;

        if (!SendDirectEnrollmentResult(
                GPendingEnrollmentResultRetry.RequestId,
                GPendingEnrollmentResultRetry.Status,
                GPendingEnrollmentResultRetry.Message,
                GPendingEnrollmentResultRetry.Samples))
        {
            return false;
        }

        GPendingEnrollmentResultRetry =
            TPendingEnrollmentResultRetry();

        return true;
    }

    bool TryGetPendingRevokeFromErp(
        TErpRevokeCommand& Command)
    {
        Command = TErpRevokeCommand();

        try
        {
            std::unique_ptr<TIdHTTP> Http(new TIdHTTP(nullptr));
            Http->ConnectTimeout = 350;
            Http->ReadTimeout = 650;

            const UnicodeString ResponseText =
                Http->Get(
                    ErpOperationalApiBase +
                    L"/revoke/pending");

            std::unique_ptr<TJSONValue> JsonValue(
                TJSONObject::ParseJSONValue(
                    ResponseText,
                    true,
                    false));

            TJSONObject* Root =
                dynamic_cast<TJSONObject*>(JsonValue.get());

            if (Root == nullptr)
                return false;

            const bool Pending =
                SameText(
                    Trim(JsonFieldText(Root, L"pending")),
                    L"true");

            if (!Pending)
                return false;

            Command.Pending = true;
            Command.RequestId =
                Trim(JsonFieldText(Root, L"requestId"));

            Command.EmployeeId =
                StrToIntDef(
                    JsonFieldText(Root, L"employeeId"),
                    0);

            Command.EmployeeName =
                JsonFieldText(Root, L"employeeName");

            Command.Terminal =
                JsonFieldText(Root, L"terminal");

            return !Command.RequestId.IsEmpty() &&
                Command.EmployeeId > 0;
        }
        catch (...)
        {
            // ERP indisponível não interrompe câmera, RFID ou acesso local.
            return false;
        }
    }

    bool SendDirectRevokeResult(
        const UnicodeString& RequestId,
        const UnicodeString& Status,
        const UnicodeString& Message)
    {
        if (Trim(RequestId).IsEmpty())
            return false;

        std::unique_ptr<TJSONObject> Payload(
            new TJSONObject());

        Payload->AddPair(
            L"requestId",
            RequestId);

        Payload->AddPair(
            L"status",
            Status);

        Payload->AddPair(
            L"message",
            Message);

        return PostOperationalJson(
            L"/revoke/result",
            Payload.get());
    }

    void QueueRevokeResultForRetry(
        const UnicodeString& RequestId,
        const UnicodeString& Status,
        const UnicodeString& Message)
    {
        GPendingRevokeResultRetry.Active = true;
        GPendingRevokeResultRetry.RequestId = RequestId;
        GPendingRevokeResultRetry.Status = Status;
        GPendingRevokeResultRetry.Message = Message;
    }

    void SendRevokeResultToErp(
        const UnicodeString& RequestId,
        const UnicodeString& Status,
        const UnicodeString& Message)
    {
        if (Trim(RequestId).IsEmpty())
            return;

        if (!SendDirectRevokeResult(
                RequestId,
                Status,
                Message))
        {
            QueueRevokeResultForRetry(
                RequestId,
                Status,
                Message);
        }
    }

    bool FlushPendingRevokeResultToErp()
    {
        if (!GPendingRevokeResultRetry.Active)
            return true;

        if (SendDirectRevokeResult(
                GPendingRevokeResultRetry.RequestId,
                GPendingRevokeResultRetry.Status,
                GPendingRevokeResultRetry.Message))
        {
            GPendingRevokeResultRetry =
                TPendingRevokeResultRetry();

            return true;
        }

        // v0.7.4.3:
        // Se o ERP reiniciar, o estado em memória do requestId anterior pode
        // desaparecer. Nesse cenário um retry antigo receberá 404 para sempre.
        //
        // Antes de bloquear novas remoções, consultamos o comando atualmente
        // pendente no ERP. Se existir outro requestId, o retry local anterior
        // ficou obsoleto e pode ser descartado com segurança.
        TErpRevokeCommand CurrentCommand;

        if (TryGetPendingRevokeFromErp(CurrentCommand) &&
            CurrentCommand.Pending &&
            !SameText(
                Trim(CurrentCommand.RequestId),
                Trim(GPendingRevokeResultRetry.RequestId)))
        {
            OutputDebugStringW(
                (L"[REVOKE][ERP3101] Retry obsoleto descartado. antigo=" +
                 GPendingRevokeResultRetry.RequestId +
                 L" atual=" +
                 CurrentCommand.RequestId +
                 L"\r\n").c_str());

            GPendingRevokeResultRetry =
                TPendingRevokeResultRetry();

            // Retorna true para que ProcessPendingBiometricCommands()
            // possa consumir imediatamente o novo /revoke/pending.
            return true;
        }

        // Mesmo request ainda pendente ou ERP indisponível:
        // preserva o retry e tenta novamente no próximo ciclo.
        return false;
    }

    std::string ToStdString(const UnicodeString& Value)
    {
        return AnsiString(Value).c_str();
    }

    UnicodeString BuildRfidFallbackIdentityKey(
        const TEmployee& Employee)
    {
        // O RFID precisa funcionar mesmo para funcionários que ainda não
        // possuem FaceKey. O fallback usa ID + nome normalizado para não
        // depender do cadastro de identificação facial.
        UnicodeString NormalizedName =
            LowerCase(Trim(Employee.Name));

        NormalizedName = StringReplace(
            NormalizedName,
            L"|",
            L" ",
            TReplaceFlags() << rfReplaceAll);

        return L"RFIDEMP|" +
            IntToStr(Employee.Id) +
            L"|" +
            NormalizedName;
    }

    UnicodeString BuildRfidIdentityKey(
        const TEmployee& Employee)
    {
        const UnicodeString FaceKey =
            Trim(Employee.FaceKey);

        // Mantém compatibilidade com vínculos já gravados pela v0.4.5.
        if (!FaceKey.IsEmpty())
            return FaceKey;

        return BuildRfidFallbackIdentityKey(Employee);
    }

    bool RfidIdentityMatches(
        const UnicodeString& StoredIdentityKey,
        const TEmployee& Employee)
    {
        const UnicodeString Stored =
            Trim(StoredIdentityKey);

        if (Stored.IsEmpty() || Employee.Id <= 0)
            return false;

        const UnicodeString FaceKey =
            Trim(Employee.FaceKey);

        // Vínculo antigo/ERP: FaceKey.
        if (!FaceKey.IsEmpty() &&
            SameText(Stored, FaceKey))
        {
            return true;
        }

        // Vínculo administrativo sem FaceKey:
        // ID + nome normalizado.
        return SameText(
            Stored,
            BuildRfidFallbackIdentityKey(Employee));
    }

    TColor RgbColor(int Red, int Green, int Blue)
    {
        return static_cast<TColor>(RGB(Red, Green, Blue));
    }

    int ClampInt(int Value, int MinValue, int MaxValue)
    {
        if (Value < MinValue)
        {
            return MinValue;
        }

        if (Value > MaxValue)
        {
            return MaxValue;
        }

        return Value;
    }

    TColor StatusColor(TIdentificationFactorStatus Status)
    {
        switch (Status)
        {
        case TIdentificationFactorStatus::Confirmed:
            return RgbColor(41, 214, 132);
        case TIdentificationFactorStatus::Detected:
            return RgbColor(79, 169, 255);
        case TIdentificationFactorStatus::Error:
            return RgbColor(255, 82, 96);
        default:
            return RgbColor(245, 190, 79);
        }
    }

    const char* FaceDistanceName(FaceDistance Distance)
    {
        switch (Distance)
        {
        case FaceDistance::TooFar:
            return "TooFar";
        case FaceDistance::Good:
            return "Good";
        case FaceDistance::TooClose:
            return "TooClose";
        default:
            return "NoFace";
        }
    }

    double CalculateFaceRatio(const FaceRect& Face, int FrameWidth, int FrameHeight)
    {
        if (Face.Empty() || FrameWidth <= 0 || FrameHeight <= 0)
        {
            return 0.0;
        }

        const double WidthRatio = static_cast<double>(Face.Width) / FrameWidth;
        const double HeightRatio = static_cast<double>(Face.Height) / FrameHeight;
        return std::max(WidthRatio, HeightRatio);
    }

    cv::Rect ToCvRect(const FaceRect& Face)
    {
        return cv::Rect(Face.X, Face.Y, Face.Width, Face.Height);
    }

    bool IsFaceNearFrameEdge(const cv::Rect& Face, int FrameWidth, int FrameHeight)
    {
        if (Face.width <= 0 || Face.height <= 0 || FrameWidth <= 0 || FrameHeight <= 0)
        {
            return false;
        }

        const int Margin = std::max(24, std::min(FrameWidth, FrameHeight) * 5 / 100);
        const bool NearLeft = Face.x <= Margin;
        const bool NearTop = Face.y <= Margin;
        const bool NearRight = Face.x + Face.width >= FrameWidth - Margin;
        const bool NearBottom = Face.y + Face.height >= FrameHeight - Margin;
        return NearLeft || NearTop || NearRight || NearBottom;
    }

    FaceDistance ClassifyFaceDistance(const FaceRect& Face, int FrameWidth,
        int FrameHeight, FaceDistance PreviousDistance)
    {
        if (Face.Empty() || FrameWidth <= 0 || FrameHeight <= 0)
        {
            return FaceDistance::NoFace;
        }

        const double FaceRatio = CalculateFaceRatio(Face, FrameWidth, FrameHeight);
        const bool NearEdge = IsFaceNearFrameEdge(ToCvRect(Face), FrameWidth, FrameHeight);

        // If the face is already classified as too close, do not leave this state
        // until it has clearly moved back into the acceptable region.
        if (PreviousDistance == FaceDistance::TooClose)
        {
            if (FaceRatio > TooCloseExitRatio || NearEdge)
            {
                return FaceDistance::TooClose;
            }
        }

        // If the face is already classified as too far, require it to become
        // visibly larger before considering the distance acceptable.
        if (PreviousDistance == FaceDistance::TooFar)
        {
            if (FaceRatio < TooFarExitRatio)
            {
                return FaceDistance::TooFar;
            }
        }

        // Enter the "too close" state.
        if (FaceRatio >= TooCloseEnterRatio ||
            (FaceRatio >= LargeFaceNearEdgeRatio && NearEdge))
        {
            return FaceDistance::TooClose;
        }

        // Enter the "too far" state.
        if (FaceRatio < TooFarEnterRatio)
        {
            return FaceDistance::TooFar;
        }

        return FaceDistance::Good;
    }

    bool CopyFrameToTopDownBgra(const TCameraFrame& SourceFrame, TCameraFrame& TargetFrame)
    {
        TargetFrame = TCameraFrame();
        if (SourceFrame.Empty() || SourceFrame.BytesPerPixel != 4)
        {
            return false;
        }

        const int SourceStride = SourceFrame.Stride == 0
            ? SourceFrame.Width * SourceFrame.BytesPerPixel
            : SourceFrame.Stride;
        const int AbsStride = std::abs(SourceStride);
        const int RowBytes = SourceFrame.Width * SourceFrame.BytesPerPixel;
        const unsigned char* SourceBase = SourceFrame.Data.data();

        if (static_cast<int>(SourceFrame.Data.size()) < AbsStride * SourceFrame.Height)
        {
            return false;
        }

        TargetFrame.Width = SourceFrame.Width;
        TargetFrame.Height = SourceFrame.Height;
        TargetFrame.Stride = RowBytes;
        TargetFrame.BytesPerPixel = SourceFrame.BytesPerPixel;
        TargetFrame.Data.resize(RowBytes * SourceFrame.Height);

        for (int Row = 0; Row < SourceFrame.Height; ++Row)
        {
            const int SourceRow = SourceStride < 0 ? (SourceFrame.Height - 1 - Row) : Row;
            const unsigned char* Source = SourceBase + (SourceRow * AbsStride);
            unsigned char* Target = TargetFrame.Data.data() + (Row * RowBytes);
            std::memcpy(Target, Source, RowBytes);
        }

        return true;
    }


    // v0.7.4.3 - frame leve exclusivo para detecção facial.
    // O preview e o reconhecimento continuam usando o frame original.
    bool BuildFaceDetectionFrame(
        const TCameraFrame& SourceFrame,
        TCameraFrame& DetectionFrame)
    {
        DetectionFrame = TCameraFrame();

        if (SourceFrame.Empty() ||
            SourceFrame.BytesPerPixel != 4)
        {
            return false;
        }

        const int MaxDetectionDimension = 640;
        const int SourceMax =
            std::max(SourceFrame.Width, SourceFrame.Height);

        if (SourceMax <= MaxDetectionDimension)
        {
            DetectionFrame = SourceFrame;
            return true;
        }

        const double Scale =
            static_cast<double>(MaxDetectionDimension) /
            static_cast<double>(SourceMax);

        const int TargetWidth =
            std::max(1,
                static_cast<int>(
                    std::lround(SourceFrame.Width * Scale)));

        const int TargetHeight =
            std::max(1,
                static_cast<int>(
                    std::lround(SourceFrame.Height * Scale)));

        DetectionFrame.Width = TargetWidth;
        DetectionFrame.Height = TargetHeight;
        DetectionFrame.BytesPerPixel = 4;
        DetectionFrame.Stride = TargetWidth * 4;
        DetectionFrame.Data.resize(
            static_cast<size_t>(DetectionFrame.Stride) *
            static_cast<size_t>(TargetHeight));

        for (int Y = 0; Y < TargetHeight; ++Y)
        {
            const int SourceY =
                std::min(
                    SourceFrame.Height - 1,
                    static_cast<int>(Y / Scale));

            const unsigned char* SourceRow =
                SourceFrame.Data.data() +
                static_cast<size_t>(SourceY) *
                static_cast<size_t>(SourceFrame.Stride);

            unsigned char* TargetRow =
                DetectionFrame.Data.data() +
                static_cast<size_t>(Y) *
                static_cast<size_t>(DetectionFrame.Stride);

            for (int X = 0; X < TargetWidth; ++X)
            {
                const int SourceX =
                    std::min(
                        SourceFrame.Width - 1,
                        static_cast<int>(X / Scale));

                std::memcpy(
                    TargetRow + (X * 4),
                    SourceRow + (SourceX * 4),
                    4);
            }
        }

        return true;
    }

    void ScaleFaceRect(
        FaceRect& Rect,
        double ScaleX,
        double ScaleY)
    {
        Rect.X =
            static_cast<int>(std::lround(Rect.X * ScaleX));
        Rect.Y =
            static_cast<int>(std::lround(Rect.Y * ScaleY));
        Rect.Width =
            static_cast<int>(std::lround(Rect.Width * ScaleX));
        Rect.Height =
            static_cast<int>(std::lround(Rect.Height * ScaleY));
    }

    void ScaleFacePoint(
        FacePoint& Point,
        double ScaleX,
        double ScaleY)
    {
        Point.X =
            static_cast<float>(Point.X * ScaleX);
        Point.Y =
            static_cast<float>(Point.Y * ScaleY);
    }

    void ScaleDetectionsToDisplay(
        std::vector<FaceDetection>& Detections,
        int DetectionWidth,
        int DetectionHeight,
        int DisplayWidth,
        int DisplayHeight)
    {
        if (DetectionWidth <= 0 ||
            DetectionHeight <= 0 ||
            (DetectionWidth == DisplayWidth &&
             DetectionHeight == DisplayHeight))
        {
            return;
        }

        const double ScaleX =
            static_cast<double>(DisplayWidth) /
            static_cast<double>(DetectionWidth);

        const double ScaleY =
            static_cast<double>(DisplayHeight) /
            static_cast<double>(DetectionHeight);

        for (FaceDetection& Detection : Detections)
        {
            ScaleFaceRect(Detection.DetectionBounds, ScaleX, ScaleY);
            ScaleFaceRect(Detection.RecognitionBounds, ScaleX, ScaleY);
            ScaleFaceRect(Detection.Bounds, ScaleX, ScaleY);
            ScaleFacePoint(Detection.RightEye, ScaleX, ScaleY);
            ScaleFacePoint(Detection.LeftEye, ScaleX, ScaleY);
            ScaleFacePoint(Detection.Nose, ScaleX, ScaleY);
            ScaleFacePoint(Detection.RightMouth, ScaleX, ScaleY);
            ScaleFacePoint(Detection.LeftMouth, ScaleX, ScaleY);
        }
    }
    bool RotateBgraFrame(const TCameraFrame& SourceFrame,
        TCameraFrame& TargetFrame, TCameraRotationMode Rotation)
    {
        if (SourceFrame.Empty() || SourceFrame.BytesPerPixel != 4)
        {
            return false;
        }

        if (Rotation == TCameraRotationMode::Deg0)
        {
            TargetFrame = SourceFrame;
            return true;
        }

        const int SourceStride = SourceFrame.Stride == 0
            ? SourceFrame.Width * 4
            : SourceFrame.Stride;

        if (SourceStride <= 0)
        {
            return false;
        }

        if (Rotation == TCameraRotationMode::Deg180)
        {
            TargetFrame = TCameraFrame();
            TargetFrame.Width = SourceFrame.Width;
            TargetFrame.Height = SourceFrame.Height;
            TargetFrame.BytesPerPixel = 4;
            TargetFrame.Stride = TargetFrame.Width * 4;
            TargetFrame.Data.resize(
                static_cast<size_t>(TargetFrame.Stride) * TargetFrame.Height);

            for (int Y = 0; Y < SourceFrame.Height; ++Y)
            {
                for (int X = 0; X < SourceFrame.Width; ++X)
                {
                    const unsigned char* Src =
                        SourceFrame.Data.data() + (Y * SourceStride) + (X * 4);
                    const int DX = SourceFrame.Width - 1 - X;
                    const int DY = SourceFrame.Height - 1 - Y;
                    unsigned char* Dst =
                        TargetFrame.Data.data() +
                        (DY * TargetFrame.Stride) + (DX * 4);
                    std::memcpy(Dst, Src, 4);
                }
            }
            return true;
        }

        TargetFrame = TCameraFrame();
        TargetFrame.Width = SourceFrame.Height;
        TargetFrame.Height = SourceFrame.Width;
        TargetFrame.BytesPerPixel = 4;
        TargetFrame.Stride = TargetFrame.Width * 4;
        TargetFrame.Data.resize(
            static_cast<size_t>(TargetFrame.Stride) * TargetFrame.Height);

        for (int Y = 0; Y < SourceFrame.Height; ++Y)
        {
            for (int X = 0; X < SourceFrame.Width; ++X)
            {
                int DX = 0;
                int DY = 0;

                if (Rotation == TCameraRotationMode::Deg90CW)
                {
                    DX = SourceFrame.Height - 1 - Y;
                    DY = X;
                }
                else
                {
                    DX = Y;
                    DY = SourceFrame.Width - 1 - X;
                }

                const unsigned char* Src =
                    SourceFrame.Data.data() + (Y * SourceStride) + (X * 4);
                unsigned char* Dst =
                    TargetFrame.Data.data() +
                    (DY * TargetFrame.Stride) + (DX * 4);
                std::memcpy(Dst, Src, 4);
            }
        }

        return true;
    }

    bool FrameToBitmap(const TCameraFrame& Frame, Graphics::TBitmap* Bitmap)
    {
        if (Frame.Empty() || Bitmap == nullptr || Frame.BytesPerPixel != 4)
        {
            return false;
        }

        Bitmap->PixelFormat = pf32bit;
        Bitmap->SetSize(Frame.Width, Frame.Height);

        const int SourceStride = Frame.Stride == 0
            ? Frame.Width * Frame.BytesPerPixel
            : Frame.Stride;
        const int AbsStride = std::abs(SourceStride);
        const int RowBytes = Frame.Width * Frame.BytesPerPixel;
        const unsigned char* SourceBase = Frame.Data.data();

        if (static_cast<int>(Frame.Data.size()) < AbsStride * Frame.Height)
        {
            return false;
        }

        for (int Row = 0; Row < Frame.Height; ++Row)
        {
            const int SourceRow = SourceStride < 0 ? (Frame.Height - 1 - Row) : Row;
            const unsigned char* Source = SourceBase + (SourceRow * AbsStride);
            unsigned char* Target = static_cast<unsigned char*>(Bitmap->ScanLine[Row]);
            std::memcpy(Target, Source, RowBytes);
        }

        return true;
    }
}

__fastcall TMainForm::TMainForm(TComponent* Owner)
    : TForm(Owner),
      FCurrentPage(TAccessPage::Identification),
      FFacePreviewState(TFacePreviewState::Waiting),
      FIdentificationState(IdentificationState::WaitingForFace),
      FFaceQualityIssue(TFaceQualityIssue::None),
      FCameraPreviewImage(nullptr),
      FCameraPreviewTimer(nullptr),
      FCameraSelectorLabel(nullptr),
      FCameraSelector(nullptr),
      FCameraSettingsPreview(nullptr),

      FSettingsErpCard(nullptr),
      FSettingsDataCard(nullptr),
      FSettingsTerminalCard(nullptr),

      FSettingsErpTitle(nullptr),
      FSettingsErpStatus(nullptr),
      FSettingsErpInfo(nullptr),
      FSettingsApiEdit(nullptr),
      FSettingsTestErpButton(nullptr),

      FSettingsDataTitle(nullptr),
      FSettingsEmployeeDbStatus(nullptr),
      FSettingsEmployeeDbPath(nullptr),
      FSettingsAccessDbStatus(nullptr),
      FSettingsAccessDbPath(nullptr),
      FSettingsSelectDbButton(nullptr),

      FSettingsTerminalTitle(nullptr),
      FSettingsTerminalStatus(nullptr),
      FSettingsTerminalEdit(nullptr),
      FSettingsSaveTerminalButton(nullptr),
	  FSettingsDiagnosticButton(nullptr),
      FIdleLottie(nullptr),
      FTechBackground(nullptr),
      FHeaderDecor(nullptr),
      FCameraDecor(nullptr),
      FFooterDecor(nullptr),
      FBrandSubtitle(nullptr),
      FTerminalStatusCard(nullptr),
      FTerminalStatusTitle(nullptr),
      FProductVersion(nullptr),
      FCameraModeBadge(nullptr),
      FIdleVisual(nullptr),
      FIdleVisualTimer(nullptr),
      FIdleVisualPhase(0),
      FRfidPollTimer(nullptr),
      FLastRfidState(TRfidVisualState::Idle),
      FRfidReaderCard(nullptr),
      FRfidReaderTitle(nullptr),
      FRfidReaderStatus(nullptr),
      FRfidReaderUid(nullptr),

      FCameraPreviewBitmap(nullptr),
      FEmployeePhotoImage(nullptr),
      FEmployeePhotoBitmap(nullptr),
      FRecognitionCheckShape(nullptr),
      FRecognitionCheckLabel(nullptr),
      FFaceRecognitionLocked(false),
      FRecognizedEmployeeId(0),
      FPreviewFrameCounter(0),
      FPreviewCameraIndex(0),
      FCameraListInitialized(false),
      FFaceHitFrames(0),
      FFaceMissFrames(0),
      FSingleFaceFrames(0),
      FMultipleFaceFrames(0),
      FFaceDetectionInterval(FaceDetectionIntervalFrames),
      FDetectionFramesThisSecond(0),
      FLastDetectionMetricTick(0),
      FMeasuredDetectionsPerSecond(0.0),
      FHasCurrentFaceBounds(false),
      FHasSmoothedFaceDetection(false),
      FLastRecognitionAttemptTick(0),
      FRecognitionCandidateId(0),
      FRecognitionCandidateHits(0),
      FLastCorrectTestScore(-1.0),
      FLastUnknownTestScore(-1.0),
      FLastRecognitionDurationMs(0.0),
      FEnrollmentActive(false),
      FIncidentHistoryMode(false),
      FEnrollmentEmployeeId(0),
      FPrimaryFaceDetection(),
      FHasPrimaryFace(false),
      FHasMultipleOperationalFaces(false),
      FStableFaceStartTick(0),
      FLastFaceSeenTick(0),
      FNoFaceSinceTick(0),
      FHadRecentFace(false),
      FLastDistance(FaceDistance::NoFace),
      FPreviousDistance(FaceDistance::NoFace),
      FLastFaceBounds(),
      FLastFaceTime(),
      FLastFaceRatio(0.0),
      FPreviousFaceRatio(0.0),
      FLayoutMode(TTerminalLayoutMode::Auto),
      FCameraRotationMode(TCameraRotationMode::Auto),
      FEmployeeSyncStateInitialized(false),
      FLastEmployeeSyncOnline(false),
      FLastEmployeeSyncCount(-1)
{
    InitializeManagers();
    ConfigureRuntimeView();
    InitializeRfidAdminReader();
    UpdateClock();
    RefreshIdentificationView();
    LayoutTerminal();
    InitializeRfidSerial();

    // =========================================================
    // OBSERVABILITY - HEARTBEAT DA PORTARIA
    // =========================================================
    FObservabilityHeartbeat =
        std::make_unique<TObservabilityHeartbeat>();

    FObservabilityHeartbeat->SetServerUrl(
        L"http://127.0.0.1:8080");

    FObservabilityHeartbeat->SetSource(
        L"PORTARIA-01");

    FObservabilityHeartbeat->SetVersion(
        L"1.0.0");

    FObservabilityHeartbeat->UpdateRuntimeStatus(
        FCameraManager != nullptr &&
        FCameraManager->IsOpen(),

        FFaceDetector != nullptr &&
        FFaceDetector->IsInitialized());

    FObservabilityHeartbeat->Start();
}

__fastcall TMainForm::~TMainForm()
{
    if (FRfidPollTimer != nullptr)
        FRfidPollTimer->Enabled = false;

    if (FRfidSerialReader != nullptr)
        FRfidSerialReader->Stop();

    StopCameraPreview();
    delete FCameraPreviewBitmap;
    FCameraPreviewBitmap = nullptr;

    delete FEmployeePhotoBitmap;
    FEmployeePhotoBitmap = nullptr;
}

void TMainForm::InitializeManagers()
{
    FConfig = TAppConfig::Default();
    LoadPersistedSettings();

    FCameraManager = std::make_unique<TCameraManager>();
    FBleManager = std::make_unique<TBleManager>();

    FAccessEventRepository =
        std::make_unique<TAccessEventRepository>(FConfig.AccessDatabasePath);
    FAccessEventRepository->Initialize();

    FEmployeeRepository = std::make_unique<TEmployeeRepository>(FConfig.DatabasePath);
    FIntegrationClient = std::make_unique<TIntegrationClient>(FConfig.ApiUrl);
    FIdentificationManager = std::make_unique<TIdentificationManager>(
        *FEmployeeRepository, *FIntegrationClient, FConfig);

    // v0.6.3 - ERP Delphi é a fonte oficial dos funcionários.
    FEmployeeSyncClient =
        std::make_unique<TEmployeeSyncClient>(
            FEmployeeRepository.get(),
            FConfig.ApiUrl);
    FEmployeeSyncClient->Start();

    FFaceDetector = std::make_unique<FaceDetector>();
    FFaceDetector->Initialize();

    FFaceRecognizer = std::make_unique<FaceRecognizer>();
    FFaceRecognizer->Initialize(ToStdString(FConfig.FaceRecognitionModelPath),
        ToStdString(FConfig.FaceLandmarkModelPath));

    FFaceRepository = std::make_unique<FaceRepository>(FConfig.FaceDataPath);
    FLivenessDetector = std::make_unique<LivenessDetector>(LivenessMode::Prototype);
}


void TMainForm::InitializeRfidAdminReader()
{
    if (FRfidReaderCard != nullptr || DeveloperPanel == nullptr)
        return;

    FRfidReaderCard = new TPanel(this);
    FRfidReaderCard->Parent = DeveloperPanel;
    FRfidReaderCard->Align = alNone;
    FRfidReaderCard->BevelOuter = bvNone;
    FRfidReaderCard->ParentBackground = false;
    FRfidReaderCard->Color = RgbColor(7, 19, 30);
    FRfidReaderCard->Visible = false;

    FRfidReaderTitle = new TLabel(this);
    FRfidReaderTitle->Parent = FRfidReaderCard;
    FRfidReaderTitle->AutoSize = false;
    FRfidReaderTitle->Caption = L"LEITOR DE TAG RFID";
    FRfidReaderTitle->Font->Name = L"Segoe UI Semibold";
    FRfidReaderTitle->Font->Size = 9;
    FRfidReaderTitle->Font->Color = RgbColor(220, 230, 240);
    FRfidReaderTitle->Transparent = true;

    FRfidReaderStatus = new TLabel(this);
    FRfidReaderStatus->Parent = FRfidReaderCard;
    FRfidReaderStatus->AutoSize = false;
    FRfidReaderStatus->Alignment = taRightJustify;
    FRfidReaderStatus->Font->Name = L"Segoe UI Semibold";
    FRfidReaderStatus->Font->Size = 9;
    FRfidReaderStatus->Transparent = true;

    FRfidReaderUid = new TLabel(this);
    FRfidReaderUid->Parent = FRfidReaderCard;
    FRfidReaderUid->AutoSize = false;
    FRfidReaderUid->Font->Name = L"Consolas";
    FRfidReaderUid->Font->Size = 11;
    FRfidReaderUid->Font->Color = RgbColor(101, 190, 255);
    FRfidReaderUid->Transparent = true;

    UpdateRfidAdminReader();
}

void TMainForm::UpdateRfidAdminReader()
{
    if (FRfidReaderCard == nullptr)
        return;

    const bool Visible =
        FCurrentPage == TAccessPage::BleDevices;

    FRfidReaderCard->Visible = Visible;

    if (!Visible)
        return;

    const bool PortOpen =
        FRfidSerialReader != nullptr &&
        FRfidSerialReader->IsPortOpen();

    const bool Ready =
        PortOpen &&
        FRfidSerialReader->IsDeviceReady();

    if (!PortOpen)
    {
        FRfidReaderStatus->Caption = L"● OFFLINE • COM5";
        FRfidReaderStatus->Font->Color = RgbColor(255, 82, 96);
    }
    else if (!Ready)
    {
        FRfidReaderStatus->Caption = L"● INICIALIZANDO / RECUPERANDO • COM5";
        FRfidReaderStatus->Font->Color = RgbColor(245, 190, 79);
    }
    else
    {
        FRfidReaderStatus->Caption = L"● ONLINE • COM5";
        FRfidReaderStatus->Font->Color = RgbColor(41, 214, 132);
    }

    if (FRfidAdminUid.IsEmpty())
    {
        FRfidReaderUid->Caption =
            L"UID: --   •   Aproxime um cartão ou chaveiro do leitor";
        FRfidReaderUid->Font->Color = RgbColor(164, 176, 194);

        if (BtnSimulate != nullptr)
            BtnSimulate->Caption = L"CADASTRAR TAG RFID";
    }
    else
    {
        FRfidReaderUid->Caption =
            L"UID: " + FRfidAdminUid +
            L"   •   TAG capturada — selecione o funcionário e vincule";
        FRfidReaderUid->Font->Color = RgbColor(101, 190, 255);

        if (BtnSimulate != nullptr)
            BtnSimulate->Caption = L"VINCULAR TAG LIDA";
    }
}

void TMainForm::InitializeRfidSerial()
{
    FRfidSerialReader = std::make_unique<TRfidSerialReader>();

    // ETAPA 2:
    // COM5 foi validada fisicamente com o ESP32-S3.
    // Depois desta prova ponta a ponta a porta será movida para Configurações.
    FRfidSerialReader->Start(L"COM5", 115200);

    FRfidPollTimer = new TTimer(this);
    FRfidPollTimer->Enabled = false;
    // Firmware 0.4.0 entrega o UID imediatamente. O polling da VCL em 20 ms
    // reduz a latencia percebida na portaria sem bloquear a camera.
    FRfidPollTimer->Interval = 20;
    FRfidPollTimer->OnTimer = RfidPollTimerTimer;
    FRfidPollTimer->Enabled = true;

    ApplyRfidStatus();
}

void __fastcall TMainForm::RfidPollTimerTimer(TObject* Sender)
{
    (void)Sender;

    if (FRfidSerialReader == nullptr)
    {
        ApplyRfidStatus();
        return;
    }

    UnicodeString RawUid;

    while (FRfidSerialReader->TryPopTag(RawUid))
    {
        const UnicodeString Uid = NormalizeRfidUid(RawUid);

        if (!IsValidRfidUid(Uid))
        {
            OutputDebugStringW(
                (L"[RFID][PORTARIA] UID inválido recebido: " +
                 RawUid + L"\r\n").c_str());
            continue;
        }

        FLastRfidUid = Uid;
        FLastRfidState = TRfidVisualState::TagRead;

        OutputDebugStringW(
            (L"[RFID][PORTARIA] TAG recebida via USB Serial: " +
             Uid + L"\r\n").c_str());

        // v0.4:
        // Na tela principal a TAG física já é um fator de acesso independente.
        // Na tela administrativa continuamos apenas exibindo o UID recebido,
        // para que o operador possa cadastrar/remover vínculos.
        if (FCurrentPage == TAccessPage::Identification)
        {
            ProcessRfidIdentification(Uid);
        }
        else if (FCurrentPage == TAccessPage::BleDevices)
        {
            // Na área administrativa a leitura é capturada para vínculo,
            // sem executar a liberação de acesso da tela principal.
            FRfidAdminUid = Uid;

            if (LblDeveloperStatus != nullptr)
            {
                LblDeveloperStatus->Caption =
                    L"TAG capturada pelo leitor • UID " + Uid +
                    L" • selecione o funcionário para vincular";
            }

            UpdateRfidAdminReader();
        }
    }

    ApplyRfidStatus();
    UpdateRfidAdminReader();
}

void TMainForm::ApplyRfidStatus()
{
    if (LblBleIndicator == nullptr ||
        LblBleStatusDetail == nullptr)
    {
        return;
    }

    LblBleIndicator->Caption = L"RFID";
    LblBleIndicator->Font->Color = RgbColor(164, 176, 194);

    if (FRfidSerialReader == nullptr ||
        !FRfidSerialReader->IsPortOpen())
    {
        LblBleStatusDetail->Caption = L"● COM5 offline";
        LblBleStatusDetail->Font->Color = RgbColor(255, 82, 96);
        return;
    }

    // v0.4.4.1:
    // O UID recebido não é, por si só, um resultado positivo.
    // Mantemos o estado semântico da última leitura para que uma TAG
    // desconhecida não seja exibida em verde apenas por ter sido lida.
    if (!FLastRfidUid.IsEmpty())
    {
        switch (FLastRfidState)
        {
            case TRfidVisualState::Authorized:
                LblBleStatusDetail->Caption =
                    L"● AUTORIZADA • " + FLastRfidUid;
                LblBleStatusDetail->Font->Color =
                    RgbColor(41, 214, 132);
                return;

            case TRfidVisualState::UnknownTag:
                LblBleStatusDetail->Caption =
                    L"● NÃO CADASTRADA • " + FLastRfidUid;
                LblBleStatusDetail->Font->Color =
                    RgbColor(245, 190, 79);
                return;

            case TRfidVisualState::Denied:
                LblBleStatusDetail->Caption =
                    L"● ACESSO NEGADO • " + FLastRfidUid;
                LblBleStatusDetail->Font->Color =
                    RgbColor(220, 72, 82);
                return;

            case TRfidVisualState::InvalidLink:
                LblBleStatusDetail->Caption =
                    L"● VÍNCULO INVÁLIDO • " + FLastRfidUid;
                LblBleStatusDetail->Font->Color =
                    RgbColor(220, 72, 82);
                return;

            case TRfidVisualState::TagRead:
                LblBleStatusDetail->Caption =
                    L"● TAG " + FLastRfidUid;
                LblBleStatusDetail->Font->Color =
                    RgbColor(41, 214, 132);
                return;

            case TRfidVisualState::Idle:
            default:
                break;
        }
    }

    if (FRfidSerialReader->IsDeviceReady())
    {
        LblBleStatusDetail->Caption = L"● Leitor ONLINE";
        LblBleStatusDetail->Font->Color = RgbColor(41, 214, 132);
        return;
    }

    LblBleStatusDetail->Caption = L"● RFID inicializando / recuperando";
    LblBleStatusDetail->Font->Color = RgbColor(245, 190, 79);
}

void TMainForm::ConfigureRuntimeView()
{
    // Paleta empresarial: preto grafite + azul petróleo + estados fortes.
    // A estrutura segue a lógica visual de um terminal de acesso dedicado,
    // sem copiar marca/identidade visual de terceiros.
    const TColor BackgroundColor = RgbColor(7, 12, 18);
    const TColor HeaderColor = RgbColor(4, 8, 13);
    const TColor CardColor = RgbColor(12, 23, 34);
    const TColor SubtleTextColor = RgbColor(170, 181, 194);
    const TColor OnlineColor = RgbColor(34, 211, 137);

    Caption = L"EmployeeAccess";
    Position = poScreenCenter;
    ConfigureCaptions();

    // Reduz flicker da VCL durante atualização contínua da webcam.
    DoubleBuffered = true;
    RootPanel->DoubleBuffered = true;
    CameraPanel->DoubleBuffered = true;
    BottomStatusPanel->DoubleBuffered = true;
    EmployeeResultPanel->DoubleBuffered = true;

    RootPanel->Color = BackgroundColor;
    TopBarPanel->Color = HeaderColor;
    ClockPanel->Color = BackgroundColor;
    PageHost->Color = BackgroundColor;
    IdentificationView->Color = BackgroundColor;
    BottomStatusPanel->Color = BackgroundColor;
    CameraPanel->Color = CardColor;
    FaceStatusCard->Color = CardColor;
    BleStatusCard->Color = CardColor;
    MenuCenterPanel->Color = BackgroundColor;
    // Botão principal inspirado em terminais corporativos de acesso:
    // vermelho como ação de menu, com hover mais luminoso.
    BtnMenu->Color = RgbColor(198, 32, 42);
    BtnMenu->OnMouseEnter = MenuHoverEnter;
    BtnMenu->OnMouseLeave = MenuHoverLeave;

    TopBarPanel->Height = 72;
    ClockPanel->Height = 150;

    const bool ShowRecognizedCard =
        EmployeeResultPanel != nullptr && EmployeeResultPanel->Visible;
    BottomStatusPanel->Height = ShowRecognizedCard ? 340 : 210;

    LblAppName->Font->Name = L"Segoe UI Semibold";
    LblAppName->Font->Size = 16;
    LblTerminal->Font->Name = L"Segoe UI Semibold";
    LblTerminal->Font->Size = 11;
    LblTerminal->Font->Color = SubtleTextColor;
    LblOnline->Font->Name = L"Segoe UI Semibold";
	LblOnline->Font->Size = 10;
    LblOnline->Font->Color = OnlineColor;

    LblClock->Font->Name = L"Segoe UI Light";
    LblClock->Font->Size = 44;
    LblDate->Font->Name = L"Segoe UI";
    LblDate->Font->Size = 13;
    LblDate->Font->Color = SubtleTextColor;

    LblPrompt->Font->Name = L"Segoe UI Semibold";
    LblPrompt->Font->Size = 18;
    LblCameraStatus->Font->Name = L"Segoe UI";
    LblCameraStatus->Font->Size = 10;
    LblCameraStatus->Font->Color = SubtleTextColor;

    // O resultado facial não deve cobrir a webcam. O card é reaproveitado
    // como um resumo compacto abaixo da câmera.
    EmployeeResultPanel->Parent = BottomStatusPanel;
    EmployeeResultPanel->Color = CardColor;
    EmployeeResultPanel->BevelOuter = bvNone;
    EmployeeResultPanel->Visible = false;

    PhotoPanel->Color = RgbColor(22, 36, 52);
    PhotoPanel->BevelOuter = bvNone;

    if (FEmployeePhotoImage == nullptr)
    {
        FEmployeePhotoImage = new TImage(PhotoPanel);
        FEmployeePhotoImage->Parent = PhotoPanel;
        FEmployeePhotoImage->Align = alClient;
        FEmployeePhotoImage->Stretch = true;
        FEmployeePhotoImage->Proportional = true;
        FEmployeePhotoImage->Center = true;
        FEmployeePhotoImage->Visible = false;
    }

    if (FEmployeePhotoBitmap == nullptr)
    {
        FEmployeePhotoBitmap = new Graphics::TBitmap();
    }

    LblPhoto->Visible = true;
    LblPhoto->Caption = L"FOTO";
    LblEmployeeState->Caption = L"FUNCIONÁRIO RECONHECIDO";

    // Badge de confirmação sobre a área da câmera.
    if (FRecognitionCheckShape == nullptr)
    {
        FRecognitionCheckShape = new TShape(CameraPanel);
        FRecognitionCheckShape->Parent = CameraPanel;
        FRecognitionCheckShape->Shape = stCircle;
        FRecognitionCheckShape->Brush->Color = RgbColor(34, 211, 137);
        FRecognitionCheckShape->Pen->Style = psClear;
        FRecognitionCheckShape->Visible = false;
    }

    if (FRecognitionCheckLabel == nullptr)
    {
        FRecognitionCheckLabel = new TLabel(CameraPanel);
        FRecognitionCheckLabel->Parent = CameraPanel;
        FRecognitionCheckLabel->AutoSize = false;
        FRecognitionCheckLabel->Transparent = true;
        FRecognitionCheckLabel->Alignment = taCenter;
        FRecognitionCheckLabel->Layout = tlCenter;
        FRecognitionCheckLabel->Font->Name = L"Segoe UI Semibold";
        FRecognitionCheckLabel->Font->Size = 16;
        FRecognitionCheckLabel->Font->Color = clWhite;
        FRecognitionCheckLabel->Caption = L"✓";
        FRecognitionCheckLabel->Visible = false;
    }

    InitializeTechBackground();
    InitializeCorporateDecor();
    InitializeIdleVisual();
    InitializeCameraPreview();
	InitializeIdleAnimation();
	InitializeCameraSelector();
	InitializeSettingsControls();
    ReturnTimer->Enabled = false;
    ClockTimer->Enabled = true;
    ShowPage(TAccessPage::Identification);
    StartCameraPreview();
}

void TMainForm::ConfigureCaptions()
{
    LblTerminal->Caption = TerminalDisplayName();
    LblOnline->Caption = L"● ONLINE";
    LblMenuFooter->Caption =
        TerminalDisplayName() + L" | Versão 1.0.0";
    LblMenuHeader->Caption = L"Operações da portaria";
    BtnMenu->Caption = L"MENU";
    LblMenuHint->Caption = L"Opções da portaria";
    BtnBackFromPage->Caption = L"VOLTAR PARA IDENTIFICAÇÃO";
	BtnMenuBack->Caption = L"FECHAR MENU -->";


    LblMenuIdentificationTitle->Caption = L"Identificação";
    LblMenuIdentificationDesc->Caption = L"Tela principal de identificação";
    LblMenuPresentTitle->Caption = L"Funcionários presentes";
    LblMenuPresentDesc->Caption = L"Pessoas presentes na empresa";
    LblMenuRecentTitle->Caption = L"Últimas entradas";
    LblMenuRecentDesc->Caption = L"Eventos recentes do terminal";
    LblMenuCameraTitle->Caption = L"Câmera";
    LblMenuCameraDesc->Caption = L"Configuração e teste de vídeo";
    LblMenuBleTitle->Caption = L"TAG RFID";
    LblMenuBleDesc->Caption = L"Cadastro de chaveiros e cartões RFID";
    LblMenuManualTitle->Caption = L"Liberação manual";
    LblMenuManualDesc->Caption = L"Liberação assistida pelo porteiro";
    LblMenuOccurrencesTitle->Caption = L"Ocorrências";
    LblMenuOccurrencesDesc->Caption = L"Eventos e problemas de acesso";
    LblMenuSettingsTitle->Caption = L"Configurações";
    LblMenuSettingsDesc->Caption = L"Terminal, API e parâmetros";

    // v0.4.3.1 - o estado de espera já aparece no card FACE.
    // Mantemos os overlays centrais vazios para impedir qualquer
    // piscada de "APROXIME-SE" durante alternância rápida dos estados
    // do detector entre frames.
    LblFaceGlyph->Caption = L"";
    LblCameraPlaceholder->Caption = L"";
    LblFaceGlyph->Visible = false;
    LblCameraPlaceholder->Visible = false;

    LblPrompt->Caption = L"Aproxime-se para identificação";
    LblFaceIndicator->Caption = L"FACE";
    LblFaceStatusDetail->Caption = L"● Aguardando";
    LblBleIndicator->Caption = L"RFID";
    LblBleStatusDetail->Caption = L"● Conectando...";
    LblCameraStatus->Caption = L"● Câmera aguardando inicialização";
    LblDeveloperStatus->Caption = L"Selecione um funcionário e cadastre a identificação facial.";
    BtnStartCamera->Caption = L"Iniciar câmera";
    BtnSimulate->Caption = L"Cadastrar identificação facial";
    BtnClear->Caption = L"Atualizar funcionários";
}


void TMainForm::InitializeTechBackground()
{
    if (FTechBackground != nullptr)
    {
        return;
    }

    FTechBackground = new TPaintBox(IdentificationView);
    FTechBackground->Parent = IdentificationView;
    FTechBackground->Align = alClient;
    FTechBackground->Enabled = false;
    FTechBackground->OnPaint = TechBackgroundPaint;
    FTechBackground->SendToBack();
}

void __fastcall TMainForm::TechBackgroundPaint(TObject* Sender)
{
    (void)Sender;

    if (FTechBackground == nullptr)
    {
        return;
    }

    TCanvas* C = FTechBackground->Canvas;
    const int W = FTechBackground->ClientWidth;
    const int H = FTechBackground->ClientHeight;

    C->Brush->Style = bsSolid;
    C->Brush->Color = RgbColor(3, 10, 18);
    C->FillRect(TRect(0, 0, W, H));

    // Grade técnica muito discreta.
    C->Pen->Style = psSolid;
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(7, 27, 43);

    const int Grid = 72;
    for (int X = 0; X < W; X += Grid)
    {
        C->MoveTo(X, 0);
        C->LineTo(X, H);
    }

    for (int Y = 0; Y < H; Y += Grid)
    {
        C->MoveTo(0, Y);
        C->LineTo(W, Y);
    }

    // Linhas laterais em perspectiva, mantendo o centro limpo.
    C->Pen->Color = RgbColor(9, 55, 88);

    const int CenterY = H / 2;
    for (int I = 0; I < 5; ++I)
    {
        const int Offset = I * 34;

        C->MoveTo(0, CenterY - 170 + Offset);
        C->LineTo(W / 5, CenterY - 70 + Offset / 2);

        C->MoveTo(W, CenterY - 170 + Offset);
        C->LineTo(W - (W / 5), CenterY - 70 + Offset / 2);
    }

    // Pequenos pontos tecnológicos nas laterais.
    C->Pen->Style = psClear;
    C->Brush->Style = bsSolid;
    C->Brush->Color = RgbColor(16, 92, 145);

    for (int I = 0; I < 7; ++I)
    {
        const int Y = 80 + (I * 74);

        C->Ellipse(26, Y, 30, Y + 4);
        C->Ellipse(W - 30, Y + 22, W - 26, Y + 26);
    }

    // Linha de energia horizontal muito sutil.
    C->Pen->Style = psSolid;
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(11, 72, 115);

    C->MoveTo(W / 16, CenterY);
    C->LineTo(W / 4, CenterY);

    C->MoveTo((W * 3) / 4, CenterY);
    C->LineTo((W * 15) / 16, CenterY);

    // Circuitos angulares nas extremidades superiores/inferiores.
    C->Pen->Color = RgbColor(8, 44, 72);
    C->Pen->Width = 1;

    C->MoveTo(0, 28);
    C->LineTo(W / 8, 28);
    C->LineTo(W / 8 + 28, 56);
    C->LineTo(W / 5, 56);

    C->MoveTo(W, H - 36);
    C->LineTo((W * 7) / 8, H - 36);
    C->LineTo((W * 7) / 8 - 28, H - 64);
    C->LineTo((W * 4) / 5, H - 64);

    // Pequenos nós luminosos.
    C->Pen->Style = psClear;
    C->Brush->Color = RgbColor(20, 112, 174);
    for (int I = 0; I < 5; ++I)
    {
        const int X1 = 70 + (I * 90);
        const int X2 = W - 74 - (I * 88);
        C->Ellipse(X1, 40 + I * 16, X1 + 3, 43 + I * 16);
        C->Ellipse(X2, H - 70 - I * 15, X2 + 3, H - 67 - I * 15);
    }
}


void TMainForm::InitializeCorporateDecor()
{
    if (FHeaderDecor == nullptr)
    {
        FHeaderDecor = new TPaintBox(TopBarPanel);
        FHeaderDecor->Parent = TopBarPanel;
        FHeaderDecor->Align = alClient;
        FHeaderDecor->Enabled = false;
        FHeaderDecor->OnPaint = HeaderDecorPaint;
        FHeaderDecor->SendToBack();
    }

    if (FCameraDecor == nullptr)
    {
        FCameraDecor = new TPaintBox(CameraPanel);
        FCameraDecor->Parent = CameraPanel;
        FCameraDecor->Align = alClient;
        FCameraDecor->Enabled = false;
        FCameraDecor->OnPaint = CameraDecorPaint;
        FCameraDecor->SendToBack();
    }

    if (FFooterDecor == nullptr)
    {
        FFooterDecor = new TPaintBox(MenuCenterPanel);
        FFooterDecor->Parent = MenuCenterPanel;
        FFooterDecor->Align = alClient;
        FFooterDecor->Enabled = false;
        FFooterDecor->OnPaint = FooterDecorPaint;
        FFooterDecor->SendToBack();
    }

    if (FBrandSubtitle == nullptr)
    {
        FBrandSubtitle = new TLabel(TopBarPanel);
        FBrandSubtitle->Parent = TopBarPanel;
        FBrandSubtitle->AutoSize = false;
        FBrandSubtitle->Transparent = true;
        FBrandSubtitle->Caption = L"IDENTIFICA  •  AUTENTICA  •  INTEGRA";
        FBrandSubtitle->Font->Name = L"Segoe UI";
        FBrandSubtitle->Font->Size = 7;
        FBrandSubtitle->Font->Color = RgbColor(108, 144, 177);
        FBrandSubtitle->Alignment = taLeftJustify;
    }

    if (FTerminalStatusTitle == nullptr)
    {
        FTerminalStatusTitle = new TLabel(FTerminalStatusCard);
        FTerminalStatusTitle->Parent = FTerminalStatusCard;
        FTerminalStatusTitle->AutoSize = false;
        FTerminalStatusTitle->Transparent = true;
        FTerminalStatusTitle->Caption = L"TERMINAL";
        FTerminalStatusTitle->Font->Name = L"Segoe UI Semibold";
        FTerminalStatusTitle->Font->Size = 8;
        FTerminalStatusTitle->Font->Color = RgbColor(132, 160, 187);
        FTerminalStatusTitle->Alignment = taCenter;
    }

    if (FProductVersion == nullptr)
    {
        FProductVersion = new TLabel(MenuCenterPanel);
        FProductVersion->Parent = MenuCenterPanel;
        FProductVersion->AutoSize = false;
		FProductVersion->Transparent = true;
		FProductVersion->Caption = L"Portaria  •  C++ TERMINAL  •  v1.0.0";
        FProductVersion->Font->Name = L"Segoe UI";
        FProductVersion->Font->Size = 7;
        FProductVersion->Font->Color = RgbColor(128, 154, 178);
        FProductVersion->Alignment = taCenter;
    }

    if (FCameraModeBadge == nullptr)
    {
        FCameraModeBadge = new TLabel(CameraPanel);
        FCameraModeBadge->Parent = CameraPanel;
        FCameraModeBadge->AutoSize = false;
        FCameraModeBadge->Transparent = true;
        FCameraModeBadge->Caption = L"IDENTIFICAÇÃO FACIAL  •  LIVE";
        FCameraModeBadge->Font->Name = L"Segoe UI Semibold";
        FCameraModeBadge->Font->Size = 7;
        FCameraModeBadge->Font->Color = RgbColor(92, 176, 232);
        FCameraModeBadge->Alignment = taLeftJustify;
    }

    if (FTerminalStatusCard == nullptr)
    {
        FTerminalStatusCard = new TPanel(BottomStatusPanel);
        FTerminalStatusCard->Parent = BottomStatusPanel;
        FTerminalStatusCard->BevelOuter = bvNone;
        FTerminalStatusCard->Caption = L"";
        FTerminalStatusCard->Color = RgbColor(5, 18, 29);
    }
}

void __fastcall TMainForm::HeaderDecorPaint(TObject* Sender)
{
    (void)Sender;

    if (FHeaderDecor == nullptr)
        return;

    TCanvas* C = FHeaderDecor->Canvas;
    const int W = FHeaderDecor->ClientWidth;
    const int H = FHeaderDecor->ClientHeight;

    C->Brush->Style = bsSolid;
    C->Brush->Color = RgbColor(2, 7, 12);
    C->FillRect(TRect(0, 0, W, H));

    // Linha inferior azul, com acento vermelho sob a marca TSX.
    C->Pen->Style = psSolid;
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(10, 54, 86);
    C->MoveTo(0, H - 2);
    C->LineTo(W, H - 2);

    C->Pen->Width = 2;
    C->Pen->Color = RgbColor(210, 24, 40);
    C->MoveTo(22, H - 3);
    C->LineTo(188, H - 3);

    // Cantos tecnológicos laterais.
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(18, 105, 170);

    C->MoveTo(8, 10); C->LineTo(8, 25); C->LineTo(18, 25);
    C->MoveTo(W - 8, 10); C->LineTo(W - 8, 25); C->LineTo(W - 18, 25);

    // Trilhos angulares: aparência de painel físico.
    C->Pen->Style = psSolid;
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(12, 69, 108);

    C->MoveTo(218, H - 3);
    C->LineTo(252, H - 3);
    C->LineTo(266, H - 17);
    C->LineTo(std::max(280, W / 2 - 92), H - 17);

    C->MoveTo(W - 218, H - 3);
    C->LineTo(W - 252, H - 3);
    C->LineTo(W - 266, H - 17);
    C->LineTo(std::min(W - 280, W / 2 + 92), H - 17);

    C->Pen->Style = psClear;
    C->Brush->Style = bsSolid;
    C->Brush->Color = RgbColor(24, 122, 190);
    C->Ellipse(205, H - 7, 209, H - 3);
    C->Ellipse(W - 209, H - 7, W - 205, H - 3);
}

void __fastcall TMainForm::CameraDecorPaint(TObject* Sender)
{
    (void)Sender;

    if (FCameraDecor == nullptr)
        return;

    TCanvas* C = FCameraDecor->Canvas;
    const int W = FCameraDecor->ClientWidth;
    const int H = FCameraDecor->ClientHeight;

    C->Brush->Style = bsClear;
    C->Pen->Style = psSolid;
    C->Pen->Width = 2;
    C->Pen->Color = RgbColor(27, 132, 215);

    const int M = 8;
    const int L = 24;

    // Quatro "brackets" nos cantos do card, sem cobrir a imagem.
    C->MoveTo(M, M + L); C->LineTo(M, M); C->LineTo(M + L, M);
    C->MoveTo(W - M - L, M); C->LineTo(W - M, M); C->LineTo(W - M, M + L);

    C->MoveTo(M, H - M - L); C->LineTo(M, H - M); C->LineTo(M + L, H - M);
    C->MoveTo(W - M - L, H - M); C->LineTo(W - M, H - M); C->LineTo(W - M, H - M - L);

    // Linha inferior ciano bem discreta.
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(13, 72, 116);
    C->MoveTo(W / 4, H - 5);
    C->LineTo((W * 3) / 4, H - 5);

    // Micro detalhes tecnológicos laterais.
    C->Pen->Style = psSolid;
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(12, 84, 137);

    C->MoveTo(4, H / 2 - 30);
    C->LineTo(4, H / 2 + 30);

    C->MoveTo(W - 4, H / 2 - 30);
    C->LineTo(W - 4, H / 2 + 30);

    C->Pen->Color = RgbColor(31, 151, 232);
    C->MoveTo(W / 2 - 38, 4);
    C->LineTo(W / 2 + 38, 4);

    C->MoveTo(W / 2 - 52, H - 4);
    C->LineTo(W / 2 + 52, H - 4);
}

void __fastcall TMainForm::FooterDecorPaint(TObject* Sender)
{
    (void)Sender;

    if (FFooterDecor == nullptr)
        return;

    TCanvas* C = FFooterDecor->Canvas;
    const int W = FFooterDecor->ClientWidth;
    const int H = FFooterDecor->ClientHeight;
    const int CX = W / 2;

    C->Brush->Style = bsSolid;
    C->Brush->Color = RgbColor(82, 4, 16);
    C->FillRect(TRect(0, 0, W, H));

    // Trilhos vermelhos convergindo para o MENU.
    C->Pen->Style = psSolid;
    C->Pen->Width = 2;
    C->Pen->Color = RgbColor(198, 22, 38);

    C->MoveTo(0, 8);
    C->LineTo(CX - 116, 8);
    C->LineTo(CX - 96, 22);

    C->MoveTo(W, 8);
    C->LineTo(CX + 116, 8);
    C->LineTo(CX + 96, 22);

    // Linha ciano de acabamento sob a faixa vermelha.
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(18, 73, 112);
    C->MoveTo(18, H - 5);
    C->LineTo(W - 18, H - 5);

    // Segunda camada de profundidade abaixo do botão.
    C->Pen->Style = psSolid;
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(116, 8, 25);

    C->MoveTo(0, H - 17);
    C->LineTo(CX - 126, H - 17);
    C->LineTo(CX - 106, H - 30);

    C->MoveTo(W, H - 17);
    C->LineTo(CX + 126, H - 17);
    C->LineTo(CX + 106, H - 30);
}


void TMainForm::InitializeIdleVisual()
{
    if (FIdleVisual == nullptr)
    {
        FIdleVisual = new TPaintBox(CameraPanel);
        FIdleVisual->Parent = CameraPanel;
        FIdleVisual->Align = alNone;
        FIdleVisual->Visible = false;
        FIdleVisual->Enabled = false;
        FIdleVisual->OnPaint = IdleVisualPaint;
    }

    if (FIdleVisualTimer == nullptr)
    {
        FIdleVisualTimer = new TTimer(this);
        FIdleVisualTimer->Enabled = false;
        FIdleVisualTimer->Interval = 90;
        FIdleVisualTimer->OnTimer = IdleVisualTimerTimer;
    }
}

void __fastcall TMainForm::IdleVisualTimerTimer(TObject* Sender)
{
    (void)Sender;

    FIdleVisualPhase = (FIdleVisualPhase + 1) % 30;

    if (FIdleVisual != nullptr && FIdleVisual->Visible)
    {
        FIdleVisual->Invalidate();
    }
}

void __fastcall TMainForm::IdleVisualPaint(TObject* Sender)
{
    (void)Sender;

    if (FIdleVisual == nullptr)
        return;

    TCanvas* C = FIdleVisual->Canvas;
    const int W = FIdleVisual->ClientWidth;
    const int H = FIdleVisual->ClientHeight;
    const int CX = W / 2;
    const int CY = H / 2 - 24;

    // Não pintamos fundo sólido: o card tecnológico permanece visível.
    C->Brush->Style = bsClear;

    // Pulso/radar suave ao redor do usuário.
    const int Pulse = (FIdleVisualPhase % 10) * 3;

    C->Pen->Style = psSolid;
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(10, 54, 88);

    C->Ellipse(
        CX - 90 - Pulse,
        CY - 90 - Pulse,
        CX + 90 + Pulse,
        CY + 90 + Pulse);

    C->Pen->Color = RgbColor(12, 75, 122);
    C->Ellipse(
        CX - 62 - (Pulse / 2),
        CY - 62 - (Pulse / 2),
        CX + 62 + (Pulse / 2),
        CY + 62 + (Pulse / 2));

    // Silhueta minimalista.
    C->Pen->Width = 2;
    C->Pen->Color = RgbColor(44, 156, 238);

    C->Ellipse(CX - 24, CY - 76, CX + 24, CY - 28);

    C->MoveTo(CX - 42, CY + 44);
    C->LineTo(CX - 36, CY - 2);
    C->LineTo(CX - 18, CY - 24);

    C->MoveTo(CX + 42, CY + 44);
    C->LineTo(CX + 36, CY - 2);
    C->LineTo(CX + 18, CY - 24);

    C->MoveTo(CX - 42, CY + 44);
    C->LineTo(CX + 42, CY + 44);

    // Cantos de enquadramento facial.
    C->Pen->Width = 2;
    C->Pen->Color = RgbColor(26, 123, 205);
    const int BoxW = 150;
    const int BoxH = 190;
    const int BX = CX - (BoxW / 2);
    const int BY = CY - 96;
    const int Corner = 22;

    C->MoveTo(BX, BY + Corner); C->LineTo(BX, BY); C->LineTo(BX + Corner, BY);
    C->MoveTo(BX + BoxW - Corner, BY); C->LineTo(BX + BoxW, BY); C->LineTo(BX + BoxW, BY + Corner);
    C->MoveTo(BX, BY + BoxH - Corner); C->LineTo(BX, BY + BoxH); C->LineTo(BX + Corner, BY + BoxH);
    C->MoveTo(BX + BoxW - Corner, BY + BoxH); C->LineTo(BX + BoxW, BY + BoxH); C->LineTo(BX + BoxW, BY + BoxH - Corner);

    // Setas ascendentes animadas.
    const int ArrowBaseY = CY + 112;
    for (int I = 0; I < 3; ++I)
    {
        const int Shift = ((FIdleVisualPhase * 3) + (I * 22)) % 66;
        const int Y = ArrowBaseY - Shift;

        C->Pen->Width = 3;
        C->Pen->Color =
            I == 0 ? RgbColor(54, 183, 255) :
            I == 1 ? RgbColor(28, 132, 221) :
                     RgbColor(14, 83, 145);

        C->MoveTo(CX - 24, Y);
        C->LineTo(CX, Y - 18);
        C->LineTo(CX + 24, Y);
    }

    // Linha inferior "scanner".
    C->Pen->Width = 1;
    C->Pen->Color = RgbColor(20, 102, 166);
    const int ScanX = 40 + ((FIdleVisualPhase * 17) % std::max(1, W - 80));
    C->MoveTo(std::max(18, ScanX - 70), H - 24);
    C->LineTo(std::min(W - 18, ScanX + 70), H - 24);
}

void TMainForm::InitializeCameraPreview()
{
    if (FCameraPreviewImage == nullptr)
    {
        FCameraPreviewImage = new TImage(CameraPanel);
        FCameraPreviewImage->Parent = CameraPanel;
        FCameraPreviewImage->Align = alNone;
        FCameraPreviewImage->Stretch = true;
        FCameraPreviewImage->Proportional = true;
        FCameraPreviewImage->Center = true;
        FCameraPreviewImage->Visible = false;
        FCameraPreviewImage->SendToBack();
    }

    if (FCameraPreviewBitmap == nullptr)
    {
        FCameraPreviewBitmap = new Graphics::TBitmap();
    }

    if (FCameraPreviewTimer == nullptr)
    {
        FCameraPreviewTimer = new TTimer(this);
        FCameraPreviewTimer->Enabled = false;
        FCameraPreviewTimer->Interval = 40;
        FCameraPreviewTimer->OnTimer = CameraPreviewTimerTimer;
    }
}

void TMainForm::InitializeIdleAnimation()
{
    if (FIdleLottie != nullptr)
    {
        return;
    }

    FIdleLottie = new TSkAnimatedImage(CameraPanel);
    FIdleLottie->Parent = CameraPanel;

    FIdleLottie->Align = alNone;
    FIdleLottie->Visible = false;

    // Mantém a animação proporcional dentro da área definida.
    FIdleLottie->WrapMode =
        TSkAnimatedImageWrapMode::Fit;

    // A animação deve ficar acima do fundo,
    // mas abaixo dos textos APROXIME-SE.
    FIdleLottie->SendToBack();
}

void TMainForm::InitializeCameraSelector()
{
    if (FCameraSelectorLabel == nullptr)
    {
        FCameraSelectorLabel = new TLabel(DeveloperPanel);
        FCameraSelectorLabel->Parent = DeveloperPanel;
        FCameraSelectorLabel->AutoSize = false;
        FCameraSelectorLabel->Caption = L"Câmera de vídeo";
        FCameraSelectorLabel->Font->Name = L"Segoe UI Semibold";
        FCameraSelectorLabel->Font->Size = 10;
        FCameraSelectorLabel->Font->Color = RgbColor(170, 181, 194);
        FCameraSelectorLabel->Visible = false;
    }

    if (FCameraSelector == nullptr)
    {
        FCameraSelector = new TComboBox(DeveloperPanel);
        FCameraSelector->Parent = DeveloperPanel;
        FCameraSelector->Style = csDropDownList;
        FCameraSelector->Font->Name = L"Segoe UI";
        FCameraSelector->Font->Size = 11;

        // v0.4.1 - o VCL Style escuro estava aplicando fonte clara
        // sobre o fundo claro do dropdown. Mantemos somente a borda
        // estilizada e deixamos cor/fonte sob controle do componente.
        FCameraSelector->StyleElements =
            TStyleElements() << seBorder;
        FCameraSelector->Color = clWhite;
        FCameraSelector->Font->Color = clBlack;
        FCameraSelector->DropDownCount = 8;

        FCameraSelector->OnChange = CameraSelectorChange;
        FCameraSelector->Visible = false;
    }

    if (FCameraSettingsPreview == nullptr)
    {
        FCameraSettingsPreview = new TImage(DeveloperPanel);
        FCameraSettingsPreview->Parent = DeveloperPanel;
        FCameraSettingsPreview->Stretch = true;
        FCameraSettingsPreview->Proportional = true;
        FCameraSettingsPreview->Center = true;
        FCameraSettingsPreview->Visible = false;
    }
}

void TMainForm::RefreshCameraDeviceList()
{
    if (FCameraSelector == nullptr || FCameraManager == nullptr)
        return;

    const int PreviousIndex = FPreviewCameraIndex;
    const bool WasOpen = FCameraManager->IsOpen();

    if (WasOpen)
        StopCameraPreview();

    FCameraSelector->Items->BeginUpdate();
    try
    {
        FCameraSelector->Items->Clear();

        // IMPORTANTE:
        // O índice OpenCV NÃO indica se a câmera é nativa ou USB.
        // Em uma máquina a USB pode ser índice 0 e a integrada índice 1.
        // Portanto não tentamos mais adivinhar o tipo físico pelo índice.
        //
        // Também não basta Open() retornar true: alguns backends abrem o
        // dispositivo, mas não entregam frames. Só listamos índices que
        // realmente fornecem ao menos um frame.
        for (int CameraIndex = 0; CameraIndex < 6; ++CameraIndex)
        {
            std::unique_ptr<TCameraManager> Probe =
                std::make_unique<TCameraManager>();

            if (!Probe->Open(CameraIndex))
                continue;

            bool HasFrame = false;
            TCameraFrame ProbeFrame;

            for (int Attempt = 0; Attempt < 10; ++Attempt)
            {
                if (Probe->ReadFrame(ProbeFrame) && !ProbeFrame.Empty())
                {
                    HasFrame = true;
                    break;
                }

                ::Sleep(60);
            }

            Probe->Close();

            if (!HasFrame)
                continue;

            const UnicodeString Caption =
                L"Câmera " + IntToStr(CameraIndex) +
                L" (índice de vídeo)";

            const int ItemIndex =
                FCameraSelector->Items->AddObject(
                    Caption,
                    reinterpret_cast<TObject*>(
                        static_cast<NativeInt>(CameraIndex + 1)));

            if (CameraIndex == PreviousIndex)
                FCameraSelector->ItemIndex = ItemIndex;
        }

        if (FCameraSelector->Items->Count == 0)
        {
            FCameraSelector->Items->Add(L"Nenhuma câmera com vídeo encontrada");
            FCameraSelector->ItemIndex = 0;
            FCameraSelector->Enabled = false;
        }
        else
        {
            FCameraSelector->Enabled = true;

            if (FCameraSelector->ItemIndex < 0)
            {
                FCameraSelector->ItemIndex = 0;

                const NativeInt Value =
                    reinterpret_cast<NativeInt>(
                        FCameraSelector->Items->Objects[0]);

                FPreviewCameraIndex =
                    static_cast<int>(Value) - 1;
            }
        }
    }
    __finally
    {
        FCameraSelector->Items->EndUpdate();
    }

    FCameraListInitialized = true;

    // v1.0.1 - Recuperação da câmera após enumeração.
    // Se a abertura inicial ocorreu cedo demais (comum em execução sem debugger),
    // a enumeração pode localizar uma câmera operacional depois que o formulário
    // já está visível. Nesse caso também iniciamos o preview mesmo que WasOpen=false.
    if (FCameraSelector->Enabled)
    {
        ::Sleep(120);
        StartCameraPreview();
    }
}

bool TMainForm::SwitchCamera(int CameraIndex)
{
    if (FCameraManager == nullptr || CameraIndex < 0)
        return false;

    if (FEnrollmentActive)
    {
        MessageDlg(
            L"Cadastro de identificação facial em andamento.\n\n"
            L"Conclua a captura das 8 amostras antes de trocar a câmera.",
            mtInformation,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    const int PreviousIndex = FPreviewCameraIndex;
    const bool WasOpen = FCameraManager->IsOpen();

    StopCameraPreview();
    FPreviewCameraIndex = CameraIndex;

    if (!WasOpen)
    {
        // Mesmo com a câmera previamente parada, validamos a câmera escolhida
        // antes de persistir o índice.
        StartCameraPreview();

        if (FCameraManager->IsOpen())
        {
            SavePersistedSettings();

            LblDeveloperStatus->Caption =
                L"Câmera " + IntToStr(CameraIndex) +
                L" selecionada. Preview operacional.";
            return true;
        }

        FPreviewCameraIndex = PreviousIndex;

        LblDeveloperStatus->Caption =
            L"A câmera " + IntToStr(CameraIndex) +
            L" não entregou vídeo.";
        return false;
    }

    StartCameraPreview();

    if (FCameraManager->IsOpen())
    {
        SavePersistedSettings();

        LblDeveloperStatus->Caption =
            L"Câmera " + IntToStr(CameraIndex) +
            L" selecionada. Preview operacional.";
        return true;
    }

    // A câmera abriu sem fornecer frames ou falhou por completo.
    // Restaura a fonte que estava ativa antes da troca.
    FPreviewCameraIndex = PreviousIndex;
    StartCameraPreview();

    if (FCameraSelector != nullptr)
    {
        for (int Item = 0; Item < FCameraSelector->Items->Count; ++Item)
        {
            const NativeInt Value =
                reinterpret_cast<NativeInt>(
                    FCameraSelector->Items->Objects[Item]);

            if ((static_cast<int>(Value) - 1) == PreviousIndex)
            {
                FCameraSelector->ItemIndex = Item;
                break;
            }
        }
    }

    MessageDlg(
        L"A câmera selecionada não entregou um frame de vídeo válido. "
        L"A câmera anterior foi restaurada.",
        mtWarning,
        TMsgDlgButtons() << mbOK,
        0);

    return false;
}

void __fastcall TMainForm::CameraSelectorChange(TObject *Sender)
{
    (void)Sender;

    if (FCameraSelector == nullptr ||
        FCameraSelector->ItemIndex < 0 ||
        !FCameraSelector->Enabled)
        return;

    const NativeInt Value =
        reinterpret_cast<NativeInt>(
            FCameraSelector->Items->Objects[
                FCameraSelector->ItemIndex]);

    const int CameraIndex = static_cast<int>(Value) - 1;

    if (CameraIndex == FPreviewCameraIndex)
        return;

    SwitchCamera(CameraIndex);
    RefreshIdentificationView();
}

void TMainForm::UpdateCameraSettingsPreview()
{
    if (FCurrentPage != TAccessPage::Camera ||
        FCameraSettingsPreview == nullptr ||
        FCameraPreviewBitmap == nullptr)
    {
        return;
    }

    if (!FCameraManager->IsOpen())
    {
        FCameraSettingsPreview->Picture->Assign(nullptr);
        return;
    }

    // Usa exatamente o mesmo bitmap que alimenta o preview principal,
    // sem abrir uma segunda instância da câmera.
    FCameraSettingsPreview->Picture->Assign(FCameraPreviewBitmap);
}

bool TMainForm::WaitForOperationalCameraFrame(int Attempts)
{
    if (FCameraManager == nullptr || !FCameraManager->IsOpen())
        return false;

    if (Attempts < 1)
        Attempts = 1;

    TCameraFrame Frame;

    for (int Attempt = 0; Attempt < Attempts; ++Attempt)
    {
        if (FCameraManager->ReadFrame(Frame) && !Frame.Empty())
        {
            // O primeiro frame confirma que não temos apenas um handle aberto:
            // existe fluxo de vídeo real vindo deste índice.
            return true;
        }

        ::Sleep(60);
    }

    return false;
}

void TMainForm::StartCameraPreview()
{
    if (FCameraManager == nullptr || FCameraPreviewTimer == nullptr)
    {
        return;
    }

    bool Opened = FCameraManager->IsOpen();
    const int RequestedIndex = FPreviewCameraIndex;

    auto TryOpenOperationalIndex = [this](int CameraIndex) -> bool
    {
        if (CameraIndex < 0)
            return false;

        if (FCameraManager->IsOpen())
            FCameraManager->Close();

        // Algumas webcams/Media Foundation precisam de um pequeno intervalo
        // depois do fechamento/probe anterior antes de reabrir o dispositivo.
        ::Sleep(120);

        if (!FCameraManager->Open(CameraIndex))
            return false;

        // Na execução sem debugger o processo chega aqui muito mais rápido.
        // O antigo tempo de aquecimento podia encerrar a câmera antes do
        // primeiro frame. Damos até ~1,5 s para o fluxo ficar operacional.
        if (!WaitForOperationalCameraFrame(25))
        {
            FCameraManager->Close();
            return false;
        }

        return true;
    };

    if (!Opened)
    {
        Opened = TryOpenOperationalIndex(RequestedIndex);

        // Se o índice persistido não estiver operacional nesta execução,
        // procuramos uma câmera que realmente entregue frames. Isso evita
        // depender do atraso introduzido pelo debugger para a webcam iniciar.
        if (!Opened)
        {
            for (int CameraIndex = 0; CameraIndex < 6 && !Opened; ++CameraIndex)
            {
                if (CameraIndex == RequestedIndex)
                    continue;

                if (TryOpenOperationalIndex(CameraIndex))
                {
                    FPreviewCameraIndex = CameraIndex;
                    Opened = true;

                    OutputDebugStringW(
                        (L"[CAMERA][RECOVERY] Índice " +
                         IntToStr(RequestedIndex) +
                         L" indisponível; usando índice " +
                         IntToStr(CameraIndex) + L"\r\n").c_str());

                    // O índice recuperado entregou vídeo real; preservamos para
                    // a próxima inicialização e sincronizamos o combo, se criado.
                    SavePersistedSettings();

                    if (FCameraSelector != nullptr)
                    {
                        for (int Item = 0; Item < FCameraSelector->Items->Count; ++Item)
                        {
                            const NativeInt Value =
                                reinterpret_cast<NativeInt>(
                                    FCameraSelector->Items->Objects[Item]);

                            if ((static_cast<int>(Value) - 1) == CameraIndex)
                            {
                                FCameraSelector->ItemIndex = Item;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    if (Opened)
    {
        FPreviewFrameCounter = 0;
        ResetFacePreviewState();
    }

    FCameraPreviewTimer->Enabled = Opened;

    if (BtnStartCamera != nullptr)
    {
        BtnStartCamera->Caption =
            Opened ? L"Parar câmera" : L"Iniciar câmera";
    }

    if (LblCameraStatus != nullptr)
    {
        LblCameraStatus->Caption = Opened
            ? L"● Câmera ativa • índice " +
              IntToStr(FPreviewCameraIndex)
            : L"● Câmera indisponível";
    }

    UpdateCameraPreviewVisibility();
    RefreshIdentificationView();
}

void TMainForm::StopCameraPreview()
{
    if (FCameraPreviewTimer != nullptr)
    {
        FCameraPreviewTimer->Enabled = false;
    }

    if (FCameraSettingsPreview != nullptr)
    {
        FCameraSettingsPreview->Picture->Assign(nullptr);
    }

    if (FCameraManager != nullptr)
    {
        FCameraManager->Close();
    }

    if (FCameraPreviewImage != nullptr)
    {
        FCameraPreviewImage->Visible = false;
        FCameraPreviewImage->Picture->Bitmap->SetSize(0, 0);
    }

    if (BtnStartCamera != nullptr)
    {
        BtnStartCamera->Caption = L"Iniciar câmera";
    }

    if (FIdleVisualTimer != nullptr)
        FIdleVisualTimer->Enabled = false;

    if (FIdleVisual != nullptr)
        FIdleVisual->Visible = false;

    ResetFacePreviewState();
}

void TMainForm::UpdateCameraPreviewVisibility()
{
    static constexpr unsigned int IdleAnimationDelayMs = 1500;

    const bool CameraActive =
        FCameraManager != nullptr &&
        FCameraManager->IsOpen();

    const bool FacePresent =
        FHasPrimaryFace ||
        FHasMultipleOperationalFaces;

    const bool ShowingEmployee =
        EmployeeResultPanel != nullptr &&
        EmployeeResultPanel->Visible;

    // A câmera selecionada permanece visível sempre que estiver operacional.
    const bool ShowLiveCamera =
        CameraActive &&
        !ShowingEmployee;

    if (FCameraPreviewImage != nullptr)
    {
        FCameraPreviewImage->Visible = ShowLiveCamera;

        if (ShowLiveCamera)
            FCameraPreviewImage->SendToBack();
    }

    ShapeFaceFrame->Visible = false;

    // ---------------------------------------------------------
    // CÂMERA DESLIGADA / INDISPONÍVEL
    // ---------------------------------------------------------
    if (!CameraActive && !ShowingEmployee)
    {
        FNoFaceSinceTick = 0;

        if (FIdleVisual != nullptr)
            FIdleVisual->Visible = false;

        if (FIdleVisualTimer != nullptr)
            FIdleVisualTimer->Enabled = false;

        if (FIdleLottie != nullptr)
            FIdleLottie->Visible = false;

        LblFaceGlyph->Visible = true;
        LblFaceGlyph->Caption = L"CÂMERA INDISPONÍVEL";
        LblFaceGlyph->Font->Color = RgbColor(220, 72, 82);
        LblFaceGlyph->BringToFront();

        LblCameraPlaceholder->Visible = true;
        LblCameraPlaceholder->Caption =
            L"Verifique a configuração da câmera";
        LblCameraPlaceholder->BringToFront();

        return;
    }

    // ---------------------------------------------------------
    // FUNCIONÁRIO / RESULTADO
    // ---------------------------------------------------------
    if (ShowingEmployee)
    {
        FNoFaceSinceTick = 0;

        if (FIdleVisual != nullptr)
            FIdleVisual->Visible = false;

        if (FIdleVisualTimer != nullptr)
            FIdleVisualTimer->Enabled = false;

        if (FIdleLottie != nullptr)
            FIdleLottie->Visible = false;

        LblFaceGlyph->Visible = false;
        LblCameraPlaceholder->Visible = false;
        return;
    }

    // ---------------------------------------------------------
    // FACE PRESENTE
    // Qualquer detecção válida cancela IMEDIATAMENTE a animação.
    // ---------------------------------------------------------
    if (FacePresent ||
        FFacePreviewState == TFacePreviewState::Detected ||
        FFacePreviewState == TFacePreviewState::Recognizing ||
        FFacePreviewState == TFacePreviewState::Recognized ||
        FFacePreviewState == TFacePreviewState::Enrolling ||
        FFacePreviewState == TFacePreviewState::TooClose ||
        FFacePreviewState == TFacePreviewState::TooFar ||
        FFacePreviewState == TFacePreviewState::Multiple)
    {
        FNoFaceSinceTick = 0;

        if (FIdleVisual != nullptr)
            FIdleVisual->Visible = false;

        if (FIdleVisualTimer != nullptr)
            FIdleVisualTimer->Enabled = false;

        if (FIdleLottie != nullptr)
            FIdleLottie->Visible = false;

        // Sem textos grandes sobre o rosto.
        LblFaceGlyph->Caption = L"";
        LblCameraPlaceholder->Caption = L"";
        LblFaceGlyph->Visible = false;
        LblCameraPlaceholder->Visible = false;
        return;
    }

    // ---------------------------------------------------------
    // SEM FACE
    // Inicia contagem. Não mostra a animação imediatamente.
    // Isso elimina o pisca-pisca quando o YuNet perde 1 ou 2 frames.
    // ---------------------------------------------------------
    const unsigned int NowTick = GetTickCount();

    if (FNoFaceSinceTick == 0)
        FNoFaceSinceTick = NowTick;

    const unsigned int NoFaceElapsed =
        NowTick - FNoFaceSinceTick;

    const bool ShowIdleAnimation =
        CameraActive &&
        FFacePreviewState == TFacePreviewState::Waiting &&
        NoFaceElapsed >= IdleAnimationDelayMs;

    if (ShowIdleAnimation)
    {
        if (FIdleVisual != nullptr)
        {
            FIdleVisual->Visible = true;
            FIdleVisual->BringToFront();
            FIdleVisual->Invalidate();
        }

        if (FIdleVisualTimer != nullptr)
            FIdleVisualTimer->Enabled = true;

        // O visual TSX animado é o PaintBox.
        if (FIdleLottie != nullptr)
            FIdleLottie->Visible = false;

        // A animação em si já comunica aproximação.
        // Mantemos os textos centrais desligados para nunca cobrir o rosto.
        LblFaceGlyph->Caption = L"";
        LblCameraPlaceholder->Caption = L"";
        LblFaceGlyph->Visible = false;
        LblCameraPlaceholder->Visible = false;
    }
    else
    {
        if (FIdleVisual != nullptr)
            FIdleVisual->Visible = false;

        if (FIdleVisualTimer != nullptr)
            FIdleVisualTimer->Enabled = false;

        if (FIdleLottie != nullptr)
            FIdleLottie->Visible = false;

        LblFaceGlyph->Caption = L"";
        LblCameraPlaceholder->Caption = L"";
        LblFaceGlyph->Visible = false;
        LblCameraPlaceholder->Visible = false;
    }
}

void TMainForm::ResetFacePreviewState()
{
    FFacePreviewState = TFacePreviewState::Waiting;
    FFaceHitFrames = 0;
    FFaceMissFrames = 0;
    FSingleFaceFrames = 0;
    FMultipleFaceFrames = 0;
    FLastFaceDetections.clear();
    FCurrentFaceBounds = FaceRect();
    FSmoothedFaceDetection = FaceDetection();
    FHasCurrentFaceBounds = false;
    FHasSmoothedFaceDetection = false;
    FDetectionFramesThisSecond = 0;
    FLastDetectionMetricTick = GetTickCount();
    FMeasuredDetectionsPerSecond = 0.0;
    FLastRecognitionAttemptTick = 0;
    FRecognitionCandidateId = 0;
    FRecognitionCandidateHits = 0;
    FLastRecognitionResult = FaceRecognitionResult();
    FLastRecognitionDurationMs = 0.0;
    FEnrollmentActive = false;
    FEnrollmentEmployeeId = 0;
    FEnrollmentSamples.clear();
    FPrimaryFaceDetection = FaceDetection();
    FHasPrimaryFace = false;
    FHasMultipleOperationalFaces = false;
    FStableFaceStartTick = 0;
    FLastFaceSeenTick = 0;
    FNoFaceSinceTick = 0;
    FHadRecentFace = false;
    FIdentificationState = IdentificationState::WaitingForFace;
    FFaceQualityIssue = TFaceQualityIssue::None;
    FLastDistance = FaceDistance::NoFace;
    FPreviousDistance = FaceDistance::NoFace;
    FLastFaceBounds = cv::Rect();
    FLastFaceTime = std::chrono::steady_clock::time_point();
    FLastFaceRatio = 0.0;
    FPreviousFaceRatio = 0.0;
    FFaceRecognitionLocked = false;
    FRecognizedEmployeeId = 0;

    if (EmployeeResultPanel != nullptr)
    {
        EmployeeResultPanel->Visible = false;
    }

    if (FEmployeePhotoImage != nullptr)
    {
        FEmployeePhotoImage->Visible = false;
    }

    if (FRecognitionCheckShape != nullptr)
    {
        FRecognitionCheckShape->Visible = false;
    }
    if (FRecognitionCheckLabel != nullptr)
    {
        FRecognitionCheckLabel->Visible = false;
    }

    if (FLivenessDetector != nullptr)
    {
        FLivenessDetector->Reset();
    }
}

void TMainForm::UpdateFacePreviewState(const std::vector<FaceDetection>& Detections,
    int FrameWidth, int FrameHeight)
{
    // Um reconhecimento facial confirmado fica travado enquanto a pessoa
    // continuar diante da câmera. BLE ainda pode estar aguardando, portanto
    // não usamos HasCurrentEmployee() como trava.
    if (FFaceRecognitionLocked)
    {
        // v0.4.5 - resultados de acesso (FACE ou RFID) ficam visíveis pelo
        // tempo do ReturnTimer. A ausência do rosto não pode apagar o card
        // antes de o operador/funcionário conseguir ler o resultado.
        if (ReturnTimer != nullptr && ReturnTimer->Enabled)
        {
            if (!Detections.empty())
                FLastFaceDetections = Detections;

            return;
        }

        if (Detections.empty())
        {
            ++FFaceMissFrames;

            // Só libera o terminal depois de uma ausência consistente.
            // Com detecção a cada poucos frames, 8 misses evita reset por uma
            // simples perda momentânea do YuNet.
            if (FFaceMissFrames >= 8)
            {
                ClearRecognizedFaceResult();
            }
        }
        else
        {
            FFaceMissFrames = 0;
            FLastFaceDetections = Detections;
        }
        return;
    }

    const bool HoldNotRecognized =
        FFacePreviewState == TFacePreviewState::NotRecognized &&
        ReturnTimer != nullptr &&
        ReturnTimer->Enabled;

    if (HoldNotRecognized)
    {
        if (!Detections.empty())
        {
            FLastFaceDetections = Detections;
        }
        return;
    }

    const auto Now = std::chrono::steady_clock::now();
    const bool HasRecentFace = FHadRecentFace &&
        FLastFaceTime != std::chrono::steady_clock::time_point() &&
        std::chrono::duration_cast<std::chrono::milliseconds>(
            Now - FLastFaceTime).count() <= RecentFaceToleranceMs;

    if (Detections.empty())
    {
        FFaceHitFrames = 0;
        FSingleFaceFrames = 0;
        FMultipleFaceFrames = 0;
        ++FFaceMissFrames;
        FCurrentFaceBounds = FaceRect();
        FHasCurrentFaceBounds = false;
        FHasPrimaryFace = false;
        FPrimaryFaceDetection = FaceDetection();
        FStableFaceStartTick = 0;

        if (HasRecentFace)
        {
            const bool LastFaceWasLarge = FLastFaceRatio >= LargeFaceNearEdgeRatio;
            const bool LastFaceWasGrowing = FPreviousFaceRatio > 0.0 &&
                FLastFaceRatio >= FPreviousFaceRatio + GrowingFaceRatioDelta;
            const bool LastFaceNearEdge = IsFaceNearFrameEdge(FLastFaceBounds,
                FrameWidth, FrameHeight);

            if (FLastDistance == FaceDistance::TooClose || LastFaceWasLarge ||
                LastFaceWasGrowing || LastFaceNearEdge)
            {
                FLastDistance = FaceDistance::TooClose;
                FFacePreviewState = TFacePreviewState::TooClose;
            }
            else if (FLastDistance == FaceDistance::TooFar)
            {
                FFacePreviewState = TFacePreviewState::TooFar;
            }
            else if (FFacePreviewState == TFacePreviewState::Waiting)
            {
                FFacePreviewState = TFacePreviewState::Detected;
            }
            return;
        }

        if (FFaceMissFrames >= FaceMissingRequiredFrames)
        {
            FFacePreviewState = TFacePreviewState::Waiting;
            FIdentificationState = IdentificationState::WaitingForFace;
            FLastDistance = FaceDistance::NoFace;
            FHadRecentFace = false;
            FHasSmoothedFaceDetection = false;
            FLastFaceBounds = cv::Rect();
            FLastFaceRatio = 0.0;
            FPreviousFaceRatio = 0.0;
            FLastFaceDetections.clear();
        }
        return;
    }

    FFaceMissFrames = 0;
    ++FFaceHitFrames;
    FHadRecentFace = true;
    FLastFaceTime = Now;
    FLastFaceSeenTick = GetTickCount();

    // Face voltou: cancela imediatamente a contagem da animação ociosa.
    FNoFaceSinceTick = 0;

    if (Detections.size() > 1)
    {
        FSingleFaceFrames = 0;
        ++FMultipleFaceFrames;
        FHasMultipleOperationalFaces = true;
        FHasPrimaryFace = false;
        FPrimaryFaceDetection = FaceDetection();
        FStableFaceStartTick = 0;
        FIdentificationState = IdentificationState::Failed;
        if (FMultipleFaceFrames >= FaceDetectedRequiredFrames)
        {
            FFacePreviewState = TFacePreviewState::Multiple;
            FCurrentFaceBounds = FaceRect();
            FHasCurrentFaceBounds = false;
            FHasSmoothedFaceDetection = false;
        }
        return;
    }

    ++FSingleFaceFrames;
    FMultipleFaceFrames = 0;
    FHasMultipleOperationalFaces = false;

    const FaceDetection& NewDetection = Detections[0];
    FPrimaryFaceDetection = NewDetection;
    FHasPrimaryFace = true;
    if (!FHasSmoothedFaceDetection)
    {
        FSmoothedFaceDetection = NewDetection;
        FHasSmoothedFaceDetection = true;
    }
    else
    {
        const double Alpha = 0.5;
        FSmoothedFaceDetection.Bounds.X = static_cast<int>(std::round(
            Alpha * NewDetection.Bounds.X + (1.0 - Alpha) * FSmoothedFaceDetection.Bounds.X));
        FSmoothedFaceDetection.Bounds.Y = static_cast<int>(std::round(
            Alpha * NewDetection.Bounds.Y + (1.0 - Alpha) * FSmoothedFaceDetection.Bounds.Y));
        FSmoothedFaceDetection.Bounds.Width = static_cast<int>(std::round(
            Alpha * NewDetection.Bounds.Width + (1.0 - Alpha) * FSmoothedFaceDetection.Bounds.Width));
        FSmoothedFaceDetection.Bounds.Height = static_cast<int>(std::round(
            Alpha * NewDetection.Bounds.Height + (1.0 - Alpha) * FSmoothedFaceDetection.Bounds.Height));
        FSmoothedFaceDetection.Confidence = NewDetection.Confidence;
    }

    // IMPORTANTE: DrawDetections() usa DetectionBounds, enquanto a suavizacao
    // acima atualizava somente Bounds. Isso fazia o retangulo visual ficar
    // preso/deslocado em relacao ao rosto real. Mantemos ambos sincronizados.
    FSmoothedFaceDetection.DetectionBounds = FSmoothedFaceDetection.Bounds;

    FPreviousFaceRatio = FLastFaceRatio;
    FPreviousDistance = FLastDistance;
    FLastFaceRatio = CalculateFaceRatio(FSmoothedFaceDetection.Bounds,
        FrameWidth, FrameHeight);
    FLastDistance = ClassifyFaceDistance(FSmoothedFaceDetection.Bounds,
        FrameWidth, FrameHeight, FPreviousDistance);
    FLastFaceBounds = ToCvRect(FSmoothedFaceDetection.Bounds);

    FLastFaceDetections.clear();
    FLastFaceDetections.push_back(FSmoothedFaceDetection);

    if (FLastDistance == FaceDistance::TooClose)
    {
        FFacePreviewState = TFacePreviewState::TooClose;
        FIdentificationState = IdentificationState::AdjustDistance;
        FCurrentFaceBounds = FaceRect();
        FHasCurrentFaceBounds = false;
        FStableFaceStartTick = 0;
        return;
    }

    if (FLastDistance == FaceDistance::TooFar)
    {
        FFacePreviewState = TFacePreviewState::TooFar;
        FIdentificationState = IdentificationState::AdjustDistance;
        FCurrentFaceBounds = FaceRect();
        FHasCurrentFaceBounds = false;
        FStableFaceStartTick = 0;
        return;
    }

    if (FSingleFaceFrames >= FaceDetectedRequiredFrames)
    {
        const unsigned int NowTick = GetTickCount();
        if (FStableFaceStartTick == 0)
        {
            FStableFaceStartTick = NowTick;
        }

        FCurrentFaceBounds = FSmoothedFaceDetection.Bounds;
        FHasCurrentFaceBounds = true;
        if (NowTick - FStableFaceStartTick >= 250)
        {
            FFacePreviewState = TFacePreviewState::Detected;
            FIdentificationState = IdentificationState::ReadyForRecognition;
        }
        else
        {
            FFacePreviewState = TFacePreviewState::Detected;
            FIdentificationState = IdentificationState::Stabilizing;
        }
    }
}

void TMainForm::ApplyFacePreviewStatus()
{
    const TColor WaitingColor = RgbColor(245, 190, 79);
    const TColor DetectedColor = RgbColor(41, 214, 132);
    const TColor MultipleColor = RgbColor(245, 190, 79);

    UnicodeString FaceCaption = L"FACE";
    UnicodeString FaceDetail = L"● Aguardando";
    UnicodeString Prompt = L"Aproxime-se para identificação";
    TColor FaceColor = WaitingColor;

    if (FFacePreviewState == TFacePreviewState::TooFar)
    {
        FaceDetail = L"● Muito distante";
        Prompt = L"Aproxime-se um pouco";
        FaceColor = WaitingColor;
    }
    else if (FFacePreviewState == TFacePreviewState::Detected)
    {
        FaceDetail = L"● Detectada";
        Prompt = FIdentificationState == IdentificationState::ReadyForRecognition
            ? L"Pronto para reconhecimento"
            : L"Aguardando estabilidade da face";
        FaceColor = DetectedColor;

        if (FIdentificationState == IdentificationState::ReadyForRecognition)
        {
            if (FFaceQualityIssue == TFaceQualityIssue::LowLight)
            {
                FaceDetail = L"● Pouca iluminação";
                Prompt = L"Iluminação insuficiente • aumente a iluminação sobre o rosto";
                FaceColor = WaitingColor;
            }
            else if (FFaceQualityIssue == TFaceQualityIssue::Blurred)
            {
                FaceDetail = L"● Imagem sem nitidez";
                Prompt = L"Mantenha-se imóvel por um instante";
                FaceColor = WaitingColor;
            }
        }
    }
    else if (FFacePreviewState == TFacePreviewState::TooClose)
    {
        FaceDetail = L"● Muito próxima";
        Prompt = L"Afaste-se um pouco";
        FaceColor = WaitingColor;
    }
    else if (FFacePreviewState == TFacePreviewState::Multiple)
    {
        FaceDetail = L"● Múltiplas pessoas";
        Prompt = L"Mantenha apenas uma pessoa diante da câmera";
        FaceColor = MultipleColor;
    }
    else if (FFacePreviewState == TFacePreviewState::Recognizing)
    {
        FaceDetail = L"● Detectada";
        Prompt = L"Identificando funcionário...";
        FaceColor = DetectedColor;
    }
    else if (FFacePreviewState == TFacePreviewState::Recognized)
    {
        FaceDetail = L"● Confirmada";
        Prompt = L"Acesso autorizado por identificação facial";
        FaceColor = DetectedColor;
    }
    else if (FFacePreviewState == TFacePreviewState::NotRecognized)
    {
        FaceDetail = L"● Não reconhecida";
        Prompt = L"Pessoa não reconhecida";
        FaceColor = RgbColor(210, 82, 92);
    }
    else if (FFacePreviewState == TFacePreviewState::Enrolling)
    {
        const int EnrollmentCount =
            static_cast<int>(FEnrollmentSamples.size());

        FaceDetail =
            L"● Cadastro " +
            IntToStr(EnrollmentCount) +
            L"/" +
            IntToStr(FaceEnrollmentRequiredSamples);

        const UnicodeString EnrollmentName =
            !FRemoteEnrollmentEmployeeName.IsEmpty()
                ? FRemoteEnrollmentEmployeeName
                : L"funcionário selecionado";

        Prompt =
            L"Cadastrando identificação facial • " +
            EnrollmentName +
            L" • " +
            IntToStr(EnrollmentCount) +
            L"/" +
            IntToStr(FaceEnrollmentRequiredSamples);

        FaceColor = DetectedColor;

        if (FFaceQualityIssue == TFaceQualityIssue::LowLight)
        {
            Prompt =
                L"Iluminação insuficiente • aumente a iluminação para continuar • " +
                IntToStr(EnrollmentCount) +
                L"/" +
                IntToStr(FaceEnrollmentRequiredSamples);
            FaceColor = WaitingColor;
        }
        else if (FFaceQualityIssue == TFaceQualityIssue::Blurred)
        {
            Prompt =
                L"Mantenha-se imóvel para continuar o cadastro • " +
                IntToStr(EnrollmentCount) +
                L"/" +
                IntToStr(FaceEnrollmentRequiredSamples);
            FaceColor = WaitingColor;
        }
    }

    // Se o resultado atual veio do RFID, a identificação facial não participou
    // da decisão. Não exibir "Não reconhecida" em vermelho nesse intervalo,
    // pois isso sugere uma falha embora o acesso RFID já tenha sido decidido.
    const bool RfidResultVisible =
        FFaceRecognitionLocked &&
        ReturnTimer != nullptr &&
        ReturnTimer->Enabled &&
        (FLastRfidState == TRfidVisualState::Authorized ||
         FLastRfidState == TRfidVisualState::Denied);

    if (RfidResultVisible)
    {
        FaceDetail = L"○ Não utilizada";
        FaceColor = RgbColor(164, 176, 194);
    }

    LblFaceIndicator->Caption = FaceCaption;
    LblFaceStatusDetail->Caption = FaceDetail;
    LblFaceIndicator->Font->Color = RgbColor(164, 176, 194);
    LblFaceStatusDetail->Font->Color = FaceColor;

    ApplyRfidStatus();

    if (!FFaceRecognitionLocked &&
        !FIdentificationManager->HasCurrentEmployee())
    {
        LblPrompt->Caption = Prompt;
        LblPrompt->Font->Color = FaceColor;
    }
}

void TMainForm::UpdateDetectionMetrics()
{
    ++FDetectionFramesThisSecond;
    const unsigned int NowTick = GetTickCount();
    const unsigned int Elapsed = NowTick - FLastDetectionMetricTick;
    if (Elapsed >= 1000)
    {
        FMeasuredDetectionsPerSecond =
            (static_cast<double>(FDetectionFramesThisSecond) * 1000.0) / Elapsed;
        FDetectionFramesThisSecond = 0;
        FLastDetectionMetricTick = NowTick;
    }
}

void TMainForm::RefreshEmployeeList()
{
    FEmployees.clear();
    LstEmployees->Items->BeginUpdate();
    try
    {
        LstEmployees->Items->Clear();
        if (FEmployeeRepository != nullptr)
        {
            FEmployees = FEmployeeRepository->GetAll();
        }

        for (const TEmployee& Employee : FEmployees)
        {
            LstEmployees->Items->Add(Format(L"%d - %s (%s)",
                ARRAYOFCONST((Employee.Id, Employee.Name, Employee.Department))));
        }

        if (!FEmployees.empty())
        {
            LstEmployees->ItemIndex = 0;
            LblDeveloperStatus->Caption = Format(L"%d funcionário(s) disponíveis. Selecione um registro para cadastrar a identificação facial.",
                ARRAYOFCONST((static_cast<int>(FEmployees.size()))));
        }
        else
        {
            LblDeveloperStatus->Caption = L"Nenhum funcionário disponível. Verifique a sincronização com o ERP Delphi.";
        }
    }
    __finally
    {
        LstEmployees->Items->EndUpdate();
    }
}


void TMainForm::ReconfigureEmployeeSync()
{
    if (FEmployeeSyncClient != nullptr)
    {
        FEmployeeSyncClient->Stop();
        FEmployeeSyncClient.reset();
    }

    if (FEmployeeRepository == nullptr)
        return;

    FEmployeeSyncClient =
        std::make_unique<TEmployeeSyncClient>(
            FEmployeeRepository.get(),
            FConfig.ApiUrl);

    FEmployeeSyncStateInitialized = false;
    FLastEmployeeSyncOnline = false;
    FLastEmployeeSyncCount = -1;

    FEmployeeSyncClient->Start();
}

void TMainForm::ProcessEmployeeSyncStatus()
{
    if (FEmployeeSyncClient == nullptr)
        return;

    TEmployeeSyncStatus Status;

    if (!FEmployeeSyncClient->TryConsumeStatus(
            Status))
    {
        return;
    }

    const bool Changed =
        !FEmployeeSyncStateInitialized ||
        FLastEmployeeSyncOnline != Status.Success ||
        (Status.Success &&
         FLastEmployeeSyncCount != Status.EmployeeCount);

    FEmployeeSyncStateInitialized = true;
    FLastEmployeeSyncOnline = Status.Success;

    if (Status.Success)
    {
        FLastEmployeeSyncCount = Status.EmployeeCount;

        // v0.4.5 - ERP é a fonte oficial dos funcionários.
        // Remove TAGs locais que ficaram órfãs depois de uma exclusão no ERP.
        ReconcileRfidAssignments();
    }

    if (Changed &&
        FObservabilityHeartbeat != nullptr)
    {
        FObservabilityHeartbeat->SendEvent(
            Status.Success ? L"SUCCESS" : L"WARN",
            L"EMPLOYEE_SYNC",
            Status.Success
                ? L"Funcionários sincronizados do ERP Delphi"
                : L"Falha na sincronização de funcionários do ERP Delphi",
            L"",
            Status.Success
                ? IntToStr(Status.EmployeeCount) + L" funcionário(s)"
                : Status.Message,
            0.0);
    }

    // Não mexe na tela de câmera/identificação.
    // Atualiza somente telas administrativas quando necessário.
    if (FCurrentPage == TAccessPage::Settings)
    {
        RefreshSettingsView();
    }
    else if (Status.Success &&
             FCurrentPage == TAccessPage::ManualRelease)
    {
        RefreshManualReleaseEmployees();
    }
    else if (Status.Success &&
             FCurrentPage == TAccessPage::BleDevices)
    {
        RefreshRfidTagEmployees();
    }
    else if (Status.Success &&
             FCurrentPage == TAccessPage::Incidents)
    {
        RefreshOccurrenceEmployees();
    }
}


void TMainForm::ReconcileRfidAssignments()
{
    if (FAccessEventRepository == nullptr ||
        FEmployeeRepository == nullptr ||
        !FEmployeeRepository->HasRemoteSnapshot())
    {
        return;
    }

    const std::vector<TRfidTagAssignment> Tags =
        FAccessEventRepository->GetRfidTags();

    int RemovedCount = 0;

    for (const TRfidTagAssignment& Tag : Tags)
    {
        if (!Tag.Active || Tag.EmployeeId <= 0)
            continue;

        TEmployee Employee;
        const bool EmployeeFound =
            FEmployeeRepository->FindById(
                Tag.EmployeeId, Employee) &&
            Employee.Id > 0;

        const bool IdentityMatches =
            EmployeeFound &&
            RfidIdentityMatches(
                Tag.IdentityKey,
                Employee);

        if (IdentityMatches)
            continue;

        if (!FAccessEventRepository->RemoveRfidTag(Tag.EmployeeId))
            continue;

        ++RemovedCount;

        if (SameText(FLastRfidUid, Tag.TagUid))
        {
            FLastRfidUid = UnicodeString();
            FLastRfidState = TRfidVisualState::Idle;
        }

        if (FObservabilityHeartbeat != nullptr)
        {
            FObservabilityHeartbeat->SendEvent(
                L"WARN",
                L"RFID_ORPHAN_TAG_REMOVED",
                L"Vínculo RFID órfão removido após sincronização do ERP",
                L"",
                Tag.TagUid,
                0.0);
        }
    }

    if (RemovedCount > 0)
    {
        OutputDebugStringW(
            (L"[RFID][PORTARIA] " +
             IntToStr(RemovedCount) +
             L" vínculo(s) RFID órfão(s) removido(s).\\r\\n").c_str());

        ApplyRfidStatus();
    }
}


void TMainForm::RecordFaceAccessEvent(const TEmployee& Employee, double Score)
{
    if (FAccessEventRepository == nullptr || Employee.Id <= 0)
    {
        return;
    }

    TAccessEvent Event;
    Event.EmployeeId = Employee.Id;
    Event.EmployeeName = Employee.Name;
    Event.Department = Employee.Department;
    Event.EventType = L"ENTRADA";
    Event.IdentificationMethod = L"FACE";
    Event.EventDateTime = FormatDateTime(L"yyyy-mm-dd hh:nn:ss", Now());
    Event.Terminal = TerminalDisplayName();
    Event.Status = L"FACE_AUTORIZADA";
    Event.RecognitionScore = Score;

    if (!FAccessEventRepository->Add(Event))
    {
        OutputDebugStringW(
            L"[MainForm] Falha ao registrar evento de acesso.\r\n");
    }
}

void TMainForm::RefreshRecentEntries()
{
    if (LstEmployees == nullptr)
    {
        return;
    }

    LstEmployees->Items->BeginUpdate();
    try
    {
        LstEmployees->Items->Clear();

        if (FAccessEventRepository == nullptr)
        {
            LblDeveloperStatus->Caption =
                L"Histórico de acessos indisponível.";
            return;
        }

        const std::vector<TAccessEvent> Events =
            FAccessEventRepository->GetRecent(30);

        for (const TAccessEvent& Event : Events)
        {
            UnicodeString StatusText = Event.Status;

            if (Event.Status == L"FACE_AUTORIZADA")
            {
                StatusText = L"Acesso autorizado • identificação facial";
            }
            else if (Event.Status == L"FACE_CONFIRMADA_BLE_PENDENTE")
            {
                // Compatibilidade com registros antigos.
                StatusText = L"Identificação facial confirmada (legado)";
            }
            else if (Event.Status == L"LIBERACAO_MANUAL")
            {
                StatusText = L"Liberação manual";
            }

            // A data completa já aparece no cabeçalho da página. Na lista
            // exibimos hora + funcionário + setor + fatores, evitando linhas
            // gigantes que eram cortadas visualmente.
            UnicodeString DisplayTime = Event.EventDateTime;
            if (DisplayTime.Length() >= 19)
            {
                DisplayTime = DisplayTime.SubString(12, 8);
            }

            UnicodeString Line =
                DisplayTime + L"   " + Event.EmployeeName;

            if (!Event.Department.IsEmpty())
            {
                Line += L"  •  " + Event.Department;
            }

            Line += L"  •  " + Event.IdentificationMethod +
                L"  •  " + StatusText;

            LstEmployees->Items->Add(Line);
        }

        if (Events.empty())
        {
            LblDeveloperStatus->Caption =
                L"Nenhum acesso registrado ainda.";
        }
        else
        {
            LblDeveloperStatus->Caption =
                IntToStr(static_cast<int>(Events.size())) +
                L" evento(s) recente(s) • access.s3db";
        }
    }
    __finally
    {
        LstEmployees->Items->EndUpdate();
    }
}

void TMainForm::RefreshPresentEmployees()
{
    if (LstEmployees == nullptr)
    {
        return;
    }

    LstEmployees->Items->BeginUpdate();
    try
    {
        LstEmployees->Items->Clear();

        if (FAccessEventRepository == nullptr)
        {
            LblDeveloperStatus->Caption =
                L"Controle de presença indisponível.";
            return;
        }

        const std::vector<TAccessEvent> Present =
            FAccessEventRepository->GetPresentToday();

        for (const TAccessEvent& Event : Present)
        {
            UnicodeString EntryTime = Event.EventDateTime;
            if (EntryTime.Length() >= 19)
            {
                EntryTime = EntryTime.SubString(12, 8);
            }

            UnicodeString Line =
                Event.EmployeeName;

            if (!Event.Department.IsEmpty())
            {
                Line += L"  •  " + Event.Department;
            }

            Line += L"  •  identificado às " + EntryTime;

            if (!Event.IdentificationMethod.IsEmpty())
            {
                Line += L"  •  " + Event.IdentificationMethod;
            }

            LstEmployees->Items->Add(Line);
        }

        if (Present.empty())
        {
            LblDeveloperStatus->Caption =
                L"Nenhum funcionário identificado como presente hoje.";
        }
        else
        {
            LblDeveloperStatus->Caption =
                IntToStr(static_cast<int>(Present.size())) +
                L" funcionário(s) presente(s) identificado(s) hoje";
        }
    }
    __finally
    {
        LstEmployees->Items->EndUpdate();
    }
}

void TMainForm::RefreshManualReleaseEmployees()
{
    FEmployees.clear();

    if (LstEmployees == nullptr)
    {
        return;
    }

    LstEmployees->Items->BeginUpdate();
    try
    {
        LstEmployees->Items->Clear();

        if (FEmployeeRepository != nullptr)
        {
            FEmployees = FEmployeeRepository->GetAll();
        }

        for (const TEmployee& Employee : FEmployees)
        {
            UnicodeString Line = Employee.Name;

            if (!Employee.Department.IsEmpty())
            {
                Line += L"  •  " + Employee.Department;
            }

            Line += L"  •  ID " + IntToStr(Employee.Id);
            LstEmployees->Items->Add(Line);
        }

        if (!FEmployees.empty())
        {
            LstEmployees->ItemIndex = 0;
            LblDeveloperStatus->Caption =
                IntToStr(static_cast<int>(FEmployees.size())) +
                L" funcionário(s) disponível(is) para liberação assistida.";
        }
        else
        {
            LblDeveloperStatus->Caption =
                L"Nenhum funcionário encontrado em Employees.s3db.";
        }
    }
    __finally
    {
        LstEmployees->Items->EndUpdate();
    }
}

bool TMainForm::RecordManualAccessEvent(const TEmployee& Employee)
{
    if (FAccessEventRepository == nullptr || Employee.Id <= 0)
    {
        return false;
    }

    TAccessEvent Event;
    Event.EmployeeId = Employee.Id;
    Event.EmployeeName = Employee.Name;
    Event.Department = Employee.Department;
    Event.EventType = L"ENTRADA";
    Event.IdentificationMethod = L"MANUAL";
    Event.EventDateTime = FormatDateTime(L"yyyy-mm-dd hh:nn:ss", Now());
    Event.Terminal = TerminalDisplayName();
    Event.Status = L"LIBERACAO_MANUAL";
    Event.RecognitionScore = 0.0;

    return FAccessEventRepository->Add(Event);
}

void TMainForm::RefreshOccurrences()
{
    if (LstEmployees == nullptr)
    {
        return;
    }

    LstEmployees->Items->BeginUpdate();
    try
    {
        LstEmployees->Items->Clear();

        if (FAccessEventRepository == nullptr)
        {
            LblDeveloperStatus->Caption =
                L"Registro de ocorrências indisponível.";
            return;
        }

        const std::vector<TOccurrence> Occurrences =
            FAccessEventRepository->GetRecentOccurrences(50);

        for (const TOccurrence& Occurrence : Occurrences)
        {
            UnicodeString DisplayTime = Occurrence.EventDateTime;
            if (DisplayTime.Length() >= 19)
            {
                DisplayTime = DisplayTime.SubString(12, 8);
            }

            UnicodeString Line =
                DisplayTime + L"  •  " +
                Occurrence.OccurrenceType;

            if (!Occurrence.EmployeeName.IsEmpty())
            {
                Line += L"  •  " + Occurrence.EmployeeName;
            }

            if (!Occurrence.Description.IsEmpty())
            {
                Line += L"  •  " + Occurrence.Description;
            }

            LstEmployees->Items->Add(Line);
        }

        if (Occurrences.empty())
        {
            LblDeveloperStatus->Caption =
                L"Nenhuma ocorrência registrada.";
        }
        else
        {
            LblDeveloperStatus->Caption =
                IntToStr(static_cast<int>(Occurrences.size())) +
                L" ocorrência(s) recente(s)";
        }
    }
    __finally
    {
        LstEmployees->Items->EndUpdate();
    }
}

bool TMainForm::ResolveEmployeeByName(
    const UnicodeString& Name,
    TEmployee& Employee)
{
    Employee = TEmployee();

    if (FEmployeeRepository == nullptr || Trim(Name).IsEmpty())
    {
        return false;
    }

    const UnicodeString Wanted = LowerCase(Trim(Name));
    const std::vector<TEmployee> Employees =
        FEmployeeRepository->GetAll();

    for (const TEmployee& Candidate : Employees)
    {
        if (LowerCase(Trim(Candidate.Name)) == Wanted)
        {
            Employee = Candidate;
            return Employee.Id > 0;
        }
    }

    return false;
}

bool TMainForm::IsEmployeeAccessBlocked(
    const TEmployee& Employee,
    UnicodeString& Reason) const
{
    Reason = UnicodeString();

    return FAccessEventRepository != nullptr &&
        FAccessEventRepository->IsEmployeeBlocked(
            Employee.Id, Reason);
}

void TMainForm::ShowBlockedEmployeeResult(
    const TEmployee& Employee,
    const UnicodeString& Reason,
    const TCameraFrame& Frame)
{
    FFacePreviewState = TFacePreviewState::NotRecognized;
    FIdentificationState = IdentificationState::Failed;
    FFaceRecognitionLocked = true;
    FRecognizedEmployeeId = Employee.Id;
    FFaceMissFrames = 0;
    FRecognitionCandidateId = 0;
    FRecognitionCandidateHits = 0;

    if (ReturnTimer != nullptr)
    {
        ReturnTimer->Enabled = false;
        ReturnTimer->Interval = 3500;
        ReturnTimer->Enabled = true;
    }

    UpdateEmployeePhotoSnapshot(Frame, FPrimaryFaceDetection);

    EmployeeResultPanel->Visible = true;
    EmployeeResultPanel->BringToFront();

    if (FRecognitionCheckShape != nullptr)
    {
        FRecognitionCheckShape->Visible = false;
    }
    if (FRecognitionCheckLabel != nullptr)
    {
        FRecognitionCheckLabel->Visible = false;
    }

    const TColor DeniedColor = RgbColor(220, 72, 82);

    LblEmployeeState->Caption = L"ACESSO NEGADO";
    LblEmployeeState->Font->Color = DeniedColor;

    LblName->Caption = Employee.Name;
    LblDepartment->Caption = Employee.Department;

    LblIdentifiedAt->Caption =
        L"Bloqueado às " + FormatDateTime(L"hh:nn:ss", Now());

    LblPrompt->Caption = Reason.IsEmpty()
        ? L"Acesso negado — procure a portaria"
        : L"Acesso negado — " + Reason;
    LblPrompt->Font->Color = DeniedColor;

    TOccurrence Attempt;
    Attempt.OccurrenceType = L"Tentativa bloqueada";
    Attempt.Description = Reason.IsEmpty()
        ? L"Funcionário reconhecido com acesso bloqueado."
        : Reason;
    Attempt.EmployeeName = Employee.Name;
    Attempt.EventDateTime =
        FormatDateTime(L"yyyy-mm-dd hh:nn:ss", Now());
    Attempt.Terminal = TerminalDisplayName();
    Attempt.Status = L"REGISTRADA";

    if (FAccessEventRepository != nullptr)
    {
        FAccessEventRepository->AddOccurrence(Attempt);
    }

    // OBSERVABILITY:
    // A tentativa bloqueada por identificação facial também precisa chegar
    // ao WebServer :8080. Antes ela era registrada somente no access.s3db,
    // por isso o Dashboard não mostrava o bloqueio.
    if (FObservabilityHeartbeat != nullptr)
    {
        FObservabilityHeartbeat->SendEvent(
            L"WARN",
            L"FACE_ACCESS_DENIED",
            L"Acesso negado por identificação facial",
            Employee.Name,
            Reason.IsEmpty()
                ? UnicodeString(L"ACCESS_DENIED")
                : Reason,
            FLastRecognitionDurationMs);
    }

    LayoutTerminal();
}

void TMainForm::RefreshOccurrenceEmployees()
{
    FEmployees.clear();

    if (LstEmployees == nullptr)
    {
        return;
    }

    LstEmployees->Items->BeginUpdate();
    try
    {
        LstEmployees->Items->Clear();

        if (FEmployeeRepository != nullptr)
        {
            FEmployees = FEmployeeRepository->GetAll();
        }

        for (const TEmployee& Employee : FEmployees)
        {
            UnicodeString Reason;
            const bool Blocked =
                IsEmployeeAccessBlocked(Employee, Reason);

            UnicodeString Line = Employee.Name;

            if (!Employee.Department.IsEmpty())
            {
                Line += L"  •  " + Employee.Department;
            }

            Line += Blocked
                ? L"  •  BLOQUEADO"
                : L"  •  LIBERADO";

            if (Blocked && !Reason.IsEmpty())
            {
                Line += L"  •  " + Reason;
            }

            LstEmployees->Items->Add(Line);
        }

        if (!FEmployees.empty())
        {
            LstEmployees->ItemIndex = 0;
        }

        LblDeveloperStatus->Caption =
            IntToStr(static_cast<int>(FEmployees.size())) +
            L" funcionário(s) • selecione um cadastro para bloquear/liberar.";
    }
    __finally
    {
        LstEmployees->Items->EndUpdate();
    }
}

void TMainForm::UpdateOccurrencePageButtons()
{
    if (FCurrentPage != TAccessPage::Incidents)
    {
        return;
    }

    if (FIncidentHistoryMode)
    {
        BtnSimulate->Visible = true;
        BtnSimulate->Caption = L"FUNCIONÁRIOS";

        BtnClear->Visible = true;
        BtnClear->Caption = L"REGISTRAR OCORRÊNCIA";

        BtnStartCamera->Visible = false;
    }
    else
    {
        BtnSimulate->Visible = true;
        BtnSimulate->Caption = L"BLOQUEAR ACESSO";

        BtnClear->Visible = true;
        BtnClear->Caption = L"LIBERAR ACESSO";

        BtnStartCamera->Visible = true;
        BtnStartCamera->Caption = L"HISTÓRICO";
    }
}

bool TMainForm::SetSelectedEmployeeBlocked(bool Blocked)
{
    TEmployee Employee;
    if (!TryGetSelectedEmployee(Employee))
    {
        MessageDlg(
            L"Selecione um funcionário.",
            mtWarning,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    UnicodeString Reason;

    if (Blocked)
    {
        if (!InputQuery(
                L"Bloquear acesso",
                L"Motivo do bloqueio:",
                Reason))
        {
            return false;
        }

        Reason = Trim(Reason);
        if (Reason.IsEmpty())
        {
            MessageDlg(
                L"Informe o motivo do bloqueio.",
                mtWarning,
                TMsgDlgButtons() << mbOK,
                0);
            return false;
        }
    }
    else
    {
        Reason = L"Acesso liberado pelo operador da portaria.";
    }

    const UnicodeString Question =
        (Blocked
            ? UnicodeString(L"Bloquear acesso de:\n\n")
            : UnicodeString(L"Liberar acesso de:\n\n")) +
        Employee.Name +
        (Employee.Department.IsEmpty()
            ? UnicodeString()
            : L"\n" + Employee.Department);

    if (MessageDlg(
            Question,
            mtConfirmation,
            TMsgDlgButtons() << mbYes << mbNo,
            0) != mrYes)
    {
        return false;
    }

    if (FAccessEventRepository == nullptr ||
        !FAccessEventRepository->SetEmployeeBlocked(
            Employee.Id,
            Employee.Name,
            Blocked,
            Reason,
            TerminalDisplayName()))
    {
        MessageDlg(
            L"Não foi possível atualizar o status de acesso.",
            mtError,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    TOccurrence Occurrence;
    Occurrence.OccurrenceType =
        Blocked ? L"Acesso bloqueado" : L"Acesso liberado";
    Occurrence.Description = Reason;
    Occurrence.EmployeeName = Employee.Name;
    Occurrence.EventDateTime =
        FormatDateTime(L"yyyy-mm-dd hh:nn:ss", Now());
    Occurrence.Terminal = TerminalDisplayName();
    Occurrence.Status = L"REGISTRADA";
    FAccessEventRepository->AddOccurrence(Occurrence);

    MessageDlg(
        Blocked
            ? L"Acesso bloqueado com sucesso."
            : L"Acesso liberado com sucesso.",
        mtInformation,
        TMsgDlgButtons() << mbOK,
        0);

    RefreshOccurrenceEmployees();
    return true;
}

bool TMainForm::RegisterOccurrence()
{
    if (FAccessEventRepository == nullptr)
    {
        MessageDlg(
            L"O repositório de ocorrências não está disponível.",
            mtError,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    UnicodeString OccurrenceType;
    if (!InputQuery(
            L"Registrar ocorrência",
            L"Tipo (ex.: Acesso negado, Visitante, RFID, Câmera, Exceção):",
            OccurrenceType))
    {
        return false;
    }

    OccurrenceType = Trim(OccurrenceType);
    if (OccurrenceType.IsEmpty())
    {
        MessageDlg(
            L"Informe o tipo da ocorrência.",
            mtWarning,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    UnicodeString EmployeeName;
    if (!InputQuery(
            L"Registrar ocorrência",
            L"Funcionário/visitante relacionado (opcional):",
            EmployeeName))
    {
        return false;
    }

    UnicodeString Description;
    if (!InputQuery(
            L"Registrar ocorrência",
            L"Descrição da ocorrência:",
            Description))
    {
        return false;
    }

    Description = Trim(Description);
    if (Description.IsEmpty())
    {
        MessageDlg(
            L"Informe uma descrição para a ocorrência.",
            mtWarning,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    TOccurrence Occurrence;
    Occurrence.OccurrenceType = OccurrenceType;
    Occurrence.Description = Description;
    Occurrence.EmployeeName = Trim(EmployeeName);
    Occurrence.EventDateTime =
        FormatDateTime(L"yyyy-mm-dd hh:nn:ss", Now());
    Occurrence.Terminal = TerminalDisplayName();
    Occurrence.Status = L"REGISTRADA";

    if (!FAccessEventRepository->AddOccurrence(Occurrence))
    {
        MessageDlg(
            L"Não foi possível registrar a ocorrência.",
            mtError,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    // Algumas ocorrências têm efeito operacional no controle de acesso.
    // "Acesso negado" bloqueia o funcionário; "Acesso liberado" ou
    // "Desbloqueio" remove o bloqueio. O nome deve coincidir com o cadastro.
    const UnicodeString NormalizedType =
        LowerCase(Trim(OccurrenceType));

    const bool ShouldBlock =
        NormalizedType.Pos(L"acesso negado") > 0 ||
        NormalizedType.Pos(L"bloqueio") > 0;

    const bool ShouldUnblock =
        NormalizedType.Pos(L"acesso liberado") > 0 ||
        NormalizedType.Pos(L"desbloqueio") > 0;

    if (ShouldBlock || ShouldUnblock)
    {
        TEmployee RelatedEmployee;
        if (!ResolveEmployeeByName(EmployeeName, RelatedEmployee))
        {
            MessageDlg(
                L"A ocorrência foi registrada, mas o funcionário informado "
                L"não corresponde exatamente a um cadastro do Employees.s3db. "
                L"Por isso, nenhum bloqueio foi alterado.",
                mtWarning,
                TMsgDlgButtons() << mbOK,
                0);
            return true;
        }

        if (!FAccessEventRepository->SetEmployeeBlocked(
                RelatedEmployee.Id,
                RelatedEmployee.Name,
                ShouldBlock,
                Description,
                TerminalDisplayName()))
        {
            MessageDlg(
                L"A ocorrência foi registrada, mas não foi possível atualizar "
                L"o bloqueio operacional do funcionário.",
                mtWarning,
                TMsgDlgButtons() << mbOK,
                0);
            return true;
        }

        MessageDlg(
            ShouldBlock
                ? L"Ocorrência registrada e acesso do funcionário BLOQUEADO."
                : L"Ocorrência registrada e acesso do funcionário LIBERADO.",
            mtInformation,
            TMsgDlgButtons() << mbOK,
            0);

        return true;
    }

    MessageDlg(
        L"Ocorrência registrada com sucesso.",
        mtInformation,
        TMsgDlgButtons() << mbOK,
        0);

    return true;
}

UnicodeString TMainForm::NormalizeRfidUid(
    const UnicodeString& RawUid) const
{
    UnicodeString Result;

    for (int Index = 1; Index <= RawUid.Length(); ++Index)
    {
        const wchar_t Ch = RawUid[Index];

        if ((Ch >= L'0' && Ch <= L'9') ||
            (Ch >= L'A' && Ch <= L'F') ||
            (Ch >= L'a' && Ch <= L'f'))
        {
            Result += UpCase(Ch);
        }
    }

    return Result;
}

bool TMainForm::IsValidRfidUid(const UnicodeString& Uid) const
{
    // UIDs comuns: 4, 7 ou 10 bytes = 8, 14 ou 20 dígitos hexadecimais.
    return Uid.Length() == 8 ||
           Uid.Length() == 14 ||
           Uid.Length() == 20;
}

void TMainForm::RefreshRfidTagEmployees()
{
    FEmployees.clear();

    if (LstEmployees == nullptr)
    {
        return;
    }

    LstEmployees->Items->BeginUpdate();
    try
    {
        LstEmployees->Items->Clear();

        if (FEmployeeRepository != nullptr)
        {
            FEmployees = FEmployeeRepository->GetAll();
        }

        int TagCount = 0;

        for (const TEmployee& Employee : FEmployees)
        {
            TRfidTagAssignment Tag;
            const bool HasTag =
                FAccessEventRepository != nullptr &&
                FAccessEventRepository->GetRfidTagByEmployee(
                    Employee.Id, Tag);

            UnicodeString Line = Employee.Name;

            if (!Employee.Department.IsEmpty())
            {
                Line += L"  •  " + Employee.Department;
            }

            if (HasTag && Tag.Active)
            {
                ++TagCount;
				Line += L"  •  TAG RFID: " + Tag.TagUid +
                    L"  •  " + Tag.TagType;
            }
            else
            {
                Line += L"  •  SEM TAG RFID";
            }

            LstEmployees->Items->Add(Line);
        }

        if (!FEmployees.empty())
        {
            LstEmployees->ItemIndex = 0;
		}

        LblDeveloperStatus->Caption =
            IntToStr(TagCount) + L" TAG(s) RFID cadastrada(s) • " +
            IntToStr(static_cast<int>(FEmployees.size())) +
            L" funcionário(s)";
    }
    __finally
    {
        LstEmployees->Items->EndUpdate();
    }
}

bool TMainForm::RegisterRfidTagManual()
{
    TEmployee Employee;
    if (!TryGetSelectedEmployee(Employee))
    {
        MessageDlg(
            L"Selecione um funcionário para cadastrar a TAG RFID.",
            mtWarning,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    UnicodeString RawUid;

    if (!FRfidAdminUid.IsEmpty())
    {
        RawUid = FRfidAdminUid;

        if (MessageDlg(
                L"VINCULAR TAG LIDA\n\n"
                L"Funcionário: " + Employee.Name +
                L"\nUID: " + RawUid +
                L"\n\nConfirmar este vínculo?",
                mtConfirmation,
                TMsgDlgButtons() << mbYes << mbNo,
                0) != mrYes)
        {
            return false;
        }
    }
    else
    {
        // Mantemos o cadastro manual como fallback para manutenção.
        if (!InputQuery(
                L"Cadastrar TAG RFID",
                L"Aproxime uma TAG no leitor ou informe o UID manualmente "
                L"(ex.: 556A37D5):",
                RawUid))
        {
            return false;
        }
    }

    const UnicodeString TagUid = NormalizeRfidUid(RawUid);

    if (!IsValidRfidUid(TagUid))
    {
        MessageDlg(
            L"UID inválido.\n\n"
            L"Informe apenas o UID hexadecimal da TAG.\n"
            L"Exemplo: 556A37D5\n\n"
            L"Também são aceitos espaços, hífens ou dois-pontos; "
            L"o sistema fará a normalização automaticamente.",
            mtWarning,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    TRfidTagAssignment ExistingUid;
    if (FAccessEventRepository != nullptr &&
        FAccessEventRepository->GetRfidTagByUid(
            TagUid, ExistingUid) &&
        ExistingUid.EmployeeId != Employee.Id)
    {
        MessageDlg(
            L"Esta TAG já está vinculada a outro funcionário:\n\n" +
            ExistingUid.EmployeeName +
            L"\nUID: " + ExistingUid.TagUid,
            mtError,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    TRfidTagAssignment ExistingEmployee;
    if (FAccessEventRepository != nullptr &&
        FAccessEventRepository->GetRfidTagByEmployee(
            Employee.Id, ExistingEmployee))
    {
        if (MessageDlg(
                L"Este funcionário já possui a TAG:\n\n" +
                ExistingEmployee.TagUid +
                L"\n\nDeseja substituir pelo UID " +
                TagUid + L"?",
                mtConfirmation,
                TMsgDlgButtons() << mbYes << mbNo,
                0) != mrYes)
        {
            return false;
        }
    }

    const UnicodeString RfidIdentityKey =
        BuildRfidIdentityKey(Employee);

    OutputDebugStringW(
        (L"[RFID][PORTARIA] Cadastrando vínculo: EmployeeId=" +
         IntToStr(Employee.Id) +
         L" | Employee=" + Employee.Name +
         L" | UID=" + TagUid +
         L" | IdentityKey=" + RfidIdentityKey +
         (Trim(Employee.FaceKey).IsEmpty()
             ? L" | source=RFID_FALLBACK"
             : L" | source=FACE_KEY") +
         L"\r\n").c_str());

    if (FAccessEventRepository == nullptr ||
        !FAccessEventRepository->AssignRfidTag(
            Employee.Id,
            RfidIdentityKey,
            Employee.Name,
            Employee.Department,
            TagUid,
            L"CHAVEIRO / BOLACHA RFID"))
    {
        MessageDlg(
            L"Não foi possível cadastrar a TAG RFID.\n\n"
            L"Funcionário: " + Employee.Name +
            L"\nEmployeeID: " + IntToStr(Employee.Id) +
            L"\nUID: " + TagUid +
            L"\n\nA leitura do RC522 está correta; "
            L"a falha ocorreu ao gravar o vínculo no banco local.",
            mtError,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    // Atualiza a lista ANTES da confirmação visual. Assim, enquanto a caixa
    // de sucesso estiver aberta, o operador já consegue ver o vínculo aplicado
    // na linha do funcionário ao fundo.
    RefreshRfidTagEmployees();

    MessageDlg(
        L"TAG RFID cadastrada com sucesso.\n\n" +
        Employee.Name +
        L"\nUID: " + TagUid +
        L"\nTipo: CHAVEIRO / BOLACHA RFID\n\n"
        L"O vínculo está ativo. Ao aproximar esta TAG na tela principal, "
        L"o funcionário será identificado automaticamente.",
        mtInformation,
        TMsgDlgButtons() << mbOK,
        0);

    FRfidAdminUid = UnicodeString();
    UpdateRfidAdminReader();
    return true;
}

bool TMainForm::RemoveSelectedRfidTag()
{
    TEmployee Employee;
    if (!TryGetSelectedEmployee(Employee))
    {
        MessageDlg(
            L"Selecione um funcionário.",
            mtWarning,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    TRfidTagAssignment Existing;
    if (FAccessEventRepository == nullptr ||
        !FAccessEventRepository->GetRfidTagByEmployee(
            Employee.Id, Existing))
    {
        MessageDlg(
            L"Este funcionário não possui TAG RFID cadastrada.",
            mtInformation,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    if (MessageDlg(
            L"Remover a TAG RFID " + Existing.TagUid +
            L" de " + Employee.Name + L"?",
            mtConfirmation,
            TMsgDlgButtons() << mbYes << mbNo,
            0) != mrYes)
    {
        return false;
    }

    if (!FAccessEventRepository->RemoveRfidTag(Employee.Id))
    {
        MessageDlg(
            L"Não foi possível remover a TAG RFID.",
            mtError,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    MessageDlg(
        L"TAG RFID removida com sucesso.",
        mtInformation,
        TMsgDlgButtons() << mbOK,
        0);

    RefreshRfidTagEmployees();
    return true;
}


void TMainForm::ProcessRfidIdentification(const UnicodeString& Uid)
{
    if (Uid.IsEmpty() ||
        FAccessEventRepository == nullptr ||
        FEmployeeRepository == nullptr)
    {
        return;
    }

    if (FObservabilityHeartbeat != nullptr)
    {
        FObservabilityHeartbeat->SendEvent(
            L"INFO",
            L"RFID_READ",
            L"TAG RFID lida no terminal",
            L"",
            Uid,
            0.0);
    }

    TRfidTagAssignment Assignment;
    if (!FAccessEventRepository->GetRfidTagByUid(
            Uid, Assignment) ||
        !Assignment.Active ||
        Assignment.EmployeeId <= 0)
    {
        OutputDebugStringW(
            (L"[RFID][PORTARIA] TAG não cadastrada: " +
             Uid + L"\r\n").c_str());

        if (FObservabilityHeartbeat != nullptr)
        {
            FObservabilityHeartbeat->SendEvent(
                L"WARN",
                L"RFID_UNKNOWN_TAG",
                L"TAG RFID não cadastrada",
                L"",
                Uid,
                0.0);
        }

        // Feedback rápido sem criar um falso funcionário.
        LblPrompt->Caption =
            L"TAG RFID não cadastrada • procure a portaria";
        LblPrompt->Font->Color = RgbColor(245, 190, 79);

        FLastRfidState = TRfidVisualState::UnknownTag;

        LblBleStatusDetail->Caption =
            L"● NÃO CADASTRADA • " + Uid;
        LblBleStatusDetail->Font->Color =
            RgbColor(245, 190, 79);

        if (ReturnTimer != nullptr)
        {
            ReturnTimer->Enabled = false;
            ReturnTimer->Interval = 2500;
            ReturnTimer->Enabled = true;
        }

        return;
    }

    // Sempre consulta o funcionário atual. O snapshot de nome/departamento
    // gravado no access.s3db não é usado como fonte oficial.
    TEmployee Employee;

    const bool EmployeeFound =
        FEmployeeRepository->FindById(
            Assignment.EmployeeId, Employee) &&
        Employee.Id > 0;

    const bool IdentityMatches =
        EmployeeFound &&
        RfidIdentityMatches(
            Assignment.IdentityKey,
            Employee);

    if (!IdentityMatches)
    {
        OutputDebugStringW(
            (L"[RFID][PORTARIA] Vínculo RFID inválido/órfão: " +
             Uid +
             L" | EmployeeId=" +
             IntToStr(Assignment.EmployeeId) +
             L"\r\n").c_str());

        if (FObservabilityHeartbeat != nullptr)
        {
            FObservabilityHeartbeat->SendEvent(
                L"WARN",
                L"RFID_INVALID_LINK",
                L"Vínculo RFID inválido ou órfão removido",
                EmployeeFound ? Employee.Name : L"",
                Uid,
                0.0);
        }

        // Evita que um EmployeeID eventualmente reutilizado herde uma
        // TAG antiga. Também elimina vínculos legados sem IdentityKey.
        if (FAccessEventRepository != nullptr)
            FAccessEventRepository->RemoveRfidTag(
                Assignment.EmployeeId);

        FLastRfidState =
            TRfidVisualState::InvalidLink;

        LblPrompt->Caption =
            EmployeeFound
                ? L"Vínculo RFID inválido • recadastre a TAG"
                : L"TAG vinculada a funcionário indisponível";

        LblPrompt->Font->Color =
            RgbColor(220, 72, 82);

        ApplyRfidStatus();

        if (ReturnTimer != nullptr)
        {
            ReturnTimer->Enabled = false;
            ReturnTimer->Interval = 2500;
            ReturnTimer->Enabled = true;
        }

        return;
    }

    UnicodeString BlockReason;
    const bool LocalBlocked =
        IsEmployeeAccessBlocked(Employee, BlockReason);

    // ETAPA 5: ERP online decide. A regra local fica somente como fallback.
    TErpAccessDecision ErpDecision;
    TryGetErpAccessDecision(
        Employee.Id,
        L"RFID",
        ErpDecision);
    LogAccessDecisionComparison(
        L"RFID",
        Employee,
        !LocalBlocked,
        ErpDecision);

    if (ErpDecision.Available)
    {
        if (!ErpDecision.Authorized)
        {
            ShowRfidBlockedEmployeeResult(
                Employee,
                Uid,
                ErpAccessReasonToDisplay(ErpDecision.Reason));
            return;
        }

        ShowRfidEmployeeResult(Employee, Uid);
        return;
    }

    // ETAPA 6 - CONTINGENCIA EXPLICITA:
    // ERP indisponivel -> a Portaria continua operacional com a regra local,
    // mas deixa claro para o operador e para a observabilidade que a decisao
    // nao veio da fonte corporativa em tempo real.
    if (FObservabilityHeartbeat != nullptr)
    {
        FObservabilityHeartbeat->SendEvent(
            L"WARN",
            L"ACCESS_DECISION_OFFLINE",
            L"ERP indisponível • decisão local de contingência",
            Employee.Name,
            LocalBlocked
                ? UnicodeString(L"RFID|ERP_UNAVAILABLE|LOCAL_DENIED")
                : UnicodeString(L"RFID|ERP_UNAVAILABLE|LOCAL_GRANTED"),
            0.0);
    }

    if (LocalBlocked)
    {
        const UnicodeString ContingencyReason =
            BlockReason.IsEmpty()
                ? UnicodeString(L"Modo contingência • ERP indisponível")
                : UnicodeString(L"Modo contingência • ") + BlockReason;

        ShowRfidBlockedEmployeeResult(
            Employee, Uid, ContingencyReason);
        return;
    }

    ShowRfidEmployeeResult(Employee, Uid);

    // ShowRfidEmployeeResult monta o card normal de sucesso; nesta etapa
    // apenas enriquecemos a mensagem para evidenciar a contingencia.
    if (LblPrompt != nullptr)
    {
        LblPrompt->Caption =
            L"Acesso autorizado • Modo contingência (ERP indisponível)";
        LblPrompt->Font->Color = RgbColor(245, 190, 79);
    }
}

void TMainForm::ShowRfidEmployeeResult(
    const TEmployee& Employee,
    const UnicodeString& Uid)
{
    // Enquanto o resultado RFID está visível, não permitimos que uma
    // identificação facial simultânea sobrescreva o card do funcionário.
    FFaceRecognitionLocked = true;
    FRecognizedEmployeeId = Employee.Id;
    FRecognitionCandidateId = 0;
    FRecognitionCandidateHits = 0;

    if (FIdentificationManager != nullptr)
        FIdentificationManager->ClearIdentification();

    if (FEmployeePhotoImage != nullptr)
        FEmployeePhotoImage->Visible = false;

    if (LblPhoto != nullptr)
    {
        LblPhoto->Visible = true;
        LblPhoto->Caption = L"RFID";
    }

    if (FRecognitionCheckShape != nullptr)
        FRecognitionCheckShape->Visible = false;

    if (FRecognitionCheckLabel != nullptr)
        FRecognitionCheckLabel->Visible = false;

    const TColor GrantedColor = RgbColor(41, 214, 132);

    EmployeeResultPanel->Visible = true;
    EmployeeResultPanel->BringToFront();

    LblEmployeeState->Caption = L"ACESSO AUTORIZADO";
    LblEmployeeState->Font->Color = GrantedColor;
    LblName->Caption = Employee.Name;
    LblDepartment->Caption = Employee.Department;
    LblIdentifiedAt->Caption =
        L"RFID confirmado às " +
        FormatDateTime(L"hh:nn:ss", Now());

    LblPrompt->Caption =
        L"Acesso autorizado por TAG RFID";
    LblPrompt->Font->Color = GrantedColor;

    FLastRfidState = TRfidVisualState::Authorized;

    LblBleStatusDetail->Caption =
        L"● AUTORIZADA • " + Uid;
    LblBleStatusDetail->Font->Color = GrantedColor;

    RecordRfidAccessEvent(Employee, Uid);

    if (FObservabilityHeartbeat != nullptr)
    {
        FObservabilityHeartbeat->SendEvent(
            L"SUCCESS",
            L"RFID_ACCESS_GRANTED",
            L"Acesso autorizado por TAG RFID",
            Employee.Name,
            Uid,
            0.0);
    }

    OutputDebugStringW(
        (L"[RFID][PORTARIA] ACESSO AUTORIZADO: " +
         Employee.Name + L" • " +
         Employee.Department + L" • UID " +
         Uid + L"\r\n").c_str());

    LayoutTerminal();

    // RFID é uma leitura discreta: depois de alguns segundos o terminal
    // volta automaticamente ao estado pronto para o próximo funcionário.
    if (ReturnTimer != nullptr)
    {
        ReturnTimer->Enabled = false;
        ReturnTimer->Interval = 3000;
        ReturnTimer->Enabled = true;
    }
}

void TMainForm::ShowRfidBlockedEmployeeResult(
    const TEmployee& Employee,
    const UnicodeString& Uid,
    const UnicodeString& Reason)
{
    FFaceRecognitionLocked = true;
    FRecognizedEmployeeId = Employee.Id;
    FRecognitionCandidateId = 0;
    FRecognitionCandidateHits = 0;

    if (FIdentificationManager != nullptr)
        FIdentificationManager->ClearIdentification();

    if (FEmployeePhotoImage != nullptr)
        FEmployeePhotoImage->Visible = false;

    if (LblPhoto != nullptr)
    {
        LblPhoto->Visible = true;
        LblPhoto->Caption = L"RFID";
    }

    if (FRecognitionCheckShape != nullptr)
        FRecognitionCheckShape->Visible = false;

    if (FRecognitionCheckLabel != nullptr)
        FRecognitionCheckLabel->Visible = false;

    const TColor DeniedColor = RgbColor(220, 72, 82);

    EmployeeResultPanel->Visible = true;
    EmployeeResultPanel->BringToFront();

    LblEmployeeState->Caption = L"ACESSO NEGADO";
    LblEmployeeState->Font->Color = DeniedColor;
    LblName->Caption = Employee.Name;
    LblDepartment->Caption = Employee.Department;
    LblIdentifiedAt->Caption =
        L"RFID bloqueado às " +
        FormatDateTime(L"hh:nn:ss", Now());

    LblPrompt->Caption = Reason.IsEmpty()
        ? L"Acesso negado por TAG RFID"
        : L"Acesso negado • " + Reason;
    LblPrompt->Font->Color = DeniedColor;

    FLastRfidState = TRfidVisualState::Denied;

    LblBleStatusDetail->Caption =
        L"● ACESSO NEGADO • " + Uid;
    LblBleStatusDetail->Font->Color = DeniedColor;

    TOccurrence Attempt;
    Attempt.OccurrenceType = L"Tentativa bloqueada RFID";
    Attempt.Description = Reason.IsEmpty()
        ? L"Tentativa de acesso por TAG RFID bloqueada."
        : Reason;
    Attempt.EmployeeName = Employee.Name;
    Attempt.EventDateTime =
        FormatDateTime(L"yyyy-mm-dd hh:nn:ss", Now());
    Attempt.Terminal = TerminalDisplayName();
    Attempt.Status = L"REGISTRADA";

    if (FAccessEventRepository != nullptr)
        FAccessEventRepository->AddOccurrence(Attempt);

    if (FObservabilityHeartbeat != nullptr)
    {
        FObservabilityHeartbeat->SendEvent(
            L"WARN",
            L"RFID_ACCESS_DENIED",
            L"Acesso negado por TAG RFID",
            Employee.Name,
            Reason.IsEmpty() ? Uid : Uid + L" • " + Reason,
            0.0);
    }

    LayoutTerminal();

    if (ReturnTimer != nullptr)
    {
        ReturnTimer->Enabled = false;
        ReturnTimer->Interval = 3500;
        ReturnTimer->Enabled = true;
    }
}

bool TMainForm::RecordRfidAccessEvent(
    const TEmployee& Employee,
    const UnicodeString& Uid)
{
    if (FAccessEventRepository == nullptr ||
        Employee.Id <= 0)
    {
        return false;
    }

    TAccessEvent Event;
    Event.EmployeeId = Employee.Id;
    Event.EmployeeName = Employee.Name;
    Event.Department = Employee.Department;
    Event.EventType = L"ENTRADA";
    Event.IdentificationMethod = L"RFID";
    Event.EventDateTime =
        FormatDateTime(L"yyyy-mm-dd hh:nn:ss", Now());
    Event.Terminal = TerminalDisplayName();
    Event.Status = L"RFID_AUTORIZADO";
    Event.RecognitionScore = 0.0;

    const bool Saved =
        FAccessEventRepository->Add(Event);

    if (!Saved)
    {
        OutputDebugStringW(
            (L"[RFID][PORTARIA] Falha ao registrar acesso RFID: " +
             Employee.Name + L" • UID " +
             Uid + L"\r\n").c_str());
    }

    return Saved;
}

void TMainForm::LoadPersistedSettings()
{
    try
    {
        const UnicodeString DataPath =
            TPath::Combine(ExtractFilePath(Application->ExeName), L"data");
        ForceDirectories(DataPath);

        const UnicodeString IniPath =
            TPath::Combine(DataPath, L"terminal.ini");

        if (!FileExists(IniPath))
            return;

        std::unique_ptr<TIniFile> Ini(new TIniFile(IniPath));

        FConfig.TerminalName =
            Ini->ReadString(L"Terminal", L"Name", FConfig.TerminalName);
        FConfig.ApiUrl =
            Ini->ReadString(L"ERP", L"ApiUrl", FConfig.ApiUrl);
        FConfig.DatabasePath =
            Ini->ReadString(L"Database", L"Employees", FConfig.DatabasePath);

        // v0.4 - a câmera escolhida pelo operador deve continuar sendo
        // a câmera operacional da tela principal, inclusive após reiniciar.
        FPreviewCameraIndex =
            Ini->ReadInteger(L"Camera", L"Index", FPreviewCameraIndex);

        if (FPreviewCameraIndex < 0 || FPreviewCameraIndex > 15)
            FPreviewCameraIndex = 0;
    }
    catch (...)
    {
        // Mantém os valores padrão se a configuração persistida falhar.
    }
}

void TMainForm::SavePersistedSettings()
{
    try
    {
        const UnicodeString DataPath =
            TPath::Combine(ExtractFilePath(Application->ExeName), L"data");
        ForceDirectories(DataPath);

        const UnicodeString IniPath =
            TPath::Combine(DataPath, L"terminal.ini");

        std::unique_ptr<TIniFile> Ini(new TIniFile(IniPath));
        Ini->WriteString(L"Terminal", L"Name", FConfig.TerminalName);
        Ini->WriteString(L"ERP", L"ApiUrl", FConfig.ApiUrl);
        Ini->WriteString(L"Database", L"Employees", FConfig.DatabasePath);
        Ini->WriteInteger(L"Camera", L"Index", FPreviewCameraIndex);
        Ini->UpdateFile();
    }
    catch (const Exception& E)
    {
        MessageDlg(
            L"Não foi possível salvar as configurações:\n" + E.Message,
            mtWarning,
            TMsgDlgButtons() << mbOK,
            0);
    }
}

void TMainForm::InitializeSettingsControls()
{
    const TColor CardColor = RgbColor(10, 20, 32);
    const TColor TextColor = RgbColor(224, 230, 238);
    const TColor Subtle = RgbColor(164, 176, 194);
    const TColor Green = RgbColor(41, 214, 132);

    if (FSettingsErpCard == nullptr)
    {
        FSettingsErpCard = new TPanel(DeveloperPanel);
        FSettingsErpCard->Parent = DeveloperPanel;
        FSettingsErpCard->BevelOuter = bvNone;
        FSettingsErpCard->Color = CardColor;
        FSettingsErpCard->Visible = false;

        FSettingsErpTitle = new TLabel(FSettingsErpCard);
        FSettingsErpTitle->Parent = FSettingsErpCard;
		FSettingsErpTitle->Caption = L"INTEGRAÇÃO ERP DELPHI";
        FSettingsErpTitle->Font->Name = L"Segoe UI Semibold";
        FSettingsErpTitle->Font->Size = 9;
        FSettingsErpTitle->Font->Color = TextColor;

        FSettingsErpStatus = new TLabel(FSettingsErpCard);
        FSettingsErpStatus->Parent = FSettingsErpCard;
        FSettingsErpStatus->Caption = L"● CONFIGURADO";
        FSettingsErpStatus->Font->Name = L"Segoe UI Semibold";
        FSettingsErpStatus->Font->Size = 10;
        FSettingsErpStatus->Font->Color = Green;

        FSettingsErpInfo = new TLabel(FSettingsErpCard);
        FSettingsErpInfo->Parent = FSettingsErpCard;
        FSettingsErpInfo->AutoSize = false;
        FSettingsErpInfo->WordWrap = true;
        FSettingsErpInfo->Caption =
            L"Endpoint usado pelo terminal C++Builder para integração com o ERP.";
        FSettingsErpInfo->Font->Name = L"Segoe UI";
        FSettingsErpInfo->Font->Size = 9;
        FSettingsErpInfo->Font->Color = Subtle;

        FSettingsApiEdit = new TEdit(FSettingsErpCard);
        FSettingsApiEdit->Parent = FSettingsErpCard;
        FSettingsApiEdit->Font->Name = L"Segoe UI";
        FSettingsApiEdit->Font->Size = 10;

        FSettingsTestErpButton = new TButton(FSettingsErpCard);
        FSettingsTestErpButton->Parent = FSettingsErpCard;
		FSettingsTestErpButton->Caption = L"TESTAR CONEXÃO";
        FSettingsTestErpButton->Font->Size = 10;
        FSettingsTestErpButton->OnClick = SettingsTestErpClick;
    }

    if (FSettingsDataCard == nullptr)
    {
        FSettingsDataCard = new TPanel(DeveloperPanel);
        FSettingsDataCard->Parent = DeveloperPanel;
        FSettingsDataCard->BevelOuter = bvNone;
        FSettingsDataCard->Color = CardColor;
        FSettingsDataCard->Visible = false;

        FSettingsDataTitle = new TLabel(FSettingsDataCard);
        FSettingsDataTitle->Parent = FSettingsDataCard;
        FSettingsDataTitle->Caption = L"DADOS CORPORATIVOS";
        FSettingsDataTitle->Font->Name = L"Segoe UI Semibold";
		FSettingsDataTitle->Font->Size = 9;
        FSettingsDataTitle->Font->Color = TextColor;

        FSettingsEmployeeDbStatus = new TLabel(FSettingsDataCard);
        FSettingsEmployeeDbStatus->Parent = FSettingsDataCard;
        FSettingsEmployeeDbStatus->Font->Name = L"Segoe UI Semibold";
        FSettingsEmployeeDbStatus->Font->Size = 10;

        FSettingsEmployeeDbPath = new TLabel(FSettingsDataCard);
        FSettingsEmployeeDbPath->Parent = FSettingsDataCard;
        FSettingsEmployeeDbPath->AutoSize = false;
        FSettingsEmployeeDbPath->EllipsisPosition = epEndEllipsis;
        FSettingsEmployeeDbPath->Font->Name = L"Segoe UI";
        FSettingsEmployeeDbPath->Font->Size = 8;
        FSettingsEmployeeDbPath->Font->Color = Subtle;

        FSettingsAccessDbStatus = new TLabel(FSettingsDataCard);
        FSettingsAccessDbStatus->Parent = FSettingsDataCard;
        FSettingsAccessDbStatus->Font->Name = L"Segoe UI Semibold";
        FSettingsAccessDbStatus->Font->Size = 10;

        FSettingsAccessDbPath = new TLabel(FSettingsDataCard);
        FSettingsAccessDbPath->Parent = FSettingsDataCard;
        FSettingsAccessDbPath->AutoSize = false;
        FSettingsAccessDbPath->EllipsisPosition = epEndEllipsis;
        FSettingsAccessDbPath->Font->Name = L"Segoe UI";
        FSettingsAccessDbPath->Font->Size = 8;
        FSettingsAccessDbPath->Font->Color = Subtle;

        FSettingsSelectDbButton = new TButton(FSettingsDataCard);
        FSettingsSelectDbButton->Parent = FSettingsDataCard;
        FSettingsSelectDbButton->Caption = L"SELECIONAR BANCO DE FUNCIONÁRIOS";
        FSettingsSelectDbButton->OnClick = SettingsSelectDbClick;
    }

    if (FSettingsTerminalCard == nullptr)
    {
        FSettingsTerminalCard = new TPanel(DeveloperPanel);
		FSettingsTerminalCard->Parent = DeveloperPanel;
        FSettingsTerminalCard->BevelOuter = bvNone;
        FSettingsTerminalCard->Color = CardColor;
		FSettingsTerminalCard->Visible = false;


        FSettingsTerminalTitle = new TLabel(FSettingsTerminalCard);
        FSettingsTerminalTitle->Parent = FSettingsTerminalCard;
        FSettingsTerminalTitle->Caption = L"TERMINAL DE ACESSO";
        FSettingsTerminalTitle->Font->Name = L"Segoe UI Semibold";
        FSettingsTerminalTitle->Font->Size = 9;
        FSettingsTerminalTitle->Font->Color = TextColor;

        FSettingsTerminalStatus = new TLabel(FSettingsTerminalCard);
        FSettingsTerminalStatus->Parent = FSettingsTerminalCard;
        FSettingsTerminalStatus->AutoSize = false;
        FSettingsTerminalStatus->WordWrap = true;
        FSettingsTerminalStatus->Font->Name = L"Segoe UI";
        FSettingsTerminalStatus->Font->Size = 9;
        FSettingsTerminalStatus->Font->Color = Subtle;

        FSettingsTerminalEdit = new TEdit(FSettingsTerminalCard);
        FSettingsTerminalEdit->Parent = FSettingsTerminalCard;
        FSettingsTerminalEdit->Font->Name = L"Segoe UI";
        FSettingsTerminalEdit->Font->Size = 10;

        FSettingsSaveTerminalButton = new TButton(FSettingsTerminalCard);
		FSettingsSaveTerminalButton->Parent = FSettingsTerminalCard;
		FSettingsSaveTerminalButton->Caption = L"SALVAR CONFIGURAÇÕES";
        FSettingsSaveTerminalButton->Font->Size = 8;
		FSettingsSaveTerminalButton->OnClick = SettingsSaveTerminalClick;



        FSettingsDiagnosticButton = new TButton(FSettingsTerminalCard);
        FSettingsDiagnosticButton->Parent = FSettingsTerminalCard;
        FSettingsDiagnosticButton->Caption = L"EXECUTAR DIAGNÓSTICO";
        FSettingsDiagnosticButton->OnClick = SettingsDiagnosticClick;
    }
}

bool TMainForm::ApplyEmployeeDatabasePath(
    const UnicodeString& DatabasePath)
{
    if (!FileExists(DatabasePath))
    {
        MessageDlg(
            L"O arquivo selecionado não existe.",
            mtError,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    try
    {
        std::unique_ptr<TEmployeeRepository> NewRepository =
            std::make_unique<TEmployeeRepository>(DatabasePath);

        // Força uma consulta real antes de substituir o repositório atual.
        const std::vector<TEmployee> TestEmployees =
            NewRepository->GetAll();

        FConfig.DatabasePath = DatabasePath;

        if (FEmployeeSyncClient != nullptr)
        {
            FEmployeeSyncClient->Stop();
            FEmployeeSyncClient.reset();
        }

        FEmployeeRepository = std::move(NewRepository);

        // O IdentificationManager mantém referência ao repositório.
        // Por isso deve ser reconstruído após mudar o banco.
        FIdentificationManager =
            std::make_unique<TIdentificationManager>(
                *FEmployeeRepository,
                *FIntegrationClient,
                FConfig);

        ReconfigureEmployeeSync();

        FEmployees.clear();
        SavePersistedSettings();

        MessageDlg(
            L"Banco de funcionários alterado com sucesso.\n\n" +
            IntToStr(static_cast<int>(TestEmployees.size())) +
            L" funcionário(s) encontrado(s).",
            mtInformation,
            TMsgDlgButtons() << mbOK,
            0);

        return true;
    }
    catch (const Exception& E)
    {
        MessageDlg(
            L"O arquivo foi selecionado, mas não pôde ser usado como "
            L"banco de funcionários.\n\n" + E.Message,
            mtError,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }
}

bool TMainForm::TestErpConnection()
{
    if (FSettingsApiEdit != nullptr)
        FConfig.ApiUrl = Trim(FSettingsApiEdit->Text);

    if (FConfig.ApiUrl.IsEmpty())
    {
        MessageDlg(
            L"Informe o endereço da API do ERP Delphi.",
            mtWarning,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }

    try
    {
        std::unique_ptr<THTTPClient> Http(THTTPClient::Create());
        Http->ConnectionTimeout = 3000;
        Http->ResponseTimeout = 3000;

        const UnicodeString EmployeesUrl =
            TEmployeeSyncClient::EmployeesEndpoint(
                FConfig.ApiUrl);

        const _di_IHTTPResponse Response =
            Http->Get(EmployeesUrl);

        const int StatusCode = Response->StatusCode;

        // 2xx/3xx/4xx significam que um servidor HTTP respondeu.
        // Até 404/405 provam conectividade; apenas não garantem que GET
        // seja o método correto para esse endpoint.
        const bool Connected =
            StatusCode >= 200 && StatusCode < 500;

        if (Connected)
        {
            FSettingsErpStatus->Caption =
                L"● ERP DELPHI RESPONDENDO • HTTP " +
                IntToStr(StatusCode);
            FSettingsErpStatus->Font->Color =
                RgbColor(41, 214, 132);

            SavePersistedSettings();
            return true;
        }

        FSettingsErpStatus->Caption =
            L"● ERP DELPHI INDISPONÍVEL • HTTP " +
            IntToStr(StatusCode);
        FSettingsErpStatus->Font->Color =
            RgbColor(255, 82, 96);

        return false;
    }
    catch (const Exception& E)
    {
        FSettingsErpStatus->Caption =
            L"● SEM CONEXÃO COM ERP";
        FSettingsErpStatus->Font->Color =
            RgbColor(255, 82, 96);

        MessageDlg(
            L"Não foi possível alcançar o ERP Delphi.\n\n" +
            E.Message,
            mtWarning,
            TMsgDlgButtons() << mbOK,
            0);
        return false;
    }
}

void TMainForm::RefreshSettingsView()
{
    if (FSettingsErpCard == nullptr)
        return;

    const bool EmployeeDbOk = FileExists(FConfig.DatabasePath);
    const bool AccessDbOk = FileExists(FConfig.AccessDatabasePath);

    int EmployeeCount = 0;
    try
    {
        if (FEmployeeRepository != nullptr)
            EmployeeCount =
                static_cast<int>(FEmployeeRepository->GetAll().size());
    }
    catch (...)
    {
        EmployeeCount = 0;
    }

    FSettingsApiEdit->Text = FConfig.ApiUrl;

    FSettingsErpStatus->Caption =
        FConfig.ApiUrl.IsEmpty()
            ? L"● NÃO CONFIGURADO"
            : L"● ENDPOINT CONFIGURADO";
    FSettingsErpStatus->Font->Color =
        FConfig.ApiUrl.IsEmpty()
            ? RgbColor(245, 190, 79)
            : RgbColor(41, 214, 132);

    const bool RemoteEmployeesReady =
        FEmployeeRepository != nullptr &&
        FEmployeeRepository->HasRemoteSnapshot();

    FSettingsEmployeeDbStatus->Caption =
        RemoteEmployeesReady
            ? L"● ERP Delphi sincronizado • " +
              IntToStr(EmployeeCount) + L" funcionário(s)"
            : (EmployeeDbOk
                ? L"● Fallback Employees.s3db • " +
                  IntToStr(EmployeeCount) + L" funcionário(s)"
                : L"● Aguardando sincronização do ERP Delphi");

    FSettingsEmployeeDbStatus->Font->Color =
        RemoteEmployeesReady
            ? RgbColor(41, 214, 132)
            : (EmployeeDbOk
                ? RgbColor(245, 190, 79)
                : RgbColor(255, 82, 96));
    FSettingsEmployeeDbPath->Caption = FConfig.DatabasePath;
    FSettingsEmployeeDbPath->Hint = FConfig.DatabasePath;
    FSettingsEmployeeDbPath->ShowHint = true;

    FSettingsAccessDbStatus->Caption =
        AccessDbOk
            ? L"● access.s3db disponível"
            : L"● Banco local do terminal ainda não criado";
    FSettingsAccessDbStatus->Font->Color =
        AccessDbOk
            ? RgbColor(41, 214, 132)
            : RgbColor(245, 190, 79);
    FSettingsAccessDbPath->Caption = FConfig.AccessDatabasePath;
    FSettingsAccessDbPath->Hint = FConfig.AccessDatabasePath;
    FSettingsAccessDbPath->ShowHint = true;

    FSettingsTerminalEdit->Text =
        StringReplace(
            FConfig.TerminalName,
            L"-",
            L" ",
            TReplaceFlags() << rfReplaceAll);

    FSettingsTerminalStatus->Caption =
        L"Versão 1.0.0  •  Câmera " +
        IntToStr(FPreviewCameraIndex) +
        L"  •  FACE ativo  •  RFID pronto para integração";

    LblDeveloperStatus->Caption =
        L"Configuração corporativa do terminal C++Builder e integração com o ERP Delphi.";
}

void TMainForm::RunSystemDiagnostic()
{
    const bool EmployeeDbOk = FileExists(FConfig.DatabasePath);
    const bool AccessDbOk = FileExists(FConfig.AccessDatabasePath);
    const bool CameraOk =
        FCameraManager != nullptr && FCameraManager->IsOpen();
    const bool FaceOk =
        FFaceDetector != nullptr && FFaceRecognizer != nullptr;
    const bool RfidPortOk =
        FRfidSerialReader != nullptr && FRfidSerialReader->IsPortOpen();
    const bool RfidReady =
        RfidPortOk && FRfidSerialReader->IsDeviceReady();

    UnicodeString Report =
        L"DIAGNÓSTICO DO TERMINAL\n\n";

    Report += EmployeeDbOk
        ? L"✓ Banco de funcionários\n"
        : L"✗ Banco de funcionários\n";

    Report += AccessDbOk
        ? L"✓ Banco local do terminal\n"
        : L"○ Banco local do terminal\n";

    Report += CameraOk
        ? L"✓ Câmera ativa\n"
        : L"○ Câmera parada\n";

    Report += FaceOk
        ? L"✓ Identificação facial carregada\n"
        : L"✗ Identificação facial indisponível\n";

    if (RfidReady)
        Report += L"✓ RFID / ESP32-S3 online\n";
    else if (RfidPortOk)
        Report += L"○ COM5 aberta • RFID inicializando/recuperando\n";
    else
        Report += L"✗ RFID / COM5 offline\n";

    Report += FConfig.ApiUrl.IsEmpty()
        ? L"○ ERP Delphi não configurado\n"
        : L"✓ Endpoint ERP Delphi configurado\n";

    if (RfidPortOk && !RfidReady)
    {
        Report +=
            L"\nO leitor RFID não está pronto. "
            L"Deseja solicitar recuperação do RC522 agora?";

        if (MessageDlg(
                Report,
                mtWarning,
                TMsgDlgButtons() << mbYes << mbNo,
                0) == mrYes)
        {
            FRfidSerialReader->RecoverReader();
            LblDeveloperStatus->Caption =
                L"Diagnóstico: recuperação do RC522 solicitada.";
        }
        return;
    }

    MessageDlg(
        Report,
        RfidReady ? mtInformation : mtWarning,
        TMsgDlgButtons() << mbOK,
        0);
}

void __fastcall TMainForm::SettingsSelectDbClick(TObject *Sender)
{
    (void)Sender;

    std::unique_ptr<TOpenDialog> Dialog(new TOpenDialog(this));
    Dialog->Title = L"Selecionar banco de funcionários";
    Dialog->Filter =
        L"Banco SQLite (*.s3db;*.db;*.sqlite)|*.s3db;*.db;*.sqlite|"
        L"Todos os arquivos (*.*)|*.*";
    Dialog->Options =
        TOpenOptions() << ofFileMustExist << ofPathMustExist;

    if (!Dialog->Execute())
        return;

    if (ApplyEmployeeDatabasePath(Dialog->FileName))
        RefreshSettingsView();
}

void __fastcall TMainForm::SettingsTestErpClick(TObject *Sender)
{
    (void)Sender;
    TestErpConnection();
}

void __fastcall TMainForm::SettingsSaveTerminalClick(TObject *Sender)
{
    (void)Sender;

    if (FSettingsTerminalEdit != nullptr)
    {
        UnicodeString Terminal =
            Trim(FSettingsTerminalEdit->Text);

        if (Terminal.IsEmpty())
        {
            MessageDlg(
                L"Informe o nome do terminal.",
                mtWarning,
                TMsgDlgButtons() << mbOK,
                0);
            return;
        }

        Terminal =
            StringReplace(
                Terminal,
                L" ",
                L"-",
                TReplaceFlags() << rfReplaceAll);

        FConfig.TerminalName = UpperCase(Terminal);
    }

    if (FSettingsApiEdit != nullptr)
        FConfig.ApiUrl = Trim(FSettingsApiEdit->Text);

    // Reconstrói cliente/gerenciador para usar o endpoint salvo.
    FIntegrationClient =
        std::make_unique<TIntegrationClient>(FConfig.ApiUrl);

    FIdentificationManager =
        std::make_unique<TIdentificationManager>(
            *FEmployeeRepository,
            *FIntegrationClient,
            FConfig);

    ReconfigureEmployeeSync();

    SavePersistedSettings();

    LblTerminal->Caption = TerminalDisplayName();
    LblMenuFooter->Caption =
        TerminalDisplayName() + L" | Versão 1.0.0";

    RefreshSettingsView();

    MessageDlg(
        L"Configurações salvas.",
        mtInformation,
        TMsgDlgButtons() << mbOK,
        0);
}

void __fastcall TMainForm::SettingsDiagnosticClick(TObject *Sender)
{
    (void)Sender;
    RunSystemDiagnostic();
}

void TMainForm::UpdateDeveloperPanel()
{
    // Controles exclusivos da página RFID devem desaparecer ao trocar
    // para qualquer outra tela administrativa.
    if (FRfidReaderCard != nullptr)
        FRfidReaderCard->Visible = false;

    if (FCameraSelectorLabel != nullptr)
        FCameraSelectorLabel->Visible = false;
    if (FCameraSelector != nullptr)
        FCameraSelector->Visible = false;
    if (FCameraSettingsPreview != nullptr)
        FCameraSettingsPreview->Visible = false;

    if (FSettingsErpCard != nullptr)
        FSettingsErpCard->Visible = false;
    if (FSettingsDataCard != nullptr)
        FSettingsDataCard->Visible = false;
    if (FSettingsTerminalCard != nullptr)
        FSettingsTerminalCard->Visible = false;

    const bool PresentPage =
        FCurrentPage == TAccessPage::PresentEmployees;
    const bool RecentPage =
        FCurrentPage == TAccessPage::RecentEntries;
    const bool ManualPage =
        FCurrentPage == TAccessPage::ManualRelease;
    const bool RfidPage =
        FCurrentPage == TAccessPage::BleDevices;
    const bool IncidentPage =
        FCurrentPage == TAccessPage::Incidents;
    const bool CameraPage =
        FCurrentPage == TAccessPage::Camera;
    const bool SettingsPage =
        FCurrentPage == TAccessPage::Settings;

    DeveloperPanel->Visible =
        PresentPage || RecentPage || ManualPage || RfidPage ||
        IncidentPage || CameraPage || SettingsPage;

    LstEmployees->Visible =
        PresentPage || RecentPage || ManualPage || RfidPage || IncidentPage;

    if (PresentPage)
    {
        BtnSimulate->Visible = false;

        BtnClear->Visible = true;
        BtnClear->Caption = L"Atualizar presentes";

        BtnStartCamera->Visible = false;

        RefreshPresentEmployees();
        return;
    }

    if (RecentPage)
    {
        BtnSimulate->Visible = false;

        BtnClear->Visible = true;
        BtnClear->Caption = L"Atualizar histórico";

        BtnStartCamera->Visible = false;

        RefreshRecentEntries();
        return;
    }

    if (ManualPage)
    {
        BtnSimulate->Visible = true;
        BtnSimulate->Caption = L"LIBERAR ACESSO";

        BtnClear->Visible = true;
        BtnClear->Caption = L"Atualizar funcionários";

        BtnStartCamera->Visible = false;

        RefreshManualReleaseEmployees();
        return;
    }

    if (RfidPage)
    {
        BtnSimulate->Visible = true;

        BtnClear->Visible = true;
        BtnClear->Caption = L"REMOVER TAG";

        BtnStartCamera->Visible = true;
        BtnStartCamera->Caption = L"RESET RFID / ESP32";

        RefreshRfidTagEmployees();
        UpdateRfidAdminReader();
        return;
    }

    if (IncidentPage)
    {
        UpdateOccurrencePageButtons();

        if (FIncidentHistoryMode)
        {
            RefreshOccurrences();
        }
        else
        {
            RefreshOccurrenceEmployees();
        }
        return;
    }

    if (SettingsPage)
    {
        BtnSimulate->Visible = false;
        BtnClear->Visible = false;
        BtnStartCamera->Visible = false;
        LstEmployees->Visible = false;

        if (FSettingsErpCard != nullptr)
            FSettingsErpCard->Visible = true;
        if (FSettingsDataCard != nullptr)
            FSettingsDataCard->Visible = true;
        if (FSettingsTerminalCard != nullptr)
            FSettingsTerminalCard->Visible = true;

        RefreshSettingsView();
        return;
    }

    if (CameraPage)
    {
        LblDeveloperStatus->Caption =
            L"Selecione a câmera pelo preview. O índice 0/1 é definido pelo Windows/OpenCV e não indica se é integrada ou USB.";

        if (FCameraSelectorLabel != nullptr)
            FCameraSelectorLabel->Visible = true;
        if (FCameraSelector != nullptr)
            FCameraSelector->Visible = true;
        if (FCameraSettingsPreview != nullptr)
            FCameraSettingsPreview->Visible = true;

        if (!FCameraListInitialized)
            RefreshCameraDeviceList();

        BtnSimulate->Visible = true;
        BtnSimulate->Caption =
            L"Layout: " + LayoutModeCaption();

        BtnClear->Visible = true;
        BtnClear->Caption =
            L"Rotação câmera: " + CameraRotationCaption();

        BtnStartCamera->Visible = true;
        BtnStartCamera->Caption = FCameraManager->IsOpen()
            ? L"Parar câmera"
            : L"Iniciar câmera";

        return;
    }

    LblDeveloperStatus->Caption =
        L"Ferramentas de desenvolvimento e operação do terminal.";

    BtnSimulate->Visible = false;
    BtnClear->Visible = true;
    BtnClear->Caption = L"Limpar identificação";
    BtnStartCamera->Visible = false;
}

bool TMainForm::TryGetSelectedEmployee(TEmployee& Employee) const
{
    Employee = TEmployee();
    const int Index = LstEmployees->ItemIndex;
    if (Index < 0 || Index >= static_cast<int>(FEmployees.size()))
    {
        return false;
    }

    Employee = FEmployees[static_cast<size_t>(Index)];
    return Employee.Id > 0;
}

bool TMainForm::CanProcessRecognition() const
{
    const bool HoldingNegativeResult =
        FFacePreviewState == TFacePreviewState::NotRecognized &&
        ReturnTimer != nullptr &&
        ReturnTimer->Enabled;

    return !FEnrollmentActive &&
        !FFaceRecognitionLocked &&
        !HoldingNegativeResult &&
        FHasPrimaryFace &&
        !FHasMultipleOperationalFaces &&
        FLastDistance == FaceDistance::Good &&
        FIdentificationState == IdentificationState::ReadyForRecognition;
}

bool TMainForm::FaceInsideFrame(const FaceDetection& Detection, int FrameWidth,
    int FrameHeight) const
{
    const FaceRect& Bounds = Detection.Bounds;
    return !Bounds.Empty() && Bounds.X >= 0 && Bounds.Y >= 0 &&
        Bounds.X + Bounds.Width <= FrameWidth &&
        Bounds.Y + Bounds.Height <= FrameHeight;
}

double TMainForm::FaceAverageBrightness(const TCameraFrame& Frame,
    const FaceDetection& Detection) const
{
    if (Frame.Empty() || Detection.Bounds.Empty() || Frame.BytesPerPixel != 4)
    {
        return 0.0;
    }

    // Usa a região central do rosto para reduzir a influência do fundo,
    // cabelo e bordas do bounding box.
    const FaceRect& Bounds = Detection.Bounds;

    const int HorizontalInset =
        std::max(1, Bounds.Width / 8);
    const int VerticalInset =
        std::max(1, Bounds.Height / 8);

    const int Left =
        std::max(0, Bounds.X + HorizontalInset);
    const int Top =
        std::max(0, Bounds.Y + VerticalInset);
    const int Right =
        std::min(Frame.Width,
            Bounds.X + Bounds.Width - HorizontalInset);
    const int Bottom =
        std::min(Frame.Height,
            Bounds.Y + Bounds.Height - VerticalInset);

    if (Right <= Left || Bottom <= Top)
    {
        return 0.0;
    }

    double BrightnessSum = 0.0;
    int Samples = 0;

    // Amostragem a cada 2 pixels é suficiente para feedback visual
    // e evita custo desnecessário no loop da câmera.
    for (int Y = Top; Y < Bottom; Y += 2)
    {
        const unsigned char* Row =
            Frame.Data.data() + (Y * Frame.Stride);

        for (int X = Left; X < Right; X += 2)
        {
            const int Offset = X * Frame.BytesPerPixel;

            const int Blue = Row[Offset];
            const int Green = Row[Offset + 1];
            const int Red = Row[Offset + 2];

            // Luminância aproximada perceptual.
            BrightnessSum +=
                (0.114 * Blue) +
                (0.587 * Green) +
                (0.299 * Red);

            ++Samples;
        }
    }

    if (Samples <= 0)
    {
        return 0.0;
    }

    return BrightnessSum / Samples;
}

bool TMainForm::FaceLightingEnough(const TCameraFrame& Frame,
    const FaceDetection& Detection) const
{
    return FaceAverageBrightness(Frame, Detection) >=
        FaceMinimumBrightness;
}

bool TMainForm::FaceSharpEnough(const TCameraFrame& Frame,
    const FaceDetection& Detection) const
{
    if (Frame.Empty() || Detection.Bounds.Empty() || Frame.BytesPerPixel != 4)
    {
        return false;
    }

    const FaceRect& Bounds = Detection.Bounds;
    const int Left = std::max(0, Bounds.X);
    const int Top = std::max(0, Bounds.Y);
    const int Right = std::min(Frame.Width, Bounds.X + Bounds.Width);
    const int Bottom = std::min(Frame.Height, Bounds.Y + Bounds.Height);
    const int Width = Right - Left;
    const int Height = Bottom - Top;
    if (Width < 64 || Height < 64)
    {
        return false;
    }

    double GradientSum = 0.0;
    int Samples = 0;
    for (int Y = Top + 1; Y < Bottom - 1; ++Y)
    {
        const unsigned char* Row = Frame.Data.data() + (Y * Frame.Stride);
        const unsigned char* PrevRow = Frame.Data.data() + ((Y - 1) * Frame.Stride);
        const unsigned char* NextRow = Frame.Data.data() + ((Y + 1) * Frame.Stride);
        for (int X = Left + 1; X < Right - 1; ++X)
        {
            const int Offset = X * Frame.BytesPerPixel;
            const int PrevOffset = (X - 1) * Frame.BytesPerPixel;
            const int NextOffset = (X + 1) * Frame.BytesPerPixel;

            const int GrayLeft = (Row[PrevOffset] + Row[PrevOffset + 1] + Row[PrevOffset + 2]) / 3;
            const int GrayRight = (Row[NextOffset] + Row[NextOffset + 1] + Row[NextOffset + 2]) / 3;
            const int GrayUp = (PrevRow[Offset] + PrevRow[Offset + 1] + PrevRow[Offset + 2]) / 3;
            const int GrayDown = (NextRow[Offset] + NextRow[Offset + 1] + NextRow[Offset + 2]) / 3;

            GradientSum += std::abs(GrayRight - GrayLeft) + std::abs(GrayDown - GrayUp);
            ++Samples;
        }
    }

    if (Samples <= 0)
    {
        return false;
    }

    const double AverageGradient = GradientSum / Samples;

    // Webcam de portaria: 18.0 estava excessivamente restritivo e podia
    // impedir completamente o cadastro de identificação facial mesmo com a face nítida.
    // Mantemos um filtro leve apenas para rejeitar frames claramente borrados.
    return AverageGradient >= 8.0;
}

void TMainForm::ProcessFaceEnrollment(const TCameraFrame& Frame)
{
    if (!FEnrollmentActive)
    {
        return;
    }

    // Enquanto o cadastro estiver ativo, a UI deve deixar claro que estamos
    // em modo de enrollment, mesmo antes de uma amostra ser aceita.
    FFacePreviewState = TFacePreviewState::Enrolling;

    if (FFaceRecognizer == nullptr || FFaceRepository == nullptr ||
        !FFaceRecognizer->IsInitialized())
    {
        LblPrompt->Caption = L"Reconhecimento facial indisponível";
        LblDeveloperStatus->Caption = L"FaceRecognizer/FaceRepository não inicializado.";
        ApplyFacePreviewStatus();
        return;
    }

    if (!FHasPrimaryFace)
    {
        LblPrompt->Caption = L"Posicione o rosto diante da câmera";
        ApplyFacePreviewStatus();
        return;
    }

    if (FHasMultipleOperationalFaces)
    {
        LblPrompt->Caption = L"Mantenha apenas uma pessoa diante da câmera";
        ApplyFacePreviewStatus();
        return;
    }

    if (FLastDistance != FaceDistance::Good)
    {
        LblPrompt->Caption = FLastDistance == FaceDistance::TooClose
            ? L"Afaste-se um pouco"
            : L"Aproxime-se um pouco";
        ApplyFacePreviewStatus();
        return;
    }

    if (!FaceInsideFrame(FPrimaryFaceDetection, Frame.Width, Frame.Height))
    {
        LblPrompt->Caption = L"Centralize o rosto na câmera";
        ApplyFacePreviewStatus();
        return;
    }

    if (FPrimaryFaceDetection.Confidence < 0.85f)
    {
        LblPrompt->Caption = L"Mantenha o rosto voltado para a câmera";
        ApplyFacePreviewStatus();
        return;
    }

    if (!FaceLightingEnough(Frame, FPrimaryFaceDetection))
    {
        FFaceQualityIssue = TFaceQualityIssue::LowLight;
        ApplyFacePreviewStatus();
        return;
    }

    if (!FaceSharpEnough(Frame, FPrimaryFaceDetection))
    {
        FFaceQualityIssue = TFaceQualityIssue::Blurred;
        ApplyFacePreviewStatus();
        return;
    }

    FFaceQualityIssue = TFaceQualityIssue::None;

    const unsigned int NowTick = GetTickCount();
    if (FLastRecognitionAttemptTick != 0 &&
        NowTick - FLastRecognitionAttemptTick < FaceRecognitionIntervalMs)
    {
        ApplyFacePreviewStatus();
        return;
    }

    FLastRecognitionAttemptTick = NowTick;

    FaceFeature Feature;
    if (!FFaceRecognizer->ExtractFeature(Frame.Data.data(), Frame.Width,
        Frame.Height, Frame.Stride, FPrimaryFaceDetection.Bounds, Feature))
    {
        LblPrompt->Caption = L"Não foi possível extrair as características faciais. Ajuste a posição.";
        ApplyFacePreviewStatus();
        return;
    }

    FEnrollmentSamples.push_back(Feature);

    const int SampleCount = static_cast<int>(FEnrollmentSamples.size());
    LblDeveloperStatus->Caption = Format(
        L"Capturando amostras de identificação facial: %d/%d",
        ARRAYOFCONST((SampleCount, FaceEnrollmentRequiredSamples)));

    // Atualiza imediatamente o contador visível na tela principal.
    LblPrompt->Caption =
        L"Cadastrando identificação facial • " +
        (!FRemoteEnrollmentEmployeeName.IsEmpty()
            ? FRemoteEnrollmentEmployeeName
            : L"funcionário selecionado") +
        L" • " +
        IntToStr(SampleCount) +
        L"/" +
        IntToStr(FaceEnrollmentRequiredSamples);

    if (!FRemoteEnrollmentRequestId.IsEmpty() &&
        SampleCount < FaceEnrollmentRequiredSamples)
    {
        // Canal operacional direto: Portaria -> ERP Delphi :3101.
        // O WebServer :8080 não participa do cadastro facial.
        SendDirectEnrollmentProgress(
            FRemoteEnrollmentRequestId,
            L"Portaria capturando amostras faciais",
            SampleCount);
    }

    if (SampleCount >= FaceEnrollmentRequiredSamples)
    {
        CompleteFaceEnrollment();
        return;
    }

    ApplyFacePreviewStatus();
}

void TMainForm::ProcessFaceRecognition(const TCameraFrame& Frame)
{
    if (FEnrollmentActive)
    {
        return;
    }

    if (FFaceRecognizer == nullptr || FFaceRepository == nullptr ||
        !FFaceRecognizer->IsInitialized() || !CanProcessRecognition() ||
        FFacePreviewState == TFacePreviewState::Recognized ||
        FFacePreviewState == TFacePreviewState::NotRecognized)
    {
        return;
    }

    if (!FaceInsideFrame(FPrimaryFaceDetection, Frame.Width, Frame.Height))
    {
        return;
    }

    // v0.7.1.2
    // Se não existe nenhum template facial que pertença de fato a um
    // funcionário atual (EmployeeId + FaceKey), não há o que comparar.
    // Nesse cenário a UI não deve ficar indefinidamente em "FACE Detectada":
    // a detecção ocorreu, mas a identificação não pode ser confirmada.
    bool HasEligibleFaceTemplate = false;

    if (FFaceRepository != nullptr &&
        FEmployeeRepository != nullptr)
    {
        const std::vector<FaceTemplate> Templates =
            FFaceRepository->LoadAllTemplates();

        for (const FaceTemplate& Template : Templates)
        {
            TEmployee TemplateOwner;

            if (!FEmployeeRepository->FindById(
                    Template.EmployeeId,
                    TemplateOwner))
            {
                continue;
            }

            if (Trim(Template.FaceKey).IsEmpty() ||
                Trim(TemplateOwner.FaceKey).IsEmpty())
            {
                continue;
            }

            if (SameText(
                    Trim(Template.FaceKey),
                    Trim(TemplateOwner.FaceKey)))
            {
                HasEligibleFaceTemplate = true;
                break;
            }
        }
    }

    if (!HasEligibleFaceTemplate)
    {
        RejectFaceRecognition();
        return;
    }

    if (!FaceLightingEnough(Frame, FPrimaryFaceDetection))
    {
        FFaceQualityIssue = TFaceQualityIssue::LowLight;

        // Não reaproveitar uma confirmação parcial obtida antes de
        // a qualidade do frame degradar.
        FRecognitionCandidateId = 0;
        FRecognitionCandidateHits = 0;

        FFacePreviewState = TFacePreviewState::Detected;
        ApplyFacePreviewStatus();
        return;
    }

    if (!FaceSharpEnough(Frame, FPrimaryFaceDetection))
    {
        FFaceQualityIssue = TFaceQualityIssue::Blurred;
        FRecognitionCandidateId = 0;
        FRecognitionCandidateHits = 0;

        FFacePreviewState = TFacePreviewState::Detected;
        ApplyFacePreviewStatus();
        return;
    }

    FFaceQualityIssue = TFaceQualityIssue::None;

    const unsigned int NowTick = GetTickCount();
    if (FLastRecognitionAttemptTick != 0 &&
        NowTick - FLastRecognitionAttemptTick < FaceRecognitionIntervalMs)
    {
        return;
    }
    FLastRecognitionAttemptTick = NowTick;
    FFaceQualityIssue = TFaceQualityIssue::None;
    FFacePreviewState = TFacePreviewState::Recognizing;
    ApplyFacePreviewStatus();

    if (FLivenessDetector != nullptr)
    {
        const LivenessResult Liveness = FLivenessDetector->Process(Frame.Data.data(),
            Frame.Width, Frame.Height, Frame.Stride, FPrimaryFaceDetection);
        if (FLivenessDetector->Mode() == LivenessMode::Prototype)
        {
            OutputDebugStringA("LIVENESS: prototype mode active, allowing pass-through to face recognition.\n");
        }
        else if (!Liveness.Completed || !Liveness.IsLive)
        {
            RejectFaceRecognition();
            return;
        }
    }

    const auto StartedAt = std::chrono::steady_clock::now();
    FaceFeature Feature;
    if (!FFaceRecognizer->ExtractFeature(Frame.Data.data(), Frame.Width,
        Frame.Height, Frame.Stride, FPrimaryFaceDetection.Bounds, Feature))
    {
        return;
    }

    const FaceRecognitionResult Result = RecognizeFeature(Feature);
    FLastRecognitionResult = Result;
    FLastRecognitionDurationMs = std::chrono::duration<double, std::milli>(
        std::chrono::steady_clock::now() - StartedAt).count();

    const double FaceBrightness =
        FaceAverageBrightness(Frame, FPrimaryFaceDetection);

    char DebugBuffer[384];
    std::snprintf(DebugBuffer, sizeof(DebugBuffer),
        "FACE_RECOGNITION: recognized=%d employeeId=%d score=%.4f threshold=%.4f durationMs=%.2f hits=%d brightness=%.1f\n",
        Result.Recognized ? 1 : 0,
        Result.EmployeeId,
        Result.Score,
        FConfig.FaceRecognitionThreshold,
        FLastRecognitionDurationMs,
        FRecognitionCandidateHits,
        FaceBrightness);
    OutputDebugStringA(DebugBuffer);

    if (!Result.Recognized)
    {
        RejectFaceRecognition();
        return;
    }

    if (FRecognitionCandidateId != Result.EmployeeId)
    {
        FRecognitionCandidateId = Result.EmployeeId;
        FRecognitionCandidateHits = 1;
        return;
    }

    ++FRecognitionCandidateHits;
    if (FRecognitionCandidateHits < FaceRecognitionRequiredHits)
    {
        return;
    }

    TEmployee Employee;
    if (FEmployeeRepository == nullptr || !FEmployeeRepository->FindById(Result.EmployeeId, Employee))
    {
        RejectFaceRecognition();
        return;
    }

    UnicodeString BlockReason;
    const bool LocalBlocked =
        IsEmployeeAccessBlocked(Employee, BlockReason);

    // ETAPA 5: ERP online decide. A regra local fica somente como fallback.
    TErpAccessDecision ErpDecision;
    TryGetErpAccessDecision(
        Employee.Id,
        L"FACE",
        ErpDecision);
    LogAccessDecisionComparison(
        L"FACE",
        Employee,
        !LocalBlocked,
        ErpDecision);

    if (ErpDecision.Available)
    {
        if (!ErpDecision.Authorized)
        {
            ShowBlockedEmployeeResult(
                Employee,
                ErpAccessReasonToDisplay(ErpDecision.Reason),
                Frame);
            return;
        }
    }
    else
    {
        // ETAPA 6 - CONTINGENCIA EXPLICITA PARA FACE.
        if (FObservabilityHeartbeat != nullptr)
        {
            FObservabilityHeartbeat->SendEvent(
                L"WARN",
                L"ACCESS_DECISION_OFFLINE",
                L"ERP indisponível • decisão local de contingência",
                Employee.Name,
                LocalBlocked
                    ? UnicodeString(L"FACE|ERP_UNAVAILABLE|LOCAL_DENIED")
                    : UnicodeString(L"FACE|ERP_UNAVAILABLE|LOCAL_GRANTED"),
                FLastRecognitionDurationMs);
        }

        if (LocalBlocked)
        {
            const UnicodeString ContingencyReason =
                BlockReason.IsEmpty()
                    ? UnicodeString(L"Modo contingência • ERP indisponível")
                    : UnicodeString(L"Modo contingência • ") + BlockReason;

            ShowBlockedEmployeeResult(
                Employee, ContingencyReason, Frame);
            return;
        }
    }

    FFacePreviewState = TFacePreviewState::Recognized;
    FIdentificationState = IdentificationState::ReadyForRecognition;
    FFaceRecognitionLocked = true;
    FRecognizedEmployeeId = Employee.Id;
    FFaceMissFrames = 0;
    FRecognitionCandidateId = 0;
    FRecognitionCandidateHits = 0;
    FLastCorrectTestScore = Result.Score;

    // v0.4.5 - identificação facial é um fator de acesso completo.
    // O BLE foi retirado do fluxo do MVP.
    FIdentificationManager->FaceDetected(Employee.Id, 1.0);

    if (ReturnTimer != nullptr)
    {
        ReturnTimer->Enabled = false;
        ReturnTimer->Interval = 3000;
        ReturnTimer->Enabled = true;
    }

    UpdateEmployeePhotoSnapshot(Frame, FPrimaryFaceDetection);

    EmployeeResultPanel->Visible = true;
    EmployeeResultPanel->BringToFront();

    if (FRecognitionCheckShape != nullptr)
    {
        FRecognitionCheckShape->Visible = true;
        FRecognitionCheckShape->BringToFront();
    }
    if (FRecognitionCheckLabel != nullptr)
    {
        FRecognitionCheckLabel->Visible = true;
        FRecognitionCheckLabel->BringToFront();
    }
    const TColor GrantedColor = RgbColor(41, 214, 132);

    LblEmployeeState->Caption = L"ACESSO AUTORIZADO";
    LblEmployeeState->Font->Color = GrantedColor;
    LblName->Caption = Employee.Name;
    LblDepartment->Caption = Employee.Department;
    LblIdentifiedAt->Caption =
        L"Identificação facial confirmada às " +
        FormatDateTime(L"hh:nn:ss", Now());

    // O lock facial impede gravações repetidas enquanto a mesma pessoa
    // permanece diante da câmera.
    RecordFaceAccessEvent(Employee, Result.Score);

// =========================================================
// OBSERVABILITY - EVENTO DE RECONHECIMENTO FACIAL
// =========================================================
  if (FObservabilityHeartbeat != nullptr)
	{
	  FObservabilityHeartbeat->SendEvent(
		L"SUCCESS",
		L"FACE_RECOGNITION",
		L"Funcionário reconhecido por identificação facial",
		Employee.Name,
		L"FACE_CONFIRMED",
		FLastRecognitionDurationMs);
	}

    if (!ErpDecision.Available)
    {
        LblPrompt->Caption =
            L"Acesso autorizado • Modo contingência (ERP indisponível)";
        LblPrompt->Font->Color = RgbColor(245, 190, 79);
    }
    else
    {
        LblPrompt->Caption =
            L"Acesso autorizado por identificação facial";
        LblPrompt->Font->Color = RgbColor(41, 214, 132);
    }

    LayoutTerminal();
    ApplyFacePreviewStatus();
}

FaceRecognitionResult TMainForm::RecognizeFeature(const FaceFeature& Feature)
{
    FaceRecognitionResult Result;
    if (Feature.Empty() || FFaceRecognizer == nullptr || FFaceRepository == nullptr)
    {
        return Result;
    }

    const std::vector<FaceTemplate> Templates =
        FFaceRepository->LoadAllTemplates();

    for (const FaceTemplate& Template : Templates)
    {
        // EmployeeId sozinho não é identidade suficiente:
        // o SQLite pode reutilizar um ID excluído.
        TEmployee TemplateOwner;

        if (FEmployeeRepository == nullptr ||
            !FEmployeeRepository->FindById(
                Template.EmployeeId,
                TemplateOwner))
        {
            continue;
        }

        if (Trim(Template.FaceKey).IsEmpty() ||
            Trim(TemplateOwner.FaceKey).IsEmpty() ||
            !SameText(
                Trim(Template.FaceKey),
                Trim(TemplateOwner.FaceKey)))
        {
            continue;
        }

        const double Score =
            FFaceRecognizer->Compare(
                Feature,
                Template.Feature);

        if (Score > Result.Score)
        {
            Result.Score = Score;
            Result.EmployeeId = Template.EmployeeId;
        }
    }

    Result.Recognized = Result.EmployeeId > 0 &&
        Result.Score >= FConfig.FaceRecognitionThreshold;
    if (!Result.Recognized && Result.Score > FLastUnknownTestScore)
    {
        FLastUnknownTestScore = Result.Score;
    }
    return Result;
}

bool TMainForm::BuildEnrollmentTemplate(FaceFeature& Template) const
{
    Template.Values.clear();
    if (FEnrollmentSamples.empty())
    {
        return false;
    }

    const size_t FeatureSize = FEnrollmentSamples[0].Values.size();
    if (FeatureSize == 0)
    {
        return false;
    }

    Template.Values.assign(FeatureSize, 0.0f);
    for (const FaceFeature& Sample : FEnrollmentSamples)
    {
        if (Sample.Values.size() != FeatureSize)
        {
            Template.Values.clear();
            return false;
        }

        for (size_t Index = 0; Index < FeatureSize; ++Index)
        {
            Template.Values[Index] += Sample.Values[Index];
        }
    }

    double Norm = 0.0;
    for (float& Value : Template.Values)
    {
        Value /= static_cast<float>(FEnrollmentSamples.size());
        Norm += static_cast<double>(Value) * Value;
    }

    Norm = std::sqrt(Norm);
    if (Norm <= 0.0)
    {
        Template.Values.clear();
        return false;
    }

    for (float& Value : Template.Values)
    {
        Value = static_cast<float>(Value / Norm);
    }
    return true;
}

void TMainForm::BeginFaceEnrollment()
{
    TEmployee Employee;
    if (!TryGetSelectedEmployee(Employee))
    {
        LblDeveloperStatus->Caption = L"Selecione um funcionário real antes de iniciar o cadastro de identificação facial.";
        return;
    }

    // IMPORTANTE:
    // Um ReturnTimer pendente de uma tentativa anterior de reconhecimento pode
    // disparar durante o cadastro e chamar ResetFacePreviewState(), que zera
    // FEnrollmentActive. Isso fazia o fluxo abandonar o enrollment no meio e
    // voltar para "Pessoa não reconhecida".
    if (ReturnTimer != nullptr)
    {
        ReturnTimer->Enabled = false;
        ReturnTimer->Interval = 5000;
    }

    // Enrollment iniciado manualmente pela própria Portaria.
    // Não deve responder a nenhuma request remota anterior.
    FRemoteEnrollmentRequestId = L"";
    FRemoteEnrollmentEmployeeName = L"";

    FEnrollmentActive = true;
    FEnrollmentEmployeeId = Employee.Id;
    FEnrollmentSamples.clear();
    FRecognitionCandidateId = 0;
    FRecognitionCandidateHits = 0;
    FFacePreviewState = TFacePreviewState::Enrolling;
    EmployeeResultPanel->Visible = false;

    // Guarda uma mensagem administrativa para quando o operador voltar à tela
    // de funcionários, mas executa o cadastro no preview principal da câmera.
    LblDeveloperStatus->Caption =
        L"Cadastro de identificação facial iniciado para " + Employee.Name +
        L". Aguarde a captura das 8 amostras.";

    // O cadastro de identificação facial precisa ser visual: após selecionar o funcionário,
    // voltamos automaticamente à tela principal, onde o usuário vê a webcam,
    // o bounding box e o contador 0/8 ... 8/8.
    ShowIdentification();

    ApplyFacePreviewStatus();
}


void TMainForm::BeginRemoteFaceEnrollment(
    int EmployeeId,
    const UnicodeString& EmployeeName,
    const UnicodeString& RequestId)
{
    if (RequestId.IsEmpty() || EmployeeId <= 0)
        return;

    // /api/enrollment/pending permanece "pending" durante a captura.
    // Se o mesmo RequestId aparecer novamente, apenas ignore-o.
    if (FEnrollmentActive)
    {
        if (!FRemoteEnrollmentRequestId.IsEmpty() &&
            SameText(
                Trim(FRemoteEnrollmentRequestId),
                Trim(RequestId)))
        {
            return;
        }

        SendEnrollmentResultToErp(
            RequestId,
            L"failed",
            L"Terminal ocupado com outro cadastro de identificação facial",
            0);
        return;
    }

    TEmployee Employee;

    if (FEmployeeRepository == nullptr ||
        !FEmployeeRepository->FindById(EmployeeId, Employee))
    {
        SendEnrollmentResultToErp(
            RequestId,
            L"failed",
            L"EmployeeId não encontrado no repositório da Portaria",
            0);

        LblDeveloperStatus->Caption =
            L"Cadastro remoto recusado: EmployeeId " +
            IntToStr(EmployeeId) +
            L" não existe no repositório da Portaria.";

        return;
    }

    if (FCameraManager == nullptr || !FCameraManager->IsOpen())
    {
        SendEnrollmentResultToErp(
            RequestId,
            L"failed",
            L"Câmera indisponível na Portaria",
            0);
        return;
    }

    if (FFaceRecognizer == nullptr ||
        !FFaceRecognizer->IsInitialized() ||
        FFaceRepository == nullptr)
    {
        SendEnrollmentResultToErp(
            RequestId,
            L"failed",
            L"Face Engine indisponível na Portaria",
            0);
        return;
    }

    if (ReturnTimer != nullptr)
    {
        ReturnTimer->Enabled = false;
        ReturnTimer->Interval = 5000;
    }

    FRemoteEnrollmentRequestId = RequestId;
    FRemoteEnrollmentEmployeeName =
        EmployeeName.IsEmpty()
            ? Employee.Name
            : EmployeeName;

    FEnrollmentActive = true;
    FEnrollmentEmployeeId = EmployeeId;
    FEnrollmentSamples.clear();
    FRecognitionCandidateId = 0;
    FRecognitionCandidateHits = 0;
    FFacePreviewState = TFacePreviewState::Enrolling;

    if (EmployeeResultPanel != nullptr)
        EmployeeResultPanel->Visible = false;

    LblDeveloperStatus->Caption =
        L"Cadastro de identificação facial solicitado pelo ERP para " +
        FRemoteEnrollmentEmployeeName +
        L". Aguarde a captura das 8 amostras.";

    // Confirma diretamente ao ERP que a captura foi iniciada.
    SendDirectEnrollmentProgress(
        RequestId,
        L"Portaria iniciou a captura da identificação facial",
        0);

    ShowIdentification();
    ApplyFacePreviewStatus();
}

void TMainForm::ProcessRemoteBiometricRevoke(
    int EmployeeId,
    const UnicodeString& EmployeeName,
    const UnicodeString& RequestId)
{
    if (RequestId.IsEmpty() || EmployeeId <= 0)
        return;

    // Se houver cadastro do MESMO funcionário em andamento,
    // a revogação prevalece e cancela o enrollment.
    if (FEnrollmentActive &&
        FEnrollmentEmployeeId == EmployeeId)
    {
        const UnicodeString EnrollmentRequestId =
            FRemoteEnrollmentRequestId;

        FEnrollmentActive = false;
        FEnrollmentEmployeeId = 0;
        FEnrollmentSamples.clear();
        FRemoteEnrollmentRequestId = L"";
        FRemoteEnrollmentEmployeeName = L"";

        if (!EnrollmentRequestId.IsEmpty())
        {
            SendEnrollmentResultToErp(
                EnrollmentRequestId,
                L"failed",
                L"Cadastro cancelado por remoção da identificação facial",
                0);
        }
    }

    const bool Existed =
        FFaceRepository != nullptr &&
        FFaceRepository->HasTemplate(EmployeeId);

    const bool Removed =
        FFaceRepository != nullptr &&
        FFaceRepository->DeleteTemplate(EmployeeId);

    if (Removed &&
        FRecognizedEmployeeId == EmployeeId)
    {
        ClearRecognizedFaceResult();
    }

    SendRevokeResultToErp(
        RequestId,
        Removed ? L"completed" : L"failed",
        Removed
            ? (Existed
                ? L"Template facial removido"
                : L"Template facial já estava ausente")
            : L"Falha ao remover o template facial");

    LblDeveloperStatus->Caption =
        Removed
            ? L"Identificação facial removida para EmployeeId " +
                IntToStr(EmployeeId) +
                (EmployeeName.IsEmpty()
                    ? L"."
                    : L" • " + EmployeeName)
            : L"Falha ao remover identificação facial do EmployeeId " +
                IntToStr(EmployeeId) + L".";
}

void TMainForm::ProcessPendingBiometricCommands()
{
    // Se um resultado final não conseguiu chegar ao ERP, tente novamente.
    // Enquanto ele estiver pendente, não inicie outro cadastro remoto.
    const bool EnrollmentResultChannelReady =
        FlushPendingEnrollmentResultToErp();

    const bool EmployeesReady =
        FEmployeeRepository != nullptr &&
        FEmployeeRepository->HasRemoteSnapshot();

    if (EmployeesReady && EnrollmentResultChannelReady)
    {
        const bool RemoteEnrollmentAlreadyActive =
            FEnrollmentActive &&
            !FRemoteEnrollmentRequestId.IsEmpty();

        if (!RemoteEnrollmentAlreadyActive)
        {
            TErpEnrollmentCommand EnrollmentCommand;

            if (TryGetPendingEnrollmentFromErp(
                    EnrollmentCommand))
            {
                BeginRemoteFaceEnrollment(
                    EnrollmentCommand.EmployeeId,
                    EnrollmentCommand.EmployeeName,
                    EnrollmentCommand.RequestId);
            }
        }
    }
    else if (!EmployeesReady && FEmployeeSyncClient != nullptr)
    {
        FEmployeeSyncClient->SyncNow();
    }

    // Remoção de identificação facial também usa o canal operacional
    // direto do ERP Delphi :3101. O WebServer :8080 não participa.
    const bool RevokeResultChannelReady =
        FlushPendingRevokeResultToErp();

    if (RevokeResultChannelReady)
    {
        TErpRevokeCommand RevokeCommand;

        if (TryGetPendingRevokeFromErp(
                RevokeCommand))
        {
            ProcessRemoteBiometricRevoke(
                RevokeCommand.EmployeeId,
                RevokeCommand.EmployeeName,
                RevokeCommand.RequestId);
        }
    }
}

void TMainForm::CompleteFaceEnrollment()
{
    const int SavedEmployeeId = FEnrollmentEmployeeId;
    const int SampleCount =
        static_cast<int>(FEnrollmentSamples.size());

    const UnicodeString RemoteRequestId =
        FRemoteEnrollmentRequestId;

    FaceFeature Template;

    const bool Built =
        BuildEnrollmentTemplate(Template);

    TEmployee EnrollmentEmployee;

    const bool EmployeeResolved =
        FEmployeeRepository != nullptr &&
        FEmployeeRepository->FindById(
            SavedEmployeeId,
            EnrollmentEmployee);

    const bool IdentityReady =
        EmployeeResolved &&
        !Trim(EnrollmentEmployee.FaceKey).IsEmpty();

    const bool Saved =
        Built &&
        IdentityReady &&
        FFaceRepository != nullptr &&
        FFaceRepository->SaveTemplate(
            SavedEmployeeId,
            EnrollmentEmployee.FaceKey,
            Template);

    if (Saved && FFaceRecognizer != nullptr)
    {
        FLastCorrectTestScore =
            FFaceRecognizer->Compare(
                Template,
                Template);
    }

    FEnrollmentActive = false;
    FEnrollmentEmployeeId = 0;
    FEnrollmentSamples.clear();

    FFacePreviewState =
        Saved
            ? TFacePreviewState::Detected
            : TFacePreviewState::NotRecognized;

    LblDeveloperStatus->Caption =
        Saved
            ? Format(
                L"Identificação facial salva para EmployeeId %d.",
                ARRAYOFCONST((SavedEmployeeId)))
            : L"Falha ao salvar o template de identificação facial.";

    // Cadastro remoto: resultado volta diretamente ao ERP Delphi :3101.
    if (!RemoteRequestId.IsEmpty())
    {
        SendEnrollmentResultToErp(
            RemoteRequestId,
            Saved ? L"completed" : L"failed",
            Saved
                ? L"Template salvo pela Portaria"
                : L"Falha ao salvar o template de identificação facial",
            SampleCount);
    }

    FRemoteEnrollmentRequestId = L"";
    FRemoteEnrollmentEmployeeName = L"";

    ApplyFacePreviewStatus();
}

void TMainForm::RejectFaceRecognition()
{
    // Se já estamos exibindo o resultado negativo, não rearmar o timer a cada
    // frame. Isso evita alternância em milissegundos entre Ready e NotRecognized.
    if (FFacePreviewState == TFacePreviewState::NotRecognized &&
        ReturnTimer != nullptr && ReturnTimer->Enabled)
    {
        return;
    }

    FRecognitionCandidateId = 0;
    FRecognitionCandidateHits = 0;
    FFacePreviewState = TFacePreviewState::NotRecognized;
    EmployeeResultPanel->Visible = false;

    if (ReturnTimer != nullptr)
    {
        ReturnTimer->Enabled = false;

        // Só rearma o retorno automático se o usuário continua realmente
        // na tela principal e o menu está fechado.
        if ((OverlayMenu == nullptr || !OverlayMenu->Visible) &&
            FCurrentPage == TAccessPage::Identification)
        {
            ReturnTimer->Interval = 2000;
            ReturnTimer->Enabled = true;
        }
    }

    ApplyFacePreviewStatus();
}

void TMainForm::ClearRecognizedFaceResult()
{
    FFaceRecognitionLocked = false;
    FRecognizedEmployeeId = 0;
    FRecognitionCandidateId = 0;
    FRecognitionCandidateHits = 0;
    FFacePreviewState = TFacePreviewState::Waiting;
    FIdentificationState = IdentificationState::WaitingForFace;
    FFaceMissFrames = 0;
    FSingleFaceFrames = 0;
    FStableFaceStartTick = 0;
    FLastFaceDetections.clear();
    FHasPrimaryFace = false;
    FPrimaryFaceDetection = FaceDetection();

    if (FIdentificationManager != nullptr)
    {
        FIdentificationManager->ClearIdentification();
    }

    if (EmployeeResultPanel != nullptr)
    {
        EmployeeResultPanel->Visible = false;
    }

    if (FEmployeePhotoImage != nullptr)
    {
        FEmployeePhotoImage->Visible = false;
    }

    if (FRecognitionCheckShape != nullptr)
    {
        FRecognitionCheckShape->Visible = false;
    }
    if (FRecognitionCheckLabel != nullptr)
    {
        FRecognitionCheckLabel->Visible = false;
    }

    LblPrompt->Caption = L"Aproxime-se para identificação";
    LblPrompt->Font->Color = RgbColor(245, 190, 79);

    LayoutTerminal();
    ApplyFacePreviewStatus();
}

void TMainForm::UpdateEmployeePhotoSnapshot(const TCameraFrame& Frame,
    const FaceDetection& Detection)
{
    if (FEmployeePhotoImage == nullptr || FEmployeePhotoBitmap == nullptr ||
        Frame.Empty() || Detection.Bounds.Empty())
    {
        return;
    }

    std::unique_ptr<Graphics::TBitmap> SourceBitmap(new Graphics::TBitmap());
    if (!FrameToBitmap(Frame, SourceBitmap.get()))
    {
        return;
    }

    const FaceRect& B = Detection.Bounds;

    // O card usa uma foto quadrada. Antes o recorte tinha proporção variável
    // e era forçado para 180x180, achatando/espremendo o rosto.
    // Agora geramos um crop quadrado ao redor da face.
    const double CenterX = B.X + (B.Width * 0.5);
    const double CenterY = B.Y + (B.Height * 0.48);

    int CropSize = static_cast<int>(std::round(
        std::max(B.Width * 1.55, B.Height * 1.35)));

    CropSize = std::max(96, CropSize);
    CropSize = std::min(CropSize, std::min(Frame.Width, Frame.Height));

    int Left = static_cast<int>(std::round(CenterX - (CropSize * 0.5)));
    int Top = static_cast<int>(std::round(CenterY - (CropSize * 0.48)));

    // Mantém o quadrado inteiro dentro do frame sem alterar a proporção.
    Left = std::max(0, std::min(Left, Frame.Width - CropSize));
    Top = std::max(0, std::min(Top, Frame.Height - CropSize));

    const int Right = Left + CropSize;
    const int Bottom = Top + CropSize;

    if (Right <= Left || Bottom <= Top)
    {
        return;
    }

    const int TargetSize = 220;
    FEmployeePhotoBitmap->PixelFormat = pf32bit;
    FEmployeePhotoBitmap->SetSize(TargetSize, TargetSize);

    // IMPORTANTE:
    // TCanvas::StretchDraw() recebe apenas o retângulo de DESTINO e desenha
    // o bitmap inteiro. O SourceRect calculado anteriormente não era usado,
    // por isso o frame 16:9 completo estava sendo espremido em um quadrado.
    //
    // StretchBlt permite informar explicitamente o retângulo de origem
    // (crop quadrado da face) e o destino quadrado.
    SetStretchBltMode(FEmployeePhotoBitmap->Canvas->Handle, HALFTONE);
    SetBrushOrgEx(FEmployeePhotoBitmap->Canvas->Handle, 0, 0, nullptr);

    StretchBlt(
        FEmployeePhotoBitmap->Canvas->Handle,
        0, 0, TargetSize, TargetSize,
        SourceBitmap->Canvas->Handle,
        Left, Top, CropSize, CropSize,
        SRCCOPY);

    FEmployeePhotoImage->Picture->Assign(FEmployeePhotoBitmap);
    FEmployeePhotoImage->Stretch = true;
    FEmployeePhotoImage->Proportional = true;
    FEmployeePhotoImage->Center = true;
    FEmployeePhotoImage->Visible = true;
    LblPhoto->Visible = false;
}

void __fastcall TMainForm::MenuHoverEnter(TObject* Sender)
{
    (void)Sender;
    if (BtnMenu != nullptr)
    {
        BtnMenu->Color = RgbColor(232, 44, 54);
        BtnMenu->Font->Size = 12;
        BtnMenu->Cursor = crHandPoint;
    }
}

void __fastcall TMainForm::MenuHoverLeave(TObject* Sender)
{
    (void)Sender;
    if (BtnMenu != nullptr)
    {
        BtnMenu->Color = RgbColor(198, 32, 42);
        BtnMenu->Font->Size = 11;
    }
}

void TMainForm::UpdateClock()
{
    const TDateTime NowValue = Now();
    LblClock->Caption = FormatDateTime(L"hh:nn", NowValue);
    LblDate->Caption = FormatDateTime(L"dddd, dd \"de\" mmmm \"de\" yyyy", NowValue);
}

void TMainForm::RefreshIdentificationView()
{
    ApplyFacePreviewStatus();
    LblCameraStatus->Caption =
        L"● Câmera " + FCameraManager->StatusText() +
        L" • índice " + IntToStr(FPreviewCameraIndex);

    if (!FIdentificationManager->HasCurrentEmployee())
    {
        if (FFacePreviewState != TFacePreviewState::Recognized)
        {
            EmployeeResultPanel->Visible = false;
        }
        UpdateCameraPreviewVisibility();
        ApplyFacePreviewStatus();
        return;
    }

    const TEmployee Employee = FIdentificationManager->CurrentEmployee();
    EmployeeResultPanel->Visible = true;
    EmployeeResultPanel->BringToFront();
    ShapeFaceFrame->Pen->Color = RgbColor(41, 214, 132);
    LblPrompt->Caption = L"ACESSO AUTORIZADO";
    LblPrompt->Font->Color = RgbColor(41, 214, 132);
    LblEmployeeState->Caption = L"IDENTIDADE CONFIRMADA";
    LblName->Caption = Employee.Name;
    LblDepartment->Caption = Employee.Department;
    LblIdentifiedAt->Caption = FormatDateTime(L"hh:nn:ss", FIdentificationManager->IdentifiedAt());
    LblFaceIndicator->Caption = L"FACE";
    LblFaceStatusDetail->Caption = L"● Confirmada";
    LblFaceIndicator->Font->Color = RgbColor(164, 176, 194);
    LblFaceStatusDetail->Font->Color = RgbColor(41, 214, 132);
    ApplyRfidStatus();
    UpdateCameraPreviewVisibility();
}

void TMainForm::ShowPage(TAccessPage Page)
{
    const TAccessPage PreviousPage = FCurrentPage;
    FCurrentPage = Page;

    if (Page == TAccessPage::BleDevices &&
        PreviousPage != TAccessPage::BleDevices)
    {
        // Uma leitura usada anteriormente para acesso não deve virar,
        // por acidente, candidata de cadastro administrativo.
        FRfidAdminUid = UnicodeString();
    }

    // A enumeração das câmeras é feita uma vez por execução.
    // Reabrir o menu não deve fechar/probar/reabrir todos os dispositivos,
    // pois isso pode alterar o comportamento do backend de captura.
    CloseMenu();

    if (Page == TAccessPage::Identification)
    {
        ShowIdentification();
        return;
    }

    ReturnTimer->Enabled = false;
    IdentificationView->Visible = false;
    SecondaryView->Visible = true;
    SecondaryView->BringToFront();
    LblAdminTitle->Caption = PageTitle(Page);
    LblAdminDescription->Caption = PageDescription(Page);
    UpdateDeveloperPanel();
    UpdateMenuSelection();
    LayoutTerminal();
}

void TMainForm::ShowIdentification()
{
    FCurrentPage = TAccessPage::Identification;
    SecondaryView->Visible = false;
    IdentificationView->Visible = true;
    IdentificationView->BringToFront();
    if (FTechBackground != nullptr)
    {
        FTechBackground->SendToBack();
        FTechBackground->Invalidate();
    }
    DeveloperPanel->Visible = false;
    CloseMenu();
    RefreshIdentificationView();
    UpdateDeveloperPanel();
    UpdateMenuSelection();

    if (FTechBackground != nullptr)
    {
        FTechBackground->SendToBack();
        FTechBackground->Invalidate();
    }

    if (FHeaderDecor != nullptr)
        FHeaderDecor->Invalidate();

    if (FCameraDecor != nullptr)
        FCameraDecor->Invalidate();

    if (FFooterDecor != nullptr)
        FFooterDecor->Invalidate();

    if (FProductVersion != nullptr)
    {
        FProductVersion->Visible = true;
        FProductVersion->BringToFront();
    }

}

void TMainForm::OpenMenu()
{
    // O menu deve ser independente do resultado da identificação facial.
    // Cancela qualquer retorno automático armado por "Pessoa não reconhecida".
    if (ReturnTimer != nullptr)
    {
        ReturnTimer->Enabled = false;
        ReturnTimer->Interval = 5000;
    }

    OverlayMenu->Visible = true;
    OverlayMenu->BringToFront();

    UpdateMenuSelection();
    LayoutTerminal();

    // LayoutTerminal reorganiza a interface. Garanta novamente o Z-order do menu.
    OverlayMenu->BringToFront();
}

void TMainForm::CloseMenu()
{
    OverlayMenu->Visible = false;
}


bool TMainForm::IsTotemLayout() const
{
    if (FLayoutMode == TTerminalLayoutMode::TotemVertical)
    {
        return true;
    }

    if (FLayoutMode == TTerminalLayoutMode::Horizontal)
    {
        return false;
    }

    // Automático: uma pequena histerese visual não é necessária porque
    // FormResize só relayouta os controles; não reinicia câmera/identificação facial.
    return ClientHeight > ClientWidth;
}

UnicodeString TMainForm::LayoutModeCaption() const
{
    switch (FLayoutMode)
    {
    case TTerminalLayoutMode::Horizontal:
        return L"HORIZONTAL";
    case TTerminalLayoutMode::TotemVertical:
        return L"TOTEM";
    default:
        return L"AUTOMÁTICO";
    }
}

void TMainForm::CycleLayoutMode()
{
    switch (FLayoutMode)
    {
    case TTerminalLayoutMode::Auto:
        FLayoutMode = TTerminalLayoutMode::Horizontal;
        break;
    case TTerminalLayoutMode::Horizontal:
        FLayoutMode = TTerminalLayoutMode::TotemVertical;
        break;
    default:
        FLayoutMode = TTerminalLayoutMode::Auto;
        break;
    }

    ResetFacePreviewState();
    UpdateDeveloperPanel();
    LayoutTerminal();
}

TCameraRotationMode TMainForm::EffectiveCameraRotation() const
{
    if (FCameraRotationMode != TCameraRotationMode::Auto)
    {
        return FCameraRotationMode;
    }

    return IsTotemLayout()
        ? TCameraRotationMode::Deg90CCW
        : TCameraRotationMode::Deg0;
}

UnicodeString TMainForm::CameraRotationCaption() const
{
    switch (FCameraRotationMode)
    {
    case TCameraRotationMode::Deg0:
        return L"0°";
    case TCameraRotationMode::Deg90CW:
        return L"90° →";
    case TCameraRotationMode::Deg90CCW:
        return L"90° ←";
    case TCameraRotationMode::Deg180:
        return L"180°";
    default:
        return L"AUTO";
    }
}

void TMainForm::CycleCameraRotation()
{
    switch (FCameraRotationMode)
    {
    case TCameraRotationMode::Auto:
        FCameraRotationMode = TCameraRotationMode::Deg0;
        break;
    case TCameraRotationMode::Deg0:
        FCameraRotationMode = TCameraRotationMode::Deg90CW;
        break;
    case TCameraRotationMode::Deg90CW:
        FCameraRotationMode = TCameraRotationMode::Deg90CCW;
        break;
    case TCameraRotationMode::Deg90CCW:
        FCameraRotationMode = TCameraRotationMode::Deg180;
        break;
    default:
        FCameraRotationMode = TCameraRotationMode::Auto;
        break;
    }

    ResetFacePreviewState();
    UpdateDeveloperPanel();
    LayoutTerminal();
}

void TMainForm::LayoutOverlayMenu(bool TotemMode)
{
    if (OverlayMenu == nullptr)
    {
        return;
    }

    OverlayMenu->Color = RgbColor(4, 12, 20);
    OverlayMenu->BevelOuter = bvNone;

	BtnMenuBack->Color = RgbColor(61, 61, 61);
    BtnMenuBack->Font->Name = L"Segoe UI Semibold";
    BtnMenuBack->Font->Size = TotemMode ? 10: 10;
    BtnMenuBack->Font->Color = clWhite;

	LblMenuHeader->Font->Name = L"Segoe UI";
    LblMenuHeader->Font->Size = TotemMode ? 10 : 10;
    LblMenuHeader->Font->Color = clWhite;

    LblMenuFooter->Font->Name = L"Segoe UI";
    LblMenuFooter->Font->Size = 8;
    LblMenuFooter->Font->Color = RgbColor(111, 145, 175);

    const int RootWidth = RootPanel->ClientWidth;
    const int RootHeight = RootPanel->ClientHeight;

    int MenuWidth = 0;
    int MenuLeft = 0;

    if (TotemMode)
    {
        // No totem, o menu vira uma folha quase de largura total.
        MenuWidth = std::max(360, RootWidth - 28);
        MenuLeft = (RootWidth - MenuWidth) / 2;
    }
    else
    {
        MenuWidth = ClampInt(RootWidth * 30 / 100, 460, 560);
        MenuLeft = RootWidth - MenuWidth;
    }

    OverlayMenu->SetBounds(MenuLeft, 0, MenuWidth, RootHeight);

    const int Side = TotemMode ? 24 : 28;
    const int ContentWidth = MenuWidth - (Side * 2);

    BtnMenuBack->SetBounds(Side, 24, ContentWidth, 58);
    LblMenuHeader->SetBounds(Side, 102, ContentWidth, 42);

    TPanel* Panels[] = {
        MenuIdentification, MenuPresent, MenuRecent, MenuCamera,
        MenuBle, MenuManual, MenuOccurrences, MenuSettings
    };

    TLabel* Icons[] = {
        LblMenuIdentificationIcon, LblMenuPresentIcon, LblMenuRecentIcon,
        LblMenuCameraIcon, LblMenuBleIcon, LblMenuManualIcon,
        LblMenuOccurrencesIcon, LblMenuSettingsIcon
    };

    TLabel* Titles[] = {
        LblMenuIdentificationTitle, LblMenuPresentTitle, LblMenuRecentTitle,
        LblMenuCameraTitle, LblMenuBleTitle, LblMenuManualTitle,
		LblMenuOccurrencesTitle, LblMenuSettingsTitle
    };

    TLabel* Descs[] = {
        LblMenuIdentificationDesc, LblMenuPresentDesc, LblMenuRecentDesc,
        LblMenuCameraDesc, LblMenuBleDesc, LblMenuManualDesc,
        LblMenuOccurrencesDesc, LblMenuSettingsDesc
    };

    TLabel* Arrows[] = {
        LblMenuIdentificationArrow, LblMenuPresentArrow, LblMenuRecentArrow,
        LblMenuCameraArrow, LblMenuBleArrow, LblMenuManualArrow,
        LblMenuOccurrencesArrow, LblMenuSettingsArrow
    };

    const int ItemHeight = TotemMode ? 88 : 96;
    const int ItemGap = TotemMode ? 9 : 12;
    int Y = 154;

    for (int I = 0; I < 8; ++I)
    {
        Panels[I]->BevelOuter = bvNone;
        Panels[I]->SetBounds(Side, Y, ContentWidth, ItemHeight);

        Icons[I]->Font->Name = L"Segoe UI Semibold";
        Icons[I]->Font->Size = TotemMode ? 15 : 17;
        Icons[I]->Font->Color = RgbColor(214, 229, 241);

        Titles[I]->Font->Name = L"Segoe UI Semibold";
        Titles[I]->Font->Size = TotemMode ? 11 : 12;
        Titles[I]->Font->Color = clWhite;

        Descs[I]->Font->Name = L"Segoe UI";
        Descs[I]->Font->Size = TotemMode ? 8 : 9;
        Descs[I]->Font->Color = RgbColor(177, 196, 214);

        Arrows[I]->Font->Name = L"Segoe UI Semibold";
        Arrows[I]->Font->Size = TotemMode ? 14 : 15;
        Arrows[I]->Font->Color = RgbColor(225, 236, 245);

        const int IconWidth = TotemMode ? 64 : 76;
        Icons[I]->SetBounds(12, 0, IconWidth, ItemHeight);

        const int TextLeft = IconWidth + 20;
        const int ArrowWidth = 42;
        const int TextWidth = ContentWidth - TextLeft - ArrowWidth - 10;

        Titles[I]->AutoSize = false;
        Titles[I]->WordWrap = false;
        Titles[I]->SetBounds(TextLeft, 14, TextWidth, 30);

        Descs[I]->AutoSize = false;
        Descs[I]->WordWrap = false;
        Descs[I]->SetBounds(TextLeft, 46, TextWidth, 25);

        Arrows[I]->SetBounds(ContentWidth - ArrowWidth - 8, 0,
            ArrowWidth, ItemHeight);

        Y += ItemHeight + ItemGap;
    }

    LblMenuFooter->SetBounds(Side, RootHeight - 46, ContentWidth, 28);
}

void TMainForm::LayoutTerminal()
{
    const bool PortraitMode = ClientHeight > ClientWidth;
	// Base visual corporativa.
	// fundo quase preto, mas com azul para separar
	// visualmente o terminal de uma janela VCL comum.
	const TColor BackgroundColor = RgbColor(13, 9, 15);
	const TColor CardColor = RgbColor(7, 20, 32);
	const TColor SubtleTextColor = RgbColor(170, 181, 194);
	const TColor BorderTextColor = RgbColor(219, 225, 232);

	const bool TotemMode = IsTotemLayout();
	const bool ShowRecognizedCard =
		EmployeeResultPanel != nullptr && EmployeeResultPanel->Visible;

	// Cabeçalho empresarial TSX. Nesta etapa usamos texto;
	// depois o mesmo espaço receberá o logo definitivo compartilhado com o ERP Delphi.
	LblAppName->Visible = true;
	LblAppName->Caption = L"C++Builder 13.1 Florence";
	LblClock->Visible = true;

	FaceStatusCard->Visible = false;
	BleStatusCard->Visible = false;
	LblCameraStatus->Visible = false;

	TopBarPanel->Align = alTop;
	ClockPanel->Align = alTop;

	// O bloco inferior acompanha a câmera, sem ficar preso ao rodapé da janela.
	// Isso elimina o vazio entre câmera e identificação.
	BottomStatusPanel->Align = alNone;
	PageHost->Align = alClient;
	IdentificationView->Align = alClient;

	// A câmera é posicionada manualmente apenas nesta página.
	// Isso permite que o card tenha exatamente a altura do vídeo 16:9,
    // sem áreas vazias e sem deformar a imagem.
    CameraPanel->Align = alNone;

    TopBarPanel->Height = TotemMode ? 56 : 60;
    ClockPanel->Height = PortraitMode ? 126 : 144;
    BottomStatusPanel->Height = ShowRecognizedCard
        ? (TotemMode ? 242 : 238)
        : (TotemMode ? 150 : 146);

    // Cabeçalho empresarial: marca à esquerda, terminal/status à direita.
    LblAppName->SetBounds(
        TotemMode ? 18 : 24,
        14,
        TotemMode ? 430 : 620,
        30);
    LblAppName->Font->Name = L"Segoe UI Semibold";
    LblAppName->Font->Size = PortraitMode ? 8 : (TotemMode ? 9 : 10);
    LblAppName->Font->Color = clWhite;
    if (FBrandSubtitle != nullptr)
    {
        FBrandSubtitle->Visible = false;
    }
    LblAppName->Font->Name = L"Segoe UI Semibold";
	LblAppName->Font->Size = TotemMode ? 11 : 11;
	LblAppName->Caption = L"C++Builder 13.1 - FLORENCE";
    TopBarPanel->Color = RgbColor(2, 7, 12);
    TopBarPanel->BevelOuter = bvNone;
    if (FHeaderDecor != nullptr)
    {
        FHeaderDecor->Visible = true;
        FHeaderDecor->SendToBack();
        FHeaderDecor->Invalidate();
    }
    TopBarPanel->Height = TotemMode ? 64 : 70;

    LblTerminal->SetBounds(
        TotemMode ? TopBarPanel->ClientWidth - 245 :
            TopBarPanel->ClientWidth - 290,
        18,
        TotemMode ? 125 : 155,
        26);

    LblOnline->SetBounds(
        TotemMode ? TopBarPanel->ClientWidth - 116 :
            TopBarPanel->ClientWidth - 124,
        18, 108, 26);

    if (PortraitMode)
    {
        // Cabeçalho compacto para orientação vertical.
        LblAppName->SetBounds(14, 12, TopBarPanel->ClientWidth - 28, 24);
        LblAppName->Alignment = taLeftJustify;
        LblAppName->Font->Size = 8;

        if (FBrandSubtitle != nullptr)
            FBrandSubtitle->Visible = false;

        LblTerminal->SetBounds(
            std::max(14, TopBarPanel->ClientWidth - 210),
            12,
            112,
            24);

        LblOnline->SetBounds(
            std::max(126, TopBarPanel->ClientWidth - 96),
            12,
            84,
            24);

        LblTerminal->Font->Size = 9;
        LblOnline->Font->Size = 9;
    }

    // Relógio no estilo terminal comercial: grande, centralizado e com
    // altura suficiente para não cortar os dígitos em DPI alto.
    LblClock->Align = alNone;
    LblClock->Alignment = taCenter;
    LblClock->Layout = tlCenter;
    LblClock->Font->Name = L"Segoe UI Light";
    LblClock->Font->Size = PortraitMode ? 30 : (TotemMode ? 36 : 42);
    LblClock->SetBounds(0, 8, ClockPanel->ClientWidth, PortraitMode ? 86 : 100);

    LblDate->Align = alNone;
    LblDate->Alignment = taCenter;
    LblDate->Layout = tlCenter;
    LblDate->Font->Name = L"Segoe UI";
    LblDate->Font->Size = PortraitMode ? 9 : (TotemMode ? 10 : 11);
    LblDate->SetBounds(0, PortraitMode ? 92 : 110, ClockPanel->ClientWidth, 28);

    // -----------------------------------------------------------------
    // Páginas administrativas / secundárias
    // -----------------------------------------------------------------
    SecondaryView->Align = alClient;

    if (SecondaryView->Visible)
    {
        const int SecondaryWidth = SecondaryView->ClientWidth;
        const int SecondaryHeight = SecondaryView->ClientHeight;

        const int SideMargin = TotemMode ? 24 : 56;
        const int ContentWidth = std::max(320, SecondaryWidth - (SideMargin * 2));

        BtnBackFromPage->Align = alNone;
        BtnBackFromPage->Align = alNone;
        BtnBackFromPage->AutoSize = false;
        BtnBackFromPage->Font->Name = L"Segoe UI Semibold";
        BtnBackFromPage->Font->Size = TotemMode ? 9 : 10;
        BtnBackFromPage->Alignment = taCenter;
        BtnBackFromPage->SetBounds(
            SideMargin,
            TotemMode ? 18 : 26,
            TotemMode ? std::min(330, ContentWidth) : 350,
            50);

        LblAdminTitle->Align = alNone;
        LblAdminTitle->AutoSize = false;
        LblAdminTitle->WordWrap = false;
        LblAdminTitle->Alignment = taLeftJustify;
        LblAdminTitle->Layout = tlCenter;
        LblAdminTitle->Font->Name = L"Segoe UI Semibold";
        LblAdminTitle->Font->Size = TotemMode ? 14 : 14;
        LblAdminTitle->SetBounds(
            SideMargin,
            TotemMode ? 88 : 102,
            ContentWidth,
            46);

        LblAdminDescription->Align = alNone;
        LblAdminDescription->AutoSize = false;
        LblAdminDescription->WordWrap = true;
        LblAdminDescription->Alignment = taLeftJustify;
        LblAdminDescription->Layout = tlTop;
        LblAdminDescription->Font->Name = L"Segoe UI";
        LblAdminDescription->Font->Size = TotemMode ? 9 : 10;
        LblAdminDescription->SetBounds(
            SideMargin,
            TotemMode ? 138 : 152,
            ContentWidth,
            TotemMode ? 58 : 48);

        if (FCurrentPage == TAccessPage::RecentEntries ||
            FCurrentPage == TAccessPage::PresentEmployees ||
            FCurrentPage == TAccessPage::ManualRelease ||
            FCurrentPage == TAccessPage::BleDevices ||
            FCurrentPage == TAccessPage::Incidents)
        {
            // Presença, histórico e liberação manual usam praticamente
            // toda a largura disponível.
            const int PanelTop = TotemMode ? 208 : 218;
            const int PanelHeight = std::max(
                280, SecondaryHeight - PanelTop - (TotemMode ? 24 : 34));

            DeveloperPanel->Align = alNone;
            DeveloperPanel->SetBounds(
                SideMargin,
                PanelTop,
                ContentWidth,
                PanelHeight);

            const int Inner = TotemMode ? 18 : 24;

            BtnSimulate->Font->Name = L"Segoe UI Semibold";
            BtnClear->Font->Name = L"Segoe UI Semibold";
            BtnStartCamera->Font->Name = L"Segoe UI Semibold";

            BtnSimulate->Font->Size = TotemMode ? 8 : 9;
            BtnClear->Font->Size = TotemMode ? 8 : 9;
            BtnStartCamera->Font->Size = TotemMode ? 8 : 9;

            LblDeveloperStatus->AutoSize = false;
            LblDeveloperStatus->WordWrap = false;
            LblDeveloperStatus->Alignment = taLeftJustify;
            LblDeveloperStatus->SetBounds(
                Inner,
                18,
                DeveloperPanel->ClientWidth - (Inner * 2),
                28);

            LstEmployees->SetBounds(
                Inner,
                58,
                DeveloperPanel->ClientWidth - (Inner * 2),
                std::max(150, DeveloperPanel->ClientHeight - 142));

            // Permite scroll horizontal caso um nome/setor excepcionalmente
            // longo ainda ultrapasse o espaço disponível.
            LstEmployees->ScrollWidth =
                std::max(LstEmployees->ClientWidth, 1100);

            if (FCurrentPage == TAccessPage::BleDevices)
            {
                // Faixa de leitura RFID dentro da própria área administrativa.
                // Assim o operador enxerga ONLINE/COM e o UID em tempo real,
                // sem precisar retornar à tela principal.
                if (FRfidReaderCard != nullptr)
                {
                    FRfidReaderCard->SetBounds(
                        Inner,
                        50,
                        DeveloperPanel->ClientWidth - (Inner * 2),
                        58);

                    if (FRfidReaderTitle != nullptr)
                        FRfidReaderTitle->SetBounds(
                            14, 7, 220, 20);

                    if (FRfidReaderStatus != nullptr)
                        FRfidReaderStatus->SetBounds(
                            std::max(240, FRfidReaderCard->ClientWidth - 390),
                            7,
                            376,
                            20);

                    if (FRfidReaderUid != nullptr)
                        FRfidReaderUid->SetBounds(
                            14,
                            30,
                            std::max(100, FRfidReaderCard->ClientWidth - 28),
                            22);

                    FRfidReaderCard->Visible = true;
                    FRfidReaderCard->BringToFront();
                }

                LstEmployees->SetBounds(
                    Inner,
                    118,
                    DeveloperPanel->ClientWidth - (Inner * 2),
                    std::max(105, DeveloperPanel->ClientHeight - 192));

                const int ButtonWidth = TotemMode ? 170 : 210;
                const int Gap = 16;
                const int ButtonsWidth = (ButtonWidth * 3) + (Gap * 2);
                const int ButtonsLeft =
                    std::max(Inner,
                        (DeveloperPanel->ClientWidth - ButtonsWidth) / 2);

                BtnSimulate->SetBounds(
                    ButtonsLeft,
                    DeveloperPanel->ClientHeight - 64,
                    ButtonWidth,
                    40);

                BtnClear->SetBounds(
                    ButtonsLeft + ButtonWidth + Gap,
                    DeveloperPanel->ClientHeight - 64,
                    ButtonWidth,
                    40);

                BtnStartCamera->SetBounds(
                    ButtonsLeft + ((ButtonWidth + Gap) * 2),
                    DeveloperPanel->ClientHeight - 64,
                    ButtonWidth,
                    40);

                BtnSimulate->Visible = true;
                BtnClear->Visible = true;
                BtnStartCamera->Visible = true;
                UpdateRfidAdminReader();
            }
            else if (FCurrentPage == TAccessPage::Incidents)
            {
                const int ButtonWidth = TotemMode ? 170 : 205;
                const int Gap = 12;
                const int ButtonCount = FIncidentHistoryMode ? 2 : 3;
                const int ButtonsWidth =
                    (ButtonWidth * ButtonCount) + (Gap * (ButtonCount - 1));
                const int ButtonsLeft =
                    std::max(Inner,
                        (DeveloperPanel->ClientWidth - ButtonsWidth) / 2);

                BtnSimulate->SetBounds(
                    ButtonsLeft,
                    DeveloperPanel->ClientHeight - 66,
                    ButtonWidth,
                    42);

                BtnClear->SetBounds(
                    ButtonsLeft + ButtonWidth + Gap,
                    DeveloperPanel->ClientHeight - 66,
                    ButtonWidth,
                    42);

                if (!FIncidentHistoryMode)
                {
                    BtnStartCamera->SetBounds(
                        ButtonsLeft + ((ButtonWidth + Gap) * 2),
                        DeveloperPanel->ClientHeight - 66,
                        ButtonWidth,
                        42);
                }
            }
            else if (FCurrentPage == TAccessPage::ManualRelease)
            {
                const int ButtonWidth = TotemMode ? 185 : 220;
                const int Gap = 14;
                const int ButtonsWidth = (ButtonWidth * 2) + Gap;
                const int ButtonsLeft =
                    std::max(Inner,
                        (DeveloperPanel->ClientWidth - ButtonsWidth) / 2);

                BtnSimulate->SetBounds(
                    ButtonsLeft,
                    DeveloperPanel->ClientHeight - 66,
                    ButtonWidth,
                    42);

                BtnClear->SetBounds(
                    ButtonsLeft + ButtonWidth + Gap,
                    DeveloperPanel->ClientHeight - 66,
                    ButtonWidth,
                    42);

                BtnSimulate->Visible = true;
            }
            else
            {
                BtnClear->SetBounds(
                    DeveloperPanel->ClientWidth - Inner - 220,
                    DeveloperPanel->ClientHeight - 64,
                    220,
                    40);

                BtnSimulate->Visible = false;
            }

            // O terceiro botão é usado na página RFID para recovery/reset
            // e na página de Ocorrências quando aplicável.
            if (FCurrentPage != TAccessPage::BleDevices &&
                FCurrentPage != TAccessPage::Incidents)
            {
                BtnStartCamera->Visible = false;
            }
        }
        else if (DeveloperPanel->Visible)
        {
            // Mantém as outras páginas administrativas em um card central
            // proporcional, sem invadir título/descrição.
            // Câmera e Configurações usam toda a coluna direita disponível,
            // partindo após o centro da tela e terminando na margem direita.
            const int RightPanelLeft = TotemMode
                ? SideMargin
                : (SecondaryWidth / 2) + 28;

            const int PanelWidth = TotemMode
                ? ContentWidth
                : std::max(560, SecondaryWidth - RightPanelLeft - SideMargin);

            DeveloperPanel->Align = alNone;
            DeveloperPanel->SetBounds(
                RightPanelLeft,
                TotemMode ? 208 : 196,
                PanelWidth,
                std::max(560, SecondaryHeight - (TotemMode ? 232 : 220)));

            if (FCurrentPage == TAccessPage::Settings)
            {
                FSettingsTestErpButton->Font->Name = L"Segoe UI Semibold";
                FSettingsSelectDbButton->Font->Name = L"Segoe UI Semibold";
                FSettingsSaveTerminalButton->Font->Name = L"Segoe UI Semibold";
                FSettingsDiagnosticButton->Font->Name = L"Segoe UI Semibold";

				FSettingsTestErpButton->Font->Size = TotemMode ? 4 : 5;
				FSettingsSelectDbButton->Font->Size = TotemMode ? 8 : 9;
				FSettingsSaveTerminalButton->Font->Size = TotemMode ? 4: 5;
				FSettingsDiagnosticButton->Font->Size = TotemMode ? 4 : 5;

                const int Inner = 20;
                const int Gap = 14;
                const int W =
                    std::max(320, DeveloperPanel->ClientWidth - (Inner * 2));
                const int AvailableH =
                    std::max(540, DeveloperPanel->ClientHeight - (Inner * 2));

                const int ErpH = 168;
                const int DataH = 198;
                const int TerminalH =
                    std::max(160, AvailableH - ErpH - DataH - (Gap * 2));

                FSettingsErpCard->SetBounds(
                    Inner, Inner, W, ErpH);
                FSettingsDataCard->SetBounds(
                    Inner, Inner + ErpH + Gap, W, DataH);
                FSettingsTerminalCard->SetBounds(
                    Inner,
                    Inner + ErpH + Gap + DataH + Gap,
                    W,
                    TerminalH);

                const int CW = W - 32;

                FSettingsErpTitle->SetBounds(16, 14, CW, 22);
                FSettingsErpStatus->SetBounds(16, 42, CW, 22);
                FSettingsErpInfo->SetBounds(16, 68, CW, 34);
                FSettingsApiEdit->SetBounds(16, 108, CW - 174, 30);
                FSettingsTestErpButton->SetBounds(
                    W - 158, 106, 142, 34);

                FSettingsDataTitle->SetBounds(16, 14, CW, 22);
                FSettingsEmployeeDbStatus->SetBounds(16, 44, CW, 22);
                FSettingsEmployeeDbPath->SetBounds(16, 68, CW, 22);
                FSettingsAccessDbStatus->SetBounds(16, 98, CW, 22);
                FSettingsAccessDbPath->SetBounds(16, 122, CW, 22);
                FSettingsSelectDbButton->SetBounds(
                    16, 152, CW, 34);

                FSettingsTerminalTitle->SetBounds(16, 14, CW, 22);
                FSettingsTerminalStatus->SetBounds(16, 42, CW, 38);
                const int TerminalButtonW = 158;
                const int TerminalButtonGap = 10;
                const int TerminalButtonsW =
                    (TerminalButtonW * 2) + TerminalButtonGap;

                FSettingsTerminalEdit->SetBounds(
                    16, 88,
                    std::max(160, CW - TerminalButtonsW - 12),
                    30);

				FSettingsSaveTerminalButton->SetBounds(
                    W - 16 - TerminalButtonsW,
                    86,
                    TerminalButtonW,
                    34);

                FSettingsDiagnosticButton->SetBounds(
                    W - 16 - TerminalButtonW,
                    86,
                    TerminalButtonW,
                    34);
            }

            if (FCurrentPage == TAccessPage::Camera)
            {
                BtnSimulate->Font->Name = L"Segoe UI Semibold";
                BtnClear->Font->Name = L"Segoe UI Semibold";
                BtnStartCamera->Font->Name = L"Segoe UI Semibold";
                BtnSimulate->Font->Size = TotemMode ? 8 : 9;
                BtnClear->Font->Size = TotemMode ? 8 : 9;
                BtnStartCamera->Font->Size = TotemMode ? 8 : 9;

                const int Inner = 24;
                const int ControlWidth =
                    std::max(260, DeveloperPanel->ClientWidth - (Inner * 2));

                LblDeveloperStatus->AutoSize = false;
                LblDeveloperStatus->WordWrap = true;
                LblDeveloperStatus->SetBounds(
                    Inner, 20, ControlWidth, 56);

                if (FCameraSelectorLabel != nullptr)
                    FCameraSelectorLabel->SetBounds(
                        Inner, 94, ControlWidth, 24);

                if (FCameraSelector != nullptr)
                    FCameraSelector->SetBounds(
                        Inner, 120, ControlWidth, 34);

                if (FCameraSettingsPreview != nullptr)
                    FCameraSettingsPreview->SetBounds(
                        Inner, 166, ControlWidth, 205);

                BtnSimulate->SetBounds(
                    Inner, 388, ControlWidth, 40);

                BtnClear->SetBounds(
                    Inner, 438, ControlWidth, 40);

                BtnStartCamera->SetBounds(
                    Inner, 488, ControlWidth, 40);

                BtnSimulate->Visible = true;
                BtnClear->Visible = true;
                BtnStartCamera->Visible = true;
            }
        }
    }

    CameraPanel->Color = RgbColor(6, 22, 36);
    CameraPanel->BevelOuter = bvNone;
    CameraPanel->BringToFront();
    if (FCameraDecor != nullptr)
    {
        FCameraDecor->Visible = true;
        FCameraDecor->BringToFront();
        FCameraDecor->Invalidate();
        if (FCameraPreviewImage != nullptr && FCameraPreviewImage->Visible)
            FCameraPreviewImage->BringToFront();
        if (FRecognitionCheckShape != nullptr)
            FRecognitionCheckShape->BringToFront();
        if (FRecognitionCheckLabel != nullptr)
            FRecognitionCheckLabel->BringToFront();
    }

    // ---------------------------------------------------------
    // COLUNA PRINCIPAL DA IDENTIFICAÇÃO
    // A câmera e o card do funcionário usam a mesma largura.
    // ---------------------------------------------------------
    const int OverlayReserve =
        (!TotemMode && OverlayMenu != nullptr && OverlayMenu->Visible)
            ? OverlayMenu->Width
            : 0;

    // Com o menu aberto, o terminal se reorganiza no espaço restante.
    const int LayoutWidth =
        std::max(1, IdentificationView->ClientWidth - OverlayReserve);

    const int MainContentWidth = PortraitMode
        ? ClampInt(LayoutWidth * 92 / 100, 360, std::max(360, LayoutWidth - 24))
        : (TotemMode
            ? std::max(320, LayoutWidth - 16)
            : ClampInt(LayoutWidth * 50 / 100, 660, 860));

    const int Padding = TotemMode ? 14 : 10;
    const int PromptHeight = PortraitMode ? 34 : (TotemMode ? 36 : 30);

    const TCameraRotationMode Rotation = EffectiveCameraRotation();
    const bool PortraitCamera =
        Rotation == TCameraRotationMode::Deg90CW ||
        Rotation == TCameraRotationMode::Deg90CCW;

    const int AspectW = PortraitCamera ? 9 : 16;
    const int AspectH = PortraitCamera ? 16 : 9;

    // O vídeo sempre mantém sua proporção. Em horizontal, a largura define
    // a altura 16:9; em rotação 90°, passa naturalmente para 9:16.
    int VideoWidth = std::max(1, MainContentWidth - (Padding * 2));
    int VideoHeight = VideoWidth * AspectH / AspectW;

    // Em orientação vertical, priorizamos a largura útil mas limitamos a altura
    // para reservar funcionário/status/menu. Nunca distorcemos a câmera.

    // Se o monitor for baixo, reduzimos largura e altura juntas.
    const int ReservedBottomHeight = PortraitMode
        ? (ShowRecognizedCard ? 260 : 170)
        : 8;

    const int MaxPanelHeight =
        std::max(220, IdentificationView->ClientHeight - ReservedBottomHeight);

    // Em vertical a câmera não pode dominar toda a tela.
    // Limitamos o vídeo a aproximadamente 67% da altura útil disponível,
    // preservando a proporção do frame.
    const int PortraitVideoCap = PortraitMode
        ? std::max(220, (IdentificationView->ClientHeight * 67) / 100)
        : MaxPanelHeight;

    const int MaxVideoHeight =
        std::max(
            120,
            std::min(
                MaxPanelHeight - PromptHeight - (Padding * 2),
                PortraitVideoCap - PromptHeight - (Padding * 2)));

    if (VideoHeight > MaxVideoHeight)
    {
        VideoHeight = MaxVideoHeight;
        VideoWidth = VideoHeight * AspectW / AspectH;
    }

    VideoWidth = std::max(1, VideoWidth);
    VideoHeight = std::max(1, VideoHeight);

    const int CameraPanelHeight =
        VideoHeight + PromptHeight + (Padding * 2);

    CameraPanel->Margins->Left = 0;
    CameraPanel->Margins->Right = 0;
    CameraPanel->Margins->Top = 0;
    CameraPanel->Margins->Bottom = 0;

    CameraPanel->SetBounds(
        (LayoutWidth - MainContentWidth) / 2,
        4,
        MainContentWidth,
        CameraPanelHeight);

    // O bloco de identificação passa a ficar imediatamente abaixo do card da câmera.
    const int StatusGap = PortraitMode ? 14 : (TotemMode ? 10 : 12);
    const int StatusTop = CameraPanel->Top + CameraPanel->Height + StatusGap;
    // Altura real do painel inferior. Precisa acomodar:
    // card do funcionário + FACE/BLE + MENU + rodapé.
    const int StatusHeight = ShowRecognizedCard
        ? (PortraitMode ? 312 : (TotemMode ? 304 : 302))
        : (PortraitMode ? 208 : (TotemMode ? 204 : 200));

    BottomStatusPanel->SetBounds(
        0,
        StatusTop,
        LayoutWidth,
        StatusHeight);
    BottomStatusPanel->Visible = true;
    BottomStatusPanel->BringToFront();

    const int VideoLeft =
        (CameraPanel->ClientWidth - VideoWidth) / 2;
    const int VideoTop = Padding;

    if (FCameraModeBadge != nullptr)
    {
        FCameraModeBadge->Font->Size = PortraitMode ? 6 : 7;
        FCameraModeBadge->SetBounds(
            VideoLeft + 12,
            VideoTop + 8,
            std::max(120, std::min(220, VideoWidth - 90)),
            18);
        FCameraModeBadge->BringToFront();
    }

    if (FIdleVisual != nullptr)
    {
        FIdleVisual->Align = alNone;
        FIdleVisual->SetBounds(
            VideoLeft,
            VideoTop,
            VideoWidth,
            VideoHeight);
    }

    // Lottie usa a mesma área útil do vídeo. Quando não há rosto, ocupa
    // exatamente o espaço que depois será substituído pela webcam.
    if (FIdleLottie != nullptr)
    {
        const int AnimWidth =
            std::min(VideoWidth * (TotemMode ? 64 : 46) / 100, 320);
        const int AnimHeight =
            std::min(VideoHeight * 48 / 100, TotemMode ? 250 : 210);

        FIdleLottie->Align = alNone;
        FIdleLottie->SetBounds(
            (CameraPanel->ClientWidth - AnimWidth) / 2,
            VideoTop + std::max(8, (VideoHeight - AnimHeight) / 2 - 38),
            AnimWidth,
            AnimHeight);
    }

    if (FCameraPreviewImage != nullptr)
    {
        FCameraPreviewImage->Align = alNone;
        FCameraPreviewImage->Stretch = true;
        FCameraPreviewImage->Proportional = true;
        FCameraPreviewImage->Center = true;
        FCameraPreviewImage->SetBounds(
            VideoLeft, VideoTop, VideoWidth, VideoHeight);
    }

    // Check de confirmação no canto do vídeo.
    const int CheckSize = TotemMode ? 40 : 34;
    const int CheckLeft = VideoLeft + VideoWidth - CheckSize - 12;
    const int CheckTop = VideoTop + 12;

    if (FRecognitionCheckShape != nullptr)
    {
        FRecognitionCheckShape->SetBounds(
            CheckLeft, CheckTop, CheckSize, CheckSize);
    }

    if (FRecognitionCheckLabel != nullptr)
    {
        FRecognitionCheckLabel->Font->Size = TotemMode ? 18 : 16;
        FRecognitionCheckLabel->SetBounds(
            CheckLeft, CheckTop - 1, CheckSize, CheckSize);
    }

    // Moldura tecnológica fixa do card da câmera.
    ShapeFaceFrame->Visible = true;
    ShapeFaceFrame->Shape = stRectangle;
    ShapeFaceFrame->Brush->Style = bsClear;
    ShapeFaceFrame->Pen->Color = RgbColor(26, 125, 210);
    ShapeFaceFrame->Pen->Width = 1;
    ShapeFaceFrame->SetBounds(
        VideoLeft - 4,
        VideoTop - 4,
        VideoWidth + 8,
        VideoHeight + 8);
    ShapeFaceFrame->SendToBack();

	LblFaceGlyph->Alignment = taCenter;
	LblFaceGlyph->Layout = tlCenter;
	LblFaceGlyph->Font->Name = L"Segoe UI Semibold";
	LblFaceGlyph->Font->Size = PortraitMode ? 12 : (TotemMode ? 14 : 15);
	LblFaceGlyph->Font->Color =
	RgbColor(64, 187, 255);

    const int IdleTitleTop =
        VideoTop + (VideoHeight * 56 / 100);

    LblFaceGlyph->Align = alNone;
    LblFaceGlyph->AutoSize = false;
    LblFaceGlyph->Layout = tlCenter;
    LblFaceGlyph->SetBounds(
        VideoLeft,
        IdleTitleTop - 4,
        VideoWidth,
        30);

LblCameraPlaceholder->Alignment = taCenter;
LblCameraPlaceholder->Layout = tlCenter;
LblCameraPlaceholder->Font->Name = L"Segoe UI";
LblCameraPlaceholder->Font->Size =
    TotemMode ? 9 : 10;
LblCameraPlaceholder->Font->Color =
    RgbColor(150, 170, 195);

LblCameraPlaceholder->Font->Size =
    PortraitMode ? 8 : 9;

LblCameraPlaceholder->Align = alNone;
LblCameraPlaceholder->AutoSize = false;
LblCameraPlaceholder->Layout = tlCenter;
LblCameraPlaceholder->SetBounds(
        VideoLeft + 24,
        IdleTitleTop + 52,
        VideoWidth - 48,
        26);


    LblPrompt->Alignment = taCenter;
    LblPrompt->Layout = tlCenter;
    LblPrompt->Font->Size = TotemMode ? 12 : 11;
    LblPrompt->SetBounds(
        18,
        VideoTop + VideoHeight + 1,
        CameraPanel->ClientWidth - 36,
        PromptHeight - 2);

    const int CenterX = BottomStatusPanel->ClientWidth / 2;

    if (ShowRecognizedCard)
   {
	const int ResultWidth = MainContentWidth;

        const int ResultHeight = PortraitMode ? 98 : (TotemMode ? 102 : 98);

        EmployeeResultPanel->SetBounds(
            CenterX - (ResultWidth / 2),
            4,
            ResultWidth,
            ResultHeight);

        const int PhotoSize = TotemMode ? 76 : 78;
        PhotoPanel->SetBounds(12, 14, PhotoSize, PhotoSize);
        LblPhoto->SetBounds(
            0, 0, PhotoPanel->ClientWidth, PhotoPanel->ClientHeight);

        const int InfoLeft = PhotoSize + 28;
        const int InfoWidth = ResultWidth - InfoLeft - 16;

        LblEmployeeState->AutoSize = false;
        LblEmployeeState->WordWrap = false;
        LblEmployeeState->Alignment = taLeftJustify;
        LblEmployeeState->Font->Size = TotemMode ? 8 : 9;
        LblEmployeeState->SetBounds(
            InfoLeft, 10, InfoWidth, 20);

        LblName->AutoSize = false;
        LblName->WordWrap = false;
        LblName->Alignment = taLeftJustify;
        LblName->Font->Size = PortraitMode ? 13 : (TotemMode ? 14 : 15);
        LblName->SetBounds(
            InfoLeft, 31, InfoWidth, 34);

        LblDepartment->AutoSize = false;
        LblDepartment->WordWrap = false;
        LblDepartment->Alignment = taLeftJustify;
        LblDepartment->Font->Size = 9;

        LblIdentifiedAt->AutoSize = false;
        LblIdentifiedAt->WordWrap = false;
        LblIdentifiedAt->Font->Size = 8;

        if (TotemMode || ResultWidth < 690)
        {
            LblDepartment->SetBounds(
                InfoLeft, 68, InfoWidth * 50 / 100, 22);

            LblIdentifiedAt->Alignment = taRightJustify;
            LblIdentifiedAt->SetBounds(
                InfoLeft + (InfoWidth * 50 / 100),
                68,
                InfoWidth * 50 / 100,
                22);
        }
        else
        {
            LblDepartment->SetBounds(
                InfoLeft, 68, InfoWidth * 55 / 100, 22);

            LblIdentifiedAt->Alignment = taRightJustify;
            LblIdentifiedAt->SetBounds(
                InfoLeft + (InfoWidth * 55 / 100),
                68,
                InfoWidth * 45 / 100,
                22);
        }
    }

    // ---------------------------------------------------------
    // BARRA DE STATUS EMPRESARIAL
    // Apenas visual: usa os componentes FACE/BLE já existentes.
    // ---------------------------------------------------------
    // IMPORTANT: status cards must start AFTER the employee card.
    // Previous fixed values (100/104) overlapped the employee card by a few
    // pixels, clipping FACE/RFID/TERMINAL at the top.
    const int FactorTop = ShowRecognizedCard
        ? (EmployeeResultPanel->Top + EmployeeResultPanel->Height + 8)
        : 8;

    const int FactorLeft =
        (BottomStatusPanel->ClientWidth - MainContentWidth) / 2;
    const int FactorGap = 8;
    const int FactorWidth =
        std::max(110, (MainContentWidth - (FactorGap * 2)) / 3);

    LblFaceIndicator->Parent = FaceStatusCard;
    LblFaceStatusDetail->Parent = FaceStatusCard;

    FaceStatusCard->Visible = true;
    FaceStatusCard->Align = alNone;
    FaceStatusCard->Color = RgbColor(5, 18, 29);
    FaceStatusCard->BevelOuter = bvNone;
    FaceStatusCard->SetBounds(
        FactorLeft,
        FactorTop,
        FactorWidth,
        60);

    LblBleIndicator->Parent = BleStatusCard;
    LblBleStatusDetail->Parent = BleStatusCard;

    BleStatusCard->Visible = true;
    BleStatusCard->Align = alNone;
    BleStatusCard->Color = RgbColor(5, 18, 29);
    BleStatusCard->BevelOuter = bvNone;
    BleStatusCard->SetBounds(
        FactorLeft + FactorWidth + FactorGap,
        FactorTop,
        FactorWidth,
        60);

    if (FTerminalStatusCard != nullptr)
    {
        FTerminalStatusCard->Visible = true;
        FTerminalStatusCard->Color = RgbColor(5, 18, 29);
        FTerminalStatusCard->Align = alNone;
        FTerminalStatusCard->SetBounds(
            FactorLeft + ((FactorWidth + FactorGap) * 2),
            FactorTop,
            FactorWidth,
            60);
    }

    // Terceiro bloco visual: reaproveita o status real da câmera.
    if (FTerminalStatusCard != nullptr)
    {
        LblCameraStatus->Parent = FTerminalStatusCard;
        if (FTerminalStatusTitle != nullptr)
            FTerminalStatusTitle->Parent = FTerminalStatusCard;
    }
    LblCameraStatus->Visible = true;
    LblCameraStatus->Transparent = false;
    LblCameraStatus->Color = RgbColor(5, 18, 29);
    LblCameraStatus->Alignment = taCenter;
    LblCameraStatus->Layout = tlCenter;
    LblCameraStatus->Font->Name = L"Segoe UI Semibold";
    LblCameraStatus->Font->Size = PortraitMode ? 8 : 9;
    LblCameraStatus->Font->Color = RgbColor(70, 205, 255);
    LblCameraStatus->Font->Style = TFontStyles() << fsBold;
    if (FTerminalStatusTitle != nullptr)
    {
        FTerminalStatusTitle->Align = alNone;
        FTerminalStatusTitle->AutoSize = false;
        FTerminalStatusTitle->WordWrap = false;
        FTerminalStatusTitle->Alignment = taCenter;
        FTerminalStatusTitle->Layout = tlCenter;
        FTerminalStatusTitle->Font->Size = 9;
        FTerminalStatusTitle->SetBounds(0, 5, FactorWidth, 22);
        FTerminalStatusTitle->BringToFront();

        LblCameraStatus->Align = alNone;
        LblCameraStatus->AutoSize = false;
        LblCameraStatus->WordWrap = false;
        LblCameraStatus->Alignment = taCenter;
        LblCameraStatus->Layout = tlCenter;
        LblCameraStatus->Font->Size = 8;
        LblCameraStatus->SetBounds(4, 31, FactorWidth - 8, 22);
        LblCameraStatus->BringToFront();
    }

    LblFaceIndicator->Align = alNone;
    LblFaceIndicator->AutoSize = false;
    LblFaceIndicator->WordWrap = false;
    LblFaceIndicator->Alignment = taCenter;
    LblFaceIndicator->Layout = tlCenter;
    LblFaceIndicator->Font->Size = 9;
    LblFaceIndicator->SetBounds(0, 5, FactorWidth, 22);

    LblFaceStatusDetail->Align = alNone;
    LblFaceStatusDetail->AutoSize = false;
    LblFaceStatusDetail->WordWrap = false;
    LblFaceStatusDetail->Alignment = taCenter;
    LblFaceStatusDetail->Layout = tlCenter;
    LblFaceStatusDetail->Font->Size = 8;
    LblFaceStatusDetail->SetBounds(
        4, 31, FactorWidth - 8, 22);

    LblBleIndicator->Align = alNone;
    LblBleIndicator->AutoSize = false;
    LblBleIndicator->WordWrap = false;
    LblBleIndicator->Caption = L"RFID";
    LblBleIndicator->Alignment = taCenter;
    LblBleIndicator->Layout = tlCenter;
    LblBleIndicator->Font->Size = 9;
    LblBleIndicator->SetBounds(0, 5, FactorWidth, 22);

    LblBleStatusDetail->Align = alNone;
    LblBleStatusDetail->AutoSize = false;
    LblBleStatusDetail->WordWrap = false;
    LblBleStatusDetail->Alignment = taCenter;
    LblBleStatusDetail->Layout = tlCenter;
    LblBleStatusDetail->Font->Size = 8;
    LblBleStatusDetail->SetBounds(
        4, 31, FactorWidth - 8, 22);

    // Botão MENU vira a única ação permanente sob a identificação.
    // MENU always follows the operational status bar.
    // No magic constants => horizontal/vertical cannot overlap the labels.
    const int MenuTop = FactorTop + 66;

    // Rodapé com sensação de base física: faixa larga e botão central encaixado.
    MenuCenterPanel->SetBounds(
        CenterX - (MainContentWidth / 2),
        MenuTop,
        MainContentWidth,
        88);
	// Rodapé estrutural TSX: vinho escuro no corpo e botão vermelho em
    // primeiro plano, lembrando a base física de um terminal comercial.
    MenuCenterPanel->Color = RgbColor(92, 4, 18);
    MenuCenterPanel->BevelOuter = bvNone;
    if (FFooterDecor != nullptr)
    {
        FFooterDecor->Visible = true;
        FFooterDecor->SendToBack();
        FFooterDecor->Invalidate();
    }

    BtnMenu->SetBounds(
        (MenuCenterPanel->ClientWidth - 184) / 2,
        0,
        184,
        46);
    BtnMenu->Color = RgbColor(216, 28, 43);
    BtnMenu->Font->Name = L"Segoe UI Semibold";
    BtnMenu->Font->Size = 11;
    BtnMenu->Color = RgbColor(218, 28, 44);
    MenuCenterPanel->BringToFront();
    if (FFooterDecor != nullptr)
        FFooterDecor->SendToBack();
    BtnMenu->BringToFront();
    LblMenuHint->BringToFront();
    BtnMenu->Font->Name = L"Segoe UI Semibold";
    BtnMenu->Font->Size = 11;
    BtnMenu->Font->Color = clWhite;

    LblMenuHint->Visible = false;
	LblMenuHint->Caption = L"Portaria   |   C++ TERMINAL   |   IDENTIFICA • AUTENTICA • INTEGRA   |   v1.0.0";
    LblMenuHint->Alignment = taCenter;
    LblMenuHint->Font->Name = L"Segoe UI";
    LblMenuHint->Font->Size = 7;
    LblMenuHint->Font->Color = RgbColor(135, 155, 176);
    LblMenuHint->SetBounds(
        (BottomStatusPanel->ClientWidth - MainContentWidth) / 2,
        MenuTop + 46,
        MainContentWidth,
        20);
    if (FProductVersion != nullptr)
    {
        FProductVersion->Align = alNone;
        FProductVersion->AutoSize = false;
        FProductVersion->WordWrap = false;
        FProductVersion->Layout = tlCenter;
        FProductVersion->Visible = true;
        FProductVersion->SetBounds(
            14,
            56,
            MenuCenterPanel->ClientWidth - 28,
            22);
        FProductVersion->BringToFront();
    }


    BottomStatusPanel->Color = RgbColor(5, 10, 16);
    ShapeFaceFrame->Pen->Color = BorderTextColor;

    LayoutOverlayMenu(TotemMode);

    ApplyRoundedCorners(CameraPanel, TotemMode ? 20 : 24);
    ApplyRoundedCorners(PhotoPanel, 20);
    ApplyRoundedCorners(EmployeeResultPanel, 22);
    ApplyRoundedCorners(BtnMenu, 18);
    ApplyRoundedCorners(BtnBackFromPage, 22);
    ApplyRoundedCorners(DeveloperPanel, 22);
    ApplyRoundedCorners(OverlayMenu, 0);
	ApplyRoundedCorners(BtnMenuBack, 18);
    ApplyRoundedCorners(MenuIdentification, 16);
    ApplyRoundedCorners(MenuPresent, 16);
    ApplyRoundedCorners(MenuRecent, 16);
    ApplyRoundedCorners(MenuCamera, 16);
    ApplyRoundedCorners(MenuBle, 16);
    ApplyRoundedCorners(MenuManual, 16);
    ApplyRoundedCorners(MenuOccurrences, 16);
    ApplyRoundedCorners(MenuSettings, 16);

    UpdateCameraPreviewVisibility();
}

void TMainForm::UpdateMenuSelection()
{
    TPanel* Panels[] = {
        MenuIdentification, MenuPresent, MenuRecent, MenuCamera,
        MenuBle, MenuManual, MenuOccurrences, MenuSettings
    };

    for (int Index = 0; Index < 8; ++Index)
    {
        Panels[Index]->Color = RgbColor(18, 34, 52);
    }

    Panels[static_cast<int>(FCurrentPage)]->Color = RgbColor(24, 96, 154);
}

void TMainForm::ApplyRoundedCorners(TWinControl* Control, int Radius)
{
    if (Control == nullptr || !Control->HandleAllocated())
    {
        return;
    }

    HRGN Region = CreateRoundRectRgn(0, 0, Control->Width + 1, Control->Height + 1,
        Radius, Radius);
    SetWindowRgn(Control->Handle, Region, TRUE);
}

TAccessPage TMainForm::PageFromTag(int Tag) const
{
    switch (Tag)
    {
    case 1: return TAccessPage::PresentEmployees;
    case 2: return TAccessPage::RecentEntries;
    case 3: return TAccessPage::Camera;
    case 4: return TAccessPage::BleDevices;
    case 5: return TAccessPage::ManualRelease;
    case 6: return TAccessPage::Incidents;
    case 7: return TAccessPage::Settings;
    default: return TAccessPage::Identification;
    }
}

UnicodeString TMainForm::PageTitle(TAccessPage Page) const
{
    switch (Page)
    {
	case TAccessPage::PresentEmployees: return L"Funcionários presentes";
    case TAccessPage::RecentEntries: return L"Últimas entradas";
    case TAccessPage::Camera: return L"Câmera";
    case TAccessPage::BleDevices: return L"TAG RFID";
    case TAccessPage::ManualRelease: return L"Liberação manual";
    case TAccessPage::Incidents: return L"Ocorrências";
    case TAccessPage::Settings: return L"Configurações";
    default: return L"Identificação";
    }
}

UnicodeString TMainForm::PageDescription(TAccessPage Page) const
{
    switch (Page)
    {
    case TAccessPage::PresentEmployees:
        return L"Funcionários identificados como presentes neste terminal durante o dia atual.";
    case TAccessPage::RecentEntries:
        return L"Consulte as identificações e os acessos mais recentes registrados por este terminal.";
    case TAccessPage::Camera:
        return L"Selecione a webcam do terminal, valide o vídeo e configure layout e rotação da imagem.";
    case TAccessPage::BleDevices:
        return L"Associe, consulte ou remova TAGs RFID dos funcionários cadastrados no sistema.";
    case TAccessPage::ManualRelease:
        return L"Selecione um funcionário e registre uma liberação de acesso assistida pela portaria.";
    case TAccessPage::Incidents:
        return L"Gerencie bloqueios, liberações e ocorrências relacionadas aos acessos dos funcionários.";
    case TAccessPage::Settings:
        return L"Configure banco corporativo, integração com o ERP Delphi e parâmetros operacionais do terminal.";
    default:
        return L"Tela principal de identificação";
    }
}

UnicodeString TMainForm::TerminalDisplayName() const
{
    return StringReplace(FConfig.TerminalName, L"-", L" ", TReplaceFlags() << rfReplaceAll);
}

void __fastcall TMainForm::FormResize(TObject *Sender)
{
    (void)Sender;
    LayoutTerminal();

    if (FCurrentPage == TAccessPage::Camera)
    {
        UpdateDeveloperPanel();
    }
}

void __fastcall TMainForm::ClockTimerTimer(TObject *Sender)
{
    (void)Sender;
    UpdateClock();

    ProcessEmployeeSyncStatus();

    // Cadastro facial remoto consulta diretamente o ERP Delphi :3101.
    // Observabilidade continua independente no WebServer :8080.
    ProcessPendingBiometricCommands();
}

void __fastcall TMainForm::ReturnTimerTimer(TObject *Sender)
{
    (void)Sender;
    ReturnTimer->Enabled = false;
    ReturnTimer->Interval = 5000;

    // Nunca interromper um cadastro de identificação facial em andamento.
    // O enrollment só deve terminar por CompleteFaceEnrollment() ou por uma
    // ação explícita do operador.
    if (FEnrollmentActive)
    {
        return;
    }

    // O ReturnTimer serve apenas para limpar o resultado da tela principal.
    // Nunca pode fechar o menu ou retirar o operador de uma tela administrativa.
    if ((OverlayMenu != nullptr && OverlayMenu->Visible) ||
        FCurrentPage != TAccessPage::Identification)
    {
        ReturnTimer->Enabled = false;
        return;
    }

    FIdentificationManager->ClearIdentification();

    // Limpa somente o estado visual da última leitura.
    // O vínculo da TAG permanece persistido normalmente no banco.
    FLastRfidUid = UnicodeString();
    FLastRfidState = TRfidVisualState::Idle;

    ResetFacePreviewState();
    ShowIdentification();
    ApplyRfidStatus();
}

void __fastcall TMainForm::MenuButtonClick(TObject *Sender)
{
    (void)Sender;

    if (ReturnTimer != nullptr)
        ReturnTimer->Enabled = false;

    // MENU funciona como abre/fecha e não depende de uma face reconhecida.
    if (OverlayMenu != nullptr && OverlayMenu->Visible)
    {
        CloseMenu();
        return;
    }

    OpenMenu();
}

void __fastcall TMainForm::BackToIdentificationClick(TObject *Sender)
{
	(void)Sender;
    ReturnTimer->Enabled = false;

    // v0.7.4.2:
    // A câmera permanece aberta durante as telas administrativas.
    // Ao voltar para a identificação, limpamos somente qualquer resultado/lock
    // facial transitório criado antes de entrar no menu. Isso evita esperar
    // misses do detector para que o preview principal volte a ficar disponível.
    //
    // IMPORTANTE: não fechamos nem reabrimos FCameraManager aqui.
    if (!FEnrollmentActive)
    {
        ClearRecognizedFaceResult();
    }

	ShowIdentification();
    LayoutTerminal();
}

void __fastcall TMainForm::MenuItemClick(TObject *Sender)
{
    TComponent* Component = dynamic_cast<TComponent*>(Sender);
    if (Component == nullptr)
    {
        return;
    }

    const TAccessPage TargetPage =
        PageFromTag(Component->Tag);

    if (FEnrollmentActive &&
        TargetPage == TAccessPage::Camera)
    {
        MessageDlg(
            L"Cadastro de identificação facial em andamento.\n\n"
            L"A troca de câmera fica bloqueada até concluir as 8 amostras.",
            mtInformation,
            TMsgDlgButtons() << mbOK,
            0);
        return;
    }

	ShowPage(TargetPage);
    LayoutTerminal();
}

void __fastcall TMainForm::StartCameraClick(TObject *Sender)
{
    (void)Sender;

    if (FCurrentPage == TAccessPage::BleDevices)
    {
        if (FRfidSerialReader == nullptr ||
            !FRfidSerialReader->IsPortOpen())
        {
            MessageDlg(
                L"A porta serial do RFID não está aberta.\n\n"
                L"Verifique a conexão USB/COM5.",
                mtWarning,
                TMsgDlgButtons() << mbOK,
                0);
            return;
        }

        const int Choice = MessageDlg(
            L"RECUPERAÇÃO DO RFID\n\n"
            L"SIM  = reiniciar somente o leitor RC522 (recomendado)\n"
            L"NÃO  = reiniciar completamente o ESP32-S3\n"
            L"CANCELAR = não fazer nada\n\n"
            L"Use primeiro a recuperação do RC522. Ela mantém a porta COM aberta.",
            mtConfirmation,
            TMsgDlgButtons() << mbYes << mbNo << mbCancel,
            0);

        if (Choice == mrYes)
        {
            if (FRfidSerialReader->RecoverReader())
            {
                LblDeveloperStatus->Caption =
                    L"Comando de recuperação enviado ao RC522. Aguarde o status ONLINE.";
                FLastRfidUid = UnicodeString();
                FLastRfidState = TRfidVisualState::Idle;
                FRfidAdminUid = UnicodeString();
                ApplyRfidStatus();
                UpdateRfidAdminReader();
            }
            return;
        }

        if (Choice == mrNo)
        {
            if (MessageDlg(
                    L"O ESP32-S3 será reiniciado por software.\n"
                    L"A COM5 pode desaparecer por alguns instantes e a Portaria "
                    L"tentará reconectar automaticamente.\n\n"
                    L"Confirmar reinício completo?",
                    mtWarning,
                    TMsgDlgButtons() << mbYes << mbNo,
                    0) == mrYes)
            {
                if (FRfidSerialReader->RestartDevice())
                {
                    LblDeveloperStatus->Caption =
                        L"Reinício do ESP32-S3 solicitado. Aguardando reconexão automática...";
                    FLastRfidUid = UnicodeString();
                    FLastRfidState = TRfidVisualState::Idle;
                    FRfidAdminUid = UnicodeString();
                    ApplyRfidStatus();
                    UpdateRfidAdminReader();
                }
            }
        }

        return;
    }

    if (FCurrentPage == TAccessPage::Incidents)
    {
        FIncidentHistoryMode = true;
        UpdateOccurrencePageButtons();
        RefreshOccurrences();
        return;
    }

    if (FCameraManager->IsOpen())
    {
        StopCameraPreview();
    }
    else
    {
        StartCameraPreview();
    }

    UpdateDeveloperPanel();
    RefreshIdentificationView();
}

void __fastcall TMainForm::SimulateClick(TObject *Sender)
{
    (void)Sender;

    if (FCurrentPage == TAccessPage::Camera)
    {
        CycleLayoutMode();
        return;
    }

    if (FCurrentPage == TAccessPage::ManualRelease)
    {
        TEmployee Employee;
        if (!TryGetSelectedEmployee(Employee))
        {
            MessageDlg(
                L"Selecione um funcionário para realizar a liberação manual.",
                mtWarning,
                TMsgDlgButtons() << mbOK,
                0);
            return;
        }

        const UnicodeString Question =
            L"Confirmar liberação manual para:\n\n" +
            Employee.Name +
            (Employee.Department.IsEmpty()
                ? UnicodeString()
                : L"\n" + Employee.Department) +
			L"\n\nO evento será registrado no histórico da Portaria 01.";

        if (MessageDlg(
                Question,
                mtConfirmation,
                TMsgDlgButtons() << mbYes << mbNo,
                0) != mrYes)
        {
            return;
        }

        UnicodeString BlockReason;
        if (IsEmployeeAccessBlocked(Employee, BlockReason))
        {
            MessageDlg(
                L"Este funcionário possui bloqueio ativo de acesso.\n\n" +
                (BlockReason.IsEmpty()
                    ? UnicodeString(L"Consulte a ocorrência registrada.")
                    : BlockReason),
                mtError,
                TMsgDlgButtons() << mbOK,
                0);
            return;
        }

        if (RecordManualAccessEvent(Employee))
        {
            LblDeveloperStatus->Caption =
                L"Acesso liberado manualmente para " +
                Employee.Name + L" às " +
                FormatDateTime(L"hh:nn:ss", Now()) + L".";

            MessageDlg(
                L"Acesso liberado e registrado com sucesso.",
                mtInformation,
                TMsgDlgButtons() << mbOK,
                0);
        }
        else
        {
            MessageDlg(
                L"Não foi possível registrar a liberação manual.",
                mtError,
                TMsgDlgButtons() << mbOK,
                0);
        }

        return;
    }

    if (FCurrentPage == TAccessPage::BleDevices)
    {
        RegisterRfidTagManual();
        return;
    }

    if (FCurrentPage == TAccessPage::Incidents)
    {
        if (FIncidentHistoryMode)
        {
            FIncidentHistoryMode = false;
            UpdateOccurrencePageButtons();
            RefreshOccurrenceEmployees();
        }
        else
        {
            SetSelectedEmployeeBlocked(true);
        }
        return;
    }
}

void __fastcall TMainForm::ClearClick(TObject *Sender)
{
    (void)Sender;

    if (FCurrentPage == TAccessPage::PresentEmployees)
    {
        RefreshPresentEmployees();
        return;
    }

    if (FCurrentPage == TAccessPage::RecentEntries)
    {
        RefreshRecentEntries();
        return;
    }

    if (FCurrentPage == TAccessPage::ManualRelease)
    {
        RefreshManualReleaseEmployees();
        return;
    }

    if (FCurrentPage == TAccessPage::BleDevices)
    {
        RemoveSelectedRfidTag();
        return;
    }

    if (FCurrentPage == TAccessPage::Incidents)
    {
        if (FIncidentHistoryMode)
        {
            if (RegisterOccurrence())
            {
                RefreshOccurrences();
            }
        }
        else
        {
            SetSelectedEmployeeBlocked(false);
        }
        return;
    }

    if (FCurrentPage == TAccessPage::Camera)
    {
        CycleCameraRotation();
        return;
    }

    ReturnTimer->Enabled = false;
    FIdentificationManager->ClearIdentification();
    ResetFacePreviewState();
    ShowIdentification();
}

void __fastcall TMainForm::CameraPreviewTimerTimer(TObject *Sender)
{
    (void)Sender;

    if (FCameraManager == nullptr || FCameraPreviewImage == nullptr ||
        FCameraPreviewBitmap == nullptr)
    {
        return;
    }

    TCameraFrame Frame;
    if (!FCameraManager->ReadFrame(Frame))
    {
        if (!FCameraManager->IsOpen() && FCameraPreviewTimer != nullptr)
        {
            FCameraPreviewTimer->Enabled = false;
            UpdateCameraPreviewVisibility();
            RefreshIdentificationView();
        }
        return;
    }

    TCameraFrame NormalizedFrame;
    if (!CopyFrameToTopDownBgra(Frame, NormalizedFrame))
    {
        return;
    }

    TCameraFrame DisplayFrame;
    if (!RotateBgraFrame(NormalizedFrame, DisplayFrame,
        EffectiveCameraRotation()))
    {
        return;
    }

    ++FPreviewFrameCounter;

    const bool DetectorReady = FFaceDetector != nullptr && FFaceDetector->IsInitialized();
    const bool ShouldDetect = DetectorReady &&
        (FPreviewFrameCounter == 1 ||
        (FPreviewFrameCounter % static_cast<unsigned long>(FFaceDetectionInterval)) == 0);

    if (ShouldDetect)
    {
        TCameraFrame DetectionFrame;

        if (!BuildFaceDetectionFrame(
                DisplayFrame,
                DetectionFrame))
        {
            return;
        }

        std::vector<FaceDetection> Detections =
            FFaceDetector->Detect(
                DetectionFrame.Data.data(),
                DetectionFrame.Width,
                DetectionFrame.Height,
                DetectionFrame.Stride);

        const FaceDetectionDebugStats DebugStats =
            FFaceDetector->LastDebugStats();

        ScaleDetectionsToDisplay(
            Detections,
            DetectionFrame.Width,
            DetectionFrame.Height,
            DisplayFrame.Width,
            DisplayFrame.Height);
        const FaceDetection* CurrentFace = Detections.empty() ? nullptr : &Detections[0];
        const FaceRect CurrentBounds = CurrentFace == nullptr
            ? FaceRect()
            : CurrentFace->Bounds;
        const double CurrentRatio = CalculateFaceRatio(CurrentBounds,
            DisplayFrame.Width, DisplayFrame.Height);
        char DebugBuffer[512];
        std::snprintf(DebugBuffer, sizeof(DebugBuffer),
            "FACE_DISTANCE_INPUT rawDetections=%d validDetections=%d confidence=%.3f faceX=%d faceY=%d faceW=%d faceH=%d faceRatio=%.3f previousFace=%d previousDistance=%s\n",
            DebugStats.RawDetections,
            DebugStats.ValidDetections,
            CurrentFace == nullptr ? 0.0 : CurrentFace->Confidence,
            CurrentFace == nullptr ? -1 : CurrentBounds.X,
            CurrentFace == nullptr ? -1 : CurrentBounds.Y,
            CurrentFace == nullptr ? 0 : CurrentBounds.Width,
            CurrentFace == nullptr ? 0 : CurrentBounds.Height,
            CurrentRatio,
            FHadRecentFace ? 1 : 0,
            FaceDistanceName(FLastDistance));
        OutputDebugStringA(DebugBuffer);

        UpdateDetectionMetrics();
        UpdateFacePreviewState(Detections, DisplayFrame.Width, DisplayFrame.Height);

        std::snprintf(DebugBuffer, sizeof(DebugBuffer),
            "FACE_DISTANCE_STATE rawDetections=%d validDetections=%d faceRatio=%.3f faceWidth=%d faceHeight=%d distanceState=%s previousDistance=%s nearEdge=%d\n",
            DebugStats.RawDetections,
            DebugStats.ValidDetections,
            FLastFaceRatio,
            FLastFaceBounds.width,
            FLastFaceBounds.height,
            FaceDistanceName(FLastDistance),
            FaceDistanceName(FPreviousDistance),
            IsFaceNearFrameEdge(FLastFaceBounds, DisplayFrame.Width, DisplayFrame.Height) ? 1 : 0);
        OutputDebugStringA(DebugBuffer);

        if (Detections.size() > 1)
        {
            FLastFaceDetections = Detections;
        }
        else if (Detections.empty() && FFacePreviewState == TFacePreviewState::Waiting)
        {
            FLastFaceDetections.clear();
        }

        ApplyFacePreviewStatus();
    }

    if (FEnrollmentActive)
    {
        // Cadastro remoto/local continua tendo prioridade e usa o mesmo stream.
        ProcessFaceEnrollment(DisplayFrame);
    }
    else if (FCurrentPage == TAccessPage::Identification)
    {
        // v0.7.4.2:
        // A câmera continua capturando nas telas administrativas, porém uma
        // identificação facial só pode gerar acesso na tela de identificação.
        // Isso evita criar FFaceRecognitionLocked em background (ex.: menu TAG).
        ProcessFaceRecognition(DisplayFrame);
    }

    if (DetectorReady && !FLastFaceDetections.empty() &&
        FFacePreviewState != TFacePreviewState::Waiting)
    {
        FFaceDetector->DrawDetections(DisplayFrame.Data.data(),
            DisplayFrame.Width, DisplayFrame.Height, DisplayFrame.Stride,
            FLastFaceDetections);
    }

    if (FrameToBitmap(DisplayFrame, FCameraPreviewBitmap))
    {
          // Continua atualizando o bitmap mesmo quando o preview principal
    // estiver visualmente oculto. Assim o stream da câmera permanece aquecido.
    // O reconhecimento facial, porém, só é executado na tela Identification.
    FCameraPreviewImage->Picture->Assign(FCameraPreviewBitmap);

    // Preview da página de configuração da câmera.
    UpdateCameraSettingsPreview();

    // Quem decide se a webcam aparece ou não é exclusivamente
    // UpdateCameraPreviewVisibility().
    UpdateCameraPreviewVisibility();

    if (FCameraPreviewImage->Visible)
    {
        FCameraPreviewImage->SendToBack();
        FCameraPreviewImage->Invalidate();
    }
    }

	LblCameraStatus->Caption =
        L"● Câmera " + FCameraManager->StatusText() +
        L" • índice " + IntToStr(FPreviewCameraIndex);

      // =========================================================
    // OBSERVABILITY - STATUS REAL DA PORTARIA
    // =========================================================
    if (FObservabilityHeartbeat != nullptr)
    {
        FObservabilityHeartbeat->UpdateRuntimeStatus(
            FCameraManager != nullptr &&
            FCameraManager->IsOpen(),

            FFaceDetector != nullptr &&
            FFaceDetector->IsInitialized());
    }
}

