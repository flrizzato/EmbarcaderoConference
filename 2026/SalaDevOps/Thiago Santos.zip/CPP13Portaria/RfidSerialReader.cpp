#include <vcl.h>
#pragma hdrstop

#include "RfidSerialReader.h"

#include <Winapi.Windows.hpp>
#include <System.SysUtils.hpp>

#include <chrono>
#include <utility>
//---------------------------------------------------------------------------
#pragma package(smart_init)

namespace
{
    std::wstring BuildComDevicePath(const std::wstring& PortName)
    {
        if (PortName.rfind(L"\\\\.\\", 0) == 0)
            return PortName;

        return L"\\\\.\\" + PortName;
    }

    void DebugLine(const UnicodeString& Text)
    {
        OutputDebugStringW((L"[RFID][SERIAL] " + Text + L"\r\n").c_str());
    }

    constexpr unsigned long long STARTUP_GRACE_MS = 2500ULL;
    constexpr unsigned long long PROTOCOL_SILENCE_MS = 6500ULL;
    constexpr unsigned long long RECOVERY_COOLDOWN_MS = 5000ULL;
}

TRfidSerialReader::TRfidSerialReader()
    : FBaudRate(115200),
      FStopRequested(false),
      FRunning(false),
      FPortOpen(false),
      FDeviceReady(false),
      FPortOpenedTick(0),
      FLastProtocolRxTick(0),
      FLastRecoveryRequestTick(0)
{
}

TRfidSerialReader::~TRfidSerialReader()
{
    Stop();
}

void TRfidSerialReader::Start(
    const UnicodeString& PortName,
    unsigned int BaudRate)
{
    Stop();

    FPortName = PortName.c_str();
    FBaudRate = BaudRate;
    FStopRequested.store(false);
    FPortOpen.store(false);
    FDeviceReady.store(false);
    FPortOpenedTick.store(0);
    FLastProtocolRxTick.store(0);
    FLastRecoveryRequestTick.store(0);

    {
        std::lock_guard<std::mutex> Lock(FQueueMutex);
        FTagQueue.clear();
    }

    {
        std::lock_guard<std::mutex> Lock(FCommandMutex);
        FCommandQueue.clear();
    }

    FWorker = std::thread(&TRfidSerialReader::WorkerProc, this);
}

void TRfidSerialReader::Stop()
{
    FStopRequested.store(true);

    if (FWorker.joinable())
        FWorker.join();

    FRunning.store(false);
    FPortOpen.store(false);
    FDeviceReady.store(false);
    FPortOpenedTick.store(0);
    FLastProtocolRxTick.store(0);
}

bool TRfidSerialReader::IsRunning() const
{
    return FRunning.load();
}

bool TRfidSerialReader::IsPortOpen() const
{
    return FPortOpen.load();
}

bool TRfidSerialReader::IsDeviceReady() const
{
    return FDeviceReady.load();
}

bool TRfidSerialReader::TryPopTag(UnicodeString& Uid)
{
    Uid = UnicodeString();

    std::lock_guard<std::mutex> Lock(FQueueMutex);

    if (FTagQueue.empty())
        return false;

    const std::string Value = std::move(FTagQueue.front());
    FTagQueue.pop_front();

    Uid = UnicodeString(AnsiString(Value.c_str()));
    return true;
}

bool TRfidSerialReader::QueueProtocolCommand(const char* Command)
{
    if (Command == nullptr || *Command == '\0')
        return false;

    // O firmware processa a linha somente quando recebe '\n'.
    // Importante: isto e uma quebra de linha REAL, nao os caracteres "\\n".
    std::string Line =
        "{\"proto\":\"TSX-RFID/1.0\","
        "\"type\":\"command\","
        "\"command\":\"";

    Line += Command;
    Line += "\"}\n";

    {
        std::lock_guard<std::mutex> Lock(FCommandMutex);

        if (FCommandQueue.size() >= 16)
            FCommandQueue.pop_front();

        FCommandQueue.push_back(std::move(Line));
    }

    return true;
}

bool TRfidSerialReader::RequestStatus()
{
    if (!FRunning.load())
        return false;

    return QueueProtocolCommand("status");
}

bool TRfidSerialReader::RecoverReader()
{
    if (!FRunning.load())
        return false;

    FLastRecoveryRequestTick.store(GetTickCount64());
    FDeviceReady.store(false);
    DebugLine(L"Solicitando recovery do RC522 ao firmware");
    return QueueProtocolCommand("reader_recover");
}

bool TRfidSerialReader::RestartDevice()
{
    if (!FRunning.load())
        return false;

    FLastRecoveryRequestTick.store(GetTickCount64());
    FDeviceReady.store(false);
    DebugLine(L"Solicitando reinicio completo do ESP32-S3");
    return QueueProtocolCommand("system_restart");
}

bool TRfidSerialReader::TryPopCommand(std::string& Command)
{
    Command.clear();

    std::lock_guard<std::mutex> Lock(FCommandMutex);

    if (FCommandQueue.empty())
        return false;

    Command = std::move(FCommandQueue.front());
    FCommandQueue.pop_front();
    return true;
}

void TRfidSerialReader::PushTag(const std::string& Uid)
{
    if (Uid.empty())
        return;

    std::lock_guard<std::mutex> Lock(FQueueMutex);

    // Limita a fila para nao crescer indefinidamente caso a UI esteja ocupada.
    if (FTagQueue.size() >= 32)
        FTagQueue.pop_front();

    FTagQueue.push_back(Uid);
}

bool TRfidSerialReader::ExtractJsonString(
    const std::string& Line,
    const std::string& Name,
    std::string& Value)
{
    Value.clear();

    const std::string Token = "\"" + Name + "\":\"";
    const std::size_t BeginToken = Line.find(Token);

    if (BeginToken == std::string::npos)
        return false;

    const std::size_t ValueBegin = BeginToken + Token.size();
    const std::size_t ValueEnd = Line.find('"', ValueBegin);

    if (ValueEnd == std::string::npos || ValueEnd <= ValueBegin)
        return false;

    Value = Line.substr(ValueBegin, ValueEnd - ValueBegin);
    return true;
}

void TRfidSerialReader::ProcessLine(const std::string& RawLine)
{
    std::string Line = RawLine;

    while (!Line.empty() &&
           (Line.back() == '\r' || Line.back() == '\n' ||
            Line.back() == ' ' || Line.back() == '\t'))
    {
        Line.pop_back();
    }

    if (Line.empty())
        return;

    // Ignora boot ROM e mensagens humanas. So o protocolo TSX atualiza
    // o heartbeat da Portaria.
    if (Line.find("\"proto\":\"TSX-RFID/1.0\"") == std::string::npos)
        return;

    FLastProtocolRxTick.store(GetTickCount64());

    std::string Type;
    if (!ExtractJsonString(Line, "type", Type))
        return;

    if (Type == "device")
    {
        std::string Status;
        std::string Reader;

        const bool HasStatus = ExtractJsonString(Line, "status", Status);
        const bool HasReader = ExtractJsonString(Line, "reader", Reader);

        const bool Ready =
            HasStatus && Status == "ready" &&
            (!HasReader || Reader == "online");

        FDeviceReady.store(Ready);

        if (Ready)
            DebugLine(L"ESP32/RC522 reportou status READY");
        else if (HasStatus && Status == "error")
            DebugLine(L"ESP32/RC522 reportou status ERROR");

        return;
    }

    if (Type == "command_result")
    {
        std::string Command;
        std::string Status;

        ExtractJsonString(Line, "command", Command);
        ExtractJsonString(Line, "status", Status);

        if (Command == "reader_recover" && Status == "ok")
        {
            // O proximo heartbeat/status confirmara READY.
            DebugLine(L"Firmware confirmou recovery do RC522");
        }
        else if (Command == "system_restart" && Status == "restarting")
        {
            FDeviceReady.store(false);
            DebugLine(L"Firmware confirmou reinicio do ESP32-S3");
        }

        return;
    }

    if (Type != "rfid")
        return;

    std::string Event;
    if (!ExtractJsonString(Line, "event", Event))
        return;

    if (Event == "reader_error")
    {
        FDeviceReady.store(false);
        DebugLine(L"reader_error recebido do firmware");
        return;
    }

    if (Event != "tag_read")
        return;

    std::string Uid;
    if (!ExtractJsonString(Line, "uid", Uid) || Uid.empty())
        return;

    // Uma leitura valida tambem prova que o dispositivo esta operacional.
    FDeviceReady.store(true);
    PushTag(Uid);
}

void TRfidSerialReader::ProcessAutomaticRecovery()
{
    if (!FPortOpen.load())
        return;

    const unsigned long long NowTick = GetTickCount64();
    const unsigned long long OpenedTick = FPortOpenedTick.load();
    const unsigned long long LastRxTick = FLastProtocolRxTick.load();
    const unsigned long long LastRecoveryTick = FLastRecoveryRequestTick.load();

    if (OpenedTick == 0 || (NowTick - OpenedTick) < STARTUP_GRACE_MS)
        return;

    // Firmware 0.4.0 envia heartbeat a cada ~2 s. Se ficarmos mais de 6,5 s
    // sem protocolo TSX, deixamos de considerar o leitor pronto.
    if (LastRxTick != 0 &&
        (NowTick - LastRxTick) > PROTOCOL_SILENCE_MS)
    {
        FDeviceReady.store(false);
    }

    if (FDeviceReady.load())
        return;

    if (LastRecoveryTick != 0 &&
        (NowTick - LastRecoveryTick) < RECOVERY_COOLDOWN_MS)
    {
        return;
    }

    // Recupera somente o RC522. Nao derruba a COM e e o caminho mais seguro
    // para o MVP fechado. O firmware tambem possui autorrecuperacao propria.
    RecoverReader();
}

void TRfidSerialReader::WorkerProc()
{
    FRunning.store(true);

    std::string Pending;
    Pending.reserve(512);

    while (!FStopRequested.load())
    {
        const std::wstring DevicePath = BuildComDevicePath(FPortName);

        HANDLE Port = CreateFileW(
            DevicePath.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            0,
            nullptr,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            nullptr);

        if (Port == INVALID_HANDLE_VALUE)
        {
            FPortOpen.store(false);
            FDeviceReady.store(false);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }

        DCB State = {};
        State.DCBlength = sizeof(State);

        bool ConfigOk = GetCommState(Port, &State) != FALSE;

        if (ConfigOk)
        {
            State.BaudRate = FBaudRate;
            State.ByteSize = 8;
            State.Parity = NOPARITY;
            State.StopBits = ONESTOPBIT;
            State.fBinary = TRUE;
            State.fParity = FALSE;
            State.fOutxCtsFlow = FALSE;
            State.fOutxDsrFlow = FALSE;
            State.fDtrControl = DTR_CONTROL_DISABLE;
            State.fDsrSensitivity = FALSE;
            State.fTXContinueOnXoff = TRUE;
            State.fOutX = FALSE;
            State.fInX = FALSE;
            State.fErrorChar = FALSE;
            State.fNull = FALSE;
            State.fRtsControl = RTS_CONTROL_DISABLE;
            State.fAbortOnError = FALSE;

            ConfigOk = SetCommState(Port, &State) != FALSE;
        }

        COMMTIMEOUTS Timeouts = {};
        // v0.4.6: menor latencia para entregar tag/comando ao MVP.
        Timeouts.ReadIntervalTimeout = 10;
        Timeouts.ReadTotalTimeoutMultiplier = 0;
        Timeouts.ReadTotalTimeoutConstant = 20;
        Timeouts.WriteTotalTimeoutMultiplier = 0;
        Timeouts.WriteTotalTimeoutConstant = 50;

        if (ConfigOk)
            ConfigOk = SetCommTimeouts(Port, &Timeouts) != FALSE;

        if (!ConfigOk)
        {
            CloseHandle(Port);
            FPortOpen.store(false);
            FDeviceReady.store(false);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }

        SetupComm(Port, 4096, 4096);
        PurgeComm(Port, PURGE_RXCLEAR | PURGE_TXCLEAR);

        const unsigned long long OpenTick = GetTickCount64();
        FPortOpen.store(true);
        FDeviceReady.store(false);
        FPortOpenedTick.store(OpenTick);
        FLastProtocolRxTick.store(OpenTick);
        FLastRecoveryRequestTick.store(0);

        DebugLine(UnicodeString(FPortName.c_str()) + L" aberta em " +
            IntToStr(static_cast<int>(FBaudRate)) + L" baud");

        Pending.clear();

        // Solicita estado imediatamente. Nao precisamos esperar o heartbeat
        // de 2 segundos do firmware para mostrar READY na Portaria.
        RequestStatus();

        while (!FStopRequested.load())
        {
            // TX e RX usam a mesma thread proprietaria da COM.
            std::string Command;
            while (TryPopCommand(Command))
            {
                DWORD BytesWritten = 0;

                if (!WriteFile(
                        Port,
                        Command.data(),
                        static_cast<DWORD>(Command.size()),
                        &BytesWritten,
                        nullptr) ||
                    BytesWritten != static_cast<DWORD>(Command.size()))
                {
                    DebugLine(L"WriteFile falhou; reconectando porta");
                    ConfigOk = false;
                    break;
                }
            }

            if (!ConfigOk)
                break;

            char Buffer[512];
            DWORD BytesRead = 0;

            if (!ReadFile(Port, Buffer, sizeof(Buffer), &BytesRead, nullptr))
            {
                DebugLine(L"ReadFile falhou; reconectando porta");
                break;
            }

            if (BytesRead > 0)
            {
                Pending.append(Buffer, Buffer + BytesRead);

                for (;;)
                {
                    const std::size_t NewLine = Pending.find('\n');
                    if (NewLine == std::string::npos)
                        break;

                    const std::string Line = Pending.substr(0, NewLine);
                    Pending.erase(0, NewLine + 1);
                    ProcessLine(Line);
                }

                // Protecao contra lixo serial sem quebra de linha.
                if (Pending.size() > 8192)
                    Pending.clear();
            }

            ProcessAutomaticRecovery();
        }

        CloseHandle(Port);
        FPortOpen.store(false);
        FDeviceReady.store(false);
        FPortOpenedTick.store(0);
        FLastProtocolRxTick.store(0);

        if (!FStopRequested.load())
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
    }

    FRunning.store(false);
    FPortOpen.store(false);
    FDeviceReady.store(false);
}
