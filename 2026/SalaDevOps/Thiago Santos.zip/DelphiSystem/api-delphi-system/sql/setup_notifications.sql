CREATE TABLE IF NOT EXISTS Notification (
  ID INTEGER PRIMARY KEY AUTOINCREMENT,
  EmployeeID INTEGER,
  Title TEXT NOT NULL,
  Message TEXT NOT NULL,
  Channel TEXT NOT NULL,
  Status TEXT NOT NULL,
  RequestedBy TEXT NOT NULL,
  CreatedAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  SentAt TEXT,
  ExternalID TEXT,
  ErrorMessage TEXT,
  FOREIGN KEY (EmployeeID) REFERENCES Employee(ID)
);

CREATE INDEX IF NOT EXISTS IX_Notification_Employee_Created
ON Notification(EmployeeID, CreatedAt DESC);
