const fs = require('fs');
const path = require('path');
const admin = require('firebase-admin');

const serviceAccountPath = path.join(
  __dirname,
  '..',
  'config',
  'firebase-service-account.json'
);

let initialized = false;

function ensureInitialized() {
  if (initialized) {
    return true;
  }

  if (!fs.existsSync(serviceAccountPath)) {
    console.warn('Firebase service account JSON nao encontrado:', serviceAccountPath);
    return false;
  }

  const serviceAccount = require(serviceAccountPath);

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });

  initialized = true;
  console.log('Firebase Admin SDK inicializado com sucesso.');
  return true;
}

function getMessaging() {
  if (!ensureInitialized()) {
    return null;
  }

  return admin.messaging();
}

module.exports = {
  getMessaging,
  ensureInitialized,
};
