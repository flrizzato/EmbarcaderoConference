const sqlite3 = require('sqlite3').verbose();

const databasePath =
  'C:/Users/Public/Documents/Embarcadero/Studio/37.0/Samples/Data/Employees.s3db';

const db = new sqlite3.Database(databasePath, (err) => {
  if (err) {
    console.error('Erro ao abrir o banco SQLite:', err.message);
    return;
  }

  console.log('SQLite conectado:', databasePath);
});

module.exports = db;
