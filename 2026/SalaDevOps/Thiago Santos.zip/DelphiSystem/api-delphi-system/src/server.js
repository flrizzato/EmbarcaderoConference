const express = require('express');
const cors = require('cors');
const { ensureInitialized } = require('./firebase');

const employeesRoutes = require('./routes/employees');
const gateRoutes = require('./routes/gate');
const managerRoutes = require('./routes/manager');
const notificationsRoutes = require('./routes/notifications');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

ensureInitialized();

app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    service: 'api-delphi-system',
    timestamp: new Date().toISOString(),
  });
});

app.use('/api/employees', employeesRoutes);
app.use('/api/gate', gateRoutes);
app.use('/api/manager', managerRoutes);
app.use('/api/notifications', notificationsRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({
    error: 'internal_error',
    message: err.message,
  });
});

app.listen(port, () => {
  console.log(`API rodando em http://localhost:${port}`);
});
