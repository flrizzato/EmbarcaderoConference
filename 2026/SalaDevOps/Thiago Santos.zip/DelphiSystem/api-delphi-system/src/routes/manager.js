const express = require('express');
const db = require('../db');

const router = express.Router();

router.get('/events', (req, res) => {
  const unreadOnly = req.query.unread === '1';
  const sql = `
    SELECT
      ID,
      EventType,
      EmployeeID,
      AccessLogID,
      Title,
      Message,
      IsRead,
      CreatedAt
    FROM ManagerEvent
    ${unreadOnly ? 'WHERE IsRead = 0' : ''}
    ORDER BY CreatedAt DESC
    LIMIT 50
  `;

  db.all(sql, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    res.json(rows);
  });
});

router.post('/events/:id/read', (req, res) => {
  const sql = `
    UPDATE ManagerEvent
       SET IsRead = 1
     WHERE ID = ?
  `;

  db.run(sql, [req.params.id], function (err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    res.json({
      success: true,
      changes: this.changes,
    });
  });
});

module.exports = router;
