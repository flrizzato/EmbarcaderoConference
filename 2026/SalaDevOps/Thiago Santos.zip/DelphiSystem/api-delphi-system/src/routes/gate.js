const express = require('express');
const db = require('../db');

const router = express.Router();

router.post('/access', (req, res) => {
  const { rfidTag, gateName, direction, sourceApp } = req.body;

  if (!rfidTag || !gateName) {
    return res.status(400).json({
      error: 'rfidTag_and_gateName_required',
    });
  }

  const employeeSql = `
    SELECT ID, Name, Department, RFIDTag
    FROM Employee
    WHERE RFIDTag = ?
  `;

  db.get(employeeSql, [rfidTag], (employeeErr, employee) => {
    if (employeeErr) {
      return res.status(500).json({ error: employeeErr.message });
    }

    const status = employee ? 'granted' : 'denied';
    const accessSql = `
      INSERT INTO AccessLog (
        EmployeeID,
        RFIDTag,
        GateName,
        Direction,
        Status,
        SourceApp
      ) VALUES (?, ?, ?, ?, ?, ?)
    `;

    db.run(
      accessSql,
      [
        employee ? employee.ID : null,
        rfidTag,
        gateName,
        direction || 'entry',
        status,
        sourceApp || 'cppbuilder-gate',
      ],
      function (accessErr) {
        if (accessErr) {
          return res.status(500).json({ error: accessErr.message });
        }

        const accessLogId = this.lastID;

        const eventTitle = employee ? 'Entrada liberada' : 'Tag nao cadastrada';
        const eventMessage = employee
          ? `${employee.Name} entrou pela ${gateName}.`
          : `Tentativa de acesso com a tag ${rfidTag} na ${gateName}.`;

        const eventSql = `
          INSERT INTO ManagerEvent (
            EventType,
            EmployeeID,
            AccessLogID,
            Title,
            Message,
            IsRead
          ) VALUES (?, ?, ?, ?, ?, 0)
        `;

        db.run(
          eventSql,
          [employee ? 'access-granted' : 'access-denied', employee ? employee.ID : null, accessLogId, eventTitle, eventMessage],
          function (eventErr) {
            if (eventErr) {
              return res.status(500).json({ error: eventErr.message });
            }

            res.json({
              allowed: !!employee,
              employee: employee
                ? {
                    id: employee.ID,
                    name: employee.Name,
                    department: employee.Department,
                  }
                : null,
              accessLogId,
              managerEventId: this.lastID,
            });
          }
        );
      }
    );
  });
});

module.exports = router;
