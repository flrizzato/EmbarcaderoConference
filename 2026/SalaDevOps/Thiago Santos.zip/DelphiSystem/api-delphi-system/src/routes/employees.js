const express = require('express');
const db = require('../db');

const router = express.Router();

router.get('/', (req, res) => {
  const sql = `
    SELECT
      ID,
      Name,
      Phone,
      [E-mail] AS Email,
      Department,
      Seniority,
      RFIDTag
    FROM Employee
    ORDER BY Name
  `;

  db.all(sql, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    res.json(rows);
  });
});

router.get('/by-rfid/:tag', (req, res) => {
  const sql = `
    SELECT
      ID,
      Name,
      Phone,
      [E-mail] AS Email,
      Department,
      Seniority,
      RFIDTag
    FROM Employee
    WHERE RFIDTag = ?
  `;

  db.get(sql, [req.params.tag], (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (!row) {
      return res.status(404).json({ error: 'Funcionario nao encontrado para esta tag RFID.' });
    }

    res.json(row);
  });
});

router.get('/:id', (req, res) => {
  const sql = `
    SELECT
      ID,
      Name,
      Phone,
      [E-mail] AS Email,
      Department,
      Seniority,
      RFIDTag
    FROM Employee
    WHERE ID = ?
  `;

  db.get(sql, [req.params.id], (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (!row) {
      return res.status(404).json({ error: 'Funcionario nao encontrado.' });
    }

    res.json(row);
  });
});

router.post('/:id/devices', (req, res) => {
  const { platform, deviceName, fcmToken } = req.body;

  if (!platform || !fcmToken) {
    return res.status(400).json({
      error: 'platform_and_fcmToken_required',
    });
  }

  const updateSql = `
    UPDATE EmployeeDevice
       SET EmployeeID = ?,
           Platform = ?,
           DeviceName = ?,
           Active = 1,
           LastSeenAt = CURRENT_TIMESTAMP,
           UpdatedAt = CURRENT_TIMESTAMP
     WHERE FCMToken = ?
  `;

  db.run(updateSql, [req.params.id, platform, deviceName || null, fcmToken], function (updateErr) {
    if (updateErr) {
      return res.status(500).json({ error: updateErr.message });
    }

    if (this.changes > 0) {
      return res.json({ success: true, updated: true });
    }

    const insertSql = `
      INSERT INTO EmployeeDevice (
        EmployeeID,
        Platform,
        DeviceName,
        FCMToken,
        Active,
        LastSeenAt
      ) VALUES (?, ?, ?, ?, 1, CURRENT_TIMESTAMP)
    `;

    db.run(insertSql, [req.params.id, platform, deviceName || null, fcmToken], function (insertErr) {
      if (insertErr) {
        return res.status(500).json({ error: insertErr.message });
      }

      res.json({
        success: true,
        created: true,
        id: this.lastID,
      });
    });
  });
});

module.exports = router;
