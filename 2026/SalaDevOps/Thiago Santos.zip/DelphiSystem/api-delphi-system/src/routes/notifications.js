const express = require('express');
const db = require('../db');
const { getMessaging } = require('../firebase');

const router = express.Router();

router.post('/push', (req, res) => {
  const { employeeId, title, message, requestedBy } = req.body;

  if (!employeeId || !title || !message) {
    return res.status(400).json({
      error: 'employeeId_title_message_required',
    });
  }

  const findDeviceSql = `
    SELECT ID, EmployeeID, Platform, DeviceName, FCMToken
    FROM EmployeeDevice
    WHERE EmployeeID = ?
      AND Active = 1
    ORDER BY UpdatedAt DESC
    LIMIT 1
  `;

  db.get(findDeviceSql, [employeeId], (deviceErr, device) => {
    if (deviceErr) {
      return res.status(500).json({ error: deviceErr.message });
    }

    const messaging = getMessaging();
    const status = device
      ? messaging
        ? 'queued'
        : 'firebase_not_configured'
      : 'device_not_registered';
    const notificationSql = `
      INSERT INTO Notification (
        EmployeeID,
        Title,
        Message,
        Channel,
        Status,
        RequestedBy
      ) VALUES (?, ?, ?, ?, ?, ?)
    `;

    db.run(
      notificationSql,
      [employeeId, title, message, 'push', status, requestedBy || 'delphi-system'],
      function (insertErr) {
        if (insertErr) {
          return res.status(500).json({ error: insertErr.message });
        }

        if (!device) {
          return res.status(404).json({
            success: false,
            notificationId: this.lastID,
            error: 'Nenhum dispositivo com FCM token foi registrado para este funcionario.',
          });
        }

        if (!messaging) {
          return res.status(503).json({
            success: false,
            notificationId: this.lastID,
            error: 'Firebase Admin SDK nao configurado.',
          });
        }

        const payload = {
          notification: {
            title,
            body: message,
          },
          data: {
            employeeId: String(employeeId),
            requestedBy: requestedBy || 'delphi-system',
          },
          token: device.FCMToken,
        };

        messaging
          .send(payload)
          .then((firebaseMessageId) => {
            const updateSql = `
              UPDATE Notification
                 SET Status = ?,
                     SentAt = CURRENT_TIMESTAMP,
                     ExternalID = ?
               WHERE ID = ?
            `;

            db.run(updateSql, ['sent', firebaseMessageId, this.lastID], (updateErr) => {
              if (updateErr) {
                return res.status(500).json({ error: updateErr.message });
              }

              res.json({
                success: true,
                notificationId: this.lastID,
                provider: 'firebase',
                firebaseMessageId,
                device: {
                  id: device.ID,
                  platform: device.Platform,
                  deviceName: device.DeviceName,
                },
              });
            });
          })
          .catch((sendErr) => {
            const updateSql = `
              UPDATE Notification
                 SET Status = ?,
                     ErrorMessage = ?
               WHERE ID = ?
            `;

            db.run(updateSql, ['failed', sendErr.message, this.lastID], () => {
              res.status(500).json({
                success: false,
                notificationId: this.lastID,
                error: sendErr.message,
              });
            });
          });
      }
    );
  });
});

module.exports = router;
