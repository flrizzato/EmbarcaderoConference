# ECON26 — projetos de palco

## Palestra 2 — WebStencils + Dext

Cópia do `Examples/04-Advanced/WebStencilsDemo` com a busca extraída para `ICustomerSearch`.

| Projeto | Porta / o que mostrar |
|---|---|
| `WebStencilsDemo` | `http://localhost:5000/customers` · HTMX |
| `WebStencilsDemo.Tests` | Fixture `TCustomerSearchTests` |

Script da pipeline: `Test.WebStencilsDemo.ps1` (ao lado do demo, não do projeto de testes).

Slide 6: em `Startup.pas`, comente `.AddWebStencils` e ligue `.AddDextTemplating` com `wwwroot/views-native`. Rebuild **só** este demo. Não mexa em `Dext.inc`.

Título na janela: **ECON26 · WebStencils + Dext**.
