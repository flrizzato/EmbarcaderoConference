(function () {
  'use strict';

  var STORAGE_KEY = 'ec2026:apiUrl';
  var DEFAULT_API_URL = window.APP_CONFIG.API_BASE_URL;

  var form = document.getElementById('loginForm');
  var username = document.getElementById('username');
  var password = document.getElementById('password');
  var submitBtn = document.getElementById('submitBtn');
  var feedback = document.getElementById('feedback');
  var apiHint = document.getElementById('apiHint');
  var configBtn = document.getElementById('configBtn');
  var configDialog = document.getElementById('configDialog');
  var apiUrlInput = document.getElementById('apiUrl');
  var saveApiBtn = document.getElementById('saveApiBtn');
  var resetApiBtn = document.getElementById('resetApiBtn');

  function getApiUrl() {
    var params = new URLSearchParams(window.location.search);
    if (params.get('api')) {
      return params.get('api').replace(/\/+$/, '');
    }
    return localStorage.getItem(STORAGE_KEY) || DEFAULT_API_URL;
  }

  function showFeedback(type, message) {
    feedback.className = 'feedback ' + type;
    feedback.textContent = message;
  }

  function setLoading(loading) {
    submitBtn.disabled = loading;
    var text = submitBtn.querySelector('.btn-text');
    var spinner = submitBtn.querySelector('.btn-spinner');
    text.style.display = loading ? 'none' : 'inline';
    spinner.style.display = loading ? 'inline-block' : 'none';
  }

  apiHint.textContent = 'API: ' + getApiUrl();

  form.addEventListener('submit', async function (ev) {
    ev.preventDefault();
    feedback.className = 'feedback hidden';

    var credentials = {
      Username: username.value.trim(),
      Password: password.value
    };

    setLoading(true);
    try {
      var response = await fetch(getApiUrl() + '/v1/Login', {
        method: 'POST',
        headers: {
          'accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(credentials)
      });

      var data = await response.json();
      var loginSuccess = data.LoginSuccess !== undefined ? data.LoginSuccess : data.loginSuccess;

      if (response.ok && loginSuccess) {
        window.location.href = 'dashboard.html';
      } else {
        showFeedback('error', data.Error || data.message || 'Falha no login. Verifique suas credenciais.');
      }
    } catch (err) {
      showFeedback('error', 'N\u00e3o foi poss\u00edvel conectar \u00e0 API em ' + getApiUrl());
    } finally {
      setLoading(false);
    }
  });

  configBtn.addEventListener('click', function () {
    apiUrlInput.value = getApiUrl();
    configDialog.showModal();
  });

  saveApiBtn.addEventListener('click', function () {
    if (apiUrlInput.checkValidity()) {
      localStorage.setItem(STORAGE_KEY, apiUrlInput.value.replace(/\/+$/, ''));
      configDialog.close();
      apiHint.textContent = 'API: ' + getApiUrl();
    }
  });

  resetApiBtn.addEventListener('click', function () {
    localStorage.removeItem(STORAGE_KEY);
    apiUrlInput.value = DEFAULT_API_URL;
    apiHint.textContent = 'API: ' + getApiUrl();
  });
})();