# Embarcadero Conference 2026

Projeto de exemplo para a **Embarcadero Conference 2026**: uma API REST em Delphi (Horse) com um frontend web simples (HTML/CSS/JS) que faz login e exibe um dashboard de exemplo baseado nos dados oficiais do evento.

## Estrutura

```
├── API.dpr                 # Projeto principal da API (Delphi + Horse)
├── Controller/             # Controladores (Login)
├── Services/               # Camada de serviços (regras de negócio)
├── Repository/             # Camada de acesso a dados (SQLite via ADRConn)
├── Model/                  # Modelos JSON (request/response, erro)
├── uSwagger.Documentation.pas  # Configuração do Swagger (Rota /v1)
├── db/                     # Banco SQLite (CadTemplete.db) + libsqlite3.so
├── docker/                 # Imagem Docker pronta para a API
└── frontend/               # Frontend web (login + dashboard mockado)
```

## Arquitetura da API

Camada em camadas (Controller → Services → Repository):

- **Controller**: recebe a requisição e devolve a resposta JSON (`uController.Login.pas`)
- **Services**: aplica as regras de negócio (`uServices.Login.pas`)
- **Repository**: executa as consultas no banco via `ADRConn` + FireDAC (`uRepository.Login.pas`)
- **Model**: define os contratos de request/response utilizados no Swagger

### Endpoints

| Método | Rota        | Descrição                          |
|--------|-------------|------------------------------------|
| POST   | `/v1/Login` | Autentica usuário e senha          |

Documentação interativa (Swagger): `http://localhost:9002/swagger/doc/html`

### Exemplo de requisição

```bash
curl -X 'POST' \
  'http://localhost:9002/v1/Login' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "Username": "admin",
  "Password": "123"
}'
```

Exemplo de resposta:

```json
{ "LoginSuccess": true }
```

## Executando a API

1. Abra o projeto `API.dproj` no RAD Studio (Delphi 12).
2. Compile para o alvo desejado (`Win32` ou `Linux64`).
3. Execute:

- **Windows**: rode o `API.exe` gerado.
- **WSL/Linux**: copie o binário junto de `CadTemplete.db` e `libsqlite3.so` e execute.
- **Docker**: veja a seção abaixo.

A API sobe na porta **9002**.

### Docker

Há uma imagem Docker pronta em `docker/dockerfile` (base Ubuntu 22.04):

```bash
cd docker
docker build -t ec2026-api .
docker run -p 9002:8080 ec2026-api
```

Obs.: o `dockerfile` atual expõe a porta `8080` internamente. Ajuste o `EXPOSE` e o mapeamento de porta conforme a porta de execução do binário `API`.

## Executando o frontend

Não há dependências. Basta abrir `frontend/index.html` diretamente no navegador ou servir a pasta:

```bash
cd frontend
python -m http.server 8080
```

Credenciais padrão do ambiente de exemplo: **admin / 123**.

### Configurando a URL da API

O frontend é configurável — útil para trocar o endpoint quando a API roda em container:

1. **Arquivo de config**: edite `frontend/js/config.js`
   ```js
   window.APP_CONFIG = { API_BASE_URL: 'http://localhost:9002' };
   ```
2. **Query string**: abra o site com `?api=http://host:porta`
3. **Na interface**: botão "Configurar API" no rodapé do login (salva em `localStorage`)

Após login com sucesso, o usuário é redirecionado para `frontend/dashboard.html`, um painel de exemplo com métricas, programação, trilhas, satisfação e patrocinadores (dados mockados baseados no site oficial da conferência).

## Dependências

### Backend (API)

- **RAD Studio / Delphi 12** (C++Builder/Personality Delphi)
- **Horse** — framework web REST
- **Horse.CORS** — middleware de CORS (necessário para o frontend consumir a API)
- **Horse.GBSwagger** — documentação Swagger na rota `/v1`
- **GBSwagger** — atributos dos modelos
- **ADRConn** (com define `ADRCONN_FIREDAC`) — camada de acesso a dados
- **FireDAC** — driver de banco da Delgado (bundled no Delphi)
- **SQLite** — arquivo `db/CadTemplete.db` + `libsqlite3.so` (Linux)

### Frontend

- Nenhuma — apenas HTML, CSS e JavaScript puro.

## Banco de dados

- Banco SQLite local: `db/CadTemplete.db`
- Tabela de login: `tab_login` (colunas `username` e `senha`)
- Usuário do exemplo: `admin` / `123`