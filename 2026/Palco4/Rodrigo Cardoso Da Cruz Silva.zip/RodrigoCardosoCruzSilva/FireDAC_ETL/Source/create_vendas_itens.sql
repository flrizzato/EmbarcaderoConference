/* ============================================================
   Script: cria as tabelas VENDAS e ITENS no banco destino
   Executado com TFDScript.ExecuteAll (Firebird 3+)

   Demonstra que o TFDScript aguenta em uma única execução:
     - Bloco EXECUTE BLOCK (PSQL) delimitado por SET TERM
     - RECREATE TABLE (idempotente)
     - CREATE INDEX
     - ALTER TABLE com FOREIGN KEY
     - INSERT de dados
     - COMMIT explícito
   ============================================================ */

SET TERM ^ ;

/* Dropa a FK antiga se existir (torna o script re-executável) */
EXECUTE BLOCK AS
BEGIN
  IF (EXISTS(SELECT 1 FROM RDB$RELATION_CONSTRAINTS
             WHERE RDB$CONSTRAINT_NAME = 'FK_ITENS_VENDA')) THEN
    EXECUTE STATEMENT 'ALTER TABLE itens DROP CONSTRAINT fk_itens_venda';
END^

SET TERM ; ^

/* --------------------------------------------------------- */
/* Tabela VENDAS                                             */
/* --------------------------------------------------------- */
RECREATE TABLE vendas (
  id              INTEGER       NOT NULL PRIMARY KEY,
  cliente_id      INTEGER       NOT NULL,
  data_venda      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP NOT NULL,
  total           NUMERIC(15,2) NOT NULL,
  forma_pagamento VARCHAR(20)
);

/* --------------------------------------------------------- */
/* Tabela ITENS (com coluna calculada)                       */
/* --------------------------------------------------------- */
RECREATE TABLE itens (
  id             INTEGER       NOT NULL PRIMARY KEY,
  venda_id       INTEGER       NOT NULL,
  produto        VARCHAR(80)   NOT NULL,
  quantidade     INTEGER       NOT NULL,
  preco_unitario NUMERIC(15,2) NOT NULL,
  subtotal       COMPUTED BY (quantidade * preco_unitario)
);

/* Índice para busca de itens por venda */
CREATE INDEX idx_itens_venda_id ON itens (venda_id);

/* Foreign key */
ALTER TABLE itens ADD CONSTRAINT fk_itens_venda
  FOREIGN KEY (venda_id) REFERENCES vendas (id);


/* --------------------------------------------------------- */
/* Dados de exemplo                                          */
/* --------------------------------------------------------- */
INSERT INTO vendas (id, cliente_id, data_venda, total, forma_pagamento)
  VALUES (1, 100, TIMESTAMP '2026-01-15 10:30:00', 1250.50, 'PIX');
INSERT INTO vendas (id, cliente_id, data_venda, total, forma_pagamento)
  VALUES (2, 100, TIMESTAMP '2026-02-03 14:20:00',  875.00, 'Cartao');
INSERT INTO vendas (id, cliente_id, data_venda, total, forma_pagamento)
  VALUES (3, 205, TIMESTAMP '2026-02-18 09:15:00', 2100.75, 'PIX');
INSERT INTO vendas (id, cliente_id, data_venda, total, forma_pagamento)
  VALUES (4, 342, TIMESTAMP '2026-03-01 16:45:00',  540.20, 'Boleto');

INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)
  VALUES (1, 1, 'Teclado Mecanico', 1,  850.50);
INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)
  VALUES (2, 1, 'Mousepad',         2,  200.00);
INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)
  VALUES (3, 2, 'Cabo HDMI 2m',     5,  175.00);
INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)
  VALUES (4, 3, 'Monitor 27 pol',   1, 1800.00);
INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)
  VALUES (5, 3, 'Suporte VESA',     1,  300.75);
INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)
  VALUES (6, 4, 'Webcam Full HD',   1,  540.20);

