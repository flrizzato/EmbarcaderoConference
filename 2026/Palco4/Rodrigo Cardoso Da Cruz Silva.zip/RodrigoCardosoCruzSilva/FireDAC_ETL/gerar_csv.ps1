# Gera um CSV de clientes no layout id;nome;email;cidade;renda;data_nascimento
# Uso:
#   pwsh -File gerar_csv.ps1                                  # default: Clientes.csv com 1.000.000 linhas
#   pwsh -File gerar_csv.ps1 -Total 10000 -OutFile Clientes_10k.csv

param(
    [int]$Total = 1000000,
    [string]$OutFile = 'Clientes.csv',
    [string]$DateFormat = 'dd/MM/yyyy'
)

$PastaSource = Join-Path $PSScriptRoot 'Source'
if (-not (Test-Path $PastaSource)) { New-Item -ItemType Directory -Path $PastaSource | Out-Null }
$Destino = Join-Path $PastaSource $OutFile

$Nomes    = @('Ana','Bruno','Carla','Diego','Elena','Fabio','Gabi','Hugo','Iris','Joao','Karla','Luca','Marina','Nina','Otavio','Paula','Renato','Sofia','Tiago','Ursula','Victor','Wagner','Yara','Zeca')
$Sobrenomes = @('Souza','Lima','Dias','Alves','Rocha','Nunes','Melo','Prado','Costa','Ferreira','Ribeiro','Cardoso','Machado','Peixoto','Barros','Cavalcanti','Moreira','Xavier','Vieira','Teixeira')
$Cidades  = @('Sao Paulo','Rio de Janeiro','Belo Horizonte','Curitiba','Porto Alegre','Salvador','Recife','Fortaleza','Manaus','Brasilia','Goiania','Campinas','Florianopolis','Vitoria','Natal','Belem','Maceio','Aracaju','Cuiaba','Palmas')

# Faixa de nascimento: 1950-01-01 .. 2005-12-31 (dias entre as datas)
$DataMin  = [DateTime]::new(1950, 1, 1)
$DataMax  = [DateTime]::new(2005, 12, 31)
$RangeDias = [int]($DataMax - $DataMin).TotalDays

# Progresso: mostra a cada 10% do total (mínimo a cada 10 mil linhas)
$Passo = [Math]::Max(10000, [int]($Total / 10))

$Cultura = [System.Globalization.CultureInfo]::InvariantCulture
$Encoding = New-Object System.Text.UTF8Encoding($false)   # UTF-8 sem BOM
$SW = [System.IO.StreamWriter]::new($Destino, $false, $Encoding)
try {
    $SW.WriteLine('id;nome;email;cidade;renda;data_nascimento')
    $Rnd = [System.Random]::new(20260823)
    for ($i = 1; $i -le $Total; $i++) {
        $Nome     = "$($Nomes[$Rnd.Next($Nomes.Length)]) $($Sobrenomes[$Rnd.Next($Sobrenomes.Length)])"
        $EmailRaw = ($Nome.ToLower() -replace ' ','.') + $i + '@exemplo.com'
        $Cidade   = $Cidades[$Rnd.Next($Cidades.Length)]
        $Valor    = [Math]::Round($Rnd.NextDouble() * 5000 + 50, 2)
        $ValorStr = $Valor.ToString('F2', $Cultura)
        $DataNasc = $DataMin.AddDays($Rnd.Next($RangeDias + 1)).ToString($DateFormat)
        $SW.WriteLine("$i;$Nome;$EmailRaw;$Cidade;$ValorStr;$DataNasc")
        if (($i % $Passo) -eq 0) { Write-Host "  $i / $Total" }
    }
} finally {
    $SW.Dispose()
}

$InfoArq = Get-Item $Destino
Write-Host ""
Write-Host "OK: $Destino"
Write-Host ("Tamanho: {0:N0} bytes" -f $InfoArq.Length)
