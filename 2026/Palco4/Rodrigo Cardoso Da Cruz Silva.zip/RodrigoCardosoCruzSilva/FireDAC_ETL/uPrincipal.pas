﻿unit uPrincipal;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Classes,
  System.IOUtils, Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs,
  Vcl.StdCtrls, Vcl.ExtCtrls, Vcl.ComCtrls, Vcl.Grids, Vcl.DBGrids, Data.DB,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Error, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Stan.Async, FireDAC.Stan.Param,
  FireDAC.Stan.ExprFuncs, FireDAC.DApt, FireDAC.Phys, FireDAC.Phys.Intf,
  FireDAC.Phys.FB, FireDAC.Phys.FBDef, FireDAC.Phys.PG, FireDAC.Phys.PGDef,
  FireDAC.VCLUI.Wait, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  FireDAC.Comp.BatchMove, FireDAC.Comp.BatchMove.Text,
  FireDAC.Comp.BatchMove.DataSet, FireDAC.Comp.BatchMove.SQL,
  FireDAC.Comp.BatchMove.JSON, FireDAC.Comp.Script, FireDAC.Comp.ScriptCommands,
  FireDAC.UI.Intf, FireDAC.Phys.MongoDB, FireDAC.Phys.MongoDBDef, System.Rtti,
  System.JSON.Types, System.JSON.Readers, System.JSON.BSON, System.JSON.Builders,
  FireDAC.Phys.MongoDBWrapper, FireDAC.DatS, FireDAC.DApt.Intf,
  FireDAC.Phys.MongoDBDataSet, FireDAC.Stan.Util;

type
  TfrmPrincipal = class(TForm)
    pnlBotoes: TPanel;
    lblTitulo: TLabel;
    btnCenario1: TButton;
    btnCenario2: TButton;
    btnCenario3: TButton;
    btnCenario4: TButton;
    btnCenario5: TButton;
    btnCenario6: TButton;
    btnCenario7: TButton;
    btnCenario8: TButton;
    btnCenario9: TButton;
    btnCenario10: TButton;
    btnCenario11: TButton;
    btnLimpar: TButton;
    pgc: TPageControl;
    tsLog: TTabSheet;
    mmoLog: TMemo;
    tsGrid: TTabSheet;
    grd: TDBGrid;
    dsGrid: TDataSource;
    pbProgresso: TProgressBar;
    FDBatchMove1: TFDBatchMove;
    FDConnection1: TFDConnection;
    FDMongoQuery1: TFDMongoQuery;
    FDBatchMoveTextReader1: TFDBatchMoveTextReader;
    FDBatchMoveDataSetWriter1: TFDBatchMoveDataSetWriter;
    FDMemTable1: TFDMemTable;
    FDScript1: TFDScript;
    FDBatchMoveSQLWriter1: TFDBatchMoveSQLWriter;
    FDBatchMoveTextWriter1: TFDBatchMoveTextWriter;
    FDBatchMoveJSONWriter1: TFDBatchMoveJSONWriter;
    FDBatchMoveSQLReader1: TFDBatchMoveSQLReader;
    FDBatchMoveDataSetReader1: TFDBatchMoveDataSetReader;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    /// <summary>
    ///   Cenário 1: CSV → Database (Firebird)
    /// </summary>
    procedure btnCenario1Click(Sender: TObject);
    /// <summary>
    ///   Cenário 2: CSV → DataSet
    /// </summary>
    procedure btnCenario2Click(Sender: TObject);
    /// <summary>
    ///   Cenário 3: DataSet → Database (Firebird)
    /// </summary>
    procedure btnCenario3Click(Sender: TObject);
    /// <summary>
    ///   Cenário 4: DB → DB (Firebird → Postgres)
    /// </summary>
    procedure btnCenario4Click(Sender: TObject);
    /// <summary>
    ///  Cenário 5: Database (Firebird) → CSV
    /// </summary>
    procedure btnCenario5Click(Sender: TObject);
    /// <summary>
    ///  Cenário 6: Database (Firebird) → JSON
    /// </summary>
    procedure btnCenario6Click(Sender: TObject);
    /// <summary>
    ///   Cenário 7: Database (Firebird) → MongoDB
    /// </summary>
    procedure btnCenario7Click(Sender: TObject);
    /// <summary>
    ///   Cenário 8: FDSCRIPT + FireDAC Metadata
    /// </summary>
    procedure btnCenario8Click(Sender: TObject);
    /// <summary>
    ///   Cenário 9: ARRAY DML — tamanho fixo (ArraySize == Execute(N))
    /// </summary>
    procedure btnCenario9Click(Sender: TObject);
    /// <summary>
    ///   Cenário 10: ARRAY DML — chunks com contador (Execute(contador) != ArraySize)
    /// </summary>
    procedure btnCenario10Click(Sender: TObject);
    /// <summary>
    ///   Cenário 11: INSERT tradicional em loop (sem Array DML)
    /// </summary>
    procedure btnCenario11Click(Sender: TObject);
    procedure btnLimparClick(Sender: TObject);
  private
    FPastaSource: string;
    FPastaTarget: string;
    FArquivoCSV: string;
    FPGDriverLink: TFDPhysPGDriverLink;
    FBM3Rejeitadas: Integer;
    FBM3MemTable: TDataSet;
    LFDMemTable: TFDMemTable;
    procedure Log(const AMsg: string); overload;
    procedure Log(const AFmt: string; const AArgs: array of const); overload;
    function ArquivoCSV: string;
    function CaminhoTarget(const ANome: string): string;
    function NovaConexaoFirebird(const ACaminhoCompleto: string): TFDConnection;
    function NovaConexaoPostgres(const ADatabase: string): TFDConnection;
    procedure MontarVendaItensEmMemoria(AMem: TFDMemTable);
    procedure BM3ValidarRegistro(ASender: TObject; var AAction: TFDBatchMoveAction);
    procedure Executar(const ATitulo: string; AAcao: TProc);
  end;

var
  frmPrincipal: TfrmPrincipal;

implementation

{$R *.dfm}

uses
  System.Diagnostics, System.TimeSpan, System.StrUtils, System.Math;

function TamanhoArquivo(const APath: string): Int64;
var
  LFS: TFileStream;
begin
  LFS := TFileStream.Create(APath, fmOpenRead or fmShareDenyNone);
  try
    Result := LFS.Size;
  finally
    LFS.Free;
  end;
end;

function FormatarDuracao(const ATS: TTimeSpan): string;
var
  LH: Int64;
begin
  LH := Trunc(ATS.TotalHours);
  if LH > 0 then
    Result := Format('%dh %.2dm %.2ds %.3dms', [LH, ATS.Minutes, ATS.Seconds, ATS.Milliseconds])

  else if ATS.Minutes > 0 then
    Result := Format('%dm %.2ds %.3dms', [ATS.Minutes, ATS.Seconds, ATS.Milliseconds])

  else if ATS.Seconds > 0 then
    Result := Format('%ds %.3dms', [ATS.Seconds, ATS.Milliseconds])
  else
    Result := Format('%dms', [ATS.Milliseconds]);
end;

procedure TfrmPrincipal.Log(const AMsg: string);
begin
  mmoLog.Lines.Add(AMsg);
  SendMessage(mmoLog.Handle, EM_LINESCROLL, 0, mmoLog.Lines.Count);
end;

procedure TfrmPrincipal.Log(const AFmt: string; const AArgs: array of const);
begin
  Log(Format(AFmt, AArgs));
end;

procedure TfrmPrincipal.Executar(const ATitulo: string; AAcao: TProc);
var
  LStopWatch: TStopwatch;
begin
  Log('» ' + ATitulo);
  LStopWatch := TStopwatch.StartNew;
  Screen.Cursor := crHourGlass;
  pbProgresso.Visible := True;
  Application.ProcessMessages;
  try
    try
      AAcao();
      LStopWatch.Stop;
      Log('OK em %s', [FormatarDuracao(LStopWatch.Elapsed)]);
    except
      on E: Exception do
        Log('FALHOU: %s', [E.Message]);
    end;
  finally
    pbProgresso.Visible := False;
    Screen.Cursor := crDefault;
    Log('');
  end;
end;

function TfrmPrincipal.CaminhoTarget(const ANome: string): string;
begin
  Result := TPath.Combine(FPastaTarget, ANome);
end;

function TfrmPrincipal.NovaConexaoPostgres(const ADatabase: string): TFDConnection;
const
  LIBPQ_PATH = 'C:\Program Files\PostgreSQL\18\bin\libpq.dll';
begin
  if FPGDriverLink = nil then
  begin
    FPGDriverLink := TFDPhysPGDriverLink.Create(Self);
    FPGDriverLink.VendorLib := LIBPQ_PATH;
  end;

  Result := TFDConnection.Create(nil);
  try
    Result.DriverName := 'PG';
    Result.Params.Values['Server'] := 'localhost';
    Result.Params.Values['Port'] := '5432';
    Result.Params.Values['Database'] := ADatabase;
    Result.Params.Values['User_Name'] := 'postgres';
    Result.Params.Values['Password'] := 'rccs14';
    Result.Params.Values['CharacterSet'] := 'UTF8';
    Result.Params.Values['ExtendedMetadata'] := 'False';
    Result.LoginPrompt := False;
    Result.Open;
  except
    Result.Free;
    raise;
  end;
end;

function TfrmPrincipal.NovaConexaoFirebird(const ACaminhoCompleto: string): TFDConnection;
var
  LExiste: Boolean;
begin
  LExiste := FileExists(ACaminhoCompleto);

  Result := TFDConnection.Create(nil);
  try
    Result.DriverName := 'FB';
    Result.Params.Values['Database'] := ACaminhoCompleto;
    Result.Params.Values['User_Name'] := 'SYSDBA';
    Result.Params.Values['Password'] := 'masterkey';
    Result.Params.Values['CharacterSet'] := 'UTF8';
    Result.Params.Values['Port'] := '3060';

    if not LExiste then
      Result.Params.Values['CreateDatabase'] := 'Yes';

    Result.LoginPrompt := False;
    Result.Open;
  except
    Result.Free;
    raise;
  end;
end;

function TfrmPrincipal.ArquivoCSV: string;
var
  LDialog: TOpenDialog;
begin
  if (FArquivoCSV <> '') and TFile.Exists(FArquivoCSV) then
    Exit(FArquivoCSV);

  LDialog := TOpenDialog.Create(nil);
  try
    LDialog.Title := 'Selecione o arquivo CSV de origem';
    LDialog.Filter := 'Arquivos CSV (*.csv)|*.csv|Todos (*.*)|*.*';
    LDialog.DefaultExt := 'csv';
    LDialog.InitialDir := FPastaSource;
    LDialog.Options := LDialog.Options + [ofFileMustExist];

    if not LDialog.Execute then
      raise Exception.Create('Nenhum arquivo CSV selecionado.');

    FArquivoCSV := LDialog.FileName;
    Log('CSV selecionado: %s', [FArquivoCSV]);
    Result := FArquivoCSV;
  finally
    LDialog.Free;
  end;
end;

procedure TfrmPrincipal.FormCreate(Sender: TObject);
var
  LBase: string;
begin
  LBase := TPath.GetDirectoryName(ParamStr(0));
  FPastaSource := TPath.Combine(LBase, 'Source');
  FPastaTarget := TPath.Combine(LBase, 'Target');
  TDirectory.CreateDirectory(FPastaSource);
  TDirectory.CreateDirectory(FPastaTarget);

  LFDMemTable := TFDMemTable.Create(Self);
  dsGrid.DataSet := LFDMemTable;

  Log('FireDAC ETL — cenários');
  Log('');
end;

procedure TfrmPrincipal.FormDestroy(Sender: TObject);
begin
  dsGrid.DataSet := nil;
end;

procedure TfrmPrincipal.btnLimparClick(Sender: TObject);
begin
  mmoLog.Clear;
end;

procedure TfrmPrincipal.btnCenario1Click(Sender: TObject);
begin
  Executar('1) CSV → Banco Firebird (target.fdb)',
    procedure
    var
      LConnection: TFDConnection;
      LBMTextReader: TFDBatchMoveTextReader;
      LBMSQLWriter: TFDBatchMoveSQLWriter;
      LFDBatchMove: TFDBatchMove;
      LMapping: TFDBatchMoveMappingItem;
      LTotal: Int64;
    begin
      LConnection := NovaConexaoFirebird(CaminhoTarget('target.fdb'));
      LBMTextReader := TFDBatchMoveTextReader.Create(nil);
      LBMSQLWriter := TFDBatchMoveSQLWriter.Create(nil);
      LFDBatchMove := TFDBatchMove.Create(nil);
      try
        // Configurações de Leitura
        LBMTextReader.FileName := ArquivoCSV;
        LBMTextReader.DataDef.Separator := ';';
        LBMTextReader.DataDef.WithFieldNames := True;
        LBMTextReader.Encoding := ecUTF8;
        LBMTextReader.DataDef.FormatSettings.ShortDateFormat := 'yyyy-mm-dd';
        LBMTextReader.DataDef.FormatSettings.DateSeparator := '-';
        LBMTextReader.DataDef.FormatSettings.DecimalSeparator := '.';
        LBMTextReader.DataDef.FormatSettings.ThousandSeparator := ',';

        LBMSQLWriter.Connection := LConnection;
        LBMSQLWriter.TableName := 'cliente';

        LFDBatchMove.Reader := LBMTextReader;
        LFDBatchMove.Writer := LBMSQLWriter;
        LFDBatchMove.CommitCount := 100000;

        // Limpar Tabela
        LFDBatchMove.Options := LFDBatchMove.Options + [poClearDest];

        // Mappings explícitos
        LFDBatchMove.Mappings.Clear;
        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'id';
        LMapping.DestinationFieldName := 'id';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'nome';
        LMapping.DestinationFieldName := 'nome';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'email';
        LMapping.DestinationFieldName := 'email';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'cidade';
        LMapping.DestinationFieldName := 'cidade';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'renda';
        LMapping.DestinationFieldName := 'renda';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'data_nascimento';
        LMapping.DestinationFieldName := 'data_nascimento';

        // Tolerância a erros: linhas com data mal-formatada / violação de
        // constraint vão pro log em vez de abortar o Execute.
        LFDBatchMove.MaxErrors := 0;
        LFDBatchMove.LogFileName := CaminhoTarget('bm_erros.log');
        LFDBatchMove.LogFileAction := laCreate;

        LFDBatchMove.Execute;

        LTotal := LConnection.ExecSQLScalar('SELECT COUNT(*) FROM cliente');
        Log('Tabela cliente em target.fdb: %d linhas', [LTotal]);
        Log('Inseridas   : %d', [LFDBatchMove.InsertCount]);
        Log('Rejeitadas  : %d', [LFDBatchMove.ErrorCount]);

        if LFDBatchMove.ErrorCount > 0 then
          Log('Detalhes em : %s', [LFDBatchMove.LogFileName]);
      finally
        LFDBatchMove.Free;
        LBMSQLWriter.Free;
        LBMTextReader.Free;
        LConnection.Free;
      end;
    end);
end;

procedure TfrmPrincipal.btnCenario2Click(Sender: TObject);
begin
  FArquivoCSV := '';

  Executar('2) CSV → TFDMemTable (dataset em memória)',
    procedure
    var
      LBMTextReader: TFDBatchMoveTextReader;
      LBMDataSetWriter: TFDBatchMoveDataSetWriter;
      LFDBatchMove: TFDBatchMove;
    begin
      LFDMemTable.Close;
      LFDMemTable.FieldDefs.Clear;
      { Cria fields "manualmente"
      LFDMemTable.FieldDefs.Add('id',     ftInteger);
      LFDMemTable.FieldDefs.Add('nome',   ftString, 60);
      LFDMemTable.FieldDefs.Add('email',  ftString, 80);
      LFDMemTable.FieldDefs.Add('cidade', ftString, 40);
      LFDMemTable.FieldDefs.Add('renda',  ftFloat);
      LFDMemTable.CreateDataSet;
      }

      LFDMemTable.FormatOptions.FmtDisplayNumeric := '#,##0.00';
      LFDMemTable.FormatOptions.FmtDisplayDate := 'dd/mm/yyyy';

      LBMTextReader := TFDBatchMoveTextReader.Create(nil);
      LBMDataSetWriter := TFDBatchMoveDataSetWriter.Create(nil);
      LFDBatchMove := TFDBatchMove.Create(nil);
      try
        LBMTextReader.FileName := ArquivoCSV;
        LBMTextReader.DataDef.Separator := ';';
        LBMTextReader.DataDef.WithFieldNames := True;
        LBMTextReader.Encoding := ecANSI;

        LBMTextReader.DataDef.FormatSettings.DecimalSeparator := '.';
        LBMTextReader.DataDef.FormatSettings.ThousandSeparator := ',';
        LBMTextReader.DataDef.FormatSettings.ShortDateFormat := 'yyyy-mm-dd';
        LBMTextReader.DataDef.FormatSettings.DateSeparator := '-';

        LBMDataSetWriter.DataSet := LFDMemTable;

        LFDBatchMove.Reader := LBMTextReader;
        LFDBatchMove.Writer := LBMDataSetWriter;

        // Analisa registros e gera fields
        LFDBatchMove.AnalyzeSample := 10;
        LFDBatchMove.Analyze := [taFields];
        LFDBatchMove.Execute;
      finally
        LFDBatchMove.Free;
        LBMDataSetWriter.Free;
        LBMTextReader.Free;
      end;

      Log('Dataset em memória com %d linhas e %d colunas.', [LFDMemTable.RecordCount, LFDMemTable.FieldCount]);
      LFDMemTable.First;
      pgc.ActivePage := tsGrid;
    end);
end;

procedure TfrmPrincipal.MontarVendaItensEmMemoria(AMem: TFDMemTable);
var
  LI, LQtd: Integer;
  LVUnit, LVTotal: Double;
begin
  AMem.FieldDefs.Clear;
  AMem.FieldDefs.Add('id', ftInteger);
  AMem.FieldDefs.Add('id_venda', ftInteger);
  AMem.FieldDefs.Add('descricao', ftString, 80);
  AMem.FieldDefs.Add('quantidade', ftInteger);
  AMem.FieldDefs.Add('valor_unitario', ftFloat);
  AMem.FieldDefs.Add('valor_total', ftFloat);
  AMem.CreateDataSet;

  for LI := 1 to 10 do
  begin
    LQtd := LI + 1;              // 2, 3, 4, 5, 6, 7
    LVUnit := 10.5 * LI;           // 10.50, 21.00, 31.50, ...
    LVTotal := LVUnit * LQtd;
    AMem.Append;
    AMem.FieldByName('id').AsInteger := LI;
    AMem.FieldByName('id_venda').AsInteger := 1000 + (LI mod 3);
    AMem.FieldByName('descricao').AsString := 'Produto ' + LI.ToString;
    AMem.FieldByName('quantidade').AsInteger := LQtd;
    AMem.FieldByName('valor_unitario').AsFloat := LVUnit;
    AMem.FieldByName('valor_total').AsFloat := LVTotal;
    AMem.Post;
  end;

  // Linhas propositalmente INVÁLIDAS para o handler de validação rejeitar
  // (demonstração do OnWriteRecord no cenário 3):
  //   id=11 → descricao vazia
  AMem.Append;
  AMem.FieldByName('id').AsInteger := 11;
  AMem.FieldByName('id_venda').AsInteger := 1000;
  AMem.FieldByName('descricao').AsString := '';
  AMem.FieldByName('quantidade').AsInteger := 1;
  AMem.FieldByName('valor_unitario').AsFloat := 5.00;
  AMem.FieldByName('valor_total').AsFloat := 5.00;
  AMem.Post;

  //   id=12 → quantidade zero (e valor_total incoerente com quantidade)
  AMem.Append;
  AMem.FieldByName('id').AsInteger := 12;
  AMem.FieldByName('id_venda').AsInteger := 1001;
  AMem.FieldByName('descricao').AsString := 'Produto zero';
  AMem.FieldByName('quantidade').AsInteger := 0;
  AMem.FieldByName('valor_unitario').AsFloat := 10.00;
  AMem.FieldByName('valor_total').AsFloat := 10.00;
  AMem.Post;

  //   id=13 → valor_total NÃO bate com qtd × unitario
  AMem.Append;
  AMem.FieldByName('id').AsInteger := 13;
  AMem.FieldByName('id_venda').AsInteger := 1002;
  AMem.FieldByName('descricao').AsString := 'Total incoerente';
  AMem.FieldByName('quantidade').AsInteger := 3;
  AMem.FieldByName('valor_unitario').AsFloat := 10.00;
  AMem.FieldByName('valor_total').AsFloat := 999.99;   // esperado 30.00
  AMem.Post;
end;

procedure TfrmPrincipal.BM3ValidarRegistro(ASender: TObject; var AAction: TFDBatchMoveAction);
var
  LDescricao: string;
  LQtd: Integer;
  LVUnit, LVTotal, LEsperado: Double;
  LMotivo: string;
begin
  LDescricao := FBM3MemTable.FieldByName('descricao').AsString.Trim;
  LQtd := FBM3MemTable.FieldByName('quantidade').AsInteger;
  LVUnit := FBM3MemTable.FieldByName('valor_unitario').AsFloat;
  LVTotal := FBM3MemTable.FieldByName('valor_total').AsFloat;
  LEsperado := LQtd * LVUnit;

  if LDescricao = '' then
    LMotivo := 'descrição vazia'

  else if LQtd <= 0 then
    LMotivo := Format('quantidade inválida (%d)', [LQtd])

  else if LVUnit <= 0 then
    LMotivo := Format('valor_unitario inválido (%.2f)', [LVUnit])

  else if Abs(LVTotal - LEsperado) > 0.01 then   // tolerância de 1 centavo
    LMotivo := Format('valor_total (%.2f) != qtd*unit (%.2f)', [LVTotal, LEsperado])

  else
    Exit;   // válido — NÃO mexe em AAction; deixa o valor que veio (INSERT/UPDATE)

  Inc(FBM3Rejeitadas);
  Log('  ✖ id=%d rejeitada: %s', [FBM3MemTable.FieldByName('id').AsInteger, LMotivo]);
  AAction := paSkip;
end;

procedure TfrmPrincipal.btnCenario3Click(Sender: TObject);
begin
  Executar('3) TFDMemTable → Banco Firebird (venda_itens)',
    procedure
    var
      LConnection: TFDConnection;
      LMemTable: TFDMemTable;
      LBMDataSetReader: TFDBatchMoveDataSetReader;
      LBMSQLWriter: TFDBatchMoveSQLWriter;
      LFDBatchMove: TFDBatchMove;
      LTotal: Int64;
    begin
      LMemTable := TFDMemTable.Create(nil);
      LConnection := NovaConexaoFirebird(CaminhoTarget('target.fdb'));
      LBMDataSetReader := TFDBatchMoveDataSetReader.Create(nil);
      LBMSQLWriter := TFDBatchMoveSQLWriter.Create(nil);
      LFDBatchMove := TFDBatchMove.Create(nil);
      try
        MontarVendaItensEmMemoria(LMemTable);

        LBMDataSetReader.DataSet := LMemTable;
        LBMSQLWriter.Connection := LConnection;
        LBMSQLWriter.TableName := 'venda_itens';
        LFDBatchMove.Reader := LBMDataSetReader;
        LFDBatchMove.Writer := LBMSQLWriter;
        LFDBatchMove.Mode := dmAppendUpdate;

        FBM3Rejeitadas := 0;
        FBM3MemTable := LMemTable;
        try
          // Evento com validações
          LFDBatchMove.OnWriteRecord := BM3ValidarRegistro;
          LFDBatchMove.Execute;
        finally
          FBM3MemTable := nil;
        end;

        Log('');
        Log('Dataset origem            : %d linhas', [LMemTable.RecordCount]);
        Log('  Rejeitadas por validação: %d', [FBM3Rejeitadas]);
        Log('  Gravadas em venda_itens : %d', [LFDBatchMove.InsertCount + LFDBatchMove.UpdateCount]);
        Log('  Incluídos: %d', [LFDBatchMove.InsertCount]);
        Log('  Atualizados: %d', [LFDBatchMove.UpdateCount]);

        LTotal := LConnection.ExecSQLScalar('SELECT COUNT(*) FROM venda_itens');

        Log('Total na tabela destino   : %d', [LTotal]);
      finally
        LFDBatchMove.Free;
        LBMSQLWriter.Free;
        LBMDataSetReader.Free;
        LMemTable.Free;
        LConnection.Free;
      end;
    end);
end;

procedure TfrmPrincipal.btnCenario4Click(Sender: TObject);
begin
  Executar('4) Firebird (source.fdb) → Postgres (target_pg.cliente)',
    procedure
    var
      LOrigem, LDestino: TFDConnection;
      LBMSQLReader: TFDBatchMoveSQLReader;
      LBMSQLWriter: TFDBatchMoveSQLWriter;
      LFDBatchMove: TFDBatchMove;
      LMapping: TFDBatchMoveMappingItem;
      LTotal: Int64;
    begin
      LOrigem := NovaConexaoFirebird(CaminhoTarget('target.fdb'));
      LDestino := NovaConexaoPostgres('target_pg');

      LBMSQLReader := TFDBatchMoveSQLReader.Create(nil);
      LBMSQLWriter := TFDBatchMoveSQLWriter.Create(nil);
      LFDBatchMove := TFDBatchMove.Create(nil);
      try
        LBMSQLReader.Connection := LOrigem;
        LBMSQLReader.ReadSQL := 'SELECT * FROM cliente';

        { SQL Robusto
        LBMSQLReader.ReadSQL :=
          '''
            SELECT
              id AS codigo,
              UPPER(nome) AS nome_completo,
              CAST(email AS VARCHAR(50)) AS email,
              UPPER(cidade) as cidade,
              renda AS renda_mensal,
              data_nascimento as dt_nascimento
            FROM cliente';
          ''';
        }

        LBMSQLWriter.Connection := LDestino;
        LBMSQLWriter.TableName := 'cliente';

        LFDBatchMove.Reader := LBMSQLReader;
        LFDBatchMove.Writer := LBMSQLWriter;
        LFDBatchMove.CommitCount := 10000;

        // Mapping
        LFDBatchMove.Mappings.Clear;

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'id';
        LMapping.DestinationFieldName := 'codigo';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'nome';
        LMapping.DestinationFieldName := 'nome_completo';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'email';
        LMapping.DestinationFieldName := 'email';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'cidade';
        LMapping.DestinationFieldName := 'cidade';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'renda';
        LMapping.DestinationFieldName := 'renda_mensal';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'data_nascimento';
        LMapping.DestinationFieldName := 'dt_nascimento';

        LFDBatchMove.Execute;

        LTotal := LDestino.ExecSQLScalar('SELECT COUNT(*) FROM cliente');

        Log('Copiadas %d linhas de source.fdb (Firebird) para target_pg.cliente (Postgres)', [LTotal]);

        Log('Mappings aplicados: id→codigo, nome→nome_completo (UPPER),');

        Log('  renda→valor_gasto, data_nascimento→dt_nascimento (email/cidade iguais)');
      finally
        LFDBatchMove.Free;
        LBMSQLWriter.Free;
        LBMSQLReader.Free;
        LDestino.Free;
        LOrigem.Free;
      end;
    end);
end;

procedure TfrmPrincipal.btnCenario5Click(Sender: TObject);
begin
  Executar('5) Banco → CSV (export.csv)',
    procedure
    var
      LConnection: TFDConnection;
      LBMSQLReader: TFDBatchMoveSQLReader;
      LBMTextWriter: TFDBatchMoveTextWriter;
      LFDBatchMove: TFDBatchMove;
      LArq: string;
      LTotal: Int64;
    begin
      LArq := CaminhoTarget('export.csv');

      if TFile.Exists(LArq) then
        TFile.Delete(LArq);

      LConnection := NovaConexaoFirebird(CaminhoTarget('target.fdb'));

      LBMSQLReader := TFDBatchMoveSQLReader.Create(nil);
      LBMTextWriter := TFDBatchMoveTextWriter.Create(nil);
      LFDBatchMove := TFDBatchMove.Create(nil);
      try
        LBMSQLReader.Connection := LConnection;
        LBMSQLReader.ReadSQL := 'SELECT id, nome, email, cidade, renda, data_nascimento FROM cliente';

        LBMTextWriter.FileName := LArq;
        LBMTextWriter.DataDef.Separator := ';';
        LBMTextWriter.DataDef.WithFieldNames := True;
        LBMTextWriter.Encoding := ecUTF8;

        LFDBatchMove.Reader := LBMSQLReader;
        LFDBatchMove.Writer := LBMTextWriter;
        LFDBatchMove.Execute;

        LTotal := LConnection.ExecSQLScalar('SELECT COUNT(*) FROM cliente');
        Log('CSV gerado: %s', [LArq]);
        Log('Linhas exportadas: %d', [LTotal]);
        Log('Tamanho do arquivo: %.2f MB', [TamanhoArquivo(LArq) / (1024 * 1024)]);
      finally
        LFDBatchMove.Free;
        LBMTextWriter.Free;
        LBMSQLReader.Free;
        LConnection.Free;
      end;
    end);
end;

procedure TfrmPrincipal.btnCenario6Click(Sender: TObject);
begin
  Executar('6) Banco → JSON (export.json)',
    procedure
    var
      LConnection: TFDConnection;
      LBMSQLReader: TFDBatchMoveSQLReader;
      LBMJSONWriter: TFDBatchMoveJSONWriter;
      LFDBatchMove: TFDBatchMove;
      LArq: string;
      LTotal: Int64;
    begin
      LArq := CaminhoTarget('export.json');

      if TFile.Exists(LArq) then
        TFile.Delete(LArq);

      LConnection := NovaConexaoFirebird(CaminhoTarget('target.fdb'));
      LBMSQLReader := TFDBatchMoveSQLReader.Create(nil);
      LBMJSONWriter := TFDBatchMoveJSONWriter.Create(nil);
      LFDBatchMove := TFDBatchMove.Create(nil);
      try
        LBMSQLReader.Connection := LConnection;
        LBMSQLReader.ReadSQL := 'SELECT id, nome, email, cidade, renda,' +
                                '       CAST(data_nascimento AS VARCHAR(10)) AS data_nascimento ' +
                                'FROM cliente';

        LBMJSONWriter.FileName := LArq;

        LFDBatchMove.Reader := LBMSQLReader;
        LFDBatchMove.Writer := LBMJSONWriter;
        LFDBatchMove.Execute;

        Log('JSON gerado: %s', [LArq]);
        LTotal := LConnection.ExecSQLScalar('SELECT COUNT(*) FROM cliente');
        Log('Total de clientes na origem: %d', [LTotal]);
      finally
        LFDBatchMove.Free;
        LBMJSONWriter.Free;
        LBMSQLReader.Free;
        LConnection.Free;
      end;
    end);
end;

procedure TfrmPrincipal.btnCenario7Click(Sender: TObject);
begin
  Executar('7) Firebird → MongoDB (etl_demo.cliente)',
    procedure
    var
      LConnectionFB, LConnectionMongo: TFDConnection;
      LMongoQry: TFDMongoQuery;
      LBMSQLReader: TFDBatchMoveSQLReader;
      LBMDataSetWriter: TFDBatchMoveDataSetWriter;
      LFDBatchMove: TFDBatchMove;
      LMapping: TFDBatchMoveMappingItem;
    begin
      LConnectionFB := NovaConexaoFirebird(CaminhoTarget('target.fdb'));
      LConnectionMongo := TFDConnection.Create(nil);
      LMongoQry := TFDMongoQuery.Create(nil);
      LBMSQLReader := TFDBatchMoveSQLReader.Create(nil);
      LBMDataSetWriter := TFDBatchMoveDataSetWriter.Create(nil);
      LFDBatchMove := TFDBatchMove.Create(nil);
      try
        LConnectionMongo.DriverName := 'Mongo';
        LConnectionMongo.Params.Values['Server'] := 'localhost';
        LConnectionMongo.Params.Values['Port'] := '27017';
        LConnectionMongo.Params.Values['Database'] := 'etl_mongo';
        LConnectionMongo.LoginPrompt := False;
        LConnectionMongo.Open;

        LMongoQry.Connection := LConnectionMongo;
        LMongoQry.DatabaseName := 'etl_mongo';
        LMongoQry.CollectionName := 'cliente';

        LMongoQry.FieldDefs.Clear;
        LMongoQry.FieldDefs.Add('id', ftInteger);
        LMongoQry.FieldDefs.Add('nome', ftString, 60);
        LMongoQry.FieldDefs.Add('email', ftString, 80);
        LMongoQry.FieldDefs.Add('cidade', ftString, 40);
        LMongoQry.FieldDefs.Add('renda', ftFloat);
        LMongoQry.FieldDefs.Add('data_nascimento', ftString, 10);

        LMongoQry.CachedUpdates := False;
        LMongoQry.UpdateOptions.AutoCommitUpdates := True;

        LMongoQry.Open;

        LBMSQLReader.Connection := LConnectionFB;
        LBMSQLReader.ReadSQL := 'SELECT id, nome, email, cidade, renda,' +
                                '       CAST(data_nascimento AS VARCHAR(10)) AS data_nascimento ' +
                                'FROM cliente';

        LBMDataSetWriter.DataSet := LMongoQry;

        LFDBatchMove.Reader := LBMSQLReader;
        LFDBatchMove.Writer := LBMDataSetWriter;

        // Mapping
        LFDBatchMove.Mappings.Clear;
        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'id';
        LMapping.DestinationFieldName := 'id';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'nome';
        LMapping.DestinationFieldName := 'nome';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'email';
        LMapping.DestinationFieldName := 'email';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'cidade';
        LMapping.DestinationFieldName := 'cidade';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'renda';
        LMapping.DestinationFieldName := 'renda';

        LMapping := LFDBatchMove.Mappings.Add;
        LMapping.SourceFieldName := 'data_nascimento';
        LMapping.DestinationFieldName := 'data_nascimento';

        LFDBatchMove.Execute;

        Log('Documentos inseridos em etl_mongo.cliente');
        Log('  BatchMove.InsertCount: %d', [LFDBatchMove.InsertCount]);
        Log('  BatchMove.ErrorCount : %d', [LFDBatchMove.ErrorCount]);
      finally
        LFDBatchMove.Free;
        LBMDataSetWriter.Free;
        LBMSQLReader.Free;
        LMongoQry.Free;
        LConnectionMongo.Free;
        LConnectionFB.Free;
      end;
    end);
end;

procedure TfrmPrincipal.btnCenario8Click(Sender: TObject);
begin
  Executar('8) FDScript inline + TFDMetaInfoQuery',
    procedure
    var
      LConnection: TFDConnection;
      LScript: TFDScript;
      LMetaQry: TFDMetaInfoQuery;
      LScriptSB: TStringBuilder;
      LTemVendas, LTemItens: Boolean;
      LNome: string;
      LTotalTabelas: Integer;
      LTotalVendas, LTotalItens: Int64;
    begin
      LConnection := NovaConexaoFirebird(CaminhoTarget('target.fdb'));

      LConnection.TxOptions.AutoCommit := True;

      LMetaQry := TFDMetaInfoQuery.Create(nil);
      LScriptSB := TStringBuilder.Create;
      LScript := TFDScript.Create(nil);
      try
        // Obtém metadata
        LMetaQry.Connection := LConnection;
        LMetaQry.MetaInfoKind := mkTables;
        LMetaQry.ObjectScopes := [osMy];
        LMetaQry.TableKinds := [tkTable];
        LMetaQry.Open;

        LTemVendas := False;
        LTemItens := False;
        LTotalTabelas := 0;

        while not LMetaQry.Eof do
        begin
          LNome := LMetaQry.FieldByName('TABLE_NAME').AsString;
          if SameText(LNome, 'VENDAS') then
            LTemVendas := True;

          if SameText(LNome, 'ITENS') then
            LTemItens := True;

          Inc(LTotalTabelas);
          LMetaQry.Next;
        end;
        LMetaQry.Close;

        Log('Metadata via TFDMetaInfoQuery: %d tabelas no banco', [LTotalTabelas]);
        Log('  vendas: %s', [IfThen(LTemVendas, 'já existe', 'AUSENTE — será criada')]);
        Log('  itens : %s', [IfThen(LTemItens, 'já existe', 'AUSENTE — será criada')]);

        // SCRIPT SQL
        if not LTemVendas then
        begin
          LScriptSB.AppendLine('CREATE TABLE vendas (').
                    AppendLine('  id              INTEGER       NOT NULL PRIMARY KEY,').
                    AppendLine('  cliente_id      INTEGER       NOT NULL,').
                    AppendLine('  data_venda      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP NOT NULL,').
                    AppendLine('  total           NUMERIC(15,2) NOT NULL,').
                    AppendLine('  forma_pagamento VARCHAR(20)').
                    AppendLine(');');
        end;

        if not LTemItens then
        begin
          LScriptSB.AppendLine('CREATE TABLE itens (').
                    AppendLine('  id             INTEGER       NOT NULL PRIMARY KEY,').
                    AppendLine('  venda_id       INTEGER       NOT NULL,').
                    AppendLine('  produto        VARCHAR(80)   NOT NULL,').
                    AppendLine('  quantidade     INTEGER       NOT NULL,').
                    AppendLine('  preco_unitario NUMERIC(15,2) NOT NULL,').
                    AppendLine('  subtotal       COMPUTED BY (quantidade * preco_unitario)').
                    AppendLine(');').

                    AppendLine('CREATE INDEX idx_itens_venda_id ON itens (venda_id);').
                    AppendLine('ALTER TABLE itens ADD CONSTRAINT fk_itens_venda').
                    AppendLine('  FOREIGN KEY (venda_id) REFERENCES vendas (id);');
        end;

        LScriptSB.AppendLine('DELETE FROM itens;').
                  AppendLine('DELETE FROM vendas;');

        // Dados de amostra
        LScriptSB.AppendLine('INSERT INTO vendas (id, cliente_id, data_venda, total, forma_pagamento)').
                  AppendLine('  VALUES (1, 100, TIMESTAMP ''2026-01-15 10:30:00'', 1250.50, ''PIX'');').

                  AppendLine('INSERT INTO vendas (id, cliente_id, data_venda, total, forma_pagamento)').
                  AppendLine('  VALUES (2, 100, TIMESTAMP ''2026-02-03 14:20:00'',  875.00, ''Cartao'');').

                  AppendLine('INSERT INTO vendas (id, cliente_id, data_venda, total, forma_pagamento)').
                  AppendLine('  VALUES (3, 205, TIMESTAMP ''2026-02-18 09:15:00'', 2100.75, ''PIX'');').

                  AppendLine('INSERT INTO vendas (id, cliente_id, data_venda, total, forma_pagamento)').
                  AppendLine('  VALUES (4, 342, TIMESTAMP ''2026-03-01 16:45:00'',  540.20, ''Boleto'');').

                  AppendLine('INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)').
                  AppendLine('  VALUES (1, 1, ''Teclado Mecanico'', 1,  850.50);').

                  AppendLine('INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)').
                  AppendLine('  VALUES (2, 1, ''Mousepad'',         2,  200.00);').

                  AppendLine('INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)').
                  AppendLine('  VALUES (3, 2, ''Cabo HDMI 2m'',     5,  175.00);').

                  AppendLine('INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)').
                  AppendLine('  VALUES (4, 3, ''Monitor 27 pol'',   1, 1800.00);').

                  AppendLine('INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)').
                  AppendLine('  VALUES (5, 3, ''Suporte VESA'',     1,  300.75);').

                  AppendLine('INSERT INTO itens (id, venda_id, produto, quantidade, preco_unitario)').
                  AppendLine('  VALUES (6, 4, ''Webcam Full HD'',   1,  540.20);');

        LScript.Connection := LConnection;
        LScript.SQLScripts.Clear;
        LScript.SQLScripts.Add.SQL.Text := LScriptSB.ToString;
        LScript.ValidateAll;
        LScript.ExecuteAll;

        LTotalVendas := LConnection.ExecSQLScalar('SELECT COUNT(*) FROM vendas');
        LTotalItens := LConnection.ExecSQLScalar('SELECT COUNT(*) FROM itens');
        Log('Tabela vendas: %d linhas', [LTotalVendas]);
        Log('Tabela itens : %d linhas', [LTotalItens]);
      finally
        LScript.Free;
        LScriptSB.Free;
        LMetaQry.Free;
        LConnection.Free;
      end;
    end);
end;

{
  Fonte dos dados: SELECT FIRST 1000 em source.fdb.cliente
  Destino:         tabela pessoa em target.fdb (já criada)

  Schema esperado de pessoa:
    id              INTEGER NOT NULL PRIMARY KEY
    nome            VARCHAR(60)
    email           VARCHAR(80)
    cidade          VARCHAR(40)
    renda           NUMERIC(15,2)
    data_nascimento DATE
}
procedure TfrmPrincipal.btnCenario9Click(Sender: TObject);
const
  LQuantidade = 10000;
begin
  Executar(Format('9) Array DML — SELECT FIRST %d cliente (source) → pessoa (target)', [LQUantidade]),
    procedure
    var
      LConnectionTarget: TFDConnection;
      LQrySelect, LQryInsert: TFDQuery;
      LIndex: Integer;
      LTotal: Int64;
    begin
      LConnectionTarget := NovaConexaoFirebird(CaminhoTarget('target.fdb'));
      LConnectionTarget.TxOptions.AutoCommit := True;
      LQrySelect := TFDQuery.Create(nil);
      LQryInsert := TFDQuery.Create(nil);
      try
        LQrySelect.Connection := LConnectionTarget;
        LQrySelect.SQL.Text := 'SELECT FIRST ' + IntToStr(LQuantidade) + '  id, nome, email, cidade, renda, data_nascimento ' + 'FROM cliente';
        LQrySelect.Open;

        LConnectionTarget.ExecSQL('DELETE FROM pessoa');

        LQryInsert.Connection := LConnectionTarget;
        LQryInsert.SQL.Text := 'INSERT INTO pessoa (id, nome, email, cidade, renda, data_nascimento) ' + 'VALUES (:id, :nome, :email, :cidade, :renda, :data_nascimento)';
        LQryInsert.Prepare;
        LQryInsert.Params.ArraySize := LQuantidade;

        LIndex := 0;
        while not LQrySelect.Eof do
        begin
          LQryInsert.ParamByName('id').AsIntegers[LIndex] := LQrySelect.FieldByName('id').AsInteger;
          LQryInsert.ParamByName('nome').AsWideStrings[LIndex] := LQrySelect.FieldByName('nome').AsString;
          LQryInsert.ParamByName('email').AsWideStrings[LIndex] := LQrySelect.FieldByName('email').AsString;
          LQryInsert.ParamByName('cidade').AsWideStrings[LIndex] := LQrySelect.FieldByName('cidade').AsString;
          LQryInsert.ParamByName('renda').AsFloats[LIndex] := LQrySelect.FieldByName('renda').AsFloat;
          LQryInsert.ParamByName('data_nascimento').Values[LIndex] := LQrySelect.FieldByName('data_nascimento').Value;
          Inc(LIndex);
          LQrySelect.Next;
        end;

        LQryInsert.Execute(LQuantidade);

        LTotal := LConnectionTarget.ExecSQLScalar('SELECT COUNT(*) FROM pessoa');
        Log('Lidos %d registros de source.fdb.cliente', [LIndex]);
        Log('ArraySize = %d, Execute(%d) — 1 viagem ao banco', [LQuantidade, LIndex]);
        Log('Total em target.fdb.pessoa: %d linhas', [LTotal]);
      finally
        LQryInsert.Free;
        LQrySelect.Free;
        LConnectionTarget.Free;
      end;
    end);
end;

{
  Mesma origem/destino do cenário 9 (source.fdb.cliente → target.fdb.pessoa),
  mas em CHUNKS. Um contador rastreia quantos slots do array estão preenchidos:
  quando enche, Execute(ArraySize) e reseta; ao final, se sobrou parcial,
  Execute(contador) — onde contador NÃO é ArraySize.

  Total = 5678 registros, chunk = 500.
  Resultado: 11 chamadas Execute completas (500) + 1 parcial (178).
  Sem Array DML seriam 5678 chamadas Execute individuais.
}
procedure TfrmPrincipal.btnCenario10Click(Sender: TObject);
const
  TOTAL = 5678;
  CHUNK = 500;
begin
  Executar(Format('10) Array DML — chunks (%d cliente em blocos de %d → pessoa)', [TOTAL, CHUNK]),
    procedure
    var
      LConnectionTarget: TFDConnection;
      LQrySelect, LQryInsert: TFDQuery;
      LIndexChunk, LChunksCompletos: Integer;
      LTotal: Int64;
    begin
      LConnectionTarget := NovaConexaoFirebird(CaminhoTarget('target.fdb'));
      LConnectionTarget.TxOptions.AutoCommit := True;
      LQrySelect := TFDQuery.Create(nil);
      LQryInsert := TFDQuery.Create(nil);
      try
        // Limpa a tabela destino
        LConnectionTarget.ExecSQL('DELETE FROM pessoa');

        // 1) Lê até TOTAL registros da tabela cliente em source.fdb
        LQrySelect.Connection := LConnectionTarget;
        LQrySelect.SQL.Text := 'SELECT FIRST ' + IntToStr(TOTAL) +
                               '  id, nome, email, cidade, renda, data_nascimento ' +
                               'FROM cliente';
        LQrySelect.Open;

        // 2) Prepara o INSERT e aloca o array do tamanho do CHUNK
        LQryInsert.Connection := LConnectionTarget;
        LQryInsert.SQL.Text := 'INSERT INTO pessoa (id, nome, email, cidade, renda, data_nascimento) ' +
                               'VALUES (:id, :nome, :email, :cidade, :renda, :data_nascimento)';
        LQryInsert.Prepare;
        LQryInsert.Params.ArraySize := CHUNK;

        LIndexChunk := 0;
        LChunksCompletos := 0;

        // 3) Iteração: preenche o chunk; quando enche, dispara e reseta
        while not LQrySelect.Eof do
        begin
          LQryInsert.ParamByName('id').AsIntegers[LIndexChunk] := LQrySelect.FieldByName('id').AsInteger;
          LQryInsert.ParamByName('nome').AsWideStrings[LIndexChunk] := LQrySelect.FieldByName('nome').AsString;
          LQryInsert.ParamByName('email').AsWideStrings[LIndexChunk] := LQrySelect.FieldByName('email').AsString;
          LQryInsert.ParamByName('cidade').AsWideStrings[LIndexChunk] := LQrySelect.FieldByName('cidade').AsString;
          LQryInsert.ParamByName('renda').Values[LIndexChunk] := LQrySelect.FieldByName('renda').Value;
          LQryInsert.ParamByName('data_nascimento').Values[LIndexChunk] := LQrySelect.FieldByName('data_nascimento').Value;
          Inc(LIndexChunk);

          // Array cheio? Envia o chunk inteiro
          if LIndexChunk = CHUNK then
          begin
            LQryInsert.Execute(CHUNK);
            Inc(LChunksCompletos);
            LIndexChunk := 0;
          end;

          LQrySelect.Next;
        end;

        // 4) Sobrou algum registro no chunk parcial? (LIndexChunk != CHUNK)
        if LIndexChunk > 0 then
        begin
          LQryInsert.Execute(LIndexChunk);   // <-- Execute(N) != ArraySize
          Log('Último chunk PARCIAL: Execute(%d) — só as posições 0..%d do array', [LIndexChunk, LIndexChunk - 1]);
        end;

        LTotal := LConnectionTarget.ExecSQLScalar('SELECT COUNT(*) FROM pessoa');
        Log('Chunks completos : %d x Execute(%d) = %d registros', [LChunksCompletos, CHUNK, LChunksCompletos * CHUNK]);
        Log('Total de chamadas Execute: %d (vs %d se fossem individuais)', [LChunksCompletos + IfThen(LIndexChunk > 0, 1, 0), TOTAL]);
        Log('Total em target.fdb.pessoa: %d linhas', [LTotal]);
      finally
        LQryInsert.Free;
        LQrySelect.Free;
        LConnectionTarget.Free;
      end;
    end);
end;

{
  Mesmo pipeline do cenário 9 (SELECT FIRST 1000 em source.fdb.cliente →
  target.fdb.pessoa), mas com um INSERT por linha via Execute individual —
  Comparar o custo do modelo tradicional contra o Array DML do cenário 9.
}
procedure TfrmPrincipal.btnCenario11Click(Sender: TObject);
const
  QTD = 10000;
begin
  Executar(Format('11) INSERT tradicional (loop) — %d cliente → pessoa (%d Executes)', [QTD, QTD]),
    procedure
    var
      LConnectionTarget: TFDConnection;
      LQrySelect, LQryInsert: TFDQuery;
      LCount: Integer;
      LTotal: Int64;
    begin
      LConnectionTarget := NovaConexaoFirebird(CaminhoTarget('target.fdb'));
      LQrySelect := TFDQuery.Create(nil);
      LQryInsert := TFDQuery.Create(nil);
      try
        // 1) Lê até QTD registros da cliente em source.fdb
        LQrySelect.Connection := LConnectionTarget;
        LQrySelect.SQL.Text := 'SELECT FIRST ' + IntToStr(QTD) +
                               '  id, nome, email, cidade, renda, data_nascimento ' +
                               'FROM cliente';
        LQrySelect.Open;

        // 2) Prepara UMA vez o INSERT (Prepare reaproveita o plano no banco)
        LQryInsert.Connection := LConnectionTarget;
        LQryInsert.SQL.Text := 'INSERT INTO pessoa (id, nome, email, cidade, renda, data_nascimento) ' +
                               'VALUES (:id, :nome, :email, :cidade, :renda, :data_nascimento)';
        LQryInsert.Prepare;

        LConnectionTarget.StartTransaction;
        try
          LConnectionTarget.ExecSQL('DELETE FROM pessoa');

          LCount := 0;
          while not LQrySelect.Eof do
          begin
            LQryInsert.ParamByName('id').AsInteger := LQrySelect.FieldByName('id').AsInteger;
            LQryInsert.ParamByName('nome').AsString := LQrySelect.FieldByName('nome').AsString;
            LQryInsert.ParamByName('email').AsString := LQrySelect.FieldByName('email').AsString;
            LQryInsert.ParamByName('cidade').AsString := LQrySelect.FieldByName('cidade').AsString;
            LQryInsert.ParamByName('renda').Value := LQrySelect.FieldByName('renda').Value;
            LQryInsert.ParamByName('data_nascimento').Value := LQrySelect.FieldByName('data_nascimento').Value;
            LQryInsert.ExecSQL;
            Inc(LCount);
            LQrySelect.Next;
          end;
          LConnectionTarget.Commit;
        except
          LConnectionTarget.Rollback;
          raise;
        end;

        LTotal := LConnectionTarget.ExecSQLScalar('SELECT COUNT(*) FROM pessoa');
        Log('Lidos %d registros de source.fdb.cliente', [LCount]);
        Log('%d Executes individuais (uma viagem ao banco por linha)', [LCount]);
        Log('Transação COMMIT — %d linhas gravadas', [LCount]);
        Log('Total em target.fdb.pessoa: %d linhas', [LTotal]);
      finally
        LQryInsert.Free;
        LQrySelect.Free;
        LConnectionTarget.Free;
      end;
    end);
end;

end.
