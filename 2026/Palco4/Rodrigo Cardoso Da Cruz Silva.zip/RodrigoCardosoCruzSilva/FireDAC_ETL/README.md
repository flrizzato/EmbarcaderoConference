# ETL Completo — FireDAC (Firebird)

Projeto Delphi VCL simples que mostra **todos os componentes de ETL do FireDAC** em ação.
Cada botão monta o pipeline do zero (Reader + BatchMove + Writer) — sem componentes
arrastados no form, para ficar evidente o que é o quê.

## Os 7 cenários

| # | Origem              | Destino              | Componentes                                                |
|---|---------------------|----------------------|------------------------------------------------------------|
| 1 | Arquivo texto (CSV) | Banco (Firebird)     | `TFDBatchMoveTextReader` → `TFDBatchMoveSQLWriter`         |
| 2 | Arquivo texto (CSV) | Dataset (`TFDMemTable`) | `TFDBatchMoveTextReader` → `TFDBatchMoveDataSetWriter`  |
| 3 | Dataset (`TFDMemTable`) | Banco (Firebird) | `TFDBatchMoveDataSetReader` → `TFDBatchMoveSQLWriter`      |
| 4 | Banco (Firebird)    | Banco (PostgreSQL)   | `TFDBatchMoveSQLReader` → `TFDBatchMoveSQLWriter` (cross-DB via driver `PG`) |
| 5 | Banco (Firebird)    | Arquivo texto (CSV)  | `TFDBatchMoveSQLReader` → `TFDBatchMoveTextWriter`         |
| 6 | Banco (Firebird)    | Arquivo JSON         | `TFDBatchMoveSQLReader` → `TFDBatchMoveJSONWriter`         |
| 7 | Banco (Firebird)    | MongoDB              | `TFDBatchMoveSQLReader` → `TFDBatchMoveDataSetWriter` → `TFDMongoQuery` (driver Mongo em `TFDConnection`, `CollectionName='cliente'`) |
| 8 | Script SQL externo  | Banco (Firebird)     | `TFDScript` executa `Source/create_vendas_itens.sql` (DDL + DML) |
| 9 | Dados gerados em código | Banco (`vendas_bulk`) | Array DML: `ArraySize = 100`, `Execute(100)` — 1 chamada ao banco |
| 10 | Dados gerados em código | Banco (`itens_bulk`) | Array DML em chunks: `ArraySize = 500`, contador rastreia slots preenchidos, último `Execute(178)` (chunk parcial) |
| 11 | Dados gerados em código | Banco (`showdown_arr` + `showdown_bm`) | **Showdown**: insere 50.000 registros por Array DML e por BatchMove, cronometra os dois e mostra a diferença |

> A propriedade do `TFDBatchMoveSQLReader` que recebe o SELECT é **`ReadSQL`** (um `string`, não `TStrings`).

Em todos, o **`TFDBatchMove`** é o orquestrador: você pluga um `Reader` na
propriedade `.Reader`, um `Writer` na `.Writer`, chama `.Execute` e ele cuida
do loop e comita em lotes.

## Pré-requisitos

**Firebird** (cenários 1, 3, 4-origem, 5, 6, 8):
- Firebird 3.0+ instalado (com `fbclient.dll` acessível no PATH ou ao lado do `.exe`).
- Usuário `SYSDBA` / senha `masterkey` (padrão da instalação).
- O servidor pode estar rodando local (`localhost`) ou em modo embedded — a conexão usa apenas o caminho do arquivo `.fdb`.
- Os arquivos `.fdb` são **criados automaticamente** na primeira execução (o helper `NovaConexaoFirebird` adiciona `CreateDatabase=Yes` quando o arquivo não existe).

**PostgreSQL** (cenário 4-destino):
- PostgreSQL 10+ rodando em `localhost:5432`.
- Banco `target_pg` **criado previamente** (`CREATE DATABASE target_pg`) — Postgres não cria automaticamente pela conexão como o Firebird.
- Cliente `libpq.dll` acessível (via PATH ou ao lado do `.exe`).
- User/senha default do helper: `postgres` / `postgres` — ajuste em `NovaConexaoPostgres`.

**MongoDB** (cenário 7): servidor rodando em `localhost:27017`. Coleção criada automaticamente ao primeiro insert.

## Como rodar

1. Abra `FireDAC_ETL.dproj` no Delphi (10.3 Rio+, por causa do JSON reader/writer).
2. Compile e execute (F9).
3. Clique nos botões na ordem que preferir. Os cenários 1, 2, 4, 5, 6, 7 pedem o **arquivo CSV de origem** na primeira vez (via `TOpenDialog`, que abre em `Source/`); o caminho fica em cache pela sessão. O CSV precisa ter cabeçalho `id;nome;email;cidade;renda;data_nascimento` e separador `;` (`data_nascimento` no formato ISO `YYYY-MM-DD`).

### Estrutura de pastas ao lado do `.exe`

```
Source/                          ← arquivos de ORIGEM
├── Clientes.csv                 (gerado por gerar_csv.ps1)
├── source.fdb                   (populado a partir do CSV; fonte para 4, 5, 6, 7)
└── create_vendas_itens.sql      (script executado pelo cenário 8 — versionado)

Target/                          ← arquivos de DESTINO
├── target.fdb                  (destino dos cenários 1, 3 e 8)
├── export.csv                   (destino do cenário 5)
└── export.json                  (destino do cenário 6)
```

O cenário 4 grava no PostgreSQL (`target_pg.cliente`) — externo, não fica no `Target/`. O cenário 7 grava no MongoDB (`etl_demo.cliente`), idem.

As duas pastas são criadas automaticamente no `FormCreate` se não existirem.

## Sobre o cenário 7 (MongoDB)

O truque é tratar a coleção Mongo como um dataset FireDAC:

- **Conexão**: `TFDConnection` com `DriverName='Mongo'` e parâmetros
  `Server=localhost`, `Port=27017`, `Database=etl_demo`.
- **Coleção como dataset**: `TFDMongoQuery` com `CollectionName='cliente'`
  aberto sobre essa conexão — cada `Append/Post` vira um documento.
- **Pipeline**: `TFDBatchMoveSQLReader` (SELECT no Firebird) → `TFDBatchMove`
  → `TFDBatchMoveDataSetWriter` apontando pro `TFDMongoQuery`.

Ou seja, o mesmo `TFDBatchMoveDataSetWriter` que grava em um `TFDMemTable` no
cenário 2 também grava em uma coleção Mongo — quem materializa cada linha
como documento BSON é o driver Mongo por trás do `TFDMongoQuery`.

Precisa de um servidor MongoDB em `localhost:27017` (crie o banco `etl_demo`
antes ou deixe o driver criar no primeiro insert).

## Notas de conversão SQLite → Firebird

- `TEXT` → `VARCHAR(n)`
- `REAL` → `NUMERIC(15,2)`
- `INTEGER PRIMARY KEY` → `INTEGER NOT NULL PRIMARY KEY`
- `DROP TABLE IF EXISTS x; CREATE TABLE x (...)` → `RECREATE TABLE x (...)` (uma instrução só)
- Existência de tabela (`CREATE TABLE IF NOT EXISTS`) → consulta a `RDB$RELATIONS`
- Driver: `SQLite` → `FB`; parâmetros adicionais `User_Name`, `Password`, `CharacterSet=UTF8`

## Arquivos

- `FireDAC_ETL.dpr`   — programa
- `FireDAC_ETL.dproj` — projeto Delphi
- `uPrincipal.pas` / `.dfm` — form com os 7 botões e o log
