object frmPrincipal: TfrmPrincipal
  Left = 0
  Top = 0
  Caption = 'FireDAC ETL - Todos os cen'#225'rios'
  ClientHeight = 720
  ClientWidth = 988
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  TextHeight = 15
  object pnlBotoes: TPanel
    Left = 0
    Top = 0
    Width = 260
    Height = 696
    Align = alLeft
    BevelOuter = bvNone
    Padding.Left = 10
    Padding.Top = 10
    Padding.Right = 10
    Padding.Bottom = 10
    TabOrder = 0
    object lblTitulo: TLabel
      AlignWithMargins = True
      Left = 13
      Top = 13
      Width = 234
      Height = 25
      Align = alTop
      Alignment = taCenter
      Caption = 'FireDAC ETL - Cen'#225'rios'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -19
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
      Layout = tlCenter
      ExplicitWidth = 203
    end
    object btnCenario1: TButton
      AlignWithMargins = True
      Left = 13
      Top = 44
      Width = 234
      Height = 45
      Align = alTop
      Caption = '1) CSV '#8594' Database (Firebird)'
      TabOrder = 0
      OnClick = btnCenario1Click
    end
    object btnCenario2: TButton
      AlignWithMargins = True
      Left = 13
      Top = 95
      Width = 234
      Height = 45
      Align = alTop
      Caption = '2) CSV '#8594' DataSet'
      TabOrder = 1
      OnClick = btnCenario2Click
    end
    object btnCenario3: TButton
      AlignWithMargins = True
      Left = 13
      Top = 146
      Width = 234
      Height = 45
      Align = alTop
      Caption = '3) Dataset '#8594' Database (Firebird)'
      TabOrder = 2
      OnClick = btnCenario3Click
    end
    object btnCenario4: TButton
      AlignWithMargins = True
      Left = 13
      Top = 197
      Width = 234
      Height = 45
      Align = alTop
      Caption = '4) DB '#8594' DB (Firebird '#8594' Postgres)'
      TabOrder = 3
      OnClick = btnCenario4Click
    end
    object btnCenario5: TButton
      AlignWithMargins = True
      Left = 13
      Top = 248
      Width = 234
      Height = 45
      Align = alTop
      Caption = '5) Database (Firebird) '#8594' (CSV)'
      TabOrder = 4
      OnClick = btnCenario5Click
    end
    object btnCenario6: TButton
      AlignWithMargins = True
      Left = 13
      Top = 299
      Width = 234
      Height = 45
      Align = alTop
      Caption = '6) Database (Firebird) '#8594' JSON'
      TabOrder = 5
      OnClick = btnCenario6Click
    end
    object btnCenario7: TButton
      AlignWithMargins = True
      Left = 13
      Top = 350
      Width = 234
      Height = 45
      Align = alTop
      Caption = '7) Database (Firebird) '#8594' MongoDB'
      TabOrder = 6
      OnClick = btnCenario7Click
    end
    object btnCenario8: TButton
      AlignWithMargins = True
      Left = 13
      Top = 401
      Width = 234
      Height = 45
      Align = alTop
      Caption = '8) FDScript: cria vendas + itens'
      TabOrder = 7
      OnClick = btnCenario8Click
    end
    object btnCenario9: TButton
      AlignWithMargins = True
      Left = 13
      Top = 452
      Width = 234
      Height = 45
      Align = alTop
      Caption = '9) Array DML: tamanho fixo'
      TabOrder = 8
      OnClick = btnCenario9Click
    end
    object btnCenario10: TButton
      AlignWithMargins = True
      Left = 13
      Top = 503
      Width = 234
      Height = 45
      Align = alTop
      Caption = '10) Array DML: lotes'
      TabOrder = 9
      OnClick = btnCenario10Click
    end
    object btnCenario11: TButton
      AlignWithMargins = True
      Left = 13
      Top = 554
      Width = 234
      Height = 45
      Align = alTop
      Caption = '11) INSERT tradicional'
      TabOrder = 10
      OnClick = btnCenario11Click
    end
    object btnLimpar: TButton
      AlignWithMargins = True
      Left = 13
      Top = 651
      Width = 234
      Height = 32
      Align = alBottom
      Caption = 'Limpar log'
      TabOrder = 11
      OnClick = btnLimparClick
    end
  end
  object pbProgresso: TProgressBar
    Left = 0
    Top = 696
    Width = 988
    Height = 24
    Align = alBottom
    Style = pbstMarquee
    MarqueeInterval = 20
    TabOrder = 2
    Visible = False
  end
  object pgc: TPageControl
    Left = 260
    Top = 0
    Width = 728
    Height = 696
    ActivePage = tsLog
    Align = alClient
    TabOrder = 1
    object tsLog: TTabSheet
      Caption = 'Log'
      object mmoLog: TMemo
        Left = 0
        Top = 0
        Width = 720
        Height = 666
        Align = alClient
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'Consolas'
        Font.Style = []
        ParentFont = False
        ReadOnly = True
        ScrollBars = ssBoth
        TabOrder = 0
        WordWrap = False
      end
    end
    object tsGrid: TTabSheet
      Caption = 'Grid (Cen'#225'rio 2)'
      ImageIndex = 1
      object grd: TDBGrid
        Left = 0
        Top = 0
        Width = 720
        Height = 666
        Align = alClient
        DataSource = dsGrid
        ReadOnly = True
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -12
        TitleFont.Name = 'Segoe UI'
        TitleFont.Style = []
      end
    end
  end
  object dsGrid: TDataSource
    Left = 984
    Top = 88
  end
  object FDBatchMove1: TFDBatchMove
    Reader = FDBatchMoveTextReader1
    Writer = FDBatchMoveDataSetWriter1
    Mode = dmAppendUpdate
    Mappings = <
      item
      end>
    LogFileName = 'Data.log'
    Left = 576
    Top = 184
  end
  object FDConnection1: TFDConnection
    Params.Strings = (
      'DriverID=Mongo')
    LoginPrompt = False
    Left = 576
    Top = 40
  end
  object FDMongoQuery1: TFDMongoQuery
    Connection = FDConnection1
    Left = 896
    Top = 207
  end
  object FDBatchMoveTextReader1: TFDBatchMoveTextReader
    DataDef.Fields = <>
    Left = 384
    Top = 88
  end
  object FDBatchMoveDataSetWriter1: TFDBatchMoveDataSetWriter
    Left = 760
    Top = 208
  end
  object FDMemTable1: TFDMemTable
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    Left = 896
    Top = 272
  end
  object FDScript1: TFDScript
    SQLScripts = <>
    Connection = FDConnection1
    Params = <>
    Macros = <>
    Left = 576
    Top = 96
  end
  object FDBatchMoveSQLWriter1: TFDBatchMoveSQLWriter
    Connection = FDConnection1
    Left = 760
    Top = 144
  end
  object FDBatchMoveTextWriter1: TFDBatchMoveTextWriter
    DataDef.Fields = <>
    Left = 760
    Top = 90
  end
  object FDBatchMoveJSONWriter1: TFDBatchMoveJSONWriter
    DataDef.Fields = <>
    Left = 760
    Top = 274
  end
  object FDBatchMoveSQLReader1: TFDBatchMoveSQLReader
    Connection = FDConnection1
    Left = 384
    Top = 144
  end
  object FDBatchMoveDataSetReader1: TFDBatchMoveDataSetReader
    Left = 384
    Top = 218
  end
end
