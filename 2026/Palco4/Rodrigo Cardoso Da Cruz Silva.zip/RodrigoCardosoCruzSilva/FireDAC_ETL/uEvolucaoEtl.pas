﻿{*******************************************************************************
  Evolução de um pipeline ETL incremental — 4 versões do MESMO problema

  Cenário: uma franquia com N unidades. Cada unidade tem a tabela `caixa` no
  banco local. O objetivo é sincronizar as linhas dessas tabelas para uma
  tabela central `caixa` num datalake corporativo.

  Semântica: sincronização INCREMENTAL com UPSERT.
    * SELECT filtra pelo timestamp `data_alteracao >= :desde` — só leva o que
      mudou desde a última sincronização.
    * INSERT ou UPDATE (por chave `id`) no destino — se o registro já existe,
      sobrescreve; se não, insere.
    * `ADesde` normalmente é o max(data_alteracao) da última carga bem-sucedida.

  Schema comum de `caixa`:
    id              INTEGER    NOT NULL PRIMARY KEY
    unidade_id      INTEGER    NOT NULL         -- de qual unidade veio a linha
    data            DATE
    abertura        NUMERIC(15,2)
    fechamento      NUMERIC(15,2)
    operador        VARCHAR(60)
    data_alteracao  TIMESTAMP  NOT NULL         -- coluna de controle incremental

  As 4 versões, na ordem de refatoração:

    V1 — Hardcoded, UPDATE OR INSERT campo-a-campo, uma execução por linha
    V2 — Genérico: descobre colunas do SELECT e monta UPDATE OR INSERT dinâmico
    V3 — V2 + Array DML (chunks): reduz N execuções para N/CHUNK
    V4 — TFDBatchMove com Mode := dmAppendUpdate

  Cada procedure recebe as conexões origem e destino já abertas — quem chama
  gerencia a vida das conexões.
*******************************************************************************}
unit uEvolucaoEtl;

interface

uses
  System.SysUtils, System.Classes, Data.DB,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Error, FireDAC.Stan.Def,
  FireDAC.Stan.Param, FireDAC.DApt,
  FireDAC.Phys, FireDAC.Phys.Intf,
  FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  FireDAC.Comp.BatchMove, FireDAC.Comp.BatchMove.SQL;

{ V1 — UPDATE OR INSERT tradicional, campo-a-campo, uma execução por linha }
procedure MigrarCaixaV1_Hardcoded(
  AConnOrigem, AConnDestino: TFDConnection;
  AUnidadeId: Integer;
  ADesde: TDateTime);

{ V2 — Genérico: descobre colunas do SELECT e monta UPDATE OR INSERT dinâmico }
procedure MigrarTabelaV2_Dinamico(
  AConnOrigem, AConnDestino: TFDConnection;
  const ATabelaOrigem, ATabelaDestino, AColunaChave: string;
  ADesde: TDateTime);

{ V3 — V2 + Array DML (chunks de N linhas por Execute) }
procedure MigrarTabelaV3_ArrayDML(
  AConnOrigem, AConnDestino: TFDConnection;
  const ATabelaOrigem, ATabelaDestino, AColunaChave: string;
  ADesde: TDateTime;
  AChunk: Integer = 500);

{ V4 — TFDBatchMove em modo dmAppendUpdate: o FireDAC orquestra tudo }
procedure MigrarTabelaV4_BatchMove(
  AConnOrigem, AConnDestino: TFDConnection;
  const ATabelaOrigem, ATabelaDestino: string;
  ADesde: TDateTime);

implementation

{ ============================================================================
  V1 — UPDATE OR INSERT tradicional, campo-a-campo, uma execução por linha

  Como costuma nascer o código em muito sistema legado:
    * SELECT hardcoded na origem, filtrando por data_alteracao
    * UPDATE OR INSERT com todas as colunas nomeadas (sintaxe nativa do FB)
    * Cada campo lido no dataset e passado por AsXXX específico
    * ExecSQL a cada linha (N registros = N round-trips ao destino)

  Dor: qualquer alteração de schema exige mudar SELECT + UPDATE OR INSERT +
  código de bind. Cada tabela nova é uma cópia deste método. E é lento —
  N Executes.
  ============================================================================ }
procedure MigrarCaixaV1_Hardcoded(
  AConnOrigem, AConnDestino: TFDConnection;
  AUnidadeId: Integer;
  ADesde: TDateTime);
var
  LQrySelect, LQryUpsert: TFDQuery;
begin
  LQrySelect := TFDQuery.Create(nil);
  LQryUpsert := TFDQuery.Create(nil);
  // Um método pra cada Tabela
  try
   // Select Tabela em cada Filial
    LQrySelect.Connection := AConnOrigem;
    LQrySelect.SQL.Text :=
      'SELECT id, data, abertura, fechamento, operador, data_alteracao ' +
      'FROM caixa ' +
      'WHERE data_alteracao >= :desde';
    LQrySelect.ParamByName('desde').AsDateTime := ADesde;
    LQrySelect.Open;

    // Update or Insert
    LQryUpsert.Connection := AConnDestino;

    while not LQrySelect.Eof do
    begin
      LQryUpsert.SQL.Text :=
      'UPDATE OR INSERT INTO caixa ' +
      '  (id, unidade_id, data, abertura, fechamento, operador, data_alteracao) ' +
      'VALUES ' +
      '  (:id, :unidade_id, :data, :abertura, :fechamento, :operador, :data_alteracao) ' +
      'MATCHING (id)';

      LQryUpsert.ParamByName('id')            .AsInteger  := LQrySelect.FieldByName('id').AsInteger;
      LQryUpsert.ParamByName('unidade_id')    .AsInteger  := AUnidadeId;
      LQryUpsert.ParamByName('data')          .AsDateTime := LQrySelect.FieldByName('data').AsDateTime;
      LQryUpsert.ParamByName('abertura')      .AsFloat    := LQrySelect.FieldByName('abertura').AsFloat;
      LQryUpsert.ParamByName('fechamento')    .AsFloat    := LQrySelect.FieldByName('fechamento').AsFloat;
      LQryUpsert.ParamByName('operador')      .AsString   := LQrySelect.FieldByName('operador').AsString;
      LQryUpsert.ParamByName('data_alteracao').AsDateTime := LQrySelect.FieldByName('data_alteracao').AsDateTime;
      LQryUpsert.ExecSQL;
      LQrySelect.Next;
    end;
  finally
    LQryUpsert.Free;
    LQrySelect.Free;
  end;
end;

{ ============================================================================
  V2 — Genérico: descobre colunas do SELECT e monta UPDATE OR INSERT dinâmico

  Primeiro salto: parar de amarrar o código ao schema. Recebe origem/destino
  e a coluna-chave (para o MATCHING) como parâmetros e:
    * Abre o SELECT * na tabela origem, filtrando por data_alteracao
    * Percorre os Fields do dataset e monta as listas de colunas/params
    * Gera "UPDATE OR INSERT INTO destino (...) VALUES (...) MATCHING (chave)"
    * Para cada linha, seta cada param via ParamByName(field.FieldName).Value

  Vantagem: um único método serve para caixa, venda, produto etc. — basta as
  duas tabelas terem os mesmos nomes de coluna e uma coluna-chave para o
  MATCHING. Ainda é uma execução por linha (N round-trips).
  ============================================================================ }
procedure MigrarTabelaV2_Dinamico(
  AConnOrigem, AConnDestino: TFDConnection;
  const ATabelaOrigem, ATabelaDestino, AColunaChave: string;
  ADesde: TDateTime);
var
  LQrySelect, LQryUpsert: TFDQuery;
  LColunas, LParams: TStringBuilder;
  LI: Integer;
begin
  LQrySelect := TFDQuery.Create(nil);
  LQryUpsert := TFDQuery.Create(nil);
  LColunas   := TStringBuilder.Create;
  LParams    := TStringBuilder.Create;
  try
    LQrySelect.Connection := AConnOrigem;
    LQrySelect.SQL.Text   :=
      'SELECT * FROM ' + ATabelaOrigem + ' ' +
      'WHERE data_alteracao >= :desde';
    LQrySelect.ParamByName('desde').AsDateTime := ADesde;
    LQrySelect.Open;

    // Dinamismo de geração de instrução SQL e passagem de parâmetros

    // Monta "col1, col2, col3" e ":col1, :col2, :col3" a partir dos fields
    for LI := 0 to LQrySelect.FieldCount - 1 do
    begin
      if LI > 0 then
      begin
        LColunas.Append(', ');
        LParams .Append(', ');
      end;
      LColunas.Append(LQrySelect.Fields[LI].FieldName);
      LParams .Append(':').Append(LQrySelect.Fields[LI].FieldName);
    end;

    LQryUpsert.Connection := AConnDestino;
    LQryUpsert.SQL.Text   := Format(
      'UPDATE OR INSERT INTO %s (%s) VALUES (%s) MATCHING (%s)',
      [ATabelaDestino, LColunas.ToString, LParams.ToString, AColunaChave]);

    while not LQrySelect.Eof do
    begin
      for LI := 0 to LQrySelect.FieldCount - 1 do
      begin
        LQryUpsert.ParamByName(LQrySelect.Fields[LI].FieldName).Value := LQrySelect.Fields[LI].Value;
      end;

      LQryUpsert.ExecSQL;
      LQrySelect.Next;
    end;
  finally
    LParams .Free;
    LColunas.Free;
    LQryUpsert.Free;
    LQrySelect.Free;
  end;
end;

{ ============================================================================
  V3 — V2 + Array DML: envia CHUNK linhas por Execute

  Mesma introspecção genérica da V2, agora com:
    * Prepare  — força FireDAC a resolver metadata do destino uma vez
    * ArraySize := CHUNK — aloca N slots por parâmetro
    * Loop preenche os slots; quando enche, Execute(CHUNK) dispara o bloco
    * Ao final, se sobrou parcial (LIndex > 0), Execute(LIndex)

  Cada Execute(N) manda N UPDATE OR INSERT em uma única viagem ao banco.
  Ganho grande em cargas volumosas.
  ============================================================================ }
procedure MigrarTabelaV3_ArrayDML(
  AConnOrigem, AConnDestino: TFDConnection;
  const ATabelaOrigem, ATabelaDestino, AColunaChave: string;
  ADesde: TDateTime;
  AChunk: Integer);
var
  LQrySelect, LQryUpsert: TFDQuery;
  LColunas, LParams: TStringBuilder;
  LI, LIndex: Integer;
begin
  LQrySelect := TFDQuery.Create(nil);
  LQryUpsert := TFDQuery.Create(nil);
  LColunas   := TStringBuilder.Create;
  LParams    := TStringBuilder.Create;
  try
    LQrySelect.Connection := AConnOrigem;
    LQrySelect.SQL.Text   :=
      'SELECT * FROM ' + ATabelaOrigem + ' ' +
      'WHERE data_alteracao >= :desde';
    LQrySelect.ParamByName('desde').AsDateTime := ADesde;
    LQrySelect.Open;

    for LI := 0 to LQrySelect.FieldCount - 1 do
    begin
      if LI > 0 then
      begin
        LColunas.Append(', ');
        LParams .Append(', ');
      end;
      LColunas.Append(LQrySelect.Fields[LI].FieldName);
      LParams .Append(':').Append(LQrySelect.Fields[LI].FieldName);
    end;

    LQryUpsert.Connection := AConnDestino;
    LQryUpsert.SQL.Text   := Format(
      'UPDATE OR INSERT INTO %s (%s) VALUES (%s) MATCHING (%s)',
      [ATabelaDestino, LColunas.ToString, LParams.ToString, AColunaChave]);

    // ArrayDML
    LQryUpsert.Prepare;
    LQryUpsert.Params.ArraySize := AChunk;

    LIndex := 0;
    while not LQrySelect.Eof do
    begin
      for LI := 0 to LQrySelect.FieldCount - 1 do
        LQryUpsert.ParamByName(LQrySelect.Fields[LI].FieldName).Values[LIndex] := LQrySelect.Fields[LI].Value;
      Inc(LIndex);

      if LIndex = AChunk then
      begin
        LQryUpsert.Execute(AChunk);
        LIndex := 0;
      end;

      LQrySelect.Next;
    end;

    // Chunk parcial ao fim: Execute(N) onde N < ArraySize
    if LIndex > 0 then
      LQryUpsert.Execute(LIndex);
  finally
    LParams .Free;
    LColunas.Free;
    LQryUpsert.Free;
    LQrySelect.Free;
  end;
end;

{ ============================================================================
  V4 — TFDBatchMove em modo dmAppendUpdate: o FireDAC orquestra tudo

  Última evolução: o próprio FireDAC assume todo o trabalho.
    * Reader (SQLReader) lê da origem filtrando por data_alteracao
    * BatchMove com Mode := dmAppendUpdate faz UPSERT por chave
    * Writer (SQLWriter) escreve no destino
    * A chave é auto-detectada da PK da tabela destino via metadata
    * CommitCount controla frequência de commit

  Escrever este método toma ~20 linhas. O tuning fica em propriedades
  declarativas. Trade-off: pipeline é uma caixa-preta relativa — para
  diagnosticar problemas, é preciso entender o comportamento do BatchMove.
  ============================================================================ }
procedure MigrarTabelaV4_BatchMove(
  AConnOrigem, AConnDestino: TFDConnection;
  const ATabelaOrigem, ATabelaDestino: string;
  ADesde: TDateTime);
var
  LReader: TFDBatchMoveSQLReader;
  LWriter: TFDBatchMoveSQLWriter;
  LBatch : TFDBatchMove;
begin
  LReader := TFDBatchMoveSQLReader.Create(nil);
  LWriter := TFDBatchMoveSQLWriter.Create(nil);
  LBatch  := TFDBatchMove.Create(nil);
  try
    LReader.Connection := AConnOrigem;
    LReader.ReadSQL    :=
      'SELECT * FROM ' + ATabelaOrigem + ' ' +
      'WHERE data_alteracao >= ' + QuotedStr(FormatDateTime('yyyy-mm-dd hh:nn:ss', ADesde));

    LWriter.Connection := AConnDestino;
    LWriter.TableName  := ATabelaDestino;

    LBatch.Reader      := LReader;
    LBatch.Writer      := LWriter;
    LBatch.Mode        := dmAppendUpdate;    // UPSERT — chave vem da PK do destino
    LBatch.CommitCount := 10000;
    LBatch.Execute;
  finally
    LBatch .Free;
    LWriter.Free;
    LReader.Free;
  end;
end;

end.
