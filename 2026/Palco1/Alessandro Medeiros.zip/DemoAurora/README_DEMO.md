# Demo Aurora — Roteiro de Ensaio

## Pré-requisitos

1. Delphi 13 Florence (Studio 37.0) instalado — testado com `dcc32.exe` diretamente
   e também com `msbuild DemoAurora.dproj /p:Config=Debug /p:Platform=Win32`.
2. **Chave da OpenAI configurada de forma permanente** (uma vez só, não precisa
   repetir a cada ensaio):
   - Windows: `Configurações → Sistema → Sobre → Configurações avançadas do
     sistema → Variáveis de Ambiente` → em "Variáveis do usuário" clique
     "Novo" → Nome: `OPENAI_API_KEY`, Valor: sua chave `sk-...`.
   - Ou via terminal: `setx OPENAI_API_KEY "sk-sua-chave-aqui"`.
   - **Depois de configurar, faça logoff/login (ou reinicie o Windows) uma vez**
     — sem isso o Explorer não enxerga a variável nova e o `.exe` continua
     reclamando que ela está vazia.
   - Depois desse passo único, dar duplo clique no `.exe` (ou no
     `Resetar_Demo.bat`) direto do Explorer já funciona, sem terminal.
3. `Fixtures\sefaz_authorization.json` precisa estar ao lado do `.exe`
   (em `Output\Fixtures\`) — se você mover a pasta `Output` ou compilar em
   outra máquina, copie esse arquivo de novo (o build não faz isso sozinho).
4. Compilar `DemoAurora.dproj` (Win32, Debug).

## Compatibilidade com o Dext.AI (manutenção pós-palestra)

O Demo Aurora foi construído sobre o framework `dext` (repositório irmão,
`..\..\dext`). Como esse framework segue evoluindo, depois da palestra
(01/09) ele recebeu 5 commits novos até 08/09/2026 que quebraram a
compatibilidade — registro aqui pra quem for atualizar o exemplo de novo no
futuro e passar pela mesma dor:

**O que mudou no `dext` e não afetou nada aqui** (mecânico ou fora do nosso
caminho de código):
- Migração de RTL generics pra `Dext.Collections` em `Dext.AI.Agent`/`Graph`.
- LLM providers (OpenAI/Anthropic/Ollama) passaram a usar `Dext.Net.RestClient`
  em vez de `THTTPClient` cru.
- Fix de colisão de checkpoint em `TFileCheckpointer.SanitizeId` — não nos
  afeta porque usamos `TMemoryCheckpointer` (`Compile(..., ACheckpointer=nil)`).
- `Dext.AI.Core.dpk` passou a exigir `Dext.Net.Core` e `Dext.Web.Core` — só
  exigiu acrescentar pastas novas (`Sources\Events`, `Sources\Debug`,
  `Sources\Core\Interception`, `Sources\Net`) ao search path do `dcc32`/
  `.dproj`, nenhuma mudança de código.

**O que quebrou de verdade**: a migração de `System.JSON` pra
`DextJsonDataObjects` dentro de `Dext.AI.MCP`/`Agent`/`Graph`. O invocador
RTTI de tools (`Dext.AI.MCP.Tools.TMCPToolRegistry.MakeProviderCallback`)
passou a montar `TValue.From<TJsonObject>(Args)` usando o `TJsonObject` do
`DextJsonDataObjects` — mas os quatro arquivos `Aurora.Tools.*.pas` (e os 3
closures pós-aprovação em `Aurora.Agent.ERP.pas`) ainda declaravam
`Args: TJSONObject` do `System.JSON`, uma classe totalmente diferente apesar
do nome quase igual. Isso **compilou limpo, sem erro nem warning nenhum**
(RTTI é dinamicamente tipado, o compilador não tem como pegar isso) e só
quebrava em runtime, no primeiro tool call — provável causa de um Access
Violation visto durante um teste manual. Corrigido reescrevendo os 4 arquivos
de tools + `Aurora.Agent.ERP.pas` pra usar a API fluente do
`DextJsonDataObjects` (`.S[]`/`.I[]`/`.F[]`/`.B[]`/`.A[]` em vez de
`TJSONObject.AddPair`). Revalidado ao vivo resolvendo as 3 notas em sequência
(Notebook → Smartphone → Cabo), sem erro.

**Lição pra próxima vez**: depois de qualquer atualização do `dext`, não
basta compilar limpo — o ponto de risco real é justamente onde o compilador
não ajuda (RTTI, serialização). Teste ao vivo pelo menos um fluxo completo
(pedir pra resolver uma nota → aprovar) antes de considerar compatível.

## Como resetar entre ensaios (importante!)

O banco (`aurora_seed.sqlite`) só é semeado **na primeira vez** — depois que
você aprova a correção uma vez, o produto fica com a configuração fiscal
correta *salva*, e a próxima vez que abrir a app vai aparecer tudo verde,
sem nenhum problema pra investigar (porque, de fato, já foi corrigido).

Pra voltar ao cenário do zero (NFC-e rejeitada, pronta pra investigar) antes
de cada ensaio ou antes de subir no palco, dê **duplo clique em
`Resetar_Demo.bat`** (está em `Output\`, do lado do `.exe`). Ele:
1. Fecha a Aurora se estiver aberta;
2. Apaga o `aurora_seed.sqlite` (o próximo start semeia tudo de novo);
3. Abre a Aurora de novo, já no cenário quebrado.

Se preferir fazer manualmente: feche a app, apague
`Output\aurora_seed.sqlite`, abra a app de novo.

## Cenário: 3 NFC-e rejeitadas, 3 causas diferentes

A grid abre com 3 vendas problemáticas ao mesmo tempo, cada uma com um tipo
de erro fiscal diferente — a ideia é mostrar o agente generalizando o mesmo
fluxo de investigação pra causas variadas, não repetindo um caso hardcoded:

| Venda    | Produto                  | Documento | Causa da rejeição                                    |
|----------|---------------------------|-----------|-------------------------------------------------------|
| PDV-1004 | Smartphone XYZ             | 10458     | Alíquota de ICMS incompatível com CFOP (subst. tributária) |
| PDV-1005 | Notebook Turbo Pro          | 10512     | NCM não corresponde à descrição do produto             |
| PDV-1006 | Cabo USB-C Reforçado 2m     | 10523     | CFOP incompatível com a UF de destino (interestadual)  |

A grid já deixa visualmente óbvio que há vendas rejeitadas — não faz sentido
perguntar "tem algum problema?" com a plateia vendo as linhas vermelhas.
Uma pergunta natural, citando o produto e já pedindo pra resolver, resolve
cada uma de forma **independente e direcionada** (o agente identifica qual
nota pelo nome do produto citado):

1. **"Vi que a nota do Notebook Turbo Pro está rejeitada. Pode descrever o
   motivo e já resolver isso?"**
   Esperado: `intent_analyzer` classifica como `investigar_e_resolver` →
   `fiscal_subgraph` chama `locate_document` (usando "Notebook Turbo Pro"
   como `product_hint` — é assim que ele sabe qual das 3 notas investigar)
   → as outras 3 tools → `capture_diagnosis` → direto para `risk_analyzer`
   (risco "alto") → grafo pausa em `approval_gate`, já com o diagnóstico
   (causa: NCM incorreto) junto do pedido de autorização.

2. Clicar **✓ Aprovar**.
   Esperado: o chat narra cada etapa do processamento — "Corrigindo
   configuração fiscal do produto...", "Regenerando XML da NFC-e...",
   "Validando XML regenerado...", "Transmitindo à SEFAZ..." (~1s cada, de
   propósito, pra dar a sensação de trabalho real acontecendo) — até
   "Problema resolvido. NFC-e 10512 autorizada pela SEFAZ." A linha do
   Notebook vira verde e o card "PROBLEMAS FISCAIS" cai de 3 pra 2, **ao
   vivo**. As outras duas notas continuam rejeitadas.

3. Repita pra uma segunda nota, com uma causa diferente: **"E o cabo USB-C,
   por que foi rejeitado? Corrige também."** → mesmo fluxo, mas agora o
   diagnóstico é sobre CFOP (não NCM) → aprova → card cai pra 1.

4. Se quiser fechar o cenário 100%, repita pra "o smartphone" (causa:
   alíquota de ICMS) → card chega a 0, tudo verde.

## Como pedir pra corrigir as outras (durante a apresentação)

**Sempre cite o produto na mesma frase que pede pra resolver.** Isso garante
que ele investiga e já pede aprovação num passo só, mesmo que você nunca
tenha falado daquela nota antes na conversa:

- "Resolve a nota do Notebook Turbo Pro."
- "Corrige o Cabo USB-C também."
- "E o smartphone, por que foi rejeitado? Já resolve."

Não importa a ordem, nem se você já resolveu outras antes — cada pedido é
tratado do zero, olhando só pro produto citado. Funciona tanto numa sessão
limpa quanto no meio de uma sequência (testei resolver 2 notas diferentes
seguidas, cada uma investigada e corrigida corretamente, sem misturar o
diagnóstico de uma com o pedido da outra).

**O que evitar**: um pedido vago sem citar produto ("resolve as outras",
"corrige tudo") quando ainda sobra mais de uma nota — nesse caso ele lista
as pendentes numeradas e pergunta qual primeiro (comportamento seguro de
propósito, pra nunca escolher errado sozinho). Se isso acontecer no palco,
é só responder citando o produto (ex: "o Notebook") — mas, pra não perder
tempo com esse passo extra ao vivo, prefira sempre já citar o produto na
primeira frase.

**Outro ponto a evitar**: uma frase só pedindo duas coisas sobre produtos
diferentes (ex: "resolve isso, e me passa o motivo do Notebook também") —
o classificador entende a mensagem inteira como sendo sobre o último
produto citado (o Notebook) e ignora silenciosamente a primeira parte,
sem perguntar nada. Não quebra o roteiro (o produto citado por último é
investigado e resolvido normalmente), mas o outro pedido simplesmente não
acontece. Ao vivo, uma coisa de cada vez: peça, aprove, só depois peça a
próxima.

Cada rodada reforça a narrativa: o mesmo agente, sem código novo, resolve
um tipo de erro diferente por vez — é isso que vende produtividade/
automação pra quem está assistindo.

Frases equivalentes que também funcionam (classificação é por LLM, não por
palavra-chave fixa): "Descubra a causa dessa rejeição e conserte",
"Investiga esse problema fiscal e já corrige", "Por que essa nota foi
rejeitada? Resolve pra mim".

## Roteiro passo a passo (alternativo — mais didático, mais interações)

Se quiser mostrar cada etapa do grafo separadamente (por exemplo, numa
sessão mais técnica/workshop), ainda dá pra fazer em 4 perguntas por nota —
o agente suporta as duas formas:

1. "Tem algum problema nas vendas de hoje?" → agora lista **as 3** notas
   rejeitadas (não só uma).
2. "Descubra o problema do Notebook." → só o diagnóstico dessa nota
   (`investigar_fiscal`, sem `risk_analyzer`/aprovação).
3. "Consegue resolver?" → aí sim classifica risco e pausa em
   `approval_gate` (o diagnóstico da resposta anterior é reaproveitado —
   continua se referindo à mesma nota da pergunta 2).
4. Clicar **Aprovar** → mesma resolução final, narrada, de cima.

## Console (mostra cada nó do grafo)

Cada nó aparece na janela de console separada que abre junto com a app
(`AllocConsole`) via `Writeln('[NÓ] ...')` em cada handler + o
`TConsoleObserver` padrão do framework para chamadas de LLM/tools. Vale a
pena deixar essa janela visível ao lado da app durante a palestra — é onde
a plateia vê "intenção classificada: investigar_e_resolver",
"risco classificado: alto", etc.

## Decisões de escopo (documentadas no código, não é limitação técnica)

- `regenerate_document` e `transmit_document` (`Aurora.Tools.Transmission.pas`)
  são fallback pré-computado — não existe ACBr neste repositório, e nenhuma
  chamada de rede real é feita.
- Sem persistência em disco do estado do grafo — `Compile(..., ACheckpointer=nil)`
  usa `TMemoryCheckpointer`, tudo em memória do processo.
- 3 cenários determinísticos pré-semeados (3 produtos, 3 causas de rejeição
  diferentes) — o direcionamento de qual nota investigar é feito por
  `product_hint` (nome do produto citado pelo usuário), guardado durante o
  turno em `TAuroraSession.CurrentDocumentNumber`.
- O "tempo de processamento" pós-aprovação (`ProcessingDelay` em
  `Aurora.Agent.ERP.pas`) é proposital — não é latência real de rede, é só
  pra dar a sensação de trabalho acontecendo em vez de tudo instantâneo.

## Fallback se o grafo travar ao vivo

Gravar hoje/segunda um vídeo de 2-3 min do fluxo completo (os 4 passos acima)
rodando do início ao fim, para usar como plano B durante a palestra.

## O que falta antes da palestra

- [x] Rodar o roteiro ao vivo com `OPENAI_API_KEY` real — testado resolvendo
      as 3 notas (Notebook e Cabo USB-C confirmados ao vivo; Smartphone usa
      o mesmo caminho de código, já validado antes da expansão pra 3 notas).
- [ ] Gravar o vídeo de fallback com o cenário novo (3 notas).
- [ ] Cronometrar quantas notas dá tempo de resolver ao vivo (cada uma leva
      uns 15-20s de investigação + ~5s de processamento narrado + aprovação).
