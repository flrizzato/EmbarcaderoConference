﻿program DemoAurora;

uses
  Winapi.Windows,
  Vcl.Forms,
  System.SysUtils,
  Aurora.App.Startup in 'App\Aurora.App.Startup.pas',
  Aurora.Session in 'App\Aurora.Session.pas',
  Aurora.Progress in 'App\Aurora.Progress.pas',
  Aurora.Data.Context in 'Data\Aurora.Data.Context.pas',
  Aurora.Data.Seeder in 'Data\Aurora.Data.Seeder.pas',
  Aurora.Domain.Entities in 'Domain\Aurora.Domain.Entities.pas',
  Aurora.Domain.Enums in 'Domain\Aurora.Domain.Enums.pas',
  Aurora.Agent.ERP in 'Agents\Aurora.Agent.ERP.pas',
  Aurora.Agent.Fiscal in 'Agents\Aurora.Agent.Fiscal.pas',
  Aurora.Tools.Sales in 'Tools\Aurora.Tools.Sales.pas',
  Aurora.Tools.Fiscal in 'Tools\Aurora.Tools.Fiscal.pas',
  Aurora.Tools.Products in 'Tools\Aurora.Tools.Products.pas',
  Aurora.Tools.Transmission in 'Tools\Aurora.Tools.Transmission.pas',
  Aurora.UI.Theme in 'UI\Aurora.UI.Theme.pas',
  Aurora.UI.MainForm in 'UI\Aurora.UI.MainForm.pas' {MainForm},
  Aurora.UI.AssistantPanel in 'UI\Aurora.UI.AssistantPanel.pas' {AssistantPanelFrame: TFrame};

begin
  // App é {$APPTYPE GUI} (VCL) — sem console alocado, todo Writeln (o nosso
  // e o do TConsoleObserver reaproveitado) falharia ou ficaria invisível.
  // Isso é o que o critério de aceite pede para mostrar cada nó do grafo.
  AllocConsole;
  Rewrite(Output);
  Writeln('=== Dext.AI.Graph — console da Aurora ===');

  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  try
    TAuroraStartup.Configure;
    try
      Application.CreateForm(TMainForm, MainForm);
      Application.Run;
    finally
      TAuroraStartup.Shutdown;
    end;
  except
    on E: Exception do
      Application.MessageBox(PChar(E.Message), 'Erro ao iniciar a Aurora', MB_ICONERROR);
  end;
end.
