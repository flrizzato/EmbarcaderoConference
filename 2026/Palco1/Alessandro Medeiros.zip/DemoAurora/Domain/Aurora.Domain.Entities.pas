﻿unit Aurora.Domain.Entities;

interface

uses
  Dext.Entity,
  Dext.Core.SmartTypes,
  Aurora.Domain.Enums;

type
  { -------------------------------------------------------------------------- }
  { TProduct                                                                   }
  { -------------------------------------------------------------------------- }
  [Table('Products')]
  TProduct = class
  private
    FId: IntType;
    FName: StringType;
    FCfop: StringType;
    FTaxRate: CurrencyType;
    FCorrectTaxRate: CurrencyType;
    FTaxConfigValid: BoolType;
  public
    [PK, AutoInc]
    property Id: IntType read FId write FId;
    property Name: StringType read FName write FName;
    // CFOP da operação de venda ao consumidor final.
    property Cfop: StringType read FCfop write FCfop;
    // Alíquota de ICMS atualmente cadastrada (a causadora da rejeição).
    property TaxRate: CurrencyType read FTaxRate write FTaxRate;
    // Alíquota correta para este CFOP — usada por update_tax_configuration.
    property CorrectTaxRate: CurrencyType read FCorrectTaxRate write FCorrectTaxRate;
    property TaxConfigValid: BoolType read FTaxConfigValid write FTaxConfigValid;

    class function Props: TProduct; static;
  end;

  { -------------------------------------------------------------------------- }
  { TSale                                                                      }
  { -------------------------------------------------------------------------- }
  [Table('Sales')]
  TSale = class
  private
    FId: IntType;
    FSaleNumber: StringType;
    FProductId: IntType;
    FTotal: CurrencyType;
    FHasFiscalIssue: BoolType;
    FCreatedAt: DateTimeType;
  public
    [PK, AutoInc]
    property Id: IntType read FId write FId;
    property SaleNumber: StringType read FSaleNumber write FSaleNumber;
    property ProductId: IntType read FProductId write FProductId;
    property Total: CurrencyType read FTotal write FTotal;
    property HasFiscalIssue: BoolType read FHasFiscalIssue write FHasFiscalIssue;

    [CreatedAt]
    property CreatedAt: DateTimeType read FCreatedAt write FCreatedAt;

    class function Props: TSale; static;
  end;

  { -------------------------------------------------------------------------- }
  { TFiscalDocument (NFC-e)                                                    }
  { -------------------------------------------------------------------------- }
  [Table('FiscalDocuments')]
  TFiscalDocument = class
  private
    FId: IntType;
    FSaleId: IntType;
    FProductId: IntType;
    FDocumentNumber: StringType;
    FStatus: TFiscalDocumentStatusType;
    FRejectionReason: StringType;
    FSefazReturnMessage: StringType;
    FXmlContent: StringType;
    FCorrectionSummary: StringType;
    FCreatedAt: DateTimeType;
  public
    [PK, AutoInc]
    property Id: IntType read FId write FId;
    property SaleId: IntType read FSaleId write FSaleId;
    property ProductId: IntType read FProductId write FProductId;
    property DocumentNumber: StringType read FDocumentNumber write FDocumentNumber;
    property Status: TFiscalDocumentStatusType read FStatus write FStatus;
    property RejectionReason: StringType read FRejectionReason write FRejectionReason;
    // Mensagem de retorno da SEFAZ já semeada — analyze_sefaz_return só lê.
    property SefazReturnMessage: StringType read FSefazReturnMessage write FSefazReturnMessage;
    // XML já semeado — analyze_xml só lê, não gera nada novo aqui.
    property XmlContent: StringType read FXmlContent write FXmlContent;
    // Frase genérica descrevendo a correção (serve pra qualquer tipo de erro
    // fiscal — ICMS, NCM, CFOP etc. — sem precisar de um campo por tipo).
    property CorrectionSummary: StringType read FCorrectionSummary write FCorrectionSummary;

    [CreatedAt]
    property CreatedAt: DateTimeType read FCreatedAt write FCreatedAt;

    class function Props: TFiscalDocument; static;
  end;

implementation

{ TProduct }

class function TProduct.Props: TProduct;
begin
  Result := Prototype.Entity<TProduct>;
end;

{ TSale }

class function TSale.Props: TSale;
begin
  Result := Prototype.Entity<TSale>;
end;

{ TFiscalDocument }

class function TFiscalDocument.Props: TFiscalDocument;
begin
  Result := Prototype.Entity<TFiscalDocument>;
end;

end.
