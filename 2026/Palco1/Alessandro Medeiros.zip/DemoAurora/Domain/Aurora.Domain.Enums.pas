﻿unit Aurora.Domain.Enums;

interface

uses
  Dext.Core.SmartTypes;

type
  TFiscalDocumentStatus = (Authorized, Rejected);
  TFiscalDocumentStatusType = Prop<TFiscalDocumentStatus>;

implementation

end.
