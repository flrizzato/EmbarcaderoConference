@echo off
chcp 65001 >nul
echo ==========================================================
echo   Resetando a Aurora para o cenario com as 3 NFC-e rejeitadas
echo ==========================================================

taskkill /IM DemoAurora.exe /F >nul 2>&1
ping -n 2 127.0.0.1 >nul

del /f /q "%~dp0aurora_seed.sqlite" >nul 2>&1
echo [OK] Banco resetado.

if "%OPENAI_API_KEY%"=="" (
  echo.
  echo [ERRO] A variavel OPENAI_API_KEY nao esta definida nesta sessao.
  echo         Veja o README_DEMO.md para configurar de forma permanente.
  echo.
  pause
  exit /b 1
)

echo [OK] Iniciando a Aurora...
start "" "%~dp0DemoAurora.exe"
echo.
echo Pronto! A janela da Aurora deve abrir em instantes, com as 3 vendas
echo (Smartphone XYZ, Notebook Turbo Pro, Cabo USB-C) marcadas como
echo REJEITADA de novo.
ping -n 4 127.0.0.1 >nul
