﻿unit Aurora.Data.Seeder;

interface

uses
  Dext.DI.Interfaces,
  Dext,
  Dext.Entity,
  Aurora.Data.Context,
  Aurora.Domain.Entities,
  Aurora.Domain.Enums;

type
  TAuroraSeeder = class
  public
    class procedure Seed(const Provider: IServiceProvider);
  end;

implementation

uses
  System.SysUtils;

// Três causas de rejeição bem diferentes entre si — não é sempre "alíquota
// de ICMS errada". A ideia é mostrar o agente generalizando o mesmo fluxo
// de investigação (locate_document → analyze_xml → analyze_sefaz_return →
// query_product_tax_context) pra tipos de erro fiscal distintos, não só
// repetindo um caso hardcoded.
procedure SeedBrokenInvoice(
  Db:                    TAuroraContext;
  const ASaleNumber:     string;
  const ADocumentNumber: string;
  const AProductName:    string;
  const ACfop:           string;
  const ATotal:          Currency;
  const ARejectionReason, ASefazMessage, AXml, ACorrectionSummary: string
);
var
  Product: TProduct;
  Sale:    TSale;
  Doc:     TFiscalDocument;
begin
  Product := TProduct.Create;
  Product.Name := AProductName;
  Product.Cfop := ACfop;
  Product.TaxRate := 0;
  Product.CorrectTaxRate := 0;
  Product.TaxConfigValid := False;
  Db.Products.Add(Product);
  Db.SaveChanges;

  Sale := TSale.Create;
  Sale.SaleNumber := ASaleNumber;
  Sale.ProductId := Product.Id;
  Sale.Total := ATotal;
  Sale.HasFiscalIssue := True;
  Db.Sales.Add(Sale);
  Db.SaveChanges;

  Doc := TFiscalDocument.Create;
  Doc.SaleId := Sale.Id;
  Doc.ProductId := Product.Id;
  Doc.DocumentNumber := ADocumentNumber;
  Doc.Status := TFiscalDocumentStatus.Rejected;
  Doc.RejectionReason := ARejectionReason;
  Doc.SefazReturnMessage := ASefazMessage;
  Doc.XmlContent := AXml;
  Doc.CorrectionSummary := ACorrectionSummary;
  Db.FiscalDocuments.Add(Doc);
  Db.SaveChanges;
end;

class procedure TAuroraSeeder.Seed(const Provider: IServiceProvider);
var
  Scope: IServiceScope;
  Db: TAuroraContext;
  ProductOk: TProduct;
  Sale: TSale;
  I: Integer;
begin
  Writeln('[*] Inicializando seed da Aurora...');

  Scope := Provider.CreateScope;
  try
    Db := Scope.ServiceProvider.GetService(TAuroraContext) as TAuroraContext;
    if not Assigned(Db) then
    begin
      Writeln('[ERRO] Não foi possível resolver TAuroraContext.');
      Exit;
    end;

    if Db.EnsureCreated then
      Writeln('[+] Schema do SQLite criado (aurora_seed.sqlite).')
    else
      Writeln('[i] Schema já existia.');

    if Db.Products.QueryAll.Any then
    begin
      Writeln('[i] Dados já semeados. Pulando.');
      Exit;
    end;

    Writeln('[*] Semeando cenário determinístico (3 causas de rejeição diferentes)...');

    // Produto sem problema fiscal — usado nas vendas normais do dia.
    ProductOk := TProduct.Create;
    ProductOk.Name := 'Fone de Ouvido Bluetooth';
    ProductOk.Cfop := '5102';
    ProductOk.TaxRate := 12;
    ProductOk.CorrectTaxRate := 12;
    ProductOk.TaxConfigValid := True;
    Db.Products.Add(ProductOk);
    Db.SaveChanges;

    // 3 vendas normais do dia, sem nenhum problema fiscal.
    for I := 1 to 3 do
    begin
      Sale := TSale.Create;
      Sale.SaleNumber := Format('PDV-%.4d', [1000 + I]);
      Sale.ProductId := ProductOk.Id;
      Sale.Total := 199.90 * I;
      Sale.HasFiscalIssue := False;
      Db.Sales.Add(Sale);
    end;
    Db.SaveChanges;

    // Causa 1: alíquota de ICMS incompatível com o CFOP (substituição
    // tributária — o ICMS já foi retido antes, não deveria ser destacado de novo).
    SeedBrokenInvoice(Db, 'PDV-1004', '10458', 'Smartphone XYZ', '5405', 3499.00,
      'Alíquota de ICMS incompatível com o CFOP do produto',
      'Rejeição 656: Divergência entre a alíquota de ICMS informada (18,00%) ' +
      'e o CST/CFOP 5405 (substituição tributária, ICMS já retido) cadastrado ' +
      'para o produto Smartphone XYZ.',
      '<NFe><infNFe><det nItem="1">' +
      '<prod><cProd>P002</cProd><xProd>Smartphone XYZ</xProd><CFOP>5405</CFOP></prod>' +
      '<imposto><ICMS><ICMS60><orig>0</orig><CST>60</CST></ICMS60></ICMS>' +
      '<pICMS>18.00</pICMS></imposto></det></infNFe></NFe>',
      'Alíquota de ICMS ajustada de 18,00% para 0,00% (ICMS já retido por substituição tributária)');

    // Causa 2: NCM (classificação fiscal da mercadoria) não corresponde ao
    // que está sendo vendido — um tipo de erro completamente diferente do de cima.
    SeedBrokenInvoice(Db, 'PDV-1005', '10512', 'Notebook Turbo Pro', '5102', 4599.00,
      'NCM informado não corresponde à descrição do produto',
      'Rejeição 228: o NCM 8471.30.12 informado não corresponde à mercadoria ' +
      'descrita como "Notebook Turbo Pro" — o NCM correto para notebooks é 8471.30.19.',
      '<NFe><infNFe><det nItem="1">' +
      '<prod><cProd>P003</cProd><xProd>Notebook Turbo Pro</xProd><NCM>8471.30.12</NCM></prod>' +
      '</det></infNFe></NFe>',
      'NCM corrigido de 8471.30.12 para 8471.30.19');

    // Causa 3: CFOP usado é de operação interna, mas a venda foi para outro
    // estado — mais um tipo de erro diferente dos dois anteriores.
    SeedBrokenInvoice(Db, 'PDV-1006', '10523', 'Cabo USB-C Reforçado 2m', '5102', 89.90,
      'CFOP incompatível com a UF de destino da venda',
      'Rejeição 301: o CFOP 5102 (operação interna/dentro do estado) foi usado ' +
      'numa venda interestadual — o CFOP correto seria 6102 (venda interestadual ' +
      'a não contribuinte).',
      '<NFe><infNFe><det nItem="1">' +
      '<prod><cProd>P004</cProd><xProd>Cabo USB-C Reforçado 2m</xProd><CFOP>5102</CFOP></prod>' +
      '</det></infNFe></NFe>',
      'CFOP corrigido de 5102 para 6102 (operação interestadual a não contribuinte)');

    Writeln('[OK] Seed concluído: 3 vendas normais, 3 NFC-e rejeitadas (10458, 10512, 10523).');
  finally
    Scope := nil;
  end;
end;

end.
