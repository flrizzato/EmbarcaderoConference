﻿unit Aurora.Data.Context;

interface

uses
  Dext.Entity,
  Dext.Entity.Core,
  Aurora.Domain.Entities;

type
  TAuroraContext = class(TDbContext)
  private
    function GetProducts: IDbSet<TProduct>;
    function GetSales: IDbSet<TSale>;
    function GetFiscalDocuments: IDbSet<TFiscalDocument>;
  public
    property Products: IDbSet<TProduct> read GetProducts;
    property Sales: IDbSet<TSale> read GetSales;
    property FiscalDocuments: IDbSet<TFiscalDocument> read GetFiscalDocuments;

    procedure OnConfiguring(Options: TDbContextOptions); override;
  end;

implementation

{ TAuroraContext }

procedure TAuroraContext.OnConfiguring(Options: TDbContextOptions);
begin
  inherited;
  Options.UseSnakeCaseNamingConvention;
end;

function TAuroraContext.GetProducts: IDbSet<TProduct>;
begin
  Result := Entities<TProduct>;
end;

function TAuroraContext.GetSales: IDbSet<TSale>;
begin
  Result := Entities<TSale>;
end;

function TAuroraContext.GetFiscalDocuments: IDbSet<TFiscalDocument>;
begin
  Result := Entities<TFiscalDocument>;
end;

end.
