﻿unit Aurora.Tools.Products;

interface

uses
  DextJsonDataObjects,
  System.SysUtils,
  Dext.Entity,
  Dext.AI.MCP.Tools,
  Dext.AI.MCP.Types,
  Dext.AI.MCP.Attributes,
  Aurora.Data.Context,
  Aurora.Domain.Entities,
  Aurora.Domain.Enums,
  Aurora.Session;

type
  // Única tool de escrita fiscal do cenário — só deve ser chamada depois que
  // o grafo passou por RequireApproval('approval_gate') e o usuário aprovou.
  TProductsTools = class(TMCPToolProvider)
  private
    FDb: TAuroraContext;
    function ResolveTargetDoc: TFiscalDocument;
  public
    constructor Create(ADb: TAuroraContext);

    [MCPTool('update_tax_configuration', 'Corrige a configuração fiscal do produto causador, gravando no banco')]
    function UpdateTaxConfiguration(const Args: TJsonObject): TMCPToolResult;
  end;

implementation

{ TProductsTools }

constructor TProductsTools.Create(ADb: TAuroraContext);
begin
  inherited Create;
  FDb := ADb;
end;

function TProductsTools.ResolveTargetDoc: TFiscalDocument;
begin
  Result := nil;
  if TAuroraSession.CurrentDocumentNumber <> '' then
    Result := FDb.FiscalDocuments.FirstOrDefault(
      TFiscalDocument.Props.DocumentNumber = TAuroraSession.CurrentDocumentNumber);

  if Result = nil then
    Result := FDb.FiscalDocuments.FirstOrDefault(
      TFiscalDocument.Props.Status = TFiscalDocumentStatus.Rejected);
end;

function TProductsTools.UpdateTaxConfiguration(const Args: TJsonObject): TMCPToolResult;
var
  Doc:     TFiscalDocument;
  Product: TProduct;
  JObj:    TJsonObject;
begin
  Doc := ResolveTargetDoc;
  if Doc = nil then
    Exit(TMCPToolResult.Error('Nenhuma NFC-e pendente de correção.'));

  Product := FDb.Products.FirstOrDefault(TProduct.Props.Id = Doc.ProductId);
  if Product = nil then
    Exit(TMCPToolResult.Error('Produto causador não encontrado.'));

  // Correção genérica — o que muda de fato (alíquota, NCM, CFOP...) já foi
  // decidido e explicado no diagnóstico (Doc.CorrectionSummary); aqui só
  // marcamos o produto como corrigido.
  Product.TaxConfigValid := True;
  FDb.SaveChanges;

  JObj := TJsonObject.Create;
  try
    JObj.S['productName'] := string(Product.Name);
    JObj.S['correctionApplied'] := string(Doc.CorrectionSummary);
    JObj.B['updated'] := True;
    Result := TMCPToolResult.Text(JObj.ToJSON);
  finally
    JObj.Free;
  end;
end;

end.
