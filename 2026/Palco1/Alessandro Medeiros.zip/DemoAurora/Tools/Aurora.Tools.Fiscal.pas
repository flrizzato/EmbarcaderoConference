﻿unit Aurora.Tools.Fiscal;

interface

uses
  DextJsonDataObjects,
  System.SysUtils,
  Dext.Entity,
  Dext.Collections,
  Dext.AI.MCP.Tools,
  Dext.AI.MCP.Types,
  Dext.AI.MCP.Protocol,
  Dext.AI.MCP.Attributes,
  Aurora.Data.Context,
  Aurora.Domain.Entities,
  Aurora.Domain.Enums,
  Aurora.Session;

type
  // Cenário determinístico: as tools abaixo só leem documentos fiscais já
  // semeados no banco (Aurora.Data.Seeder) — nenhuma gera XML novo ou fala
  // com a SEFAZ de verdade. Pode haver mais de uma NFC-e rejeitada ao mesmo
  // tempo (causas diferentes); locate_document escolhe qual investigar e
  // guarda isso em TAuroraSession para o resto do turno.
  TFiscalTools = class(TMCPToolProvider)
  private
    FDb: TAuroraContext;
    function FindByHint(const AHint: string): TFiscalDocument;
    function LocateInFocus: TFiscalDocument;
  public
    constructor Create(ADb: TAuroraContext);

    [MCPTool('locate_document', 'Localiza um documento fiscal (NFC-e) rejeitado')]
    [MCPParam('product_hint', 'Nome (ou parte do nome) do produto citado pelo usuário, se ele mencionou qual nota investigar. Deixe vazio se não foi especificado.', ptString, False)]
    function LocateDocument(const Args: TJsonObject): TMCPToolResult;

    [MCPTool('analyze_xml', 'Analisa o XML já semeado do documento em foco (o último localizado por locate_document)')]
    function AnalyzeXml(const Args: TJsonObject): TMCPToolResult;

    [MCPTool('analyze_sefaz_return', 'Lê a mensagem de retorno da SEFAZ já semeada do documento em foco')]
    function AnalyzeSefazReturn(const Args: TJsonObject): TMCPToolResult;

    [MCPTool('query_product_tax_context', 'Consulta a configuração fiscal cadastrada do produto causador do documento em foco')]
    function QueryProductTaxContext(const Args: TJsonObject): TMCPToolResult;
  end;

implementation

{ TFiscalTools }

constructor TFiscalTools.Create(ADb: TAuroraContext);
begin
  inherited Create;
  FDb := ADb;
end;

function TFiscalTools.FindByHint(const AHint: string): TFiscalDocument;
var
  Rejected: IList<TFiscalDocument>;
  Doc:      TFiscalDocument;
  Product:  TProduct;
  HintLow:  string;
begin
  Result := nil;
  Rejected := FDb.FiscalDocuments.Where(
    TFiscalDocument.Props.Status = TFiscalDocumentStatus.Rejected).ToList;
  if Rejected.Count = 0 then
    Exit;

  HintLow := AHint.Trim.ToLower;
  if HintLow <> '' then
    for Doc in Rejected do
    begin
      Product := FDb.Products.FirstOrDefault(TProduct.Props.Id = Doc.ProductId);
      if (Product <> nil) and (string(Product.Name).ToLower.Contains(HintLow)) then
        Exit(Doc);
    end;

  // Sem dica ou sem correspondência: primeira rejeitada (compatível com o
  // cenário original de uma única nota).
  Result := Rejected[0];
end;

function TFiscalTools.LocateInFocus: TFiscalDocument;
begin
  Result := nil;
  if TAuroraSession.CurrentDocumentNumber <> '' then
    Result := FDb.FiscalDocuments.FirstOrDefault(
      TFiscalDocument.Props.DocumentNumber = TAuroraSession.CurrentDocumentNumber);

  if Result = nil then
    Result := FindByHint('');
end;

function TFiscalTools.LocateDocument(const Args: TJsonObject): TMCPToolResult;
var
  Hint:     string;
  HintLow:  string;
  Rejected: IList<TFiscalDocument>;
  Doc, D:   TFiscalDocument;
  Product:  TProduct;
  JObj:     TJsonObject;
begin
  Hint := Args.S['product_hint'];
  Rejected := FDb.FiscalDocuments.Where(
    TFiscalDocument.Props.Status = TFiscalDocumentStatus.Rejected).ToList;

  if Rejected.Count = 0 then
  begin
    TAuroraSession.LastLocateWasAmbiguous := False;
    Exit(TMCPToolResult.Error('Nenhuma NFC-e rejeitada encontrada.'));
  end;

  Doc := nil;
  HintLow := Hint.Trim.ToLower;
  if HintLow <> '' then
    for D in Rejected do
    begin
      Product := FDb.Products.FirstOrDefault(TProduct.Props.Id = D.ProductId);
      if (Product <> nil) and (string(Product.Name).ToLower.Contains(HintLow)) then
      begin
        Doc := D;
        Break;
      end;
    end;

  // Só 1 rejeitada no total: não há ambiguidade real mesmo sem dica —
  // mantém o cenário de uma única nota funcionando como sempre funcionou.
  if (Doc = nil) and (Rejected.Count = 1) then
    Doc := Rejected[0];

  if Doc = nil then
  begin
    // Várias rejeitadas e nenhuma identificada pelo usuário — não escolhe
    // por conta própria. Lista as pendentes pro agente perguntar qual.
    TAuroraSession.LastLocateWasAmbiguous := True;
    TAuroraSession.CurrentDocumentNumber := '';

    JObj := TJsonObject.Create;
    try
      JObj.B['ambiguous'] := True;
      JObj.S['message'] :=
        'Há mais de uma NFC-e rejeitada. Pergunte ao usuário qual produto ele ' +
        'quer investigar antes de chamar qualquer outra tool.';
      for D in Rejected do
      begin
        Product := FDb.Products.FirstOrDefault(TProduct.Props.Id = D.ProductId);
        if Product <> nil then
          JObj.A['pendingDocuments'].Add(Format('%s (documento %s)', [string(Product.Name), string(D.DocumentNumber)]))
        else
          JObj.A['pendingDocuments'].Add(Format('documento %s', [string(D.DocumentNumber)]));
      end;
      Exit(TMCPToolResult.Text(JObj.ToJSON));
    finally
      JObj.Free;
    end;
  end;

  TAuroraSession.LastLocateWasAmbiguous := False;
  TAuroraSession.CurrentDocumentNumber := string(Doc.DocumentNumber);

  Product := FDb.Products.FirstOrDefault(TProduct.Props.Id = Doc.ProductId);
  if Product <> nil then
    TAuroraSession.CurrentProductName := string(Product.Name)
  else
    TAuroraSession.CurrentProductName := '';

  JObj := TJsonObject.Create;
  try
    JObj.S['documentNumber'] := string(Doc.DocumentNumber);
    JObj.S['status'] := 'Rejected';
    if Product <> nil then
      JObj.S['productName'] := string(Product.Name);
    Result := TMCPToolResult.Text(JObj.ToJSON);
  finally
    JObj.Free;
  end;
end;

function TFiscalTools.AnalyzeXml(const Args: TJsonObject): TMCPToolResult;
var
  Doc: TFiscalDocument;
  JObj: TJsonObject;
begin
  Doc := LocateInFocus;
  if Doc = nil then
    Exit(TMCPToolResult.Error('Nenhuma NFC-e rejeitada encontrada.'));

  JObj := TJsonObject.Create;
  try
    JObj.S['documentNumber'] := string(Doc.DocumentNumber);
    JObj.S['xml'] := string(Doc.XmlContent);
    Result := TMCPToolResult.Text(JObj.ToJSON);
  finally
    JObj.Free;
  end;
end;

function TFiscalTools.AnalyzeSefazReturn(const Args: TJsonObject): TMCPToolResult;
var
  Doc: TFiscalDocument;
  JObj: TJsonObject;
begin
  Doc := LocateInFocus;
  if Doc = nil then
    Exit(TMCPToolResult.Error('Nenhuma NFC-e rejeitada encontrada.'));

  JObj := TJsonObject.Create;
  try
    JObj.S['documentNumber'] := string(Doc.DocumentNumber);
    JObj.S['rejectionReason'] := string(Doc.RejectionReason);
    JObj.S['sefazMessage'] := string(Doc.SefazReturnMessage);
    Result := TMCPToolResult.Text(JObj.ToJSON);
  finally
    JObj.Free;
  end;
end;

function TFiscalTools.QueryProductTaxContext(const Args: TJsonObject): TMCPToolResult;
var
  Doc: TFiscalDocument;
  Product: TProduct;
  JObj: TJsonObject;
begin
  Doc := LocateInFocus;
  if Doc = nil then
    Exit(TMCPToolResult.Error('Nenhuma NFC-e rejeitada encontrada.'));

  Product := FDb.Products.FirstOrDefault(TProduct.Props.Id = Doc.ProductId);
  if Product = nil then
    Exit(TMCPToolResult.Error('Produto causador não encontrado.'));

  JObj := TJsonObject.Create;
  try
    JObj.S['productName'] := string(Product.Name);
    JObj.S['cfop'] := string(Product.Cfop);
    JObj.F['registeredTaxRate'] := Currency(Product.TaxRate);
    JObj.F['correctTaxRate'] := Currency(Product.CorrectTaxRate);
    JObj.B['taxConfigValid'] := Boolean(Product.TaxConfigValid);
    JObj.S['correctionSummary'] := string(Doc.CorrectionSummary);
    Result := TMCPToolResult.Text(JObj.ToJSON);
  finally
    JObj.Free;
  end;
end;

end.
