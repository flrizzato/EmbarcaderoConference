﻿unit Aurora.Tools.Sales;

interface

uses
  DextJsonDataObjects,
  System.SysUtils,
  Dext.Collections,
  Dext.Entity,
  Dext.AI.MCP.Tools,
  Dext.AI.MCP.Types,
  Dext.AI.MCP.Attributes,
  Aurora.Data.Context,
  Aurora.Domain.Entities;

type
  TSalesTools = class(TMCPToolProvider)
  private
    FDb: TAuroraContext;
  public
    constructor Create(ADb: TAuroraContext);

    [MCPTool('sales_check_issues', 'Verifica se há problemas fiscais nas vendas de hoje')]
    function CheckIssues(const Args: TJsonObject): TMCPToolResult;

    [MCPTool('sales_today_summary', 'Resumo das vendas do dia (quantidade e total)')]
    function TodaySummary(const Args: TJsonObject): TMCPToolResult;
  end;

implementation

{ TSalesTools }

constructor TSalesTools.Create(ADb: TAuroraContext);
begin
  inherited Create;
  FDb := ADb;
end;

function TSalesTools.CheckIssues(const Args: TJsonObject): TMCPToolResult;
var
  Sales:   IList<TSale>;
  Sale:    TSale;
  Product: TProduct;
  Doc:     TFiscalDocument;
  JObj:    TJsonObject;
  JItem:   TJsonObject;
begin
  Sales := FDb.Sales.Where(TSale.Props.HasFiscalIssue = True).ToList;
  if Sales.Count = 0 then
    Exit(TMCPToolResult.Text('{"hasIssue":false,"message":"Nenhum problema encontrado nas vendas de hoje."}'));

  JObj := TJsonObject.Create;
  try
    JObj.B['hasIssue'] := True;
    JObj.I['issueCount'] := Sales.Count;

    for Sale in Sales do
    begin
      Doc := FDb.FiscalDocuments.FirstOrDefault(TFiscalDocument.Props.SaleId = Sale.Id);
      Product := FDb.Products.FirstOrDefault(TProduct.Props.Id = Sale.ProductId);

      JItem := JObj.A['issues'].AddObject;
      JItem.S['saleNumber'] := string(Sale.SaleNumber);
      if Product <> nil then
        JItem.S['productName'] := string(Product.Name);
      if Doc <> nil then
      begin
        JItem.S['documentNumber'] := string(Doc.DocumentNumber);
        JItem.S['documentStatus'] := 'Rejected';
        JItem.S['rejectionReason'] := string(Doc.RejectionReason);
      end;
    end;

    Result := TMCPToolResult.Text(JObj.ToJSON);
  finally
    JObj.Free;
  end;
end;

function TSalesTools.TodaySummary(const Args: TJsonObject): TMCPToolResult;
var
  All: IList<TSale>;
  Sale: TSale;
  Total: Currency;
  JObj: TJsonObject;
begin
  All := FDb.Sales.QueryAll.ToList;
  Total := 0;
  for Sale in All do
    Total := Total + Currency(Sale.Total);

  JObj := TJsonObject.Create;
  try
    JObj.I['count'] := All.Count;
    JObj.F['total'] := Total;
    Result := TMCPToolResult.Text(JObj.ToJSON);
  finally
    JObj.Free;
  end;
end;

end.
