﻿unit Aurora.Tools.Transmission;

interface

uses
  DextJsonDataObjects,
  System.SysUtils,
  System.IOUtils,
  Dext.Entity,
  Dext.AI.MCP.Tools,
  Dext.AI.MCP.Types,
  Dext.AI.MCP.Attributes,
  Aurora.Data.Context,
  Aurora.Domain.Entities,
  Aurora.Domain.Enums,
  Aurora.Session;

type
  // DECISÃO DE ESCOPO (não é limitação técnica): não existe integração ACBr
  // neste repositório, então tanto a regeneração do XML quanto a transmissão
  // à SEFAZ são fallback pré-computado. Nenhuma das duas tools abaixo faz
  // chamada de rede real ou usa qualquer biblioteca fiscal. O protocolo de
  // autorização (Fixtures/sefaz_authorization.json) é fixo — só o número do
  // documento é ajustado pro documento realmente em foco.
  TTransmissionTools = class(TMCPToolProvider)
  private
    FDb: TAuroraContext;
    FFixturesPath: string;
    function ResolveTargetDoc: TFiscalDocument;
  public
    constructor Create(ADb: TAuroraContext; const AFixturesPath: string);

    [MCPTool('regenerate_document', 'Regenera o XML da NFC-e com a configuração fiscal corrigida (mock)')]
    function RegenerateDocument(const Args: TJsonObject): TMCPToolResult;

    [MCPTool('transmit_document', 'Transmite a NFC-e à SEFAZ (fallback gravado, sem chamada de rede real)')]
    function TransmitDocument(const Args: TJsonObject): TMCPToolResult;
  end;

implementation

{ TTransmissionTools }

constructor TTransmissionTools.Create(ADb: TAuroraContext; const AFixturesPath: string);
begin
  inherited Create;
  FDb := ADb;
  FFixturesPath := AFixturesPath;
end;

function TTransmissionTools.ResolveTargetDoc: TFiscalDocument;
begin
  Result := nil;
  if TAuroraSession.CurrentDocumentNumber <> '' then
    Result := FDb.FiscalDocuments.FirstOrDefault(
      TFiscalDocument.Props.DocumentNumber = TAuroraSession.CurrentDocumentNumber);

  if Result = nil then
    Result := FDb.FiscalDocuments.FirstOrDefault(
      TFiscalDocument.Props.Status = TFiscalDocumentStatus.Rejected);
end;

function TTransmissionTools.RegenerateDocument(const Args: TJsonObject): TMCPToolResult;
var
  Doc: TFiscalDocument;
  Product: TProduct;
  NewXml: string;
  JObj: TJsonObject;
begin
  Doc := ResolveTargetDoc;
  if Doc = nil then
    Exit(TMCPToolResult.Error('Nenhuma NFC-e pendente de regeneração.'));

  Product := FDb.Products.FirstOrDefault(TProduct.Props.Id = Doc.ProductId);
  if Product = nil then
    Exit(TMCPToolResult.Error('Produto do documento não encontrado.'));

  // Mock genérico: monta um XML "corrigido" em memória citando a correção
  // já decidida no diagnóstico. Sem ACBr — decisão de escopo.
  NewXml := Format(
    '<NFe><infNFe><det nItem="1">' +
    '<prod><xProd>%s</xProd><CFOP>%s</CFOP></prod>' +
    '<correcaoAplicada>%s</correcaoAplicada>' +
    '</det></infNFe></NFe>',
    [string(Product.Name), string(Product.Cfop), string(Doc.CorrectionSummary)]);

  Doc.XmlContent := NewXml;
  FDb.SaveChanges;

  JObj := TJsonObject.Create;
  try
    JObj.S['documentNumber'] := string(Doc.DocumentNumber);
    JObj.B['regenerated'] := True;
    JObj.S['xml'] := NewXml;
    Result := TMCPToolResult.Text(JObj.ToJSON);
  finally
    JObj.Free;
  end;
end;

function TTransmissionTools.TransmitDocument(const Args: TJsonObject): TMCPToolResult;
var
  Doc: TFiscalDocument;
  Sale: TSale;
  FixtureJson: string;
  Fixture: TJsonObject;
begin
  Doc := ResolveTargetDoc;
  if Doc = nil then
    Exit(TMCPToolResult.Error('Nenhuma NFC-e pendente de transmissão.'));

  if not TFile.Exists(FFixturesPath) then
    Exit(TMCPToolResult.Error('Fixture de autorização não encontrada: ' + FFixturesPath));

  FixtureJson := TFile.ReadAllText(FFixturesPath, TEncoding.UTF8);
  Fixture := TJsonObject.Parse(FixtureJson) as TJsonObject;
  if Fixture = nil then
    Exit(TMCPToolResult.Error('Fixture de autorização inválida.'));
  try
    Doc.Status := TFiscalDocumentStatus.Authorized;

    // Reflete a autorização na venda também — é o que faz o badge da grid
    // (e o card de "problemas fiscais") virarem verde em tempo real.
    Sale := FDb.Sales.FirstOrDefault(TSale.Props.Id = Doc.SaleId);
    if Sale <> nil then
      Sale.HasFiscalIssue := False;

    FDb.SaveChanges;

    // O protocolo é fixo (fallback), mas o número do documento no retorno
    // precisa ser o do documento real em foco, não o valor fixo do fixture.
    Fixture.S['documentNumber'] := string(Doc.DocumentNumber);

    Result := TMCPToolResult.Text(Fixture.ToJSON);
  finally
    Fixture.Free;
  end;
end;

end.
