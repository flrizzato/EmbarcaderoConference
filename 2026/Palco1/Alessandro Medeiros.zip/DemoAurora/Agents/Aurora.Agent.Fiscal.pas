﻿unit Aurora.Agent.Fiscal;

interface

uses
  Dext.AI.Agent.Contracts,
  Dext.AI.Graph.Contracts,
  Dext.AI.Graph.State,
  Dext.AI.Graph.Graph,
  Dext.AI.Graph.Edge,
  Dext.AI.Graph.Node.LLM,
  Dext.AI.Graph.Node.Tools,
  Aurora.Data.Context,
  Aurora.Tools.Fiscal;

const
  // TCompiledAgent.RunAsSubgraph (o caminho que AsNode usa) NÃO injeta
  // Config.SystemPrompt como TCompiledAgent.Run injeta no primeiro turno —
  // isso só acontece para o grafo raiz. Por isso este texto entra como
  // mensagem de USUÁRIO via FiscalBriefHandler, não como Config.SystemPrompt
  // (que ficaria morto) nem como um segundo TLLMMessage.System (o provider
  // Anthropic monta o campo "system" com um AddPair por mensagem lrSystem,
  // duplicando a chave se houver mais de uma).
  FISCAL_BRIEF =
    'Você é um agente fiscal especializado em investigar NFC-e rejeitadas. ' +
    'Pode haver mais de uma nota rejeitada ao mesmo tempo, cada uma com uma ' +
    'causa diferente — você só pode investigar/corrigir UMA por vez. ' +
    'Se a mensagem do usuário citar um produto/nota específica, passe esse ' +
    'nome no parâmetro product_hint de locate_document; caso contrário ' +
    'deixe product_hint vazio. ' +
    'Se locate_document responder com "ambiguous": true, PARE imediatamente ' +
    '— não chame analyze_xml, analyze_sefaz_return nem query_product_tax_context. ' +
    'Sua única resposta deve ser listar os produtos de pendingDocuments e ' +
    'perguntar ao usuário qual deles ele quer investigar/resolver primeiro. ' +
    'Caso contrário (locate_document encontrou uma nota específica), use as ' +
    'outras três tools NESTA ORDEM: analyze_xml, analyze_sefaz_return, ' +
    'query_product_tax_context. Depois de ter chamado as quatro, responda em ' +
    'UMA frase objetiva com o diagnóstico (produto e causa raiz) e um nível ' +
    'de confiança. Nunca invente dados — use só o que as tools retornarem.';

// Compila o subgrafo fiscal como um ICompiledAgent independente (seu próprio
// TAgentGraph, seu próprio par call_llm/execute_tools). Não chame
// RequireApproval/InterruptBefore aqui: AsNode levantaria EGraphCompileError
// (aprovação humana aninhada não é suportada pelo framework).
function BuildFiscalAgent(
  AProvider:        ILLMProvider;
  const ABaseConfig: TAgentConfig;
  AObserver:        IAgentObserver;
  ADb:              TAuroraContext
): ICompiledAgent;

implementation

function FiscalBriefHandler(const AState: TAgentState; const ACtx: TNodeContext): TAgentState;
begin
  Writeln('[NÓ] fiscal_brief');
  Result := AState.WithMessage(TLLMMessage.User(FISCAL_BRIEF));
end;

function BuildFiscalAgent(
  AProvider: ILLMProvider;
  const ABaseConfig: TAgentConfig;
  AObserver: IAgentObserver;
  ADb: TAuroraContext
): ICompiledAgent;
var
  FiscalConfig: TAgentConfig;
  ToolsNode:    TToolsNode;
  LLMNode:      TLLMNode;
  Graph:        TAgentGraph;
begin
  FiscalConfig := ABaseConfig;

  ToolsNode := TToolsNode.Create;
  ToolsNode.RegisterProvider(TFiscalTools.Create(ADb));
  LLMNode := TLLMNode.Create(ToolsNode.GetToolSchemas);

  Graph := TAgentGraph.Create;
  try
    Result := Graph
      .AddNode('fiscal_brief', FiscalBriefHandler)
      .AddNode('call_llm', LLMNode.AsHandler)
      .AddNode('execute_tools', ToolsNode.AsHandler)
      .SetEntryPoint('fiscal_brief')
      .AddEdge('fiscal_brief', 'call_llm')
      .AddConditionalEdge('call_llm', DefaultShouldContinue,
        [TEdgeRoute.To_('execute_tools'), TEdgeRoute.ToEnd])
      .AddEdge('execute_tools', 'call_llm')
      .Compile(AProvider, FiscalConfig, AObserver, nil);
  finally
    Graph.Free;
  end;
end;

end.
