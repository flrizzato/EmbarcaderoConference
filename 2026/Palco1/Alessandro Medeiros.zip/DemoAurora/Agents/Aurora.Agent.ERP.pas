﻿unit Aurora.Agent.ERP;

interface

uses
  Winapi.Windows,
  System.SysUtils,
  DextJsonDataObjects,
  Vcl.Forms,
  Dext.AI.Agent.Contracts,
  Dext.AI.Graph.Contracts,
  Dext.AI.Graph.State,
  Dext.AI.Graph.Graph,
  Dext.AI.Graph.Edge,
  Dext.AI.Graph.Node.LLM,
  Dext.AI.Graph.Node.Tools,
  Dext.AI.MCP.Types,
  Aurora.Tools.Products,
  Aurora.Tools.Transmission,
  Aurora.Progress,
  Aurora.Session;

// Monta o TAgentGraph do ERP e o compila. Todas as dependências (tools node
// de vendas já com TSalesTools registrado, o subgrafo fiscal já compilado, os
// providers de tools de escrita) são recebidas prontas — esta função só faz
// a fiação do grafo, sem gerenciar ciclo de vida de nada.
function BuildErpAgent(
  AProvider:           ILLMProvider;
  const AConfig:       TAgentConfig;
  AObserver:           IAgentObserver;
  ASalesToolsNode:     TToolsNode;
  ASalesLLMNode:       TLLMNode;
  AProductsTools:      TProductsTools;
  ATransmissionTools:  TTransmissionTools;
  AFiscalAgent:        ICompiledAgent
): ICompiledAgent;

implementation

const
  INTENT_PROMPT =
    'Classifique a última mensagem do usuário em EXATAMENTE uma destas ' +
    'palavras, sem mais nada: consulta_status, investigar_fiscal, ' +
    'resolver_problema, investigar_e_resolver. ' +
    'consulta_status = perguntas gerais sobre vendas ou se há algum problema. ' +
    'investigar_fiscal = pedir para descobrir/investigar/explicar a causa de ' +
    'um problema fiscal, SEM pedir para corrigir. ' +
    'resolver_problema = pedir para resolver/corrigir/consertar um problema ' +
    'cuja causa já foi explicada antes na conversa. ' +
    'investigar_e_resolver = pedir, na mesma mensagem, tanto para ' +
    'investigar/explicar a causa quanto para corrigir/resolver o problema.';

  RISK_PROMPT =
    'Você é um classificador de risco de ações de um agente de ERP. Dado o ' +
    'diagnóstico fiscal abaixo, responda com EXATAMENTE uma palavra: "alto" ' +
    'se resolver o problema exigir alterar configuração fiscal e ' +
    'retransmitir um documento à SEFAZ, ou "baixo" caso contrário.';

// Espera "visível": dá a sensação de que a nota está realmente sendo
// corrigida/processada, em vez de tudo acontecer instantaneamente. Faz
// bombeamento de mensagens durante a espera pra UI não parecer travada e
// pra o texto de progresso (TAuroraProgress.Notify) já chamado antes disso
// aparecer na tela antes de continuar.
procedure ProcessingDelay(AMs: Integer);
var
  Elapsed: Integer;
begin
  Elapsed := 0;
  while Elapsed < AMs do
  begin
    Application.ProcessMessages;
    Sleep(50);
    Inc(Elapsed, 50);
  end;
end;

function ClassifyIntent(const AState: TAgentState; AProvider: ILLMProvider): string;
const
  MAX_CONTEXT_MSGS = 3;
var
  SafeMsgs:  TArray<TLLMMessage>;
  Msg:       TLLMMessage;
  Messages:  TArray<TLLMMessage>;
  Response:  TLLMResponse;
  Text:      string;
  I, Count:  Integer;
  FocusNote: string;
begin
  // Não usa o histórico inteiro: pode conter tool_use do subgrafo fiscal
  // sem o tool_result correspondente, o que a API rejeitaria. Mas usar só a
  // ÚLTIMA mensagem também não basta — uma resposta curta tipo "o Notebook"
  // (respondendo a uma pergunta de esclarecimento) não tem sinal nenhum
  // sozinha. Por isso inclui até as últimas 3 mensagens "seguras" (sem
  // tool_calls pendurado) como contexto, sempre terminando na atual.
  for Msg in AState.Messages do
    if (Msg.Role in [lrUser, lrAssistant]) and (Length(Msg.ToolCalls) = 0) then
    begin
      SetLength(SafeMsgs, Length(SafeMsgs) + 1);
      SafeMsgs[High(SafeMsgs)] := Msg;
    end;

  Count := Length(SafeMsgs);
  if Count > MAX_CONTEXT_MSGS then
  begin
    SafeMsgs := Copy(SafeMsgs, Count - MAX_CONTEXT_MSGS, MAX_CONTEXT_MSGS);
    Count := MAX_CONTEXT_MSGS;
  end;

  // Diz ao classificador qual produto está em foco (já diagnosticado) —
  // sem isso, "corrige o Cabo USB-C também" (um produto NOVO) seria
  // confundido com "resolver_problema" e reaproveitaria por engano o
  // diagnóstico antigo de outro produto.
  if TAuroraSession.CurrentProductName <> '' then
    FocusNote := Format(
      ' O produto atualmente em foco (já diagnosticado nesta conversa) é ' +
      '"%s". Se a mensagem citar um produto DIFERENTE deste (mesmo pedindo ' +
      'pra "resolver"/"corrigir"), classifique como investigar_e_resolver — ' +
      'é um problema novo, ainda sem diagnóstico. Só use resolver_problema ' +
      'se a mensagem não citar nenhum produto novo (ex: "consegue ' +
      'resolver?") ou citar exatamente o mesmo produto em foco.',
      [TAuroraSession.CurrentProductName])
  else
    FocusNote := '';

  SetLength(Messages, Count + 1);
  Messages[0] := TLLMMessage.System(INTENT_PROMPT + FocusNote);
  for I := 0 to Count - 1 do
    Messages[I + 1] := SafeMsgs[I];

  Response := AProvider.Complete(Messages, nil);
  Text := Response.Content.ToLower;

  // Checar a combinada ANTES das simples, já que uma resposta "ruidosa" do
  // modelo pode conter as palavras "investigar" e "resolver" juntas mesmo
  // quando a intenção real é só uma delas.
  if Text.Contains('investigar_e_resolver') then
    Result := 'investigar_e_resolver'
  else if Text.Contains('investigar_fiscal') then
    Result := 'investigar_fiscal'
  else if Text.Contains('resolver_problema') then
    Result := 'resolver_problema'
  else
    Result := 'consulta_status';
end;

function IntentAnalyzerHandler(const AState: TAgentState; const ACtx: TNodeContext): TAgentState;
var
  Intent: string;
begin
  Writeln('[NÓ] intent_analyzer');
  Intent := ClassifyIntent(AState, ACtx.Provider);
  Writeln('     intenção classificada: ' + Intent);
  Result := AState.WithMeta('intent', Intent);
end;

function IntentRouter(const AState: TAgentState): string;
var
  Intent:       string;
  HasDiagnosis: Boolean;
begin
  Intent := AState.GetMeta('intent', 'consulta_status');
  HasDiagnosis := (AState.GetMeta('fiscal_diagnosis', '') <> '')
    and (AState.GetMeta('diagnosis_ambiguous', 'false') <> 'true');

  if (Intent = 'investigar_fiscal') or (Intent = 'investigar_e_resolver') then
    Result := 'fiscal_subgraph'
  else if Intent = 'resolver_problema' then
  begin
    if HasDiagnosis then
      // Causa já explicada num turno anterior — vai direto pra análise de
      // risco/aprovação, sem reinvestigar.
      Result := 'risk_analyzer'
    else
      // "Resolve a nota do Notebook" sem ter investigado essa nota antes:
      // trata como investigar_e_resolver — passa pelo fiscal_subgraph
      // primeiro (locate_document usa o nome citado na própria mensagem
      // como product_hint) e só então segue pra aprovação.
      Result := 'fiscal_subgraph';
  end
  else
    Result := 'call_llm';
end;

function CaptureDiagnosisHandler(const AState: TAgentState; const ACtx: TNodeContext): TAgentState;
var
  Temp: TAgentState;
  AmbiguousStr: string;
begin
  Writeln('[NÓ] capture_diagnosis');
  if TAuroraSession.LastLocateWasAmbiguous then
  begin
    Writeln('     locate_document ficou ambíguo — não há diagnóstico real ainda');
    AmbiguousStr := 'true';
  end
  else
    AmbiguousStr := 'false';

  Temp := AState.WithMeta('fiscal_diagnosis', AState.FinalAnswer);
  try
    Result := Temp.WithMeta('diagnosis_ambiguous', AmbiguousStr);
  finally
    Temp.Free;
  end;
end;

// Entra em cena quando o pedido já incluía "e resolva" (investigar_e_resolver)
// OU quando "resolver_problema" caiu aqui por não ter diagnóstico prévio
// (IntentRouter redirecionou pro fiscal_subgraph nesse caso) — nos dois
// casos, deixa o grafo continuar direto pra análise de risco/aprovação, em
// vez de terminar o turno esperando uma segunda mensagem. Mas só avança se
// realmente houve um diagnóstico — se locate_document ficou ambíguo (mais
// de uma nota, nenhuma citada), a resposta é a pergunta de esclarecimento,
// e pedir aprovação nesse ponto não faria sentido.
function PostDiagnosisRouter(const AState: TAgentState): string;
var
  Intent: string;
begin
  Intent := AState.GetMeta('intent', '');
  if ((Intent = 'investigar_e_resolver') or (Intent = 'resolver_problema'))
    and (AState.GetMeta('diagnosis_ambiguous', 'false') <> 'true') then
    Result := 'risk_analyzer'
  else
    Result := GRAPH_END;
end;

function RiskAnalyzerHandler(const AState: TAgentState; const ACtx: TNodeContext): TAgentState;
var
  Diagnosis: string;
  Messages:  TArray<TLLMMessage>;
  Response:  TLLMResponse;
  Risk:      string;
begin
  Writeln('[NÓ] risk_analyzer');
  Diagnosis := AState.GetMeta('fiscal_diagnosis', '');

  SetLength(Messages, 2);
  Messages[0] := TLLMMessage.System(RISK_PROMPT);
  Messages[1] := TLLMMessage.User('Diagnóstico: ' + Diagnosis);
  Response := ACtx.Provider.Complete(Messages, nil);

  if Response.Content.ToLower.Contains('alto') then
    Risk := 'alto'
  else
    Risk := 'baixo';
  Writeln('     risco classificado: ' + Risk);

  Result := AState.WithMeta('risk_level', Risk);
end;

function NeedsApprovalCondition(const AState: TAgentState): string;
begin
  if AState.GetMeta('risk_level', 'baixo') = 'alto' then
    Result := 'approval_gate'
  else
    Result := GRAPH_END;
end;

function ApprovalGateHandler(const AState: TAgentState; const ACtx: TNodeContext): TAgentState;
begin
  // Só chega aqui depois de RequireApproval('approval_gate') ter sido
  // satisfeito (via ICompiledAgent.Resume) — nada a fazer além de prosseguir.
  Writeln('[NÓ] approval_gate (aprovado, prosseguindo)');
  Result := AState;
end;

function ValidateHandler(const AState: TAgentState; const ACtx: TNodeContext): TAgentState;
begin
  Writeln('[NÓ] validate');
  TAuroraProgress.Notify('Validando XML regenerado...');
  ProcessingDelay(800);

  if AState.GetMeta('xml_regenerated', '') = 'true' then
    Result := AState.WithMeta('xml_valid', 'true')
  else
    Result := AState.AsDone('Falha na validação do XML regenerado.');
end;

function BuildErpAgent(
  AProvider:          ILLMProvider;
  const AConfig:      TAgentConfig;
  AObserver:          IAgentObserver;
  ASalesToolsNode:    TToolsNode;
  ASalesLLMNode:      TLLMNode;
  AProductsTools:     TProductsTools;
  ATransmissionTools: TTransmissionTools;
  AFiscalAgent:       ICompiledAgent
): ICompiledAgent;
var
  Graph:                    TAgentGraph;
  UpdateTaxConfigHandler:    TNodeHandler;
  RegenerateDocumentHandler: TNodeHandler;
  TransmitDocumentHandler:   TNodeHandler;
begin
  UpdateTaxConfigHandler :=
    function(const AState: TAgentState; const ACtx: TNodeContext): TAgentState
    var
      EmptyArgs:  TJsonObject;
      ToolResult: TMCPToolResult;
    begin
      Writeln('[NÓ] update_tax_config');
      TAuroraProgress.Notify('Corrigindo configuração fiscal do produto...');
      ProcessingDelay(1100);

      EmptyArgs := TJsonObject.Create;
      try
        ToolResult := AProductsTools.UpdateTaxConfiguration(EmptyArgs);
      finally
        EmptyArgs.Free;
      end;

      if ToolResult.IsError then
        Result := AState.AsDone('Falha ao corrigir a configuração fiscal do produto.')
      else
        Result := AState.WithMeta('tax_config_updated', 'true');
    end;

  RegenerateDocumentHandler :=
    function(const AState: TAgentState; const ACtx: TNodeContext): TAgentState
    var
      EmptyArgs:  TJsonObject;
      ToolResult: TMCPToolResult;
    begin
      Writeln('[NÓ] regenerate_document');
      TAuroraProgress.Notify('Regenerando XML da NFC-e...');
      ProcessingDelay(1100);

      EmptyArgs := TJsonObject.Create;
      try
        ToolResult := ATransmissionTools.RegenerateDocument(EmptyArgs);
      finally
        EmptyArgs.Free;
      end;

      if ToolResult.IsError then
        Result := AState.AsDone('Falha ao regenerar o documento fiscal.')
      else
        Result := AState.WithMeta('xml_regenerated', 'true');
    end;

  TransmitDocumentHandler :=
    function(const AState: TAgentState; const ACtx: TNodeContext): TAgentState
    var
      EmptyArgs:  TJsonObject;
      ToolResult: TMCPToolResult;
      DocNumber:  string;
    begin
      Writeln('[NÓ] transmit_document');
      if AState.GetMeta('xml_valid', '') <> 'true' then
        Exit(AState.AsDone('Não foi possível transmitir: validação falhou.'));

      TAuroraProgress.Notify('Transmitindo à SEFAZ...');
      ProcessingDelay(1300);

      EmptyArgs := TJsonObject.Create;
      try
        ToolResult := ATransmissionTools.TransmitDocument(EmptyArgs);
      finally
        EmptyArgs.Free;
      end;

      if ToolResult.IsError then
        Exit(AState.AsDone('Falha na transmissão à SEFAZ.'));

      DocNumber := TAuroraSession.CurrentDocumentNumber;
      Result := AState.AsDone(
        Format('Problema resolvido. NFC-e %s autorizada pela SEFAZ.', [DocNumber]));
    end;

  Graph := TAgentGraph.Create;
  try
    Result := Graph
      .AddNode('intent_analyzer', IntentAnalyzerHandler)
      .AddNode('call_llm', ASalesLLMNode.AsHandler)
      .AddNode('execute_tools', ASalesToolsNode.AsHandler)
      .AddNode('fiscal_subgraph', AFiscalAgent.AsNode)
      .AddNode('capture_diagnosis', CaptureDiagnosisHandler)
      .AddNode('risk_analyzer', RiskAnalyzerHandler)
      .AddNode('approval_gate', ApprovalGateHandler, True)
      .AddNode('update_tax_config', UpdateTaxConfigHandler)
      .AddNode('regenerate_document', RegenerateDocumentHandler)
      .AddNode('validate', ValidateHandler)
      .AddNode('transmit_document', TransmitDocumentHandler)
      .SetEntryPoint('intent_analyzer')
      .AddConditionalEdge('intent_analyzer', IntentRouter,
        [TEdgeRoute.To_('call_llm'), TEdgeRoute.To_('fiscal_subgraph'),
         TEdgeRoute.To_('risk_analyzer')])
      .AddConditionalEdge('call_llm', DefaultShouldContinue,
        [TEdgeRoute.To_('execute_tools'), TEdgeRoute.ToEnd])
      .AddEdge('execute_tools', 'call_llm')
      .AddEdge('fiscal_subgraph', 'capture_diagnosis')
      .AddConditionalEdge('capture_diagnosis', PostDiagnosisRouter,
        [TEdgeRoute.To_('risk_analyzer'), TEdgeRoute.ToEnd])
      .AddConditionalEdge('risk_analyzer', NeedsApprovalCondition,
        [TEdgeRoute.To_('approval_gate'), TEdgeRoute.ToEnd])
      .AddEdge('approval_gate', 'update_tax_config')
      .AddEdge('update_tax_config', 'regenerate_document')
      .AddEdge('regenerate_document', 'validate')
      .AddEdge('validate', 'transmit_document')
      .Compile(AProvider, AConfig, AObserver, nil);
  finally
    Graph.Free;
  end;
end;

end.
