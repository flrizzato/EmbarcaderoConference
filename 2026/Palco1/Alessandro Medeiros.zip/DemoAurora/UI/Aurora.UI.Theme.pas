﻿unit Aurora.UI.Theme;

interface

uses
  Vcl.Graphics;

var
  // Paleta inspirada nas referências (Mindskills / Optivox): roxo de marca
  // para cabeçalho/destaque, verde para positivo, vermelho para alerta fiscal.
  // Calculadas via RGB() na inicialização (TColor não aceita RGB() em const).
  clBrandPurple:   TColor;
  clCardBg:        TColor;
  clAccentGreen:   TColor;
  clAccentRed:     TColor;
  clAccentRedSoft: TColor;
  clAccentTeal:    TColor;

implementation

uses
  Winapi.Windows;

initialization
  clBrandPurple   := RGB(75, 63, 145);
  clCardBg        := RGB(250, 247, 255);
  clAccentGreen   := RGB(39, 174, 96);
  clAccentRed     := RGB(231, 76, 60);
  clAccentRedSoft := RGB(253, 236, 234);
  clAccentTeal    := RGB(22, 160, 133);

end.
