﻿object MainForm: TMainForm
  Left = 0
  Top = 0
  Caption = 'Aurora ERP/PDV'
  ClientHeight = 640
  ClientWidth = 1200
  Color = clWhite
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  OnCreate = FormCreate
  OnResize = FormResize
  TextHeight = 15
  object HeaderPanel: TPanel
    Left = 0
    Top = 0
    Width = 1200
    Height = 68
    Align = alTop
    BevelOuter = bvNone
    Caption = ''
    TabOrder = 0
    object TitleLabel: TLabel
      Left = 24
      Top = 10
      Width = 100
      Height = 28
      Caption = 'AURORA'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -22
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object SubtitleLabel: TLabel
      Left = 26
      Top = 40
      Width = 300
      Height = 17
      Caption = 'ERP / PDV  —  Assistente de IA'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -12
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentFont = False
    end
  end
  object ContentPanel: TPanel
    Left = 0
    Top = 68
    Width = 1200
    Height = 572
    Align = alClient
    BevelOuter = bvNone
    Caption = ''
    TabOrder = 1
    object AssistantHost: TPanel
      Left = 820
      Top = 0
      Width = 380
      Height = 572
      Align = alRight
      BevelOuter = bvNone
      Caption = ''
      TabOrder = 0
    end
    object SalesPanel: TPanel
      Left = 0
      Top = 0
      Width = 820
      Height = 572
      Align = alClient
      BevelOuter = bvNone
      Caption = ''
      TabOrder = 1
      object StatsPanel: TPanel
        Left = 0
        Top = 0
        Width = 820
        Height = 104
        Align = alTop
        BevelOuter = bvNone
        Caption = ''
        TabOrder = 0
        object CardTotalSales: TPanel
          Left = 16
          Top = 12
          Width = 250
          Height = 80
          BevelOuter = bvNone
          Caption = ''
          TabOrder = 0
          object LblCardTotalSalesValue: TLabel
            Left = 16
            Top = 10
            Width = 30
            Height = 32
            Caption = '0'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Segoe UI'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object LblCardTotalSalesCaption: TLabel
            Left = 16
            Top = 48
            Width = 100
            Height = 15
            Caption = 'VENDAS HOJE'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clGrayText
            Font.Height = -11
            Font.Name = 'Segoe UI'
            Font.Style = [fsBold]
            ParentFont = False
          end
        end
        object CardTotalValue: TPanel
          Left = 282
          Top = 12
          Width = 250
          Height = 80
          BevelOuter = bvNone
          Caption = ''
          TabOrder = 1
          object LblCardTotalValueValue: TLabel
            Left = 16
            Top = 10
            Width = 60
            Height = 32
            Caption = 'R$ 0'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Segoe UI'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object LblCardTotalValueCaption: TLabel
            Left = 16
            Top = 48
            Width = 130
            Height = 15
            Caption = 'FATURAMENTO DO DIA'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clGrayText
            Font.Height = -11
            Font.Name = 'Segoe UI'
            Font.Style = [fsBold]
            ParentFont = False
          end
        end
        object CardIssues: TPanel
          Left = 548
          Top = 12
          Width = 250
          Height = 80
          BevelOuter = bvNone
          Caption = ''
          TabOrder = 2
          object LblCardIssuesValue: TLabel
            Left = 16
            Top = 10
            Width = 30
            Height = 32
            Caption = '0'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Segoe UI'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object LblCardIssuesCaption: TLabel
            Left = 16
            Top = 48
            Width = 140
            Height = 15
            Caption = 'PROBLEMAS FISCAIS'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clGrayText
            Font.Height = -11
            Font.Name = 'Segoe UI'
            Font.Style = [fsBold]
            ParentFont = False
          end
        end
      end
      object SalesGrid: TStringGrid
        Left = 0
        Top = 104
        Width = 820
        Height = 468
        Align = alClient
        DefaultDrawing = False
        FixedCols = 0
        RowCount = 2
        FixedRows = 1
        TabOrder = 1
        OnDrawCell = SalesGridDrawCell
      end
    end
  end
end
