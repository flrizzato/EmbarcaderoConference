﻿object AssistantPanelFrame: TAssistantPanelFrame
  Left = 0
  Top = 0
  Width = 380
  Height = 600
  TabOrder = 0
  object HeaderPanel: TPanel
    Left = 0
    Top = 0
    Width = 380
    Height = 44
    Align = alTop
    BevelOuter = bvNone
    Caption = ''
    TabOrder = 0
    object TitleLabel: TLabel
      Left = 16
      Top = 12
      Width = 200
      Height = 20
      Caption = 'ASSISTENTE DE IA'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -14
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
  end
  object OutputMemo: TRichEdit
    Left = 0
    Top = 44
    Width = 380
    Height = 516
    Align = alClient
    BorderStyle = bsNone
    Color = clWhitesmoke
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -12
    Font.Name = 'Segoe UI'
    Font.Style = []
    ParentFont = False
    ReadOnly = True
    ScrollBars = ssVertical
    TabOrder = 1
    Zoom = 100
  end
  object InputPanel: TPanel
    Left = 0
    Top = 560
    Width = 380
    Height = 40
    Align = alBottom
    BevelOuter = bvNone
    TabOrder = 2
    object InputEdit: TEdit
      Left = 0
      Top = 4
      Width = 300
      Height = 30
      Align = alClient
      TabOrder = 0
      OnKeyPress = InputEditKeyPress
    end
    object SendButton: TButton
      Left = 300
      Top = 4
      Width = 80
      Height = 30
      Align = alRight
      Caption = 'Enviar'
      TabOrder = 1
      OnClick = SendButtonClick
    end
  end
  object PendingPanel: TPanel
    Left = 0
    Top = 350
    Width = 380
    Height = 210
    Align = alBottom
    BevelOuter = bvNone
    Caption = ''
    TabOrder = 3
    Visible = False
    object PendingLabel: TLabel
      Left = 16
      Top = 12
      Width = 348
      Height = 130
      AutoSize = False
      WordWrap = True
      Caption = 'Requer autorização.'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -12
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentFont = False
    end
    object ApproveBtnPanel: TPanel
      Left = 16
      Top = 152
      Width = 168
      Height = 44
      BevelOuter = bvNone
      Caption = ''
      Cursor = crHandPoint
      TabOrder = 0
      OnClick = ApproveClick
      object ApproveBtnLabel: TLabel
        Left = 0
        Top = 0
        Width = 168
        Height = 44
        Align = alClient
        Alignment = taCenter
        Layout = tlCenter
        Caption = '✓  Aprovar'
        Cursor = crHandPoint
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWhite
        Font.Height = -14
        Font.Name = 'Segoe UI'
        Font.Style = [fsBold]
        ParentFont = False
        OnClick = ApproveClick
      end
    end
    object RejectBtnPanel: TPanel
      Left = 196
      Top = 152
      Width = 168
      Height = 44
      BevelOuter = bvNone
      Caption = ''
      Cursor = crHandPoint
      TabOrder = 1
      OnClick = RejectClick
      object RejectBtnLabel: TLabel
        Left = 0
        Top = 0
        Width = 168
        Height = 44
        Align = alClient
        Alignment = taCenter
        Layout = tlCenter
        Caption = '✕  Rejeitar'
        Cursor = crHandPoint
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -14
        Font.Name = 'Segoe UI'
        Font.Style = [fsBold]
        ParentFont = False
        OnClick = RejectClick
      end
    end
  end
end
