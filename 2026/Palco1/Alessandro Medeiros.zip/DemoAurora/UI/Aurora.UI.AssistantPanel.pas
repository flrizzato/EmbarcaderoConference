﻿unit Aurora.UI.AssistantPanel;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Classes,
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls,
  Vcl.ExtCtrls, Vcl.ComCtrls,
  Dext.AI.Graph.Contracts,
  Dext.AI.Graph.State,
  Aurora.App.Startup,
  Aurora.Progress,
  Aurora.UI.Theme;

type
  TAssistantPanelFrame = class(TFrame)
    HeaderPanel: TPanel;
    TitleLabel: TLabel;
    OutputMemo: TRichEdit;
    PendingPanel: TPanel;
    PendingLabel: TLabel;
    ApproveBtnPanel: TPanel;
    ApproveBtnLabel: TLabel;
    RejectBtnPanel: TPanel;
    RejectBtnLabel: TLabel;
    InputPanel: TPanel;
    InputEdit: TEdit;
    SendButton: TButton;
    procedure SendButtonClick(Sender: TObject);
    procedure InputEditKeyPress(Sender: TObject; var Key: Char);
    procedure ApproveClick(Sender: TObject);
    procedure RejectClick(Sender: TObject);
  private
    FThreadId:         string;
    FAwaitingApproval: Boolean;
    FOnDataChanged:    TNotifyEvent;
    procedure AppendLine(const APrefix: string; APrefixColor: TColor;
      const AText: string; ATextColor: TColor; AItalic: Boolean = False);
    procedure LogUser(const AText: string);
    procedure LogAurora(const AText: string);
    procedure LogSystem(const AText: string);
    procedure LogError(const AText: string);
    procedure ShowPendingActions(const AMessage: string);
    procedure HidePendingActions;
    procedure UpdateInputEnabled;
    procedure NotifyDataChanged;
    procedure HandleProgress(const AMessage: string);
    procedure HandleRunResult(const AResult: TGraphRunResult);
    procedure SendMessage(const AText: string);
  public
    constructor Create(AOwner: TComponent); override;
    // Disparado depois de cada turno que pode ter mudado dados no banco
    // (venda/produto/documento fiscal) — é isso que faz a grid do MainForm
    // e os cards de KPI atualizarem em tempo real, sem precisar dar F5.
    property OnDataChanged: TNotifyEvent read FOnDataChanged write FOnDataChanged;
  end;

implementation

{$R *.dfm}

constructor TAssistantPanelFrame.Create(AOwner: TComponent);
var
  ProgressProc: TProc<string>;
begin
  inherited Create(AOwner);
  FThreadId := 'aurora-demo-session';

  HeaderPanel.Color := clAccentTeal;
  OutputMemo.Font.Name := 'Segoe UI';
  OutputMemo.Font.Size := 10;

  PendingPanel.Color := clAccentRedSoft;
  ApproveBtnPanel.Color := clAccentGreen;
  RejectBtnPanel.Color := clSilver;
  PendingPanel.Visible := False;

  ProgressProc :=
    procedure(AMessage: string)
    begin
      HandleProgress(AMessage);
    end;
  TAuroraProgress.OnProgress := ProgressProc;
end;

procedure TAssistantPanelFrame.HandleProgress(const AMessage: string);
begin
  LogSystem(AMessage);
  Application.ProcessMessages;
end;

procedure TAssistantPanelFrame.AppendLine(const APrefix: string; APrefixColor: TColor;
  const AText: string; ATextColor: TColor; AItalic: Boolean);
begin
  OutputMemo.SelStart := OutputMemo.GetTextLen;
  OutputMemo.SelLength := 0;

  if APrefix <> '' then
  begin
    OutputMemo.SelAttributes.Color := APrefixColor;
    OutputMemo.SelAttributes.Style := [fsBold];
    OutputMemo.SelText := APrefix + ': ';
  end;

  OutputMemo.SelAttributes.Color := ATextColor;
  if AItalic then
    OutputMemo.SelAttributes.Style := [fsItalic]
  else
    OutputMemo.SelAttributes.Style := [];
  OutputMemo.SelText := AText + sLineBreak;

  OutputMemo.SelStart := OutputMemo.GetTextLen;
  OutputMemo.Perform(EM_SCROLLCARET, 0, 0);
end;

procedure TAssistantPanelFrame.LogUser(const AText: string);
begin
  AppendLine('Você', clWindowText, AText, clWindowText);
end;

procedure TAssistantPanelFrame.LogAurora(const AText: string);
begin
  AppendLine('Aurora', clAccentTeal, AText, clWindowText);
end;

procedure TAssistantPanelFrame.LogSystem(const AText: string);
begin
  AppendLine('', clGrayText, AText, clGrayText, True);
end;

procedure TAssistantPanelFrame.LogError(const AText: string);
begin
  AppendLine('Aurora', clAccentRed, AText, clAccentRed);
end;

procedure TAssistantPanelFrame.ShowPendingActions(const AMessage: string);
begin
  FAwaitingApproval := True;
  PendingLabel.Caption := AMessage;
  PendingPanel.Visible := True;
  UpdateInputEnabled;
end;

procedure TAssistantPanelFrame.HidePendingActions;
begin
  FAwaitingApproval := False;
  PendingPanel.Visible := False;
  UpdateInputEnabled;
end;

procedure TAssistantPanelFrame.UpdateInputEnabled;
begin
  SendButton.Enabled := not FAwaitingApproval;
  InputEdit.Enabled := not FAwaitingApproval;
end;

procedure TAssistantPanelFrame.NotifyDataChanged;
begin
  if Assigned(FOnDataChanged) then
    FOnDataChanged(Self);
end;

procedure TAssistantPanelFrame.HandleRunResult(const AResult: TGraphRunResult);
var
  Message:   string;
  Diagnosis: string;
  State:     TAgentState;
begin
  case AResult.Status of
    grsFinished:
      LogAurora(AResult.FinalAnswer);

    grsWaitingApproval:
    begin
      if AResult.PendingNode = 'approval_gate' then
        Message := 'Alterar configuração fiscal do produto, regenerar e retransmitir. Requer autorização.'
      else
        Message := AResult.PendingAction;

      // Quando o pedido combinou "investigar e resolver" num turno só, o
      // diagnóstico nunca chegou a virar uma resposta própria — sem isso,
      // o card de aprovação apareceria "do nada", sem explicar o motivo.
      Diagnosis := '';
      State := TAuroraStartup.GetErpAgent.GetState(FThreadId) as TAgentState;
      if State <> nil then
        Diagnosis := State.GetMeta('fiscal_diagnosis', '');

      if Diagnosis <> '' then
        Message := Diagnosis + sLineBreak + sLineBreak + Message;

      LogSystem('aguardando aprovação...');
      ShowPendingActions(Message);
    end;

    grsError:
      LogError('erro — ' + AResult.ErrorMsg);
  end;
end;

procedure TAssistantPanelFrame.SendMessage(const AText: string);
begin
  if AText.Trim = '' then
    Exit;

  LogUser(AText);

  // Run() é uma chamada HTTP síncrona (até ~120s de timeout) na thread da UI —
  // sem isso a janela parece travada durante a espera.
  SendButton.Enabled := False;
  InputEdit.Enabled := False;
  LogSystem('pensando...');
  Application.ProcessMessages;
  try
    HandleRunResult(TAuroraStartup.GetErpAgent.Run(AText, FThreadId));
  finally
    UpdateInputEnabled;
    NotifyDataChanged;
  end;
end;

procedure TAssistantPanelFrame.ApproveClick(Sender: TObject);
begin
  HidePendingActions;
  LogSystem('aprovado pelo usuário.');

  SendButton.Enabled := False;
  InputEdit.Enabled := False;
  LogSystem('processando...');
  Application.ProcessMessages;
  try
    HandleRunResult(TAuroraStartup.GetErpAgent.Resume(FThreadId));
  finally
    UpdateInputEnabled;
    NotifyDataChanged;
  end;
end;

procedure TAssistantPanelFrame.RejectClick(Sender: TObject);
begin
  HidePendingActions;
  LogSystem('rejeitado pelo usuário.');
  TAuroraStartup.GetErpAgent.Cancel(FThreadId);
  UpdateInputEnabled;
  NotifyDataChanged;
end;

procedure TAssistantPanelFrame.SendButtonClick(Sender: TObject);
begin
  SendMessage(InputEdit.Text);
  InputEdit.Text := '';
end;

procedure TAssistantPanelFrame.InputEditKeyPress(Sender: TObject; var Key: Char);
begin
  if Key = #13 then
  begin
    Key := #0;
    SendButtonClick(SendButton);
  end;
end;

end.
