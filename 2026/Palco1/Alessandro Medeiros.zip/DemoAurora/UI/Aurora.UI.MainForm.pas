﻿unit Aurora.UI.MainForm;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Classes,
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.Grids,
  Vcl.ExtCtrls, Vcl.StdCtrls,
  Dext.Entity, Dext.Collections,
  Aurora.App.Startup,
  Aurora.Data.Context,
  Aurora.Domain.Entities,
  Aurora.UI.Theme,
  Aurora.UI.AssistantPanel;

type
  TMainForm = class(TForm)
    HeaderPanel: TPanel;
    TitleLabel: TLabel;
    SubtitleLabel: TLabel;
    ContentPanel: TPanel;
    SalesPanel: TPanel;
    StatsPanel: TPanel;
    CardTotalSales: TPanel;
    CardTotalValue: TPanel;
    CardIssues: TPanel;
    LblCardTotalSalesValue: TLabel;
    LblCardTotalSalesCaption: TLabel;
    LblCardTotalValueValue: TLabel;
    LblCardTotalValueCaption: TLabel;
    LblCardIssuesValue: TLabel;
    LblCardIssuesCaption: TLabel;
    SalesGrid: TStringGrid;
    AssistantHost: TPanel;
    procedure FormCreate(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure SalesGridDrawCell(Sender: TObject; ACol, ARow: Integer;
      Rect: TRect; State: TGridDrawState);
  private
    FSales:          IList<TSale>;
    FAssistantPanel: TAssistantPanelFrame;
    procedure LoadSales;
    procedure AssistantDataChanged(Sender: TObject);
    procedure ResizeGridColumns;
    procedure DrawPillBadge(const ARect: TRect; const AText: string; ABg, AFg: TColor);
  end;

var
  MainForm: TMainForm;

implementation

{$R *.dfm}

procedure TMainForm.FormCreate(Sender: TObject);
begin
  Caption := 'Aurora ERP/PDV — legado com Assistente de IA';

  HeaderPanel.Color := clBrandPurple;
  ContentPanel.Color := clWhite;
  StatsPanel.Color := clWhite;
  CardTotalSales.Color := clCardBg;
  CardTotalValue.Color := clCardBg;
  CardIssues.Color := clCardBg;
  LblCardTotalSalesValue.Font.Color := clBrandPurple;
  LblCardTotalValueValue.Font.Color := clBrandPurple;
  AssistantHost.Color := clCardBg;

  FAssistantPanel := TAssistantPanelFrame.Create(Self);
  FAssistantPanel.Parent := AssistantHost;
  FAssistantPanel.Align := alClient;
  FAssistantPanel.OnDataChanged := AssistantDataChanged;

  SalesGrid.ColCount := 4;
  SalesGrid.RowCount := 2;
  SalesGrid.DefaultRowHeight := 40;
  SalesGrid.Cells[0, 0] := 'VENDA';
  SalesGrid.Cells[1, 0] := 'PRODUTO';
  SalesGrid.Cells[2, 0] := 'TOTAL';
  SalesGrid.Cells[3, 0] := 'STATUS FISCAL';
  ResizeGridColumns;

  LoadSales;
end;

procedure TMainForm.FormResize(Sender: TObject);
begin
  ResizeGridColumns;
end;

procedure TMainForm.ResizeGridColumns;
var
  TotalW: Integer;
begin
  // Larguras proporcionais, não fixas em pixels — a resolução do telão
  // amanhã pode ser diferente da tela usada no ensaio.
  TotalW := SalesGrid.ClientWidth;
  if TotalW < 200 then
    Exit;

  SalesGrid.ColWidths[0] := Round(TotalW * 0.14);
  SalesGrid.ColWidths[2] := Round(TotalW * 0.16);
  SalesGrid.ColWidths[3] := Round(TotalW * 0.20);
  SalesGrid.ColWidths[1] := TotalW - SalesGrid.ColWidths[0]
    - SalesGrid.ColWidths[2] - SalesGrid.ColWidths[3] - 4;
end;

procedure TMainForm.LoadSales;
var
  Sale:        TSale;
  Product:     TProduct;
  I:           Integer;
  TotalValue:  Currency;
  IssueCount:  Integer;
begin
  FSales := TAuroraStartup.GetDb.Sales.QueryAll.ToList;
  SalesGrid.RowCount := FSales.Count + 1;

  TotalValue := 0;
  IssueCount := 0;

  for I := 0 to FSales.Count - 1 do
  begin
    Sale := FSales[I];
    Product := TAuroraStartup.GetDb.Products.FirstOrDefault(TProduct.Props.Id = Sale.ProductId);

    SalesGrid.Cells[0, I + 1] := string(Sale.SaleNumber);
    if Product <> nil then
      SalesGrid.Cells[1, I + 1] := string(Product.Name);
    SalesGrid.Cells[2, I + 1] := 'R$ ' + CurrToStr(Currency(Sale.Total));

    TotalValue := TotalValue + Currency(Sale.Total);
    if Sale.HasFiscalIssue then
      Inc(IssueCount);
  end;

  LblCardTotalSalesValue.Caption := IntToStr(FSales.Count);
  LblCardTotalValueValue.Caption := 'R$ ' + CurrToStr(TotalValue);
  LblCardIssuesValue.Caption := IntToStr(IssueCount);

  if IssueCount > 0 then
    LblCardIssuesValue.Font.Color := clAccentRed
  else
    LblCardIssuesValue.Font.Color := clAccentGreen;
end;

procedure TMainForm.AssistantDataChanged(Sender: TObject);
begin
  // O agente pode ter corrigido o produto/documento fiscal no banco durante
  // o turno — recarrega vendas + KPIs e força o redesenho da grid, sem
  // precisar de F5. É isso que faz a linha vermelha virar verde ao vivo.
  LoadSales;
  SalesGrid.Invalidate;
end;

procedure TMainForm.DrawPillBadge(const ARect: TRect; const AText: string; ABg, AFg: TColor);
var
  PillRect: TRect;
  TextSize: TSize;
begin
  PillRect := ARect;
  InflateRect(PillRect, -6, -6);

  SalesGrid.Canvas.Brush.Color := ABg;
  SalesGrid.Canvas.Pen.Color := ABg;
  SalesGrid.Canvas.RoundRect(PillRect.Left, PillRect.Top, PillRect.Right, PillRect.Bottom, 14, 14);

  SalesGrid.Canvas.Font.Color := AFg;
  SalesGrid.Canvas.Font.Style := [fsBold];
  SalesGrid.Canvas.Brush.Style := bsClear;
  TextSize := SalesGrid.Canvas.TextExtent(AText);
  SalesGrid.Canvas.TextOut(
    PillRect.Left + (PillRect.Width - TextSize.cx) div 2,
    PillRect.Top + (PillRect.Height - TextSize.cy) div 2,
    AText);
  SalesGrid.Canvas.Brush.Style := bsSolid;
  SalesGrid.Canvas.Font.Style := [];
end;

procedure TMainForm.SalesGridDrawCell(Sender: TObject; ACol, ARow: Integer;
  Rect: TRect; State: TGridDrawState);
var
  Sale: TSale;
begin
  // Cabeçalho: barra roxa de marca com texto branco em negrito.
  if ARow = 0 then
  begin
    SalesGrid.Canvas.Brush.Color := clBrandPurple;
    SalesGrid.Canvas.FillRect(Rect);
    SalesGrid.Canvas.Font.Color := clWhite;
    SalesGrid.Canvas.Font.Style := [fsBold];
    SalesGrid.Canvas.TextOut(Rect.Left + 12,
      Rect.Top + (Rect.Height - SalesGrid.Canvas.TextHeight(SalesGrid.Cells[ACol, ARow])) div 2,
      SalesGrid.Cells[ACol, ARow]);
    SalesGrid.Canvas.Font.Style := [];
    Exit;
  end;

  if (ARow - 1 < FSales.Count) and (FSales[ARow - 1].HasFiscalIssue) then
    SalesGrid.Canvas.Brush.Color := clAccentRedSoft
  else
    SalesGrid.Canvas.Brush.Color := clWindow;
  SalesGrid.Canvas.FillRect(Rect);
  SalesGrid.Canvas.Font.Color := clWindowText;

  if (ACol = 3) and (ARow - 1 < FSales.Count) then
  begin
    Sale := FSales[ARow - 1];
    if Sale.HasFiscalIssue then
      DrawPillBadge(Rect, 'REJEITADA', clAccentRed, clWhite)
    else
      DrawPillBadge(Rect, 'OK', clAccentGreen, clWhite);
    Exit;
  end;

  SalesGrid.Canvas.TextOut(Rect.Left + 12,
    Rect.Top + (Rect.Height - SalesGrid.Canvas.TextHeight(SalesGrid.Cells[ACol, ARow])) div 2,
    SalesGrid.Cells[ACol, ARow]);
end;

end.
