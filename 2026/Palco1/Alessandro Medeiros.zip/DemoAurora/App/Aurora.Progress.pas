﻿unit Aurora.Progress;

interface

uses
  System.SysUtils;

type
  // Deixa os node handlers do grafo (Aurora.Agent.ERP) narrarem o
  // processamento pós-aprovação no chat, sem criar dependência circular
  // com Aurora.UI.AssistantPanel (que é quem assina OnProgress).
  TAuroraProgress = class
  public
    class var OnProgress: TProc<string>;
    class procedure Notify(const AMessage: string);
  end;

implementation

class procedure TAuroraProgress.Notify(const AMessage: string);
begin
  if Assigned(OnProgress) then
    OnProgress(AMessage);
end;

end.
