﻿unit Aurora.Session;

interface

type
  // Lembra qual documento fiscal está "em foco" na investigação atual, pra
  // que update_tax_configuration/regenerate_document/transmit_document
  // (chamados pelo pipeline fixo pós-aprovação, sem argumentos) saibam qual
  // dos vários documentos rejeitados corrigir — sem isso, com mais de uma
  // nota rejeitada ao mesmo tempo, eles sempre pegariam a primeira.
  TAuroraSession = class
  public
    class var CurrentDocumentNumber: string;
    // Nome do produto do documento em foco — usado só pra dar contexto ao
    // classificador de intenção ("o foco atual é X; se a mensagem citar um
    // produto diferente, é um pedido novo, não continuação").
    class var CurrentProductName: string;
    // True quando locate_document não conseguiu escolher uma nota sozinho
    // (mais de uma rejeitada, nenhuma citada pelo usuário) — o grafo do ERP
    // usa isso pra não avançar pra aprovação sem um alvo real.
    class var LastLocateWasAmbiguous: Boolean;
  end;

implementation

end.
