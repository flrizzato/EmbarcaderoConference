﻿unit Aurora.App.Startup;

interface

uses
  System.SysUtils,
  System.IOUtils,
  Dext, Dext.DI.Interfaces,
  Dext.Entity,
  Dext.AI.Agent.Contracts,
  Dext.AI.Agent.Factory,
  Dext.AI.Agent.Observer,
  Dext.AI.Graph.Contracts,
  Dext.AI.Graph.Node.LLM,
  Dext.AI.Graph.Node.Tools,
  Aurora.Data.Context,
  Aurora.Data.Seeder,
  Aurora.Tools.Sales,
  Aurora.Tools.Products,
  Aurora.Tools.Transmission,
  Aurora.Agent.Fiscal,
  Aurora.Agent.ERP;

type
  TAuroraStartup = class
  private
    class var FServices:          TDextServices;
    class var FProvider:          IServiceProvider;
    class var FScope:              IServiceScope;
    class var FDb:                 TAuroraContext;
    class var FLLMProvider:        ILLMProvider;
    class var FObserver:           IAgentObserver;
    class var FSalesToolsNode:     TToolsNode;
    class var FSalesLLMNode:       TLLMNode;
    class var FProductsTools:      TProductsTools;
    class var FTransmissionTools:  TTransmissionTools;
    class var FFiscalAgent:        ICompiledAgent;
    class var FErpAgent:           ICompiledAgent;

    class procedure ConfigureDatabase(Options: TDbContextOptions);
    class function  FixturesPath: string;
  public
    class procedure Configure;
    class procedure Shutdown;

    class function GetErpAgent: ICompiledAgent;
    class function GetDb: TAuroraContext;
  end;

implementation

{ TAuroraStartup }

class procedure TAuroraStartup.ConfigureDatabase(Options: TDbContextOptions);
begin
  Options.UseSQLite('aurora_seed.sqlite');
end;

class function TAuroraStartup.FixturesPath: string;
begin
  Result := TPath.Combine(ExtractFilePath(ParamStr(0)), 'Fixtures' + PathDelim + 'sefaz_authorization.json');
end;

class procedure TAuroraStartup.Configure;
var
  Config: TAgentConfig;
begin
  FServices := TDextServices.New;
  FServices.AddDbContext<TAuroraContext>(ConfigureDatabase);
  FProvider := FServices.BuildServiceProvider;

  FScope := FProvider.CreateScope;
  FDb := FScope.ServiceProvider.GetService(TAuroraContext) as TAuroraContext;

  TAuroraSeeder.Seed(FProvider);

  Config := TAgentConfig.OpenAI('gpt-4o');
  Config.ApiKey := GetEnvironmentVariable('OPENAI_API_KEY');
  Config.SystemPrompt :=
    'Você é o assistente de IA de um ERP/PDV. Use as tools disponíveis para ' +
    'responder sobre vendas e problemas fiscais do dia. Nunca invente dados — ' +
    'use só o que as tools retornarem.';

  if Config.ApiKey = '' then
    raise ELLMProviderError.Create('Defina a variável de ambiente OPENAI_API_KEY.');

  FLLMProvider := TLLMFactory.CreateProvider(Config);
  FObserver    := TConsoleObserver.Create;

  FSalesToolsNode := TToolsNode.Create;
  FSalesToolsNode.RegisterProvider(TSalesTools.Create(FDb));
  FSalesLLMNode := TLLMNode.Create(FSalesToolsNode.GetToolSchemas);

  FProductsTools     := TProductsTools.Create(FDb);
  FTransmissionTools := TTransmissionTools.Create(FDb, FixturesPath);

  FFiscalAgent := BuildFiscalAgent(FLLMProvider, Config, FObserver, FDb);

  FErpAgent := BuildErpAgent(
    FLLMProvider, Config, FObserver,
    FSalesToolsNode, FSalesLLMNode,
    FProductsTools, FTransmissionTools,
    FFiscalAgent);
end;

class procedure TAuroraStartup.Shutdown;
begin
  FErpAgent    := nil;
  FFiscalAgent := nil;

  FreeAndNil(FProductsTools);
  FreeAndNil(FTransmissionTools);
  FreeAndNil(FSalesLLMNode);
  FreeAndNil(FSalesToolsNode);

  FLLMProvider := nil;
  FObserver    := nil;

  FDb    := nil;
  FScope := nil;
  FProvider := nil;
  FServices := Default(TDextServices);
end;

class function TAuroraStartup.GetErpAgent: ICompiledAgent;
begin
  Result := FErpAgent;
end;

class function TAuroraStartup.GetDb: TAuroraContext;
begin
  Result := FDb;
end;

end.
