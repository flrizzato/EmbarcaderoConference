﻿unit Unit1;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants,
  FMX.Types, FMX.Controls, FMX.Forms, FMX.Graphics, FMX.Dialogs,
  FMX.Objects, FMX.StdCtrls, FMX.Layouts;

type
  TForm1 = class(TForm)
  private
    FSidebar: TLayout;
    FContent: TLayout;
    FMenuButton: TButton;
    procedure FormResize(Sender: TObject);
    procedure MenuClick(Sender: TObject);
    procedure StartRunClick(Sender: TObject);
    procedure ViewHistoryClick(Sender: TObject);
    procedure BuildInterface;
    procedure ConfigureText(const AText: TText; const ASize: Single;
      const AColor: TAlphaColor; const AStyle: TFontStyles = []);
    function AddText(AParent: TFmxObject; const AText: string;
      const ASize: Single; const AColor: TAlphaColor; AX, AY, AW, AH: Single;
      const AStyle: TFontStyles = []): TText;
    function AddCard(AParent: TFmxObject; AX, AY, AW, AH: Single;
      const AColor: TAlphaColor): TRectangle;
    procedure AddMetric(AParent: TFmxObject; AX, AY: Single; const AValue,
      ALabel: string; const AAccent: TAlphaColor);
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  Form1: TForm1;

implementation

{$R *.fmx}

const
  CInk = $FF102A43;
  CMuted = $FF6B8299;
  CBlue = $FF1677FF;
  CTeal = $FF00B8A9;
  COrange = $FFFFA62B;
  CCloud = $FFF4F7FB;
  CLine = $FFE3EAF2;
  CWhite = $FFFFFFFF;

constructor TForm1.Create(AOwner: TComponent);
begin
  inherited;
  Caption := 'KAI Runner';
  Fill.Color := CCloud;
  OnResize := FormResize;
  BuildInterface;
end;

procedure TForm1.ConfigureText(const AText: TText; const ASize: Single;
  const AColor: TAlphaColor; const AStyle: TFontStyles);
begin
  AText.TextSettings.Font.Size := ASize;
  AText.TextSettings.Font.Style := AStyle;
  AText.TextSettings.FontColor := AColor;
  AText.TextSettings.HorzAlign := TTextAlign.Leading;
  AText.TextSettings.VertAlign := TTextAlign.Center;
  AText.WordWrap := False;
end;

function TForm1.AddText(AParent: TFmxObject; const AText: string;
  const ASize: Single; const AColor: TAlphaColor; AX, AY, AW, AH: Single;
  const AStyle: TFontStyles): TText;
begin
  Result := TText.Create(AParent);
  Result.Parent := AParent;
  Result.Position.X := AX;
  Result.Position.Y := AY;
  Result.Width := AW;
  Result.Height := AH;
  Result.Text := AText;
  ConfigureText(Result, ASize, AColor, AStyle);
end;

function TForm1.AddCard(AParent: TFmxObject; AX, AY, AW, AH: Single;
  const AColor: TAlphaColor): TRectangle;
begin
  Result := TRectangle.Create(AParent);
  Result.Parent := AParent;
  Result.Position.X := AX;
  Result.Position.Y := AY;
  Result.Width := AW;
  Result.Height := AH;
  Result.Fill.Color := AColor;
  Result.Stroke.Kind := TBrushKind.None;
  Result.XRadius := 16;
  Result.YRadius := 16;
end;

procedure TForm1.AddMetric(AParent: TFmxObject; AX, AY: Single; const AValue,
  ALabel: string; const AAccent: TAlphaColor);
var
  Card, Dot: TRectangle;
begin
  Card := AddCard(AParent, AX, AY, 190, 116, CWhite);
  Dot := TRectangle.Create(Card);
  Dot.Parent := Card;
  Dot.Position.X := 18;
  Dot.Position.Y := 20;
  Dot.Width := 8;
  Dot.Height := 8;
  Dot.Fill.Color := AAccent;
  Dot.Stroke.Kind := TBrushKind.None;
  Dot.XRadius := 4;
  Dot.YRadius := 4;
  AddText(Card, AValue, 26, CInk, 18, 34, 154, 38, [TFontStyle.fsBold]);
  AddText(Card, ALabel, 12, CMuted, 18, 76, 154, 22);
end;

procedure TForm1.BuildInterface;
var
  Header, Hero, WeekCard, QuickCard, Progress: TRectangle;
begin
  FSidebar := TLayout.Create(Self);
  FSidebar.Parent := Self;
  FSidebar.Align := TAlignLayout.Left;
  FSidebar.Width := 222;
  FSidebar.Padding.Rect := TRectF.Create(24, 24, 20, 24);

  AddText(FSidebar, 'KAI', 26, CBlue, 0, 0, 160, 34, [TFontStyle.fsBold]);
  AddText(FSidebar, 'RUNNER', 12, CInk, 2, 34, 150, 20, [TFontStyle.fsBold]);
  AddText(FSidebar, 'Seu ritmo. Sua jornada.', 11, CMuted, 2, 65, 180, 20);

  AddText(FSidebar, 'HOJE', 11, CMuted, 2, 138, 180, 24, [TFontStyle.fsBold]);
  FMenuButton := TButton.Create(FSidebar);
  FMenuButton.Parent := FSidebar;
  FMenuButton.Position.X := 0;
  FMenuButton.Position.Y := 170;
  FMenuButton.Width := 178;
  FMenuButton.Height := 44;
  FMenuButton.Text := '  ◉   Visão geral';
  FMenuButton.TextSettings.Font.Size := 14;
  FMenuButton.TextSettings.FontColor := CBlue;
  FMenuButton.TextSettings.HorzAlign := TTextAlign.Leading;
  FMenuButton.StyledSettings := FMenuButton.StyledSettings - [TStyledSetting.FontColor];
  FMenuButton.OnClick := MenuClick;

  AddText(FSidebar, 'TREINOS', 11, CMuted, 2, 244, 180, 24, [TFontStyle.fsBold]);
  AddText(FSidebar, '◷   Histórico', 14, CInk, 2, 280, 180, 32);
  AddText(FSidebar, '▣   Metas', 14, CInk, 2, 326, 180, 32);
  AddText(FSidebar, '⚙   Preferências', 14, CInk, 2, 372, 180, 32);

  AddCard(FSidebar, 0, 430, 178, 110, $FFE7F0FF);
  AddText(FSidebar, 'CORRA COM', 11, CBlue, 16, 446, 145, 20, [TFontStyle.fsBold]);
  AddText(FSidebar, 'consistência', 17, CInk, 16, 468, 145, 28, [TFontStyle.fsBold]);
  AddText(FSidebar, 'Toda evolução começa', 10, CMuted, 16, 500, 145, 18);
  AddText(FSidebar, 'com o próximo passo.', 10, CMuted, 16, 518, 145, 18);

  FContent := TLayout.Create(Self);
  FContent.Parent := Self;
  FContent.Align := TAlignLayout.Client;
  FContent.Padding.Rect := TRectF.Create(30, 24, 30, 24);

  Header := AddCard(FContent, 0, 0, 760, 64, CWhite);
  Header.Align := TAlignLayout.Top;
  Header.Margins.Bottom := 24;
  AddText(Header, 'Visão geral', 22, CInk, 22, 13, 300, 38, [TFontStyle.fsBold]);
  AddText(Header, 'segunda-feira, 31 de agosto', 12, CMuted, 22, 43, 280, 20);
  AddText(Header, 'MF', 12, CBlue, 690, 14, 40, 36, [TFontStyle.fsBold]);

  Hero := AddCard(FContent, 0, 88, 760, 142, CBlue);
  AddText(Hero, 'BOM DIA, MARINA', 12, $FFBBD6FF, 24, 19, 300, 20, [TFontStyle.fsBold]);
  AddText(Hero, 'Pronta para o seu próximo km?', 23, CWhite, 24, 42, 430, 34, [TFontStyle.fsBold]);
  AddText(Hero, 'Seu plano de hoje está esperando por você.', 12, $FFDCEBFF, 24, 87, 430, 24);
  AddText(Hero, '🏃', 55, CWhite, 610, 16, 110, 90, [TFontStyle.fsBold]);

  AddText(FContent, 'SEU RESUMO', 12, CMuted, 0, 254, 250, 24, [TFontStyle.fsBold]);
  AddMetric(FContent, 0, 286, '18,4 km', 'Distância semanal', CBlue);
  AddMetric(FContent, 206, 286, '02:05:32', 'Tempo em movimento', CTeal);
  AddMetric(FContent, 412, 286, '5:42 /km', 'Ritmo médio', COrange);

  WeekCard := AddCard(FContent, 0, 426, 390, 160, CWhite);
  AddText(WeekCard, 'Meta semanal', 17, CInk, 20, 16, 220, 28, [TFontStyle.fsBold]);
  AddText(WeekCard, '18,4 de 25 km', 12, CMuted, 20, 48, 220, 22);
  Progress := TRectangle.Create(WeekCard);
  Progress.Parent := WeekCard;
  Progress.Position.X := 20;
  Progress.Position.Y := 90;
  Progress.Width := 348;
  Progress.Height := 10;
  Progress.Fill.Color := $FFE4ECF5;
  Progress.Stroke.Kind := TBrushKind.None;
  Progress.XRadius := 5;
  Progress.YRadius := 5;
  Progress := TRectangle.Create(WeekCard);
  Progress.Parent := WeekCard;
  Progress.Position.X := 20;
  Progress.Position.Y := 90;
  Progress.Width := 256;
  Progress.Height := 10;
  Progress.Fill.Color := CTeal;
  Progress.Stroke.Kind := TBrushKind.None;
  Progress.XRadius := 5;
  Progress.YRadius := 5;
  AddText(WeekCard, '74%', 14, CTeal, 318, 108, 50, 24, [TFontStyle.fsBold]);

  QuickCard := AddCard(FContent, 414, 426, 346, 160, CWhite);
  AddText(QuickCard, 'Próximo treino', 17, CInk, 20, 16, 260, 28, [TFontStyle.fsBold]);
  AddText(QuickCard, 'Corrida leve', 15, CBlue, 20, 50, 180, 24, [TFontStyle.fsBold]);
  AddText(QuickCard, '5 km  ·  35 min', 12, CMuted, 20, 78, 180, 22);
  with TButton.Create(QuickCard) do
  begin
    Parent := QuickCard;
    Position.X := 20;
    Position.Y := 112;
    Width := 190;
    Height := 34;
    Text := 'Começar treino';
    TextSettings.Font.Size := 12;
    TextSettings.FontColor := CWhite;
    StyledSettings := StyledSettings - [TStyledSetting.FontColor];
    OnClick := StartRunClick;
  end;

  AddText(FContent, 'ATIVIDADE RECENTE', 12, CMuted, 0, 618, 250, 24, [TFontStyle.fsBold]);
  AddText(FContent, 'Sábado', 14, CInk, 0, 650, 180, 26, [TFontStyle.fsBold]);
  AddText(FContent, '8,2 km     46:18     5:39 /km', 13, CMuted, 190, 650, 360, 26);
  with TButton.Create(FContent) do
  begin
    Parent := FContent;
    Position.X := 610;
    Position.Y := 646;
    Width := 150;
    Height := 34;
    Text := 'Ver histórico';
    TextSettings.Font.Size := 12;
    TextSettings.FontColor := CBlue;
    StyledSettings := StyledSettings - [TStyledSetting.FontColor];
    OnClick := ViewHistoryClick;
  end;
end;

procedure TForm1.FormResize(Sender: TObject);
begin
  if Assigned(FSidebar) then
  begin
    FSidebar.Visible := ClientWidth >= 680;
    if FSidebar.Visible then
      FContent.Padding.Rect := TRectF.Create(30, 24, 30, 24)
    else
      FContent.Padding.Rect := TRectF.Create(16, 16, 16, 16);
  end;
end;

procedure TForm1.MenuClick(Sender: TObject);
begin
  ShowMessage('Visão geral já está selecionada.');
end;

procedure TForm1.StartRunClick(Sender: TObject);
begin
  ShowMessage('Treino iniciado! Boa corrida, Marina.');
end;

procedure TForm1.ViewHistoryClick(Sender: TObject);
begin
  ShowMessage('Histórico de treinos em breve.');
end;

end.
