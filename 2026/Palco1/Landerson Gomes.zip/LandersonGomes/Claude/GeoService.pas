unit GeoService;

interface

uses
  System.SysUtils, System.Net.HttpClient, System.Net.URLClient, System.JSON,
  System.NetEncoding, System.Generics.Collections;

type
  TCepAddress = record
    Found: Boolean;
    Logradouro: string;
    Bairro: string;
    Localidade: string;
    UF: string;
    function FullAddress: string;
  end;

function TryGetAddressByCEP(const CEP: string; out Address: TCepAddress): Boolean;
function TryGeocodeAddress(const Query: string; out Lat, Lon: Double): Boolean;
function TryGetLocationByIP(out Lat, Lon: Double; out City: string): Boolean;
function OnlyDigits(const S: string): string;

const
  NominatimUserAgent = 'PontosDeTaxiApp/1.0 (contato: landerson_gomes@hotmail.com)';

implementation

function OnlyDigits(const S: string): string;
var
  C: Char;
begin
  Result := '';
  for C in S do
    if CharInSet(C, ['0'..'9']) then
      Result := Result + C;
end;

{ TCepAddress }

function TCepAddress.FullAddress: string;
begin
  Result := Trim(Format('%s, %s, %s - %s', [Logradouro, Bairro, Localidade, UF]));
end;

function TryGetAddressByCEP(const CEP: string; out Address: TCepAddress): Boolean;
var
  Http: THTTPClient;
  Resp: IHTTPResponse;
  Json: TJSONObject;
  Digits: string;
begin
  Result := False;
  Address.Found := False;
  Digits := OnlyDigits(CEP);
  if Length(Digits) <> 8 then
    Exit;

  Http := THTTPClient.Create;
  try
    Http.ConnectionTimeout := 8000;
    Http.ResponseTimeout := 8000;
    try
      Resp := Http.Get(Format('https://viacep.com.br/ws/%s/json/', [Digits]));
    except
      Exit;
    end;
    if Resp.StatusCode <> 200 then
      Exit;

    Json := TJSONObject.ParseJSONValue(Resp.ContentAsString(TEncoding.UTF8)) as TJSONObject;
    if Json = nil then
      Exit;
    try
      if Json.GetValue('erro') <> nil then
        Exit;

      Address.Logradouro := Json.GetValue<string>('logradouro', '');
      Address.Bairro := Json.GetValue<string>('bairro', '');
      Address.Localidade := Json.GetValue<string>('localidade', '');
      Address.UF := Json.GetValue<string>('uf', '');
      Address.Found := True;
      Result := True;
    finally
      Json.Free;
    end;
  finally
    Http.Free;
  end;
end;

function TryGeocodeAddress(const Query: string; out Lat, Lon: Double): Boolean;
var
  Http: THTTPClient;
  Resp: IHTTPResponse;
  Arr: TJSONArray;
  Obj: TJSONObject;
  FS: TFormatSettings;
  URL: string;
begin
  Result := False;
  Lat := 0;
  Lon := 0;
  FS := TFormatSettings.Invariant;

  Http := THTTPClient.Create;
  try
    Http.ConnectionTimeout := 8000;
    Http.ResponseTimeout := 8000;
    Http.CustomHeaders['User-Agent'] := NominatimUserAgent;
    URL := 'https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q=' +
      TNetEncoding.URL.Encode(Query);
    try
      Resp := Http.Get(URL);
    except
      Exit;
    end;
    if Resp.StatusCode <> 200 then
      Exit;

    Arr := TJSONObject.ParseJSONValue(Resp.ContentAsString(TEncoding.UTF8)) as TJSONArray;
    if Arr = nil then
      Exit;
    try
      if Arr.Count = 0 then
        Exit;
      Obj := Arr.Items[0] as TJSONObject;
      Lat := StrToFloat(Obj.GetValue<string>('lat'), FS);
      Lon := StrToFloat(Obj.GetValue<string>('lon'), FS);
      Result := True;
    finally
      Arr.Free;
    end;
  finally
    Http.Free;
  end;
end;

function TryGetLocationByIP(out Lat, Lon: Double; out City: string): Boolean;
var
  Http: THTTPClient;
  Resp: IHTTPResponse;
  Json: TJSONObject;
begin
  Result := False;
  Lat := 0;
  Lon := 0;
  City := '';

  Http := THTTPClient.Create;
  try
    Http.ConnectionTimeout := 8000;
    Http.ResponseTimeout := 8000;
    try
      Resp := Http.Get('http://ip-api.com/json/?fields=status,lat,lon,city');
    except
      Exit;
    end;
    if Resp.StatusCode <> 200 then
      Exit;

    Json := TJSONObject.ParseJSONValue(Resp.ContentAsString(TEncoding.UTF8)) as TJSONObject;
    if Json = nil then
      Exit;
    try
      if Json.GetValue<string>('status', '') <> 'success' then
        Exit;
      Lat := Json.GetValue<Double>('lat');
      Lon := Json.GetValue<Double>('lon');
      City := Json.GetValue<string>('city', '');
      Result := True;
    finally
      Json.Free;
    end;
  finally
    Http.Free;
  end;
end;

end.
