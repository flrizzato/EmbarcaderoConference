unit TaxiData;

interface

uses
  System.Math, System.SysUtils;

type
  TTaxiPoint = record
    Name: string;
    Address: string;
    District: string;
    Hours: string;
    Lat: Double;
    Lon: Double;
    DistanceKm: Double;
  end;

  TTaxiPointArray = TArray<TTaxiPoint>;

function GetTaxiPoints: TTaxiPointArray;
function HaversineKm(Lat1, Lon1, Lat2, Lon2: Double): Double;
function FormatDistance(const KM: Double): string;

implementation

function HaversineKm(Lat1, Lon1, Lat2, Lon2: Double): Double;
const
  EarthRadiusKm = 6371.0;
var
  dLat, dLon, a, c: Double;
begin
  dLat := DegToRad(Lat2 - Lat1);
  dLon := DegToRad(Lon2 - Lon1);
  a := Sin(dLat / 2) * Sin(dLat / 2) +
       Cos(DegToRad(Lat1)) * Cos(DegToRad(Lat2)) * Sin(dLon / 2) * Sin(dLon / 2);
  c := 2 * ArcTan2(Sqrt(a), Sqrt(1 - a));
  Result := EarthRadiusKm * c;
end;

function FormatDistance(const KM: Double): string;
begin
  if KM < 1 then
    Result := Format('%.0f m', [KM * 1000])
  else
    Result := Format('%.1f km', [KM]);
end;

function GetTaxiPoints: TTaxiPointArray;

  procedure Add(var Arr: TTaxiPointArray; const AName, AAddress, ADistrict, AHours: string;
    ALat, ALon: Double);
  var
    Idx: Integer;
  begin
    Idx := Length(Arr);
    SetLength(Arr, Idx + 1);
    Arr[Idx].Name := AName;
    Arr[Idx].Address := AAddress;
    Arr[Idx].District := ADistrict;
    Arr[Idx].Hours := AHours;
    Arr[Idx].Lat := ALat;
    Arr[Idx].Lon := ALon;
    Arr[Idx].DistanceKm := 0;
  end;

begin
  Result := nil;
  Add(Result, 'Ponto de Táxi Central', 'Av. Presidente Vargas, 1201', 'Centro', '24 horas', -22.9068, -43.1934);
  Add(Result, 'Ponto de Táxi Aeroporto Santos Dumont', 'Av. Almirante Sílvio de Noronha, s/n', 'Centro', '24 horas', -22.9105, -43.1634);
  Add(Result, 'Ponto de Táxi Rodoviária Novo Rio', 'Av. Francisco Bicalho, 1', 'Santo Cristo', '24 horas', -22.9048, -43.2064);
  Add(Result, 'Ponto de Táxi Ipanema', 'Rua Visconde de Pirajá, 550', 'Ipanema', '24 horas', -22.9838, -43.2096);
  Add(Result, 'Ponto de Táxi Tijuca', 'Rua Conde de Bonfim, 910', 'Tijuca', '06h - 24h', -22.9271, -43.2317);
  Add(Result, 'Ponto de Táxi Copacabana', 'Av. Nossa Senhora de Copacabana, 1200', 'Copacabana', '24 horas', -22.9711, -43.1867);
  Add(Result, 'Ponto de Táxi Botafogo', 'Praia de Botafogo, 300', 'Botafogo', '24 horas', -22.9519, -43.1809);
  Add(Result, 'Ponto de Táxi Barra da Tijuca', 'Av. das Américas, 3500', 'Barra da Tijuca', '24 horas', -22.9990, -43.3651);
  Add(Result, 'Ponto de Táxi Lapa', 'Praça Cardeal Câmara, s/n', 'Lapa', '24 horas', -22.9137, -43.1793);
  Add(Result, 'Ponto de Táxi Leblon', 'Av. Ataulfo de Paiva, 1000', 'Leblon', '24 horas', -22.9847, -43.2249);
  Add(Result, 'Ponto de Táxi Maracanã', 'Rua Prof. Eurico Rabelo, s/n', 'Maracanã', '06h - 24h', -22.9121, -43.2302);
  Add(Result, 'Ponto de Táxi Flamengo', 'Praia do Flamengo, 200', 'Flamengo', '24 horas', -22.9337, -43.1747);
end;

end.
