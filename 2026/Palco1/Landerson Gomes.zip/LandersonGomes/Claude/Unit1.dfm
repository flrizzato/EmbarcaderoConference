object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Pontos de T'#225'xi'
  ClientHeight = 900
  ClientWidth = 1440
  Color = 2105118
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWhite
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  TextHeight = 15
  object pnlStatusBar: TPanel
    Left = 0
    Top = 860
    Width = 1440
    Height = 40
    Align = alBottom
    BevelOuter = bvNone
    Color = 1644568
    ParentBackground = False
    TabOrder = 0
    ExplicitTop = 852
    ExplicitWidth = 1438
    DesignSize = (
      1440
      40)
    object lblStatusLeft: TLabel
      Left = 24
      Top = 12
      Width = 205
      Height = 15
      Caption = 'Informe um CEP para come'#231'ar a busca'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 11184810
      Font.Height = -12
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentFont = False
    end
    object lblStatusRight: TLabel
      Left = 1276
      Top = 12
      Width = 87
      Height = 15
      Anchors = [akTop, akRight]
      Caption = 'Nenhuma busca'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 11184810
      Font.Height = -12
      Font.Name = 'Segoe UI'
      Font.Style = []
      ParentFont = False
    end
    object pbRefresh: TPaintBox
      Left = 1400
      Top = 6
      Width = 28
      Height = 28
      Anchors = [akTop, akRight]
      OnClick = pbRefreshClick
      OnPaint = pbRefreshPaint
    end
  end
  object pnlNav: TPanel
    Left = 0
    Top = 0
    Width = 68
    Height = 860
    Align = alLeft
    BevelOuter = bvNone
    Color = 1513239
    ParentBackground = False
    TabOrder = 1
    ExplicitHeight = 852
    DesignSize = (
      68
      860)
    object lblNavMenu: TLabel
      Left = 20
      Top = 20
      Width = 18
      Height = 18
      Alignment = taCenter
      Caption = #59136
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -18
      Font.Name = 'Segoe Fluent Icons'
      Font.Style = []
      ParentFont = False
      Layout = tlCenter
      OnClick = lblNavMenuClick
    end
    object lblNavHome: TLabel
      Left = 20
      Top = 76
      Width = 18
      Height = 18
      Alignment = taCenter
      Caption = #59407
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 2660853
      Font.Height = -18
      Font.Name = 'Segoe Fluent Icons'
      Font.Style = []
      ParentFont = False
      Layout = tlCenter
    end
    object shpNavHomeIndicator: TShape
      Left = 0
      Top = 72
      Width = 4
      Height = 36
      Brush.Color = 14120960
      Pen.Style = psClear
    end
    object lblNavFav: TLabel
      Left = 20
      Top = 140
      Width = 18
      Height = 18
      Alignment = taCenter
      Caption = #59188
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 11184810
      Font.Height = -18
      Font.Name = 'Segoe Fluent Icons'
      Font.Style = []
      ParentFont = False
      Layout = tlCenter
      OnClick = lblNavFavClick
    end
    object lblNavHistory: TLabel
      Left = 20
      Top = 188
      Width = 18
      Height = 18
      Alignment = taCenter
      Caption = #59427
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 11184810
      Font.Height = -18
      Font.Name = 'Segoe Fluent Icons'
      Font.Style = []
      ParentFont = False
      Layout = tlCenter
      OnClick = lblNavHistoryClick
    end
    object lblNavSettings: TLabel
      Left = 20
      Top = 812
      Width = 18
      Height = 18
      Alignment = taCenter
      Anchors = [akLeft, akBottom]
      Caption = #59155
      Font.Charset = DEFAULT_CHARSET
      Font.Color = 11184810
      Font.Height = -18
      Font.Name = 'Segoe Fluent Icons'
      Font.Style = []
      ParentFont = False
      Layout = tlCenter
      OnClick = lblNavSettingsClick
    end
  end
  object pnlSidebar: TPanel
    Left = 68
    Top = 0
    Width = 460
    Height = 860
    Align = alLeft
    BevelOuter = bvNone
    Color = 1974048
    ParentBackground = False
    TabOrder = 2
    ExplicitHeight = 852
    object pnlSidebarTop: TPanel
      Left = 0
      Top = 0
      Width = 460
      Height = 276
      Align = alTop
      BevelOuter = bvNone
      Color = 1974048
      ParentBackground = False
      TabOrder = 0
      object lblTitle: TLabel
        Left = 24
        Top = 24
        Width = 291
        Height = 37
        Caption = 'Encontre pontos de t'#225'xi'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWhite
        Font.Height = -27
        Font.Name = 'Segoe UI Semibold'
        Font.Style = []
        ParentFont = False
      end
      object lblSubtitle: TLabel
        Left = 24
        Top = 66
        Width = 345
        Height = 40
        Caption = 'Informe o CEP para localizar os pontos de t'#225'xi mais pr'#243'ximos.'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = 11184810
        Font.Height = -15
        Font.Name = 'Segoe UI'
        Font.Style = []
        ParentFont = False
        WordWrap = True
      end
      object lblCepCaption: TLabel
        Left = 24
        Top = 118
        Width = 83
        Height = 17
        Caption = 'C'#243'digo postal'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = 11184810
        Font.Height = -13
        Font.Name = 'Segoe UI'
        Font.Style = []
        ParentFont = False
      end
      object pbCepBox: TPaintBox
        Left = 24
        Top = 140
        Width = 340
        Height = 52
        OnPaint = pbCepBoxPaint
      end
      object lblClearCep: TLabel
        Left = 322
        Top = 156
        Width = 14
        Height = 14
        Cursor = crHandPoint
        Alignment = taCenter
        Caption = #59153
        Font.Charset = DEFAULT_CHARSET
        Font.Color = 8947848
        Font.Height = -14
        Font.Name = 'Segoe Fluent Icons'
        Font.Style = []
        ParentFont = False
        Layout = tlCenter
        OnClick = lblClearCepClick
      end
      object pbSearchBtn: TPaintBox
        Left = 376
        Top = 140
        Width = 52
        Height = 52
        OnClick = pbSearchBtnClick
        OnPaint = pbSearchBtnPaint
      end
      object lnkUseLocation: TLabel
        Left = 24
        Top = 204
        Width = 194
        Height = 19
        Cursor = crHandPoint
        Caption = #59421'  Usar minha localiza'#231#227'o atual'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = 2660853
        Font.Height = -14
        Font.Name = 'Segoe UI'
        Font.Style = []
        ParentFont = False
        OnClick = lnkUseLocationClick
      end
      object lblResultsTitle: TLabel
        Left = 24
        Top = 240
        Width = 146
        Height = 21
        Caption = 'Pontos encontrados'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWhite
        Font.Height = -16
        Font.Name = 'Segoe UI Semibold'
        Font.Style = []
        ParentFont = False
      end
      object pbBadge: TPaintBox
        Left = 168
        Top = 240
        Width = 32
        Height = 22
        OnPaint = pbBadgePaint
      end
      object edtCEP: TEdit
        Left = 42
        Top = 156
        Width = 270
        Height = 23
        BorderStyle = bsNone
        Color = 2829357
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWhite
        Font.Height = -16
        Font.Name = 'Segoe UI'
        Font.Style = []
        MaxLength = 9
        ParentFont = False
        TabOrder = 0
        TextHint = '00000-000'
        OnKeyPress = edtCEPKeyPress
      end
    end
    object lbResults: TListBox
      Left = 0
      Top = 276
      Width = 460
      Height = 584
      Style = lbOwnerDrawFixed
      Align = alClient
      BorderStyle = bsNone
      Color = 1974048
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -12
      Font.Name = 'Segoe UI'
      Font.Style = []
      ItemHeight = 92
      ParentFont = False
      TabOrder = 1
      OnClick = lbResultsClick
      OnDrawItem = lbResultsDrawItem
      ExplicitHeight = 576
    end
  end
  object pnlMap: TPanel
    Left = 528
    Top = 0
    Width = 912
    Height = 860
    Align = alClient
    BevelOuter = bvNone
    Color = 1643535
    ParentBackground = False
    TabOrder = 3
    ExplicitWidth = 910
    ExplicitHeight = 852
    DesignSize = (
      912
      860)
    object pbMap: TPaintBox
      Left = 0
      Top = 0
      Width = 912
      Height = 860
      Align = alClient
      OnMouseDown = pbMapMouseDown
      OnPaint = pbMapPaint
    end
    object pbLocate: TPaintBox
      Left = 844
      Top = 16
      Width = 44
      Height = 44
      Anchors = [akTop, akRight]
      OnClick = pbLocateClick
      OnPaint = pbLocatePaint
    end
    object pbZoom: TPaintBox
      Left = 844
      Top = 72
      Width = 44
      Height = 88
      Anchors = [akTop, akRight]
      OnMouseDown = pbZoomMouseDown
      OnPaint = pbZoomPaint
    end
    object pnlDetailCard: TPanel
      Left = 458
      Top = 606
      Width = 430
      Height = 230
      Anchors = [akRight, akBottom]
      BevelOuter = bvNone
      Color = 1974048
      ParentBackground = False
      TabOrder = 0
      Visible = False
      ExplicitLeft = 456
      ExplicitTop = 598
      object pbDetailIcon: TPaintBox
        Left = 20
        Top = 20
        Width = 56
        Height = 56
        OnPaint = pbDetailIconPaint
      end
      object lblDetailName: TLabel
        Left = 88
        Top = 18
        Width = 97
        Height = 21
        Caption = 'Ponto de T'#225'xi'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWhite
        Font.Height = -16
        Font.Name = 'Segoe UI Semibold'
        Font.Style = []
        ParentFont = False
      end
      object lblDetailAddress: TLabel
        Left = 88
        Top = 46
        Width = 55
        Height = 17
        Caption = 'Endere'#231'o'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = 11184810
        Font.Height = -13
        Font.Name = 'Segoe UI'
        Font.Style = []
        ParentFont = False
      end
      object lblDetailDistance: TLabel
        Left = 88
        Top = 70
        Width = 115
        Height = 17
        Caption = #59421' 0 m de dist'#226'ncia'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = 2660853
        Font.Height = -13
        Font.Name = 'Segoe UI'
        Font.Style = []
        ParentFont = False
      end
      object pbDetailFav: TPaintBox
        Left = 386
        Top = 18
        Width = 26
        Height = 26
        OnClick = pbDetailFavClick
        OnPaint = pbDetailFavPaint
      end
      object lblDetailHours: TLabel
        Left = 20
        Top = 118
        Width = 165
        Height = 17
        Caption = #59427' Funcionamento: 24 horas'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = 13421772
        Font.Height = -13
        Font.Name = 'Segoe UI'
        Font.Style = []
        ParentFont = False
      end
      object shpDetailDivider: TShape
        Left = 20
        Top = 100
        Width = 390
        Height = 1
        Pen.Color = 3289650
      end
      object pbBtnDirections: TPaintBox
        Left = 20
        Top = 160
        Width = 190
        Height = 44
        OnClick = pbBtnDirectionsClick
        OnPaint = pbBtnDirectionsPaint
      end
      object pbBtnShare: TPaintBox
        Left = 220
        Top = 160
        Width = 190
        Height = 44
        OnClick = pbBtnShareClick
        OnPaint = pbBtnSharePaint
      end
    end
  end
  object tmrStatusReset: TTimer
    Enabled = False
    Interval = 1800
    OnTimer = tmrStatusResetTimer
    Left = 1360
    Top = 780
  end
end
