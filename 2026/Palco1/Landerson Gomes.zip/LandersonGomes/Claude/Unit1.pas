﻿unit Unit1;

interface

uses
  Winapi.Windows, Winapi.Messages, Winapi.ShellAPI, System.SysUtils, System.Variants,
  System.Classes, System.UITypes, System.Math, System.Types, Vcl.ExtCtrls,
  System.Generics.Collections, System.Generics.Defaults, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls,  Vcl.Clipbrd,
  TaxiData, GeoService;

type
  TPinHit = record
    Rect: TRect;
    PointIndex: Integer;
  end;

  TForm1 = class(TForm)
    pnlStatusBar: TPanel;
    lblStatusLeft: TLabel;
    lblStatusRight: TLabel;
    pbRefresh: TPaintBox;
    pnlNav: TPanel;
    lblNavMenu: TLabel;
    lblNavHome: TLabel;
    shpNavHomeIndicator: TShape;
    lblNavFav: TLabel;
    lblNavHistory: TLabel;
    lblNavSettings: TLabel;
    pnlSidebar: TPanel;
    pnlSidebarTop: TPanel;
    lblTitle: TLabel;
    lblSubtitle: TLabel;
    lblCepCaption: TLabel;
    pbCepBox: TPaintBox;
    lblClearCep: TLabel;
    pbSearchBtn: TPaintBox;
    edtCEP: TEdit;
    lnkUseLocation: TLabel;
    lblResultsTitle: TLabel;
    pbBadge: TPaintBox;
    lbResults: TListBox;
    pnlMap: TPanel;
    pbMap: TPaintBox;
    pbLocate: TPaintBox;
    pbZoom: TPaintBox;
    pnlDetailCard: TPanel;
    pbDetailIcon: TPaintBox;
    lblDetailName: TLabel;
    lblDetailAddress: TLabel;
    lblDetailDistance: TLabel;
    pbDetailFav: TPaintBox;
    lblDetailHours: TLabel;
    shpDetailDivider: TShape;
    pbBtnDirections: TPaintBox;
    pbBtnShare: TPaintBox;
    tmrStatusReset: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure lblNavFavClick(Sender: TObject);
    procedure lblNavHistoryClick(Sender: TObject);
    procedure lblNavMenuClick(Sender: TObject);
    procedure lblNavSettingsClick(Sender: TObject);
    procedure pbCepBoxPaint(Sender: TObject);
    procedure lblClearCepClick(Sender: TObject);
    procedure pbSearchBtnClick(Sender: TObject);
    procedure pbSearchBtnPaint(Sender: TObject);
    procedure edtCEPKeyPress(Sender: TObject; var Key: Char);
    procedure lnkUseLocationClick(Sender: TObject);
    procedure pbBadgePaint(Sender: TObject);
    procedure lbResultsClick(Sender: TObject);
    procedure lbResultsDrawItem(Control: TWinControl; Index: Integer; Rect: TRect;
      State: TOwnerDrawState);
    procedure pbMapMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure pbMapPaint(Sender: TObject);
    procedure pbLocateClick(Sender: TObject);
    procedure pbLocatePaint(Sender: TObject);
    procedure pbZoomMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure pbZoomPaint(Sender: TObject);
    procedure pbDetailIconPaint(Sender: TObject);
    procedure pbDetailFavClick(Sender: TObject);
    procedure pbDetailFavPaint(Sender: TObject);
    procedure pbBtnDirectionsClick(Sender: TObject);
    procedure pbBtnDirectionsPaint(Sender: TObject);
    procedure pbBtnShareClick(Sender: TObject);
    procedure pbBtnSharePaint(Sender: TObject);
    procedure pbRefreshClick(Sender: TObject);
    procedure pbRefreshPaint(Sender: TObject);
    procedure tmrStatusResetTimer(Sender: TObject);
  private
    FAllPoints: TTaxiPointArray;
    FSorted: TTaxiPointArray;
    FSelectedIndex: Integer;
    FHasLocation: Boolean;
    FUserLat, FUserLon: Double;
    FLastIsCEP: Boolean;
    FLastQueryLabel: string;
    FBusy: Boolean;
    FMapZoom: Double;
    FFavorites: TStringList;
    FPinHits: TArray<TPinHit>;
    FDefaultStatusLeft: string;
    procedure StartSearchByCEP(const CEP: string);
    procedure StartSearchByLocation;
    procedure ComputeAndShowResults(Lat, Lon: Double; IsCEP: Boolean; const QueryLabel: string);
    procedure PopulateResultsList;
    procedure SelectResult(Index: Integer);
    procedure UpdateDetailCard;
    procedure SetBusy(Value: Boolean);
    procedure ShowStatusError(const Msg: string);
    procedure SetTemporaryStatus(const Msg: string);
    function BuildDirectionsURL(const P: TTaxiPoint): string;
    function IsFavorite(const Name: string): Boolean;
  public
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

const
  DWMWA_USE_IMMERSIVE_DARK_MODE = 20;

  clAppBackground   = TColor($00201F1E);
  clSidebarBg       = TColor($001E1F20);
  clCardBg          = TColor($002B2C2D);
  clCardBgHover     = TColor($00343536);
  clCardBorder      = TColor($003A3A3A);
  clAccent          = TColor($00D77800);
  clAccentLight     = TColor($00F5A040);
  clTextSecondary   = TColor($00AAAAAA);
  clMapBg           = TColor($0019140F);
  clPinYellow       = TColor($0000B9FF);
  clPinShadow       = TColor($00151515);

function DwmSetWindowAttribute(hWnd: HWND; dwAttribute: DWORD; pvAttribute: Pointer;
  cbAttribute: DWORD): HRESULT; stdcall; external 'dwmapi.dll';

function Glyph(Code: Integer): string;
begin
  Result := WideChar(Code);
end;

procedure DrawIconGlyph(Canvas: TCanvas; CX, CY, Code, Size: Integer; Color: TColor);
var
  S: string;
  TS: TSize;
begin
  Canvas.Font.Name := 'Segoe Fluent Icons';
  Canvas.Font.Height := -Size;
  Canvas.Font.Color := Color;
  Canvas.Brush.Style := bsClear;
  S := Glyph(Code);
  TS := Canvas.TextExtent(S);
  Canvas.TextOut(CX - TS.cx div 2, CY - TS.cy div 2, S);
end;

procedure DrawRoundRectFilled(Canvas: TCanvas; R: TRect; Radius: Integer;
  Fill, Border: TColor; BorderWidth: Integer = 1);
begin
  Canvas.Brush.Style := bsSolid;
  Canvas.Brush.Color := Fill;
  if Border = clNone then
    Canvas.Pen.Style := psClear
  else
  begin
    Canvas.Pen.Style := psSolid;
    Canvas.Pen.Color := Border;
    Canvas.Pen.Width := BorderWidth;
  end;
  Canvas.RoundRect(R.Left, R.Top, R.Right, R.Bottom, Radius, Radius);
end;

procedure DrawCarIcon(Canvas: TCanvas; CX, CY, Size: Integer; Color: TColor);
var
  W, H: Integer;
begin
  W := Round(Size * 0.62);
  H := Round(Size * 0.32);
  Canvas.Brush.Style := bsSolid;
  Canvas.Brush.Color := Color;
  Canvas.Pen.Style := psClear;
  Canvas.RoundRect(CX - W div 2, CY - H div 2, CX + W div 2, CY + H div 2 + 2, 6, 6);
  Canvas.RoundRect(CX - W div 3, CY - H, CX + W div 3, CY - H div 2 + 3, 4, 4);
  Canvas.Ellipse(CX - W div 2 - 1, CY + H div 2 - 5, CX - W div 2 + 7, CY + H div 2 + 3);
  Canvas.Ellipse(CX + W div 2 - 7, CY + H div 2 - 5, CX + W div 2 + 1, CY + H div 2 + 3);
end;

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
var
  DarkMode: BOOL;
begin
  DarkMode := True;
  DwmSetWindowAttribute(Handle, DWMWA_USE_IMMERSIVE_DARK_MODE, @DarkMode, SizeOf(DarkMode));

  FAllPoints := GetTaxiPoints;
  FSorted := nil;
  FSelectedIndex := -1;
  FHasLocation := False;
  FBusy := False;
  FMapZoom := 1.0;
  FFavorites := TStringList.Create;
  FFavorites.Sorted := True;
  FFavorites.Duplicates := dupIgnore;
  FDefaultStatusLeft := lblStatusLeft.Caption;
  pnlDetailCard.Visible := False;
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  FFavorites.Free;
end;

procedure TForm1.lblNavMenuClick(Sender: TObject);
begin
  // Reservado para recolher/expandir a barra lateral em uma versão futura.
end;

procedure TForm1.lblNavFavClick(Sender: TObject);
begin
  ShowMessage('Favoritos: marque uma estrela em um ponto de táxi para salvá-lo aqui.');
end;

procedure TForm1.lblNavHistoryClick(Sender: TObject);
begin
  if FLastQueryLabel <> '' then
    ShowMessage('Última busca: ' + FLastQueryLabel)
  else
    ShowMessage('Nenhuma busca recente.');
end;

procedure TForm1.lblNavSettingsClick(Sender: TObject);
begin
  ShowMessage('Configurações ainda não estão disponíveis nesta versão.');
end;

procedure TForm1.pbCepBoxPaint(Sender: TObject);
var
  PB: TPaintBox;
  Border: TColor;
begin
  PB := Sender as TPaintBox;
  if edtCEP.Focused then
    Border := clAccent
  else
    Border := clCardBorder;
  DrawRoundRectFilled(PB.Canvas, PB.ClientRect, 8, clCardBg, Border, 1);
end;

procedure TForm1.lblClearCepClick(Sender: TObject);
begin
  edtCEP.Text := '';
  edtCEP.SetFocus;
end;

procedure TForm1.pbSearchBtnPaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  DrawRoundRectFilled(PB.Canvas, R, 8, clAccent, clNone);
  DrawIconGlyph(PB.Canvas, R.Width div 2, R.Height div 2, $E721, 16, clWhite);
end;

procedure TForm1.pbSearchBtnClick(Sender: TObject);
begin
  StartSearchByCEP(edtCEP.Text);
end;

procedure TForm1.edtCEPKeyPress(Sender: TObject; var Key: Char);
begin
  if Key = #13 then
  begin
    Key := #0;
    StartSearchByCEP(edtCEP.Text);
  end;
end;

procedure TForm1.lnkUseLocationClick(Sender: TObject);
begin
  StartSearchByLocation;
end;

procedure TForm1.pbLocateClick(Sender: TObject);
begin
  StartSearchByLocation;
end;

procedure TForm1.pbLocatePaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  DrawRoundRectFilled(PB.Canvas, R, 10, clCardBg, clCardBorder, 1);
  DrawIconGlyph(PB.Canvas, R.Width div 2, R.Height div 2, $E81D, 16, clWhite);
end;

procedure TForm1.pbZoomPaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
  MidY: Integer;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  DrawRoundRectFilled(PB.Canvas, R, 10, clCardBg, clCardBorder, 1);
  MidY := R.Top + R.Height div 2;
  PB.Canvas.Pen.Color := clCardBorder;
  PB.Canvas.MoveTo(R.Left + 8, MidY);
  PB.Canvas.LineTo(R.Right - 8, MidY);
  DrawIconGlyph(PB.Canvas, R.Width div 2, MidY div 2, $E710, 14, clWhite);
  DrawIconGlyph(PB.Canvas, R.Width div 2, MidY + (R.Bottom - MidY) div 2, $E738, 14, clWhite);
end;

procedure TForm1.pbZoomMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
  X, Y: Integer);
begin
  if Y < (Sender as TPaintBox).Height div 2 then
    FMapZoom := Max(0.4, FMapZoom - 0.2)
  else
    FMapZoom := Min(2.2, FMapZoom + 0.2);
  pbMap.Invalidate;
end;

procedure TForm1.pbBadgePaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
  S: string;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  DrawRoundRectFilled(PB.Canvas, R, R.Height div 2, clCardBg, clNone);
  S := IntToStr(Length(FSorted));
  PB.Canvas.Font.Name := 'Segoe UI';
  PB.Canvas.Font.Height := -12;
  PB.Canvas.Font.Color := clWhite;
  PB.Canvas.Brush.Style := bsClear;
  PB.Canvas.TextOut(R.Left + (R.Width - PB.Canvas.TextWidth(S)) div 2,
    R.Top + (R.Height - PB.Canvas.TextHeight(S)) div 2, S);
end;

procedure TForm1.SetBusy(Value: Boolean);
begin
  FBusy := Value;
  edtCEP.Enabled := not Value;
  pbSearchBtn.Enabled := not Value;
  lnkUseLocation.Enabled := not Value;
  pbLocate.Enabled := not Value;
  if Value then
    lblStatusLeft.Caption := 'Buscando pontos de táxi...'
  else
    lblStatusLeft.Caption := FDefaultStatusLeft;
end;

procedure TForm1.ShowStatusError(const Msg: string);
begin
  lblStatusLeft.Caption := Msg;
  lblStatusLeft.Font.Color := TColor($004040E0);
  tmrStatusReset.Enabled := False;
  tmrStatusReset.Interval := 4000;
  tmrStatusReset.Tag := 1;
  tmrStatusReset.Enabled := True;
end;

procedure TForm1.SetTemporaryStatus(const Msg: string);
begin
  lblStatusRight.Caption := Msg;
  tmrStatusReset.Enabled := False;
  tmrStatusReset.Interval := 2200;
  tmrStatusReset.Tag := 2;
  tmrStatusReset.Enabled := True;
end;

procedure TForm1.tmrStatusResetTimer(Sender: TObject);
begin
  tmrStatusReset.Enabled := False;
  if tmrStatusReset.Tag = 1 then
  begin
    lblStatusLeft.Font.Color := clTextSecondary;
    lblStatusLeft.Caption := FDefaultStatusLeft;
  end
  else if tmrStatusReset.Tag = 2 then
    lblStatusRight.Caption := 'Atualizado agora';
end;

procedure TForm1.StartSearchByCEP(const CEP: string);
var
  Digits: string;
begin
  if FBusy then
    Exit;
  Digits := OnlyDigits(CEP);
  if Length(Digits) <> 8 then
  begin
    ShowStatusError('Informe um CEP válido com 8 dígitos.');
    Exit;
  end;

  SetBusy(True);
  TThread.CreateAnonymousThread(
    procedure
    var
      Addr: TCepAddress;
      Lat, Lon: Double;
      OK: Boolean;
      Label_: string;
    begin
      OK := TryGetAddressByCEP(Digits, Addr);
      if not OK or not Addr.Found then
      begin
        TThread.Queue(nil,
          procedure
          begin
            SetBusy(False);
            ShowStatusError('CEP não encontrado. Verifique e tente novamente.');
          end);
        Exit;
      end;

      OK := TryGeocodeAddress(Addr.FullAddress, Lat, Lon);
      if not OK then
        OK := TryGeocodeAddress(Addr.Localidade + ', ' + Addr.UF + ', Brasil', Lat, Lon);

      Label_ := Addr.FullAddress;
      if not OK then
      begin
        TThread.Queue(nil,
          procedure
          begin
            SetBusy(False);
            ShowStatusError('Não foi possível localizar esse endereço no mapa.');
          end);
        Exit;
      end;

      TThread.Queue(nil,
        procedure
        begin
          SetBusy(False);
          ComputeAndShowResults(Lat, Lon, True, Label_);
        end);
    end).Start;
end;

procedure TForm1.StartSearchByLocation;
begin
  if FBusy then
    Exit;
  SetBusy(True);
  TThread.CreateAnonymousThread(
    procedure
    var
      Lat, Lon: Double;
      City: string;
      OK: Boolean;
    begin
      OK := TryGetLocationByIP(Lat, Lon, City);
      if not OK then
      begin
        TThread.Queue(nil,
          procedure
          begin
            SetBusy(False);
            ShowStatusError('Não foi possível obter sua localização atual.');
          end);
        Exit;
      end;

      TThread.Queue(nil,
        procedure
        begin
          SetBusy(False);
          edtCEP.Text := '';
          ComputeAndShowResults(Lat, Lon, False, 'Sua localização atual (' + City + ')');
        end);
    end).Start;
end;

procedure TForm1.ComputeAndShowResults(Lat, Lon: Double; IsCEP: Boolean; const QueryLabel: string);
var
  I: Integer;
begin
  FUserLat := Lat;
  FUserLon := Lon;
  FHasLocation := True;
  FLastIsCEP := IsCEP;
  FLastQueryLabel := QueryLabel;

  FSorted := Copy(FAllPoints, 0, Length(FAllPoints));
  for I := 0 to High(FSorted) do
    FSorted[I].DistanceKm := HaversineKm(Lat, Lon, FSorted[I].Lat, FSorted[I].Lon);

  TArray.Sort<TTaxiPoint>(FSorted,
    TComparer<TTaxiPoint>.Construct(
      function(const A, B: TTaxiPoint): Integer
      begin
        Result := CompareValue(A.DistanceKm, B.DistanceKm);
      end));

  FMapZoom := 1.0;
  PopulateResultsList;
  SelectResult(0);

  if IsCEP then
    FDefaultStatusLeft := 'Resultados baseados no CEP informado'
  else
    FDefaultStatusLeft := 'Resultados baseados em sua localização atual';
  lblStatusLeft.Caption := FDefaultStatusLeft;
  lblStatusRight.Caption := 'Atualizado agora';
  pbBadge.Invalidate;
end;

procedure TForm1.PopulateResultsList;
begin
  lbResults.Items.BeginUpdate;
  try
    lbResults.Clear;
    while lbResults.Items.Count < Length(FSorted) do
      lbResults.Items.Add('');
  finally
    lbResults.Items.EndUpdate;
  end;
  pbBadge.Invalidate;
  pbMap.Invalidate;
end;

procedure TForm1.SelectResult(Index: Integer);
begin
  if (Length(FSorted) = 0) or (Index < 0) or (Index > High(FSorted)) then
  begin
    FSelectedIndex := -1;
    pnlDetailCard.Visible := False;
    Exit;
  end;
  FSelectedIndex := Index;
  lbResults.ItemIndex := Index;
  UpdateDetailCard;
  pnlDetailCard.Visible := True;
  pbMap.Invalidate;
end;

procedure TForm1.UpdateDetailCard;
var
  P: TTaxiPoint;
begin
  if (FSelectedIndex < 0) or (FSelectedIndex > High(FSorted)) then
    Exit;
  P := FSorted[FSelectedIndex];
  lblDetailName.Caption := P.Name;
  lblDetailAddress.Caption := P.Address + ' - ' + P.District;
  lblDetailDistance.Caption := Glyph($E81D) + ' ' + FormatDistance(P.DistanceKm) + ' de distância';
  lblDetailHours.Caption := Glyph($E823) + ' Funcionamento: ' + P.Hours;
  pbDetailIcon.Invalidate;
  pbDetailFav.Invalidate;
end;

function TForm1.IsFavorite(const Name: string): Boolean;
begin
  Result := FFavorites.IndexOf(Name) >= 0;
end;

procedure TForm1.pbDetailIconPaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
  CX, CY: Integer;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  CX := R.Width div 2;
  CY := R.Height div 2;
  PB.Canvas.Brush.Color := clPinYellow;
  PB.Canvas.Pen.Style := psClear;
  PB.Canvas.Ellipse(R);
  DrawCarIcon(PB.Canvas, CX, CY, R.Width - 18, clBlack);
end;

procedure TForm1.pbDetailFavPaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
  Fav: Boolean;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  Fav := (FSelectedIndex >= 0) and (FSelectedIndex <= High(FSorted)) and
    IsFavorite(FSorted[FSelectedIndex].Name);
  if Fav then
    DrawIconGlyph(PB.Canvas, R.Width div 2, R.Height div 2, $E735, 16, clPinYellow)
  else
    DrawIconGlyph(PB.Canvas, R.Width div 2, R.Height div 2, $E734, 16, clTextSecondary);
end;

procedure TForm1.pbDetailFavClick(Sender: TObject);
var
  Name: string;
begin
  if (FSelectedIndex < 0) or (FSelectedIndex > High(FSorted)) then
    Exit;
  Name := FSorted[FSelectedIndex].Name;
  if IsFavorite(Name) then
    FFavorites.Delete(FFavorites.IndexOf(Name))
  else
    FFavorites.Add(Name);
  pbDetailFav.Invalidate;
end;

function TForm1.BuildDirectionsURL(const P: TTaxiPoint): string;
begin
  Result := Format('https://www.google.com/maps/dir/?api=1&destination=%s,%s',
    [FloatToStr(P.Lat, TFormatSettings.Invariant), FloatToStr(P.Lon, TFormatSettings.Invariant)]);
end;

procedure TForm1.pbBtnDirectionsPaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
  S: string;
  TS: TSize;
  TextX: Integer;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  DrawRoundRectFilled(PB.Canvas, R, 8, clAccent, clNone);
  S := 'Como chegar';
  PB.Canvas.Font.Name := 'Segoe UI';
  PB.Canvas.Font.Height := -13;
  PB.Canvas.Font.Color := clWhite;
  PB.Canvas.Brush.Style := bsClear;
  TS := PB.Canvas.TextExtent(S);
  TextX := R.Left + (R.Width - TS.cx - 22) div 2;
  DrawIconGlyph(PB.Canvas, TextX + 8, R.Height div 2, $E8AB, 14, clWhite);
  PB.Canvas.TextOut(TextX + 22, (R.Height - TS.cy) div 2, S);
end;

procedure TForm1.pbBtnDirectionsClick(Sender: TObject);
begin
  if (FSelectedIndex < 0) or (FSelectedIndex > High(FSorted)) then
    Exit;
  ShellExecute(0, 'open', PChar(BuildDirectionsURL(FSorted[FSelectedIndex])), nil, nil, SW_SHOWNORMAL);
end;

procedure TForm1.pbBtnSharePaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
  S: string;
  TS: TSize;
  TextX: Integer;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  DrawRoundRectFilled(PB.Canvas, R, 8, clCardBg, clCardBorder, 1);
  S := 'Compartilhar';
  PB.Canvas.Font.Name := 'Segoe UI';
  PB.Canvas.Font.Height := -13;
  PB.Canvas.Font.Color := clWhite;
  PB.Canvas.Brush.Style := bsClear;
  TS := PB.Canvas.TextExtent(S);
  TextX := R.Left + (R.Width - TS.cx - 22) div 2;
  DrawIconGlyph(PB.Canvas, TextX + 8, R.Height div 2, $E72D, 14, clWhite);
  PB.Canvas.TextOut(TextX + 22, (R.Height - TS.cy) div 2, S);
end;

procedure TForm1.pbBtnShareClick(Sender: TObject);
var
  P: TTaxiPoint;
begin
  if (FSelectedIndex < 0) or (FSelectedIndex > High(FSorted)) then
    Exit;
  P := FSorted[FSelectedIndex];
  Clipboard.AsText := Format('%s - %s, %s (%s)', [P.Name, P.Address, P.District,
    FormatDistance(P.DistanceKm)]);
  SetTemporaryStatus('Copiado para a área de transferência');
end;

procedure TForm1.pbRefreshPaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  DrawIconGlyph(PB.Canvas, R.Width div 2, R.Height div 2, $E72C, 16, clTextSecondary);
end;

procedure TForm1.pbRefreshClick(Sender: TObject);
begin
  if not FHasLocation then
    Exit;
  ComputeAndShowResults(FUserLat, FUserLon, FLastIsCEP, FLastQueryLabel);
  SetTemporaryStatus('Atualizado agora');
end;

procedure TForm1.lbResultsClick(Sender: TObject);
begin
  if lbResults.ItemIndex >= 0 then
    SelectResult(lbResults.ItemIndex);
end;

procedure TForm1.lbResultsDrawItem(Control: TWinControl; Index: Integer; Rect: TRect;
  State: TOwnerDrawState);
var
  LB: TListBox;
  Card: TRect;
  Selected: Boolean;
  P: TTaxiPoint;
  IconCX, IconCY: Integer;
  TextLeft: Integer;
begin
  LB := Control as TListBox;
  Selected := Index = FSelectedIndex;

  LB.Canvas.Brush.Color := clSidebarBg;
  LB.Canvas.FillRect(Rect);

  Card := System.Types.Rect(Rect.Left + 16, Rect.Top + 4, Rect.Right - 16, Rect.Bottom - 4);

  if Selected then
    DrawRoundRectFilled(LB.Canvas, Card, 10, clCardBgHover, clAccent, 2)
  else
    DrawRoundRectFilled(LB.Canvas, Card, 10, clCardBg, clNone);

  if (Index < 0) or (Index > High(FSorted)) then
    Exit;
  P := FSorted[Index];

  IconCX := Card.Left + 34;
  IconCY := Card.Top + Card.Height div 2;
  LB.Canvas.Brush.Color := clPinYellow;
  LB.Canvas.Pen.Style := psClear;
  LB.Canvas.Ellipse(IconCX - 22, IconCY - 22, IconCX + 22, IconCY + 22);
  DrawCarIcon(LB.Canvas, IconCX, IconCY, 26, clBlack);

  TextLeft := Card.Left + 68;

  LB.Canvas.Brush.Style := bsClear;
  LB.Canvas.Font.Name := 'Segoe UI Semibold';
  LB.Canvas.Font.Height := -14;
  LB.Canvas.Font.Color := clWhite;
  LB.Canvas.TextOut(TextLeft, Card.Top + 12, P.Name);

  LB.Canvas.Font.Name := 'Segoe UI';
  LB.Canvas.Font.Height := -12;
  LB.Canvas.Font.Color := clTextSecondary;
  LB.Canvas.TextOut(TextLeft, Card.Top + 34, P.Address + ' - ' + P.District);

  LB.Canvas.Font.Name := 'Segoe Fluent Icons';
  LB.Canvas.Font.Height := -12;
  LB.Canvas.Font.Color := TColor($00F5A040);
  LB.Canvas.TextOut(TextLeft, Card.Top + 56, Glyph($E81D) + ' ' + FormatDistance(P.DistanceKm));

  DrawIconGlyph(LB.Canvas, Card.Right - 20, IconCY, $E76C, 12, clTextSecondary);
end;

procedure TForm1.pbMapPaint(Sender: TObject);
var
  PB: TPaintBox;
  R: TRect;
  MinLat, MaxLat, MinLon, MaxLon, LatSpan, LonSpan: Double;
  Count, I: Integer;
  Margin: Integer;

  function ProjectX(Lon: Double): Integer;
  begin
    Result := Margin + Round((Lon - MinLon) / LonSpan * (R.Width - 2 * Margin));
  end;

  function ProjectY(Lat: Double): Integer;
  begin
    Result := Margin + Round((MaxLat - Lat) / LatSpan * (R.Height - 2 * Margin));
  end;

var
  UX, UY, PX, PY, Rad: Integer;
begin
  PB := Sender as TPaintBox;
  R := PB.ClientRect;
  Margin := 70;

  PB.Canvas.Brush.Color := clMapBg;
  PB.Canvas.Pen.Style := psClear;
  PB.Canvas.FillRect(R);

  PB.Canvas.Pen.Style := psSolid;
  PB.Canvas.Pen.Color := TColor($00221E1B);
  PB.Canvas.Pen.Width := 1;
  for I := 1 to 7 do
  begin
    PB.Canvas.MoveTo(0, I * R.Height div 8);
    PB.Canvas.LineTo(R.Width, I * R.Height div 8 - 40);
  end;
  for I := 1 to 9 do
  begin
    PB.Canvas.MoveTo(I * R.Width div 10, 0);
    PB.Canvas.LineTo(I * R.Width div 10 - 30, R.Height);
  end;

  SetLength(FPinHits, 0);

  if not FHasLocation then
  begin
    PB.Canvas.Font.Name := 'Segoe UI';
    PB.Canvas.Font.Height := -14;
    PB.Canvas.Font.Color := clTextSecondary;
    PB.Canvas.Brush.Style := bsClear;
    PB.Canvas.TextOut(R.Left + (R.Width - PB.Canvas.TextWidth(
      'Informe um CEP ou use sua localização atual')) div 2, R.Height div 2 - 8,
      'Informe um CEP ou use sua localização atual');
    Exit;
  end;

  Count := Min(6, Length(FSorted));

  MinLat := FUserLat; MaxLat := FUserLat;
  MinLon := FUserLon; MaxLon := FUserLon;
  for I := 0 to Count - 1 do
  begin
    MinLat := Min(MinLat, FSorted[I].Lat);
    MaxLat := Max(MaxLat, FSorted[I].Lat);
    MinLon := Min(MinLon, FSorted[I].Lon);
    MaxLon := Max(MaxLon, FSorted[I].Lon);
  end;

  LatSpan := Max(0.01, (MaxLat - MinLat)) * 1.5 / FMapZoom;
  LonSpan := Max(0.01, (MaxLon - MinLon)) * 1.5 / FMapZoom;
  MinLat := (MinLat + MaxLat) / 2 - LatSpan / 2;
  MaxLat := MinLat + LatSpan;
  MinLon := (MinLon + MaxLon) / 2 - LonSpan / 2;

  for I := 0 to Count - 1 do
  begin
    PX := ProjectX(FSorted[I].Lon);
    PY := ProjectY(FSorted[I].Lat);
    if I = FSelectedIndex then
      Rad := 22
    else
      Rad := 17;

    PB.Canvas.Brush.Color := clPinShadow;
    PB.Canvas.Pen.Style := psClear;
    PB.Canvas.Ellipse(PX - Rad, PY - Rad + 3, PX + Rad, PY + Rad + 5);

    PB.Canvas.Brush.Color := clPinYellow;
    if I = FSelectedIndex then
    begin
      PB.Canvas.Pen.Style := psSolid;
      PB.Canvas.Pen.Color := clWhite;
      PB.Canvas.Pen.Width := 2;
    end
    else
      PB.Canvas.Pen.Style := psClear;
    PB.Canvas.Ellipse(PX - Rad, PY - Rad, PX + Rad, PY + Rad);
    DrawCarIcon(PB.Canvas, PX, PY, Rad + 6, clBlack);

    SetLength(FPinHits, Length(FPinHits) + 1);
    FPinHits[High(FPinHits)].Rect := System.Types.Rect(PX - Rad, PY - Rad, PX + Rad, PY + Rad);
    FPinHits[High(FPinHits)].PointIndex := I;
  end;

  UX := ProjectX(FUserLon);
  UY := ProjectY(FUserLat);
  PB.Canvas.Brush.Color := TColor($00402A18);
  PB.Canvas.Pen.Style := psClear;
  PB.Canvas.Ellipse(UX - 30, UY - 30, UX + 30, UY + 30);
  PB.Canvas.Brush.Color := clAccent;
  PB.Canvas.Ellipse(UX - 11, UY - 11, UX + 11, UY + 11);
  PB.Canvas.Brush.Color := clWhite;
  PB.Canvas.Ellipse(UX - 5, UY - 5, UX + 5, UY + 5);
end;

procedure TForm1.pbMapMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
  X, Y: Integer);
var
  I: Integer;
  Pt: TPoint;
begin
  Pt := System.Types.Point(X, Y);
  for I := 0 to High(FPinHits) do
    if PtInRect(FPinHits[I].Rect, Pt) then
    begin
      SelectResult(FPinHits[I].PointIndex);
      Exit;
    end;
end;

end.
