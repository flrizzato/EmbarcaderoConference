program ComponentsDemo;

{ CONSOLE}
{-}

{ *.res}

uses
  Winapi.Windows,
  System.SysUtils,
  uComponentsOwnership in 'uComponentsOwnership.pas';

procedure LimparConsole;
var
  StdOut: THandle;
  CSBI: TConsoleScreenBufferInfo;
  Coord: TCoord;
  CharsWritten: DWORD;
  ConsoleSize: DWORD;
begin
  StdOut := GetStdHandle(STD_OUTPUT_HANDLE);
  if (StdOut = 0) or (StdOut = INVALID_HANDLE_VALUE) then
    Exit;
  if not GetConsoleScreenBufferInfo(StdOut, CSBI) then
    Exit;
  ConsoleSize := DWORD(CSBI.dwSize.X) * DWORD(CSBI.dwSize.Y);
  Coord.X := 0;
  Coord.Y := 0;
  FillConsoleOutputCharacter(StdOut, ' ', ConsoleSize, Coord, CharsWritten);
  FillConsoleOutputAttribute(StdOut, CSBI.wAttributes, ConsoleSize, Coord, CharsWritten);
  SetConsoleCursorPosition(StdOut, Coord);
end;

procedure InicializarConsole;
begin
  IsConsole := True;
  {-}
  if (GetStdHandle(STD_OUTPUT_HANDLE) = 0) or (GetStdHandle(STD_OUTPUT_HANDLE) = INVALID_HANDLE_VALUE) then
  begin
    if not AttachConsole(ATTACH_PARENT_PROCESS) then
      AllocConsole;
  end;
  {+}
end;

function LerLinha(out S: string): Boolean;
var
  Buffer: string;
begin
  S := '';
  Result := False;
  try
    {-}
    Readln(Buffer);
    if IOResult = 0 then
    begin
      S := Trim(Buffer);
      Result := True;
    end;
    {+}
  except
    on E: Exception do
      Result := False;
  end;
end;

procedure PausarEFinalizar;
var
  Dummy: string;
begin
  Writeln;
  Writeln('========================================================================');
  Write('Pressione ENTER para encerrar e abrir o relatorio do FastMM...');
  LerLinha(Dummy);
end;

procedure ExibirCabecalho;
begin
  Writeln('========================================================================');
  Writeln('  EMBARCADERO CONFERENCE 2026 - DEMO 06: VCL COMPONENTS & OWNERSHIP');
  Writeln('  Palestrante: Weslley Capelari');
  Writeln('========================================================================');
end;

function ExecutarSubMenu(OpcaoExemplo: Integer): Boolean;
var
  SubOpcao: string;
  NomeExemplo: string;
begin
  Result := False;
  case OpcaoExemplo of
    1: NomeExemplo := '1. Campo Interno Nao Liberado no Destroy';
    2: NomeExemplo := '2. RemoveComponent Desfaz o Ownership';
    3: NomeExemplo := '3. Componentes Orfaos em Array vs Container';
  else
    Exit;
  end;

  LimparConsole;
  ExibirCabecalho;
  Writeln('  Exemplo Selecionado: ', NomeExemplo);
  Writeln('------------------------------------------------------------------------');
  Writeln('  [L] Executar versao LEAK (Gera Vazamento de Memoria)');
  Writeln('  [F] Executar versao FIX  (Codigo Seguro e Corrigido)');
  Writeln('  [V] Voltar ao Menu Principal');
  Writeln('------------------------------------------------------------------------');
  Write('  Escolha o modo de execucao [L / F / V]: ');
  
  if not LerLinha(SubOpcao) then
    Exit;

  SubOpcao := UpperCase(SubOpcao);

  if (SubOpcao = 'V') or (SubOpcao = '0') or (SubOpcao = '') then
    Exit;

  LimparConsole;
  ExibirCabecalho;
  Writeln('  Exemplo: ', NomeExemplo);
  Writeln('------------------------------------------------------------------------');

  if (SubOpcao = 'L') or (SubOpcao = '1') or (SubOpcao = 'LEAK') then
  begin
    Writeln('>> EXECUTANDO VERSAO [LEAK]...');
    Writeln;
    try
      case OpcaoExemplo of
        1: TComponentsOwnershipDemo.Leak_CampoInternoNaoLiberado;
        2: TComponentsOwnershipDemo.Leak_RemoveComponentSemLiberar;
        3: TComponentsOwnershipDemo.Leak_ComponentesOrfaosEmArray;
      end;
    except
      on E: Exception do
        Writeln('  [AVISO] Excecao tratada no Hub: ', E.ClassName, ' - ', E.Message);
    end;
    Writeln;
    Writeln('>> VAZAMENTO GERADO COM SUCESSO NA MEMORIA!');
    PausarEFinalizar;
    Result := True;
  end
  else if (SubOpcao = 'F') or (SubOpcao = '2') or (SubOpcao = 'FIX') then
  begin
    Writeln('>> EXECUTANDO VERSAO [FIX]...');
    Writeln;
    try
      case OpcaoExemplo of
        1: TComponentsOwnershipDemo.Fix_CampoInternoLiberado;
        2: TComponentsOwnershipDemo.Fix_RemoveComponentComLiberar;
        3: TComponentsOwnershipDemo.Fix_ComponentesComOwnerUnico;
      end;
    except
      on E: Exception do
        Writeln('  [AVISO] Excecao tratada no Hub: ', E.ClassName, ' - ', E.Message);
    end;
    Writeln('>> CODIGO SEGURO: NENHUM VAZAMENTO GERADO!');
    PausarEFinalizar;
    Result := True;
  end
  else
  begin
    Writeln('Opcao invalida!');
    Sleep(1000);
  end;
end;

procedure ExecutarHub;
var
  InputOpcao: string;
  Opcao: Integer;
begin
  while True do
  begin
    LimparConsole;
    ExibirCabecalho;
    Writeln('  [1] Campo Interno Nao Liberado no Destroy');
    Writeln('  [2] RemoveComponent Desfaz o Ownership (Filho Orfao)');
    Writeln('  [3] Componentes Orfaos em Array vs Container Dono');
    Writeln('  [0] Sair do Programa');
    Writeln('========================================================================');
    Write('  Digite o numero do exemplo desejado [0-3]: ');
    
    if not LerLinha(InputOpcao) then
      Break;

    if (InputOpcao = '0') or (UpperCase(InputOpcao) = 'S') or (UpperCase(InputOpcao) = 'Q') or (UpperCase(InputOpcao) = 'SAIR') then
    begin
      Writeln;
      Writeln('Encerrando aplicacao...');
      Break;
    end;

    if TryStrToInt(InputOpcao, Opcao) and (Opcao in [1..3]) then
    begin
      if ExecutarSubMenu(Opcao) then
        Break;
    end
    else
    begin
      Writeln('Opcao invalida! Digite um numero de 0 a 3.');
      Sleep(700);
    end;
  end;
end;

begin
  InicializarConsole;
  ReportMemoryLeaksOnShutdown := True;

  try
    ExecutarHub;
  except
    on E: Exception do
      Writeln(E.ClassName, ': ', E.Message);
  end;

  IsConsole := False;
end.
