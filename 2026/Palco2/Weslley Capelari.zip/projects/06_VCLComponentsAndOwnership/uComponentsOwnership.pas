unit uComponentsOwnership;


{\-}
{\ UNSAFE_TYPECAST OFF}
interface

uses
  System.SysUtils, System.Classes, System.Generics.Collections;

type
  // Ownership (Owner) s� cuida da libera��o do PR�PRIO objeto � jamais dos
  // campos internos que ele mesmo aloca. Isso � responsabilidade do Destroy
  // de cada classe. As duas classes abaixo s�o id�nticas, exceto pelo Destroy.

  // BUG: aloca FLog no construtor, mas "esquece" de liber�-lo no Destroy.
  TRegistroComLeak = class(TComponent)
  private
    FLog: TStringList;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
    procedure RegistrarAcesso(const AUsuario: string);
  end;

  // CORRIGIDO: mesmo comportamento, mas libera FLog corretamente no Destroy.
  TRegistroCorrigido = class(TComponent)
  private
    FLog: TStringList;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
    procedure RegistrarAcesso(const AUsuario: string);
  end;

  TComponentsOwnershipDemo = class
  public
    // Exemplo 1: Campo interno de um TComponent esquecido no Destroy
    class procedure Leak_CampoInternoNaoLiberado;
    class procedure Fix_CampoInternoLiberado;

    // Exemplo 2: RemoveComponent desfaz o v�nculo de Ownership
    class procedure Leak_RemoveComponentSemLiberar;
    class procedure Fix_RemoveComponentComLiberar;

    // Exemplo 3: Componentes �rf�os guardados em uma lista simples
    class procedure Leak_ComponentesOrfaosEmArray;
    class procedure Fix_ComponentesComOwnerUnico;
  end;

implementation

{ TRegistroComLeak }

constructor TRegistroComLeak.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FLog := TStringList.Create;
end;

destructor TRegistroComLeak.Destroy;
begin
  // ATEN��O: o Owner libera a INST�NCIA de TRegistroComLeak certinho, mas
  // NUNCA sabe que existe uma TStringList escondida dentro dela. Sem um
  // FLog.Free aqui, o Owner.Free "parece" ter limpado tudo e o leak
  // continua invis�vel at� voc� olhar o relat�rio do FastMM.
  inherited Destroy;
end;

procedure TRegistroComLeak.RegistrarAcesso(const AUsuario: string);
begin
  FLog.Add(Format('[%s] acesso registrado', [AUsuario]));
end;

{ TRegistroCorrigido }

constructor TRegistroCorrigido.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FLog := TStringList.Create;
end;

destructor TRegistroCorrigido.Destroy;
begin
  FLog.Free; // Cada campo alocado pela classe � responsabilidade da pr�pria classe.
  inherited Destroy;
end;

procedure TRegistroCorrigido.RegistrarAcesso(const AUsuario: string);
begin
  FLog.Add(Format('[%s] acesso registrado', [AUsuario]));
end;

{ TComponentsOwnershipDemo }

class procedure TComponentsOwnershipDemo.Leak_CampoInternoNaoLiberado;
var
  Owner: TComponent;
  Registro: TRegistroComLeak;
begin
  Writeln('  [LEAK] Executando Leak_CampoInternoNaoLiberado...');
  Owner := TComponent.Create(nil);
  try
    Registro := TRegistroComLeak.Create(Owner);
    Registro.RegistrarAcesso('weslley');
    // Owner tem dono corretamente atribu�do � o Owner.Free VAI destruir
    // Registro. O vazamento n�o � de Ownership, � do FLog "esquecido"
    // dentro do Destroy de TRegistroComLeak (veja a classe acima).
  finally
    Owner.Free; // Libera Owner + a inst�ncia de Registro, mas o FLog interno vaza.
  end;
end;

class procedure TComponentsOwnershipDemo.Fix_CampoInternoLiberado;
var
  Owner: TComponent;
  Registro: TRegistroCorrigido;
begin
  Writeln('  [FIX] Executando Fix_CampoInternoLiberado...');
  Owner := TComponent.Create(nil);
  try
    Registro := TRegistroCorrigido.Create(Owner);
    Registro.RegistrarAcesso('weslley');
    // Owner cuida de destruir Registro; o Destroy de TRegistroCorrigido
    // cuida de liberar o pr�prio FLog. Cada n�vel libera o que alocou.
  finally
    Owner.Free; // Libera Owner + Registro + FLog, em cascata, sem vazar nada.
  end;
end;

class procedure TComponentsOwnershipDemo.Leak_RemoveComponentSemLiberar;
var
  Owner, Filho: TComponent;
begin
  Writeln('  [LEAK] Executando Leak_RemoveComponentSemLiberar...');
  Owner := TComponent.Create(nil);
  try
    Filho := TComponent.Create(Owner);
    Filho.Name := 'FilhoDestacado';

    // RemoveComponent tira o Filho da lista interna de Components do Owner.
    // A partir daqui, Owner.Free N�O destr�i mais este Filho � ele virou �rf�o!
    Owner.RemoveComponent(Filho);
    // VAZAMENTO: ningu�m mais chama Filho.Free depois do RemoveComponent.
  finally
    Owner.Free; // Libera s� o Owner. O Filho, j� destacado, fica perdido no heap.
  end;
end;

class procedure TComponentsOwnershipDemo.Fix_RemoveComponentComLiberar;
var
  Owner, Filho: TComponent;
begin
  Writeln('  [FIX] Executando Fix_RemoveComponentComLiberar...');
  Owner := TComponent.Create(nil);
  try
    Filho := TComponent.Create(Owner);
    Filho.Name := 'FilhoDestacado';

    Owner.RemoveComponent(Filho);
    try
      // Regra de ouro: a partir do RemoveComponent, o Filho voltou a ser SUA
      // responsabilidade manual � trate-o como qualquer objeto sem Owner.
      Writeln('    Filho removido do Owner e liberado manualmente.');
    finally
      Filho.Free;
    end;
  finally
    Owner.Free;
  end;
end;

class procedure TComponentsOwnershipDemo.Leak_ComponentesOrfaosEmArray;
var
  Componentes: TArray<TComponent>;
  I: Integer;
begin
  Writeln('  [LEAK] Executando Leak_ComponentesOrfaosEmArray...');
  SetLength(Componentes, 3);
  for I := 0 to High(Componentes) do
  begin
    // Owner = nil: cada componente criado aqui � independente e n�o tem
    // ningu�m que o liberar� automaticamente.
    Componentes[I] := TComponent.Create(nil);
    Componentes[I].Name := Format('Orfao%d', [I]);
  end;
  // VAZAMENTO: o array sai de escopo e os 3 TComponent ficam perdidos no heap.
end;

class procedure TComponentsOwnershipDemo.Fix_ComponentesComOwnerUnico;
var
  Owner: TComponent;
  I: Integer;
  Filho: TComponent;
begin
  Writeln('  [FIX] Executando Fix_ComponentesComOwnerUnico...');
  // PADR�O RECOMENDADO: em vez de guardar componentes soltos em um array,
  // crie um �nico Owner "container" e deixe o Delphi cascatear a libera��o.
  Owner := TComponent.Create(nil);
  try
    for I := 0 to 2 do
    begin
      Filho := TComponent.Create(Owner);
      Filho.Name := Format('Filho%d', [I]);
    end;
  finally
    Owner.Free; // Libera Owner e os 3 filhos em cascata � zero c�digo extra.
  end;
end;

end.

