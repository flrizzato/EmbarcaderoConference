unit uCollectionsOwnership;


{\-}
{\ UNSAFE_TYPECAST OFF}
{ UNSAFE_TYPECAST OFF}

interface

uses
  System.SysUtils, System.Classes, System.Generics.Collections;

type
  TProduto = class
  private
    FID: Integer;
    FDescricao: string;
  public
    constructor Create(AID: Integer; const ADescricao: string);
    destructor Destroy; override;
  end;

  TCollectionsOwnershipDemo = class
  public
    // Exemplo 1: TList Generico vs TObjectList
    class procedure Leak_TListGenerico;
    class procedure Fix_TObjectListOwnsObjects;

    // Exemplo 2: TComponent sem Owner (Owner = nil) vs com Owner
    class procedure Leak_ComponentSemOwner;
    class procedure Fix_ComponentComOwner;

    // Exemplo 3: TDictionary vs TObjectDictionary
    class procedure Leak_TDictionaryValores;
    class procedure Fix_TDictionaryValores;
  end;

implementation

{ TProduto }

constructor TProduto.Create(AID: Integer; const ADescricao: string);
begin
  inherited Create;
  FID := AID;
  FDescricao := ADescricao;
  Writeln('    [TProduto] Criado: ID ', FID, ' - ', FDescricao);
end;

destructor TProduto.Destroy;
begin
  Writeln('    [TProduto] DESTRUIDO com sucesso: ID ', FID, ' - ', FDescricao);
  inherited Destroy;
end;

{ TCollectionsOwnershipDemo }

class procedure TCollectionsOwnershipDemo.Leak_TListGenerico;
var
  Lista: TList<TProduto>;
begin
  Writeln('  [LEAK] Executando Leak_TListGenerico...');
  Lista := TList<TProduto>.Create;
  try
    Lista.Add(TProduto.Create(1, 'Notebook Dell'));
    Lista.Add(TProduto.Create(2, 'Mouse Logitech'));
    Writeln('  -> Adicionados 2 produtos a TList<TProduto>.');
    Writeln('  -> Liberando a lista com Lista.Free...');
  finally
    Lista.Free; // Libera a lista, mas OS OBJETOS TProduto CONTINUAM NO HEAP!
    Writeln('  -> ATENCAO: A TList foi destruida, mas os objetos TProduto VAZARAM no Heap!');
  end;
end;

class procedure TCollectionsOwnershipDemo.Fix_TObjectListOwnsObjects;
var
  Lista: TObjectList<TProduto>;
begin
  Writeln('  [FIX] Executando Fix_TObjectListOwnsObjects...');
  // TObjectList com OwnsObjects = True gerencia o ciclo de vida dos itens
  Lista := TObjectList<TProduto>.Create(True);
  try
    Lista.Add(TProduto.Create(10, 'Teclado Mecanico'));
    Lista.Add(TProduto.Create(11, 'Monitor 4K'));
    Writeln('  -> Adicionados 2 produtos a TObjectList<TProduto>(True).');
    Writeln('  -> Liberando a lista com Lista.Free...');
  finally
    Lista.Free; // Libera a lista E DESTROi cada TProduto contido nela
    Writeln('  -> Lista e todos os itens internos foram destruidos automaticamente.');
  end;
end;

class procedure TCollectionsOwnershipDemo.Leak_ComponentSemOwner;
var
  CompOrfao: TComponent;
begin
  Writeln('  [LEAK] Executando Leak_ComponentSemOwner...');
  // Passar nil no construtor significa que nao ha Owner para gerenciar a destruicao
  CompOrfao := TComponent.Create(nil);
  CompOrfao.Name := 'ComponenteSemDono';
  Writeln('  -> TComponent criado com Owner = nil (Ponteiro: $', IntToHex(NativeUInt(CompOrfao), 8), ').');
  Writeln('  -> VAZAMENTO: Ninguem chamou CompOrfao.Free e o objeto ficou orfao!');
end;

class procedure TCollectionsOwnershipDemo.Fix_ComponentComOwner;
var
  Dono: TComponent;
  Filho: TComponent;
begin
  Writeln('  [FIX] Executando Fix_ComponentComOwner (Hierarquia TComponent)...');
  Dono := TComponent.Create(nil);
  try
    // Filho recebe Dono como AOwner
    Filho := TComponent.Create(Dono);
    Filho.Name := 'ComponenteFilho';
    Writeln('  -> Componente Filho criado com Dono associado como seu Owner.');
    Writeln('  -> Liberando o Dono...');
  finally
    Dono.Free; // Ao destruir o Dono, o mecanismo de Components[] destroi o Filho!
    Writeln('  -> Dono e Filho destruidos em cascata com sucesso!');
  end;
end;

class procedure TCollectionsOwnershipDemo.Leak_TDictionaryValores;
var
  Mapa: TDictionary<string, TProduto>;
begin
  Writeln('  [LEAK] Executando Leak_TDictionaryValores...');
  Mapa := TDictionary<string, TProduto>.Create;
  try
    Mapa.Add('PROD_A', TProduto.Create(100, 'Cadeira Gamer'));
    Mapa.Add('PROD_B', TProduto.Create(101, 'Mesa Regulavel'));
    Writeln('  -> Produtos adicionados ao TDictionary padrao.');
  finally
    Mapa.Free;
    Writeln('  -> TDictionary destruido, porem os objetos nos Valores VAZARAM!');
  end;
end;

class procedure TCollectionsOwnershipDemo.Fix_TDictionaryValores;
var
  Mapa: TObjectDictionary<string, TProduto>;
begin
  Writeln('  [FIX] Executando Fix_TDictionaryValores (Usando TObjectDictionary)...');
  // TObjectDictionary com [doOwnsValues] assume a destruicao dos objetos
  Mapa := TObjectDictionary<string, TProduto>.Create([doOwnsValues]);
  try
    Mapa.Add('PROD_A', TProduto.Create(200, 'Cadeira Ergonomica'));
    Mapa.Add('PROD_B', TProduto.Create(201, 'Mesa Eletrica'));
    Writeln('  -> Produtos adicionados ao TObjectDictionary com [doOwnsValues].');
  finally
    Mapa.Free;
    Writeln('  -> TObjectDictionary e todos os objetos de valores destruidos!');
  end;
end;

end.

