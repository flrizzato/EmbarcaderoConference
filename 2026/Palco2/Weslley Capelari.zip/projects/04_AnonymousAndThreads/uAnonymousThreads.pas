﻿unit uAnonymousThreads;


{\-}
{\ UNSAFE_TYPECAST OFF}
{ UNSAFE_TYPECAST OFF}

interface

uses
  System.SysUtils, System.Classes, System.Threading;

type
  TWorkerData = class
  public
    Payload: string;
    constructor Create(const APayload: string);
    destructor Destroy; override;
  end;

  TMyCustomThread = class(TThread)
  protected
    procedure Execute; override;
  end;

  TThreadsDemo = class
  public
    // Exemplo 1: TThread customizada sem FreeOnTerminate
    class procedure Leak_ThreadSemFreeOnTerminate;
    class procedure Fix_ThreadComFreeOnTerminate;

    // Exemplo 2: Objeto capturado em Anonymous Thread
    class procedure Leak_ObjetoCapturadoEmThread;
    class procedure Fix_ObjetoCapturadoEmThread;

    // Exemplo 3: TTask Assincrona capturando objetos sem bloco seguro
    class procedure Leak_TaskComObjetoNaoLiberado;
    class procedure Fix_TaskComObjetoLiberado;
  end;

implementation

{ TWorkerData }

constructor TWorkerData.Create(const APayload: string);
begin
  inherited Create;
  Payload := APayload;
  Writeln('    [TWorkerData] Criado com payload: ', Payload, ' em $', IntToHex(NativeUInt(Self), 8));
end;

destructor TWorkerData.Destroy;
begin
  Writeln('    [TWorkerData] DESTRUIDO com sucesso: ', Payload);
  inherited Destroy;
end;

{ TMyCustomThread }

procedure TMyCustomThread.Execute;
begin
  Writeln('    [TMyCustomThread] Executando em segundo plano...');
  Sleep(250);
  Writeln('    [TMyCustomThread] Concluido.');
end;

{ TThreadsDemo }

class procedure TThreadsDemo.Leak_ThreadSemFreeOnTerminate;
var
  Worker: TMyCustomThread;
begin
  Writeln('  [LEAK] Executando Leak_ThreadSemFreeOnTerminate...');
  Worker := TMyCustomThread.Create(True); // Suspended
  // FreeOnTerminate e FALSE por padrao quando herdamos de TThread!
  Worker.FreeOnTerminate := False;
  Worker.Start;
  
  Writeln('  -> Thread iniciada com FreeOnTerminate = False.');
  Writeln('  -> Aguardando conclusao da thread...');
  Sleep(350);
  // VAZAMENTO: A thread terminou, mas o objeto TMyCustomThread permanece no Heap!
  Writeln('  -> VAZAMENTO: Ninguem chamou Worker.Free apos a thread finalizar.');
end;

class procedure TThreadsDemo.Fix_ThreadComFreeOnTerminate;
var
  Worker: TMyCustomThread;
begin
  Writeln('  [FIX] Executando Fix_ThreadComFreeOnTerminate...');
  Worker := TMyCustomThread.Create(True);
  Worker.FreeOnTerminate := True; // A propria thread se destruira ao concluir Execute
  Worker.Start;

  Writeln('  -> Thread iniciada com FreeOnTerminate = True.');
  Writeln('  -> Aguardando conclusao da thread...');
  Sleep(350);
  Writeln('  -> Thread finalizou e liberou sua propria instancia da memoria.');
end;

class procedure TThreadsDemo.Leak_ObjetoCapturadoEmThread;
var
  Dados: TWorkerData;
begin
  Writeln('  [LEAK] Executando Leak_ObjetoCapturadoEmThread...');
  Dados := TWorkerData.Create('Dados Assincronos sem Liberacao');

  TThread.CreateAnonymousThread(
    procedure
    begin
      Sleep(150);
      Writeln('    [Thread Anônima] Processando: ', Dados.Payload);
      // VAZAMENTO: A Thread consome os dados mas nao os libera!
    end
  ).Start;

  Writeln('  -> Anonymous Thread disparada com variavel capturada na closure.');
  Writeln('  -> Aguardando execucao...');
  Sleep(250);
  Writeln('  -> VAZAMENTO: Objeto TWorkerData permaneceu retido no Heap!');
end;

class procedure TThreadsDemo.Fix_ObjetoCapturadoEmThread;
var
  Dados: TWorkerData;
begin
  Writeln('  [FIX] Executando Fix_ObjetoCapturadoEmThread (Ownership na Thread)...');
  Dados := TWorkerData.Create('Dados Assincronos com try..finally na Thread');

  TThread.CreateAnonymousThread(
    procedure
    begin
      try
        Sleep(150);
        Writeln('    [Thread Anonima] Processando com seguranca: ', Dados.Payload);
      finally
        // A rotina assincrona assume a responsabilidade de dar Free!
        Dados.Free;
      end;
    end
  ).Start;

  Writeln('  -> Anonymous Thread disparada com try..finally interno.');
  Writeln('  -> Aguardando execucao...');
  Sleep(250);
  Writeln('  -> Objeto consumido e liberado com sucesso pela propria thread.');
end;

class procedure TThreadsDemo.Leak_TaskComObjetoNaoLiberado;
var
  Dados: TWorkerData;
  Tarefa: ITask;
begin
  Writeln('  [LEAK] Executando Leak_TaskComObjetoNaoLiberado (TTask)...');
  Dados := TWorkerData.Create('Dados em TTask sem Free');

  Tarefa := TTask.Run(
    procedure
    begin
      Sleep(150);
      Writeln('    [TTask] Executando processamento em background: ', Dados.Payload);
    end
  );

  Tarefa.Wait(1000);
  Writeln('  -> VAZAMENTO: TTask concluida, mas TWorkerData nao foi liberado!');
end;

class procedure TThreadsDemo.Fix_TaskComObjetoLiberado;
var
  Dados: TWorkerData;
  Tarefa: ITask;
begin
  Writeln('  [FIX] Executando Fix_TaskComObjetoLiberado (TTask com Free)...');
  Dados := TWorkerData.Create('Dados em TTask com Try..Finally');

  Tarefa := TTask.Run(
    procedure
    begin
      try
        Sleep(150);
        Writeln('    [TTask] Executando processamento seguro: ', Dados.Payload);
      finally
        Dados.Free;
      end;
    end
  );

  Tarefa.Wait(1000);
  Writeln('  -> TTask concluida e recurso liberado perfeitamente.');
end;

end.

