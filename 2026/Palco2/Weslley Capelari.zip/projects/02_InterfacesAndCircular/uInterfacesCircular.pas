unit uInterfacesCircular;

{-}
{ UNSAFE_TYPECAST OFF}

interface

uses
  System.SysUtils;

type
  // Interfaces para demonstrar Referencia Circular
  IFilho = interface;

  IPai = interface
    ['{11111111-1111-1111-1111-111111111111}']
    procedure SetFilho(const AFilho: IFilho);
    function GetNome: string;
  end;

  IFilho = interface
    ['{22222222-2222-2222-2222-222222222222}']
    procedure SetPai(const APai: IPai);
    function GetNome: string;
    procedure LimparPai;
  end;

  // 1. Implementacao com Vazamento por Referencia Circular Forte
  TPaiLeak = class(TInterfacedObject, IPai)
  private
    FNome: string;
    FFilho: IFilho; // Referencia Forte (Incrementa RefCount do Filho)
  public
    constructor Create(const ANome: string);
    destructor Destroy; override;
    procedure SetFilho(const AFilho: IFilho);
    function GetNome: string;
  end;

  TFilhoLeak = class(TInterfacedObject, IFilho)
  private
    FNome: string;
    FPai: IPai; // Referencia Forte (Incrementa RefCount do Pai) -> CICLO!
  public
    constructor Create(const ANome: string);
    destructor Destroy; override;
    procedure SetPai(const APai: IPai);
    function GetNome: string;
    procedure LimparPai;
  end;

  // 2. Implementacao Corrigida usando [unsafe]
  TPaiFix = class(TInterfacedObject, IPai)
  private
    FNome: string;
    FFilho: IFilho;
  public
    constructor Create(const ANome: string);
    destructor Destroy; override;
    procedure SetFilho(const AFilho: IFilho);
    function GetNome: string;
  end;

  TFilhoFix = class(TInterfacedObject, IFilho)
  private
    FNome: string;
    [unsafe] FPai: IPai; // Atributo [unsafe] impede o incremento do RefCount (Evita o ciclo)
  public
    constructor Create(const ANome: string);
    destructor Destroy; override;
    procedure SetPai(const APai: IPai);
    function GetNome: string;
    procedure LimparPai;
  end;

  TInterfacesDemo = class
  public
    // Exemplo 1: Referencia Circular entre Interfaces
    class procedure Leak_ReferenciaCircular;
    class procedure Fix_ReferenciaCircularUnsafe;

    // Exemplo 2: Quebra Manual de Ciclo de Referencias
    class procedure Leak_CicloSemQuebra;
    class procedure Fix_CicloComQuebraManual;

    // Exemplo 3: Misturar Ponteiro de Objeto e Interface
    class procedure Leak_MisturandoObjetoEInterface;
    class procedure Fix_UsoPuroInterface;
  end;

implementation

{ TPaiLeak }

constructor TPaiLeak.Create(const ANome: string);
begin
  inherited Create;
  FNome := ANome;
  Writeln('    [TPaiLeak] Criado: ', FNome);
end;

destructor TPaiLeak.Destroy;
begin
  Writeln('    [TPaiLeak] DESTRUIDO com sucesso: ', FNome);
  inherited Destroy;
end;

function TPaiLeak.GetNome: string;
begin
  Result := FNome;
end;

procedure TPaiLeak.SetFilho(const AFilho: IFilho);
begin
  FFilho := AFilho;
end;

{ TFilhoLeak }

constructor TFilhoLeak.Create(const ANome: string);
begin
  inherited Create;
  FNome := ANome;
  Writeln('    [TFilhoLeak] Criado: ', FNome);
end;

destructor TFilhoLeak.Destroy;
begin
  Writeln('    [TFilhoLeak] DESTRUIDO com sucesso: ', FNome);
  inherited Destroy;
end;

function TFilhoLeak.GetNome: string;
begin
  Result := FNome;
end;

procedure TFilhoLeak.SetPai(const APai: IPai);
begin
  FPai := APai;
end;

procedure TFilhoLeak.LimparPai;
begin
  FPai := nil;
end;

{ TPaiFix }

constructor TPaiFix.Create(const ANome: string);
begin
  inherited Create;
  FNome := ANome;
  Writeln('    [TPaiFix] Criado: ', FNome);
end;

destructor TPaiFix.Destroy;
begin
  Writeln('    [TPaiFix] DESTRUIDO com sucesso: ', FNome);
  inherited Destroy;
end;

function TPaiFix.GetNome: string;
begin
  Result := FNome;
end;

procedure TPaiFix.SetFilho(const AFilho: IFilho);
begin
  FFilho := AFilho;
end;

{ TFilhoFix }

constructor TFilhoFix.Create(const ANome: string);
begin
  inherited Create;
  FNome := ANome;
  Writeln('    [TFilhoFix] Criado: ', FNome);
end;

destructor TFilhoFix.Destroy;
begin
  Writeln('    [TFilhoFix] DESTRUIDO com sucesso: ', FNome);
  inherited Destroy;
end;

function TFilhoFix.GetNome: string;
begin
  Result := FNome;
end;

procedure TFilhoFix.SetPai(const APai: IPai);
begin
  FPai := APai;
end;

procedure TFilhoFix.LimparPai;
begin
  FPai := nil;
end;

{ TInterfacesDemo }

class procedure TInterfacesDemo.Leak_ReferenciaCircular;
var
  Pai: IPai;
  Filho: IFilho;
begin
  Writeln('  [LEAK] Executando Leak_ReferenciaCircular...');
  Pai := TPaiLeak.Create('Pai Carlos (Leak)');
  Filho := TFilhoLeak.Create('Filho Pedro (Leak)');

  // Cria o ciclo de referencias fortes (RefCount = 2 para ambos)
  Pai.SetFilho(Filho);
  Filho.SetPai(Pai);

  Writeln('  -> Pai e Filho conectados com referencias fortes mutuamente.');
  Writeln('  -> Saindo do escopo... Nenhum destruidor sera chamado!');
end;

class procedure TInterfacesDemo.Fix_ReferenciaCircularUnsafe;
var
  Pai: IPai;
  Filho: IFilho;
begin
  Writeln('  [FIX] Executando Fix_ReferenciaCircularUnsafe...');
  Pai := TPaiFix.Create('Pai Roberto (Fix)');
  Filho := TFilhoFix.Create('Filho Lucas (Fix)');

  Pai.SetFilho(Filho);
  Filho.SetPai(Pai);

  Writeln('  -> Pai e Filho conectados com [unsafe] no ponteiro pai.');
  Writeln('  -> Saindo do escopo... Ambos serao destruidos automaticamente!');
end;

class procedure TInterfacesDemo.Leak_CicloSemQuebra;
var
  Pai: IPai;
  Filho: IFilho;
begin
  Writeln('  [LEAK] Executando Leak_CicloSemQuebra...');
  Pai := TPaiLeak.Create('Pai Sem Quebra');
  Filho := TFilhoLeak.Create('Filho Sem Quebra');
  Pai.SetFilho(Filho);
  Filho.SetPai(Pai);
  Writeln('  -> Ciclo criado e descartado sem quebra manual de ponteiro.');
end;

class procedure TInterfacesDemo.Fix_CicloComQuebraManual;
var
  Pai: IPai;
  Filho: IFilho;
begin
  Writeln('  [FIX] Executando Fix_CicloComQuebraManual...');
  Pai := TPaiLeak.Create('Pai Quebra Manual');
  Filho := TFilhoLeak.Create('Filho Quebra Manual');
  Pai.SetFilho(Filho);
  Filho.SetPai(Pai);

  Writeln('  -> Executando quebra manual: Filho.LimparPai e Pai.SetFilho(nil)...');
  Filho.LimparPai;
  Pai.SetFilho(nil);
  Writeln('  -> Ciclo quebrado com sucesso. Destruidores serao acionados.');
end;

class procedure TInterfacesDemo.Leak_MisturandoObjetoEInterface;
var
  ObjPai: TPaiFix;
  IntfPai: IPai;
begin
  Writeln('  [LEAK / CONFLITO ARC] Misturando Referencias de Objeto e Interface...');
  ObjPai := TPaiFix.Create('Pai Instancia Direta');
  Writeln('  -> Objeto instanciado diretamente como classe concreta.');
  
  IntfPai := ObjPai;
  Writeln('  -> Interface temporaria assumiu a referencia. Nome: ', IntfPai.GetNome);

  IntfPai := nil;
  Writeln('  -> IntfPai := nil executado. Objeto foi destruido pelo ARC!');
  Writeln('  -> Se o desenvolvedor tentar dar Free no ObjPai depois disso, causara CRASH (Double Free)!');
end;

class procedure TInterfacesDemo.Fix_UsoPuroInterface;
var
  IntfPai: IPai;
begin
  Writeln('  [FIX] Executando Fix_UsoPuroInterface...');
  IntfPai := TPaiFix.Create('Pai Gerenciado Exclusivamente por Interface');
  Writeln('  -> Interface instanciada e consumida de forma pura: ', IntfPai.GetNome);
  Writeln('  -> Ao sair do escopo, o Delphi cuida de toda a liberacao com seguranca.');
end;

end.
