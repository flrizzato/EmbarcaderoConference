program FastMMDemo;

{$APPTYPE CONSOLE}
{$I-}

{$R *.res}

uses
  FastMM5 in 'FastMM5.pas',
  Winapi.Windows,
  System.SysUtils,
  uFastMMUsage in 'uFastMMUsage.pas';

procedure LimparConsole;
var
  StdOut: THandle;
  CSBI: TConsoleScreenBufferInfo;
  Coord: TCoord;
  CharsWritten: DWORD;
  ConsoleSize: DWORD;
begin
  StdOut := GetStdHandle(STD_OUTPUT_HANDLE);
  if (StdOut = 0) or (StdOut = INVALID_HANDLE_VALUE) then
    Exit;
  if not GetConsoleScreenBufferInfo(StdOut, CSBI) then
    Exit;
  ConsoleSize := DWORD(CSBI.dwSize.X) * DWORD(CSBI.dwSize.Y);
  Coord.X := 0;
  Coord.Y := 0;
  FillConsoleOutputCharacter(StdOut, ' ', ConsoleSize, Coord, CharsWritten);
  FillConsoleOutputAttribute(StdOut, CSBI.wAttributes, ConsoleSize, Coord, CharsWritten);
  SetConsoleCursorPosition(StdOut, Coord);
end;

procedure InicializarConsole;
begin
  IsConsole := True;
  {$I-}
  if (GetStdHandle(STD_OUTPUT_HANDLE) = 0) or (GetStdHandle(STD_OUTPUT_HANDLE) = INVALID_HANDLE_VALUE) then
  begin
    if not AttachConsole(ATTACH_PARENT_PROCESS) then
      AllocConsole;
  end;
  {$I+}
end;

function LerLinha(out S: string): Boolean;
var
  Buffer: string;
begin
  S := '';
  Result := False;
  try
    {$I-}
    Readln(Buffer);
    if IOResult = 0 then
    begin
      S := Trim(Buffer);
      Result := True;
    end;
    {$I+}
  except
    on E: Exception do
      Result := False;
  end;
end;

procedure PausarEFinalizar;
var
  Dummy: string;
begin
  Writeln;
  Writeln('========================================================================');
  Write('Pressione ENTER para encerrar e abrir o relatorio do FastMM5...');
  LerLinha(Dummy);
end;

procedure ExibirCabecalho;
begin
  Writeln('========================================================================');
  Writeln('  EMBARCADERO CONFERENCE 2026 - DEMO 05: FASTMM5 & FULL DEBUG MODE');
  Writeln('  Palestrante: Weslley Capelari');
  Writeln('========================================================================');
end;

function ExecutarSubMenu(OpcaoExemplo: Integer): Boolean;
var
  SubOpcao: string;
  NomeExemplo: string;
begin
  Result := False;
  case OpcaoExemplo of
    1: NomeExemplo := '1. Alocacao Bruta de Heap (GetMem/FreeMem) + Stack Trace';
    2: NomeExemplo := '2. Padrao RAII / Guard (Auto-Liberacao via Interface)';
    3: NomeExemplo := '3. Alocacao de Streams de Memoria (TMemoryStream)';
    4: NomeExemplo := '4. Deteccao de Use-After-Free ($80808080 pattern)';
  else
    Exit;
  end;

  LimparConsole;
  ExibirCabecalho;
  Writeln('  Exemplo Selecionado: ', NomeExemplo);
  Writeln('------------------------------------------------------------------------');
  Writeln('  [L] Executar versao LEAK (Gera Vazamento de Memoria)');
  Writeln('  [F] Executar versao FIX  (Codigo Seguro e Corrigido)');
  Writeln('  [V] Voltar ao Menu Principal');
  Writeln('------------------------------------------------------------------------');
  Write('  Escolha o modo de execucao [L / F / V]: ');
  
  if not LerLinha(SubOpcao) then
    Exit;

  SubOpcao := UpperCase(SubOpcao);

  if (SubOpcao = 'V') or (SubOpcao = '0') or (SubOpcao = '') then
    Exit;

  LimparConsole;
  ExibirCabecalho;
  Writeln('  Exemplo: ', NomeExemplo);
  Writeln('------------------------------------------------------------------------');

  if (SubOpcao = 'L') or (SubOpcao = '1') or (SubOpcao = 'LEAK') then
  begin
    Writeln('>> EXECUTANDO VERSAO [LEAK] COM FASTMM5 FULL DEBUG MODE...');
    Writeln;
    try
      case OpcaoExemplo of
        1: TFastMMDemo.Leak_GetMemBruto;
        2: TFastMMDemo.Leak_ObjetoSemGuardRAII;
        3: TFastMMDemo.Leak_MemoryStream;
        4: TFastMMDemo.Demo_UseAfterFree;
      end;
    except
      on E: Exception do
        Writeln('  [AVISO] Excecao tratada no Hub: ', E.ClassName, ' - ', E.Message);
    end;
    Writeln;
    Writeln('>> VAZAMENTO GERADO COM SUCESSO NA MEMORIA!');
    Writeln('   (O FastMM5 registrara a chamada no arquivo FastMM5_MemoryLeak_Log.txt)');
    PausarEFinalizar;
    Result := True;
  end
  else if (SubOpcao = 'F') or (SubOpcao = '2') or (SubOpcao = 'FIX') then
  begin
    Writeln('>> EXECUTANDO VERSAO [FIX]...');
    Writeln;
    try
      case OpcaoExemplo of
        1: TFastMMDemo.Fix_GetMemBruto;
        2: TFastMMDemo.Fix_ObjetoComGuardRAII;
        3: TFastMMDemo.Fix_MemoryStream;
        4: TFastMMDemo.Fix_ObjetoComGuardRAII;
      end;
    except
      on E: Exception do
        Writeln('  [AVISO] Excecao tratada no Hub: ', E.ClassName, ' - ', E.Message);
    end;
    Writeln('>> CODIGO SEGURO: NENHUM VAZAMENTO GERADO!');
    PausarEFinalizar;
    Result := True;
  end
  else
  begin
    Writeln('Opcao invalida!');
    Sleep(1000);
  end;
end;

procedure ExecutarHub;
var
  InputOpcao: string;
  Opcao: Integer;
begin
  while True do
  begin
    LimparConsole;
    ExibirCabecalho;
    Writeln('  [1] Alocacao Bruta de Heap (GetMem/FreeMem) + Stack Trace DLL');
    Writeln('  [2] Padrao RAII / Guard (Auto-Liberacao via Interface)');
    Writeln('  [3] Alocacao de Streams de Memoria (TMemoryStream)');
    Writeln('  [4] Deteccao de Use-After-Free ($80808080 pattern)');
    Writeln('  [0] Sair do Programa');
    Writeln('========================================================================');
    Write('  Digite o numero do exemplo desejado [0-4]: ');
    
    if not LerLinha(InputOpcao) then
      Break;

    if (InputOpcao = '0') or (UpperCase(InputOpcao) = 'S') or (UpperCase(InputOpcao) = 'Q') or (UpperCase(InputOpcao) = 'SAIR') then
    begin
      Writeln;
      Writeln('Encerrando aplicacao...');
      Break;
    end;

    if TryStrToInt(InputOpcao, Opcao) and (Opcao in [1..4]) then
    begin
      if ExecutarSubMenu(Opcao) then
        Break;
    end
    else
    begin
      Writeln('Opcao invalida! Digite um numero de 0 a 4.');
      Sleep(700);
    end;
  end;
end;

begin
  InicializarConsole;
  TFastMMDemo.ConfigurarFastMM5;
  ReportMemoryLeaksOnShutdown := True;

  try
    ExecutarHub;
  except
    on E: Exception do
      Writeln(E.ClassName, ': ', E.Message);
  end;

  IsConsole := False;
end.
