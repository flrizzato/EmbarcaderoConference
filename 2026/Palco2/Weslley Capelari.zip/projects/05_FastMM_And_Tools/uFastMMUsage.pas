unit uFastMMUsage;

{$I-}
{$WARN UNSAFE_CAST OFF}

interface

uses
  System.SysUtils,
  System.Classes,
  FastMM5;

type
  // Padrao RAII (Resource Acquisition Is Initialization) usando Interface no Delphi
  ILocalGuard<T: class> = interface
    ['{33333333-3333-3333-3333-333333333333}']
    function GetTarget: T;
    property Target: T read GetTarget;
  end;

  TLocalGuard<T: class> = class(TInterfacedObject, ILocalGuard<T>)
  private
    FTarget: T;
  public
    constructor Create(ATarget: T);
    destructor Destroy; override;
    function GetTarget: T;
  end;

  TFastMMDemo = class
  public
    // Inicializacao e Configuracao de Eventos do FastMM5
    class procedure ConfigurarFastMM5;

    // Exemplo 1: Alocacao de Buffer Bruto (GetMem/FreeMem)
    class procedure Leak_GetMemBruto;
    class procedure Fix_GetMemBruto;

    // Exemplo 2: Padrao RAII / Guard para Auto-Destruicao
    class procedure Leak_ObjetoSemGuardRAII;
    class procedure Fix_ObjetoComGuardRAII;

    // Exemplo 3: TMemoryStream / Buffers de I/O
    class procedure Leak_MemoryStream;
    class procedure Fix_MemoryStream;

    // Exemplo 4: Deteccao de Use-After-Free pelo FastMM5 ($80808080)
    class procedure Demo_UseAfterFree;
  end;

implementation

{ TLocalGuard<T> }

constructor TLocalGuard<T>.Create(ATarget: T);
begin
  inherited Create;
  FTarget := ATarget;
  Writeln('    [RAII Guard] Criado para gerenciar instancia em $', IntToHex(NativeUInt(FTarget), 8));
end;

destructor TLocalGuard<T>.Destroy;
begin
  if Assigned(FTarget) then
  begin
    Writeln('    [RAII Guard] Destruindo automaticamente o objeto alvo gerenciado...');
    FTarget.Free;
    FTarget := nil;
  end;
  inherited Destroy;
end;

function TLocalGuard<T>.GetTarget: T;
begin
  Result := FTarget;
end;

{ TFastMMDemo }

class procedure TFastMMDemo.ConfigurarFastMM5;
begin
  // Ativa o modo de depuracao profunda do FastMM5 com integracao a FastMM_FullDebugMode.dll
  FastMM_EnterDebugMode;

  // Redireciona os eventos de vazamento para arquivo de log detalhado
  FastMM_LogToFileEvents := [
    mmetUnexpectedMemoryLeakDetail,
    mmetUnexpectedMemoryLeakSummary,
    mmetDebugBlockDoubleFree,
    mmetDebugBlockHeaderCorruption,
    mmetDebugBlockFooterCorruption,
    mmetDebugBlockModifiedAfterFree,
    mmetVirtualMethodCallOnFreedObject
  ];

  // Configura os eventos que devem abrir mensagem na tela
  FastMM_MessageBoxEvents := [
    mmetUnexpectedMemoryLeakSummary,
    mmetDebugBlockDoubleFree,
    mmetVirtualMethodCallOnFreedObject
  ];

  // Define nome personalizado para o arquivo de log do FastMM5
  FastMM_SetEventLogFilename('FastMM5_MemoryLeak_Log.txt');
end;

class procedure TFastMMDemo.Leak_GetMemBruto;
var
  Buffer: Pointer;
begin
  Writeln('  [LEAK] Executando Leak_GetMemBruto...');
  GetMem(Buffer, 512); // Aloca 512 bytes no Heap
  Writeln('  -> Alocados 512 bytes em $', IntToHex(NativeUInt(Buffer), 8));
  Writeln('  -> O FastMM5 registrara a pilha completa (Stack Trace) da alocacao na DLL!');
  Writeln('  -> VAZAMENTO: Nao chamou FreeMem(Buffer, 512)!');
end;

class procedure TFastMMDemo.Fix_GetMemBruto;
var
  Buffer: Pointer;
begin
  Writeln('  [FIX] Executando Fix_GetMemBruto...');
  GetMem(Buffer, 512);
  try
    Writeln('  -> Alocados 512 bytes em $', IntToHex(NativeUInt(Buffer), 8));
    Writeln('  -> Manipulando memoria com seguranca...');
  finally
    FreeMem(Buffer); // Desaloca os 512 bytes
    Writeln('  -> FreeMem executado com sucesso!');
  end;
end;

class procedure TFastMMDemo.Leak_ObjetoSemGuardRAII;
var
  Lista: TStringList;
begin
  Writeln('  [LEAK] Executando Leak_ObjetoSemGuardRAII...');
  Lista := TStringList.Create;
  Lista.Add('Sem protecao RAII');
  Writeln('  -> Objeto TStringList criado em $', IntToHex(NativeUInt(Lista), 8));
  Writeln('  -> VAZAMENTO: Metodo encerrado sem try..finally nem Guard!');
end;

class procedure TFastMMDemo.Fix_ObjetoComGuardRAII;
var
  Guard: ILocalGuard<TStringList>;
begin
  Writeln('  [FIX] Executando Fix_ObjetoComGuardRAII...');
  // O objeto e criado e imediatamente encapsulado no Guard (Interface)
  Guard := TLocalGuard<TStringList>.Create(TStringList.Create);
  Guard.Target.Add('Item 1 - Protegido por RAII');
  Guard.Target.Add('Item 2 - Nao precisa de try..finally manual!');
  Writeln('  -> Dados adicionados via Guard.Target. Count: ', Guard.Target.Count);
  Writeln('  -> Saindo do escopo... O Guard sera zerado e destruira o TStringList!');
end;

class procedure TFastMMDemo.Leak_MemoryStream;
var
  Stream: TMemoryStream;
begin
  Writeln('  [LEAK] Executando Leak_MemoryStream...');
  Stream := TMemoryStream.Create;
  Stream.SetSize(2048); // 2 KB alocados
  Writeln('  -> TMemoryStream com 2048 bytes alocado no Heap.');
  Writeln('  -> VAZAMENTO: Stream esquecido sem Stream.Free!');
end;

class procedure TFastMMDemo.Fix_MemoryStream;
var
  Stream: TMemoryStream;
begin
  Writeln('  [FIX] Executando Fix_MemoryStream...');
  Stream := TMemoryStream.Create;
  try
    Stream.SetSize(2048);
    Writeln('  -> TMemoryStream com 2048 bytes manipulado.');
  finally
    Stream.Free;
    Writeln('  -> Stream liberado com sucesso no finally.');
  end;
end;

class procedure TFastMMDemo.Demo_UseAfterFree;
var
  Lista: TStringList;
begin
  Writeln('  [FASTMM5 FULL DEBUG] Demonstrando Deteccao de Use-After-Free...');
  Lista := TStringList.Create;
  Lista.Add('Primeiro Registro');
  Writeln('  -> Objeto TStringList criado em $', IntToHex(NativeUInt(Lista), 8));
  
  // Destroi o objeto
  Lista.Free;
  Writeln('  -> Lista.Free foi executado.');
  Writeln('  -> O FastMM5 preenche o espaco liberado com o padrao de bytes $80808080.');
  Writeln('  -> Se alguem tentar chamar Lista.Count agora, o FastMM5 intercepta');
  Writeln('     a chamada de metodo virtual no bloco liberado e gera um log detalhado!');
end;

end.
