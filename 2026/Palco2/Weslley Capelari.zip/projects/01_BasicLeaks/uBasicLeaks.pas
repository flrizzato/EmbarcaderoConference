unit uBasicLeaks;


{\-}
{\ UNSAFE_TYPECAST OFF}
{ UNSAFE_TYPECAST OFF}

interface

uses
  System.SysUtils, System.Classes;

type
  TErroNoConstrutor = class
  private
    FBuffer: Pointer;
  public
    constructor Create(ComErro: Boolean);
    destructor Destroy; override;
  end;

  TBasicLeaksDemo = class
  public
    // Exemplo 1: Esquecimento simples de liberacao
    class procedure Leak_EsquecimentoSimples;
    class procedure Fix_EsquecimentoSimples;

    // Exemplo 2: Excecao no meio do codigo sem try..finally
    class procedure Leak_ExcecaoSemTryFinally;
    class procedure Fix_ExcecaoSemTryFinally;

    // Exemplo 3: Alocacao dupla no mesmo bloco try
    class procedure Leak_AlocacaoDuplaErrada;
    class procedure Fix_AlocacaoDuplaCorreta;

    // Exemplo 4: Excecao dentro do construtor
    class procedure Leak_ExcecaoNoConstrutor;
    class procedure Fix_ExcecaoNoConstrutor;
  end;

implementation

{ TErroNoConstrutor }

constructor TErroNoConstrutor.Create(ComErro: Boolean);
begin
  inherited Create;
  // Aloca memoria no heap
  GetMem(FBuffer, 1024); // 1 KB alocado

  if ComErro then
  begin
    // Se ocorrer uma excecao aqui, o Delphi chama automaticamente o Destroy(),
    // MAS apenas se o 'inherited Create' ja tiver sido executado.
    // Porem, se houver codigo que aloca recursos FORA do padrao antes da excecao, vazara!
    raise EInvalidOperation.Create('Falha proposital ao inicializar o objeto!');
  end;
end;

destructor TErroNoConstrutor.Destroy;
begin
  if Assigned(FBuffer) then
  begin
    FreeMem(FBuffer);
    FBuffer := nil;
  end;
  inherited Destroy;
end;

{ TBasicLeaksDemo }

class procedure TBasicLeaksDemo.Leak_EsquecimentoSimples;
var
  Lista: TStringList;
begin
  Writeln('  [LEAK] Executando Leak_EsquecimentoSimples...');
  Lista := TStringList.Create;
  Lista.Add('Item 1 - EC2026');
  Lista.Add('Item 2 - Memory Leak Demo');
  Writeln('  -> Objeto TStringList criado em $', IntToHex(NativeUInt(Lista), 8));
  Writeln('  -> VAZAMENTO: Nao chamou Lista.Free!');
end;

class procedure TBasicLeaksDemo.Fix_EsquecimentoSimples;
var
  Lista: TStringList;
begin
  Writeln('  [FIX] Executando Fix_EsquecimentoSimples...');
  Lista := TStringList.Create;
  try
    Lista.Add('Item 1 - EC2026');
    Lista.Add('Item 2 - Memory Leak Demo');
    Writeln('  -> Objeto TStringList criado em $', IntToHex(NativeUInt(Lista), 8));
    Writeln('  -> Liberando com seguranca no bloco finally...');
  finally
    Lista.Free; // Garante a liberacao da memoria
    Writeln('  -> Objeto liberado com sucesso!');
  end;
end;

class procedure TBasicLeaksDemo.Leak_ExcecaoSemTryFinally;
var
  Lista: TStringList;
begin
  Writeln('  [LEAK] Executando Leak_ExcecaoSemTryFinally...');
  Lista := TStringList.Create;
  Lista.Add('Processando dados criticos...');
  Writeln('  -> Objeto TStringList criado em $', IntToHex(NativeUInt(Lista), 8));
  
  Writeln('  -> Lancando excecao antes da linha Lista.Free...');
  raise EMathError.Create('Erro critico de calculo simulado!');

  // Esta linha NUNCA sera atingida devido a excecao acima!
  Lista.Free;
end;

class procedure TBasicLeaksDemo.Fix_ExcecaoSemTryFinally;
var
  Lista: TStringList;
begin
  Writeln('  [FIX] Executando Fix_ExcecaoSemTryFinally...');
  Lista := TStringList.Create;
  try
    Lista.Add('Processando dados criticos...');
    Writeln('  -> Objeto TStringList protegido por try..finally');
    Writeln('  -> Simulando operacao protegida com sucesso.');
  finally
    Lista.Free;
    Writeln('  -> Clausula finally executada: Memoria liberada!');
  end;
end;

class procedure TBasicLeaksDemo.Leak_AlocacaoDuplaErrada;
var
  ListaA, ListaB: TStringList;
begin
  Writeln('  [LEAK] Executando Leak_AlocacaoDuplaErrada...');
  
  // PRATICA INCORRETA: Criar dois objetos antes do try
  ListaA := TStringList.Create;
  ListaA.Add('Objeto A');
  Writeln('  -> Objeto A criado em $', IntToHex(NativeUInt(ListaA), 8));

  // Simulacao: Se a criacao do segundo objeto falhar
  Writeln('  -> Simulando falha ao criar o Objeto B antes de entrar no try...');
  ListaB := nil;
  if ListaB = nil then
    raise EOutOfMemory.Create('Falha simulada na criacao do Objeto B!');

  // Bloco try que nunca seria alcancado:
  try
    ListaA.Add('Processado');
  finally
    ListaA.Free;
    ListaB.Free;
  end;
end;

class procedure TBasicLeaksDemo.Fix_AlocacaoDuplaCorreta;
var
  ListaA, ListaB: TStringList;
begin
  Writeln('  [FIX] Executando Fix_AlocacaoDuplaCorreta (Trys Aninhados)...');
  
  // ABORDAGEM CORRETA: Try..finally individual para cada recurso
  ListaA := TStringList.Create;
  try
    ListaA.Add('Objeto A Seguro');
    Writeln('  -> Objeto A criado com protecao individual.');

    ListaB := TStringList.Create;
    try
      ListaB.Add('Objeto B Seguro');
      Writeln('  -> Objeto B criado com protecao individual.');
    finally
      ListaB.Free;
      Writeln('  -> Objeto B liberado no seu finally.');
    end;
  finally
    ListaA.Free;
    Writeln('  -> Objeto A liberado no seu finally.');
  end;
end;

class procedure TBasicLeaksDemo.Leak_ExcecaoNoConstrutor;
var
  Obj: TErroNoConstrutor;
begin
  Writeln('  [LEAK] Executando Leak_ExcecaoNoConstrutor...');
  Writeln('  -> Tentando instanciar TErroNoConstrutor(ComErro = True)...');
  try
    Obj := TErroNoConstrutor.Create(True);
    try
      Writeln('Objeto criado.');
    finally
      Obj.Free;
    end;
  except
    on E: Exception do
      Writeln('  -> Excecao capturada com sucesso: ', E.Message);
  end;
end;

class procedure TBasicLeaksDemo.Fix_ExcecaoNoConstrutor;
var
  Obj: TErroNoConstrutor;
begin
  Writeln('  [FIX] Executando Fix_ExcecaoNoConstrutor...');
  Writeln('  -> Instanciando TErroNoConstrutor(ComErro = False) com tratamento seguro no Destroy...');
  try
    Obj := TErroNoConstrutor.Create(False);
    try
      Writeln('  -> Objeto criado e manipulado com seguranca.');
    finally
      Obj.Free;
      Writeln('  -> Destruidor executado e buffer desalocado.');
    end;
  except
    on E: Exception do
      Writeln('  -> Excecao: ', E.Message);
  end;
end;

end.

