unit uProductionAPISimulation;


{\-}
{\ UNSAFE_TYPECAST OFF}
interface

uses
  System.SysUtils, System.Classes, System.Generics.Collections;

type
  // Representa o contexto de UMA requisi��o HTTP (ex: um endpoint Horse/RAD
  // Server). Em produ��o isso roda milhares de vezes por hora, 24/7 � um
  // leak de poucos bytes por requisi��o vira gigabytes em poucos dias.
  TRequestContext = class
  private
    FBuffer: TStringList;
  public
    constructor Create;
    destructor Destroy; override;
    procedure MontarRespostaJSON(ARequestId: Integer);
  end;

  TSessaoUsuario = class
  private
    FToken: string;
    FCriadaEm: TDateTime;
  public
    constructor Create(const AToken: string);
  end;

  TProductionAPIDemo = class
  public
    // Exemplo 1: contexto de requisi��o alocado por chamada e nunca liberado
    class procedure Leak_RequisicoesSemLiberarContexto(AQuantidade: Integer);
    class procedure Fix_RequisicoesComContextoLiberado(AQuantidade: Integer);

    // Exemplo 2: cache de sess�o sem expira��o cresce para sempre
    class procedure Leak_CacheSessaoSemExpiracao(ARequisicoesSimuladas: Integer);
    class procedure Fix_CacheSessaoComExpiracao(ARequisicoesSimuladas: Integer);
  end;

implementation

{ TRequestContext }

constructor TRequestContext.Create;
begin
  inherited Create;
  FBuffer := TStringList.Create;
end;

destructor TRequestContext.Destroy;
begin
  FBuffer.Free;
  inherited Destroy;
end;

procedure TRequestContext.MontarRespostaJSON(ARequestId: Integer);
begin
  FBuffer.Add(Format('{"requestId": %d, "status": "ok"}', [ARequestId]));
end;

{ TSessaoUsuario }

constructor TSessaoUsuario.Create(const AToken: string);
begin
  inherited Create;
  FToken := AToken;
  FCriadaEm := Now;
end;

{ TProductionAPIDemo }

class procedure TProductionAPIDemo.Leak_RequisicoesSemLiberarContexto(AQuantidade: Integer);
var
  I: Integer;
  Contexto: TRequestContext;
begin
  Writeln(Format('  [LEAK] Simulando %d requisicoes SEM liberar o contexto...', [AQuantidade]));
  for I := 1 to AQuantidade do
  begin
    // Em um handler real (ex: Horse), isto seria executado a CADA requisi��o
    // recebida pelo servidor. Sem o Free, cada chamada deixa um TRequestContext
    // (e o TStringList dentro dele) preso no heap para sempre.
    Contexto := TRequestContext.Create;
    Contexto.MontarRespostaJSON(I);
    // VAZAMENTO: faltou Contexto.Free � em um servidor 24/7 isso acumula
    // sem parar at� o processo ficar sem mem�ria (OutOfMemory em produ��o).
  end;
  Writeln(Format('    %d contextos de requisicao vazados.', [AQuantidade]));
end;

class procedure TProductionAPIDemo.Fix_RequisicoesComContextoLiberado(AQuantidade: Integer);
var
  I: Integer;
  Contexto: TRequestContext;
begin
  Writeln(Format('  [FIX] Simulando %d requisicoes liberando o contexto...', [AQuantidade]));
  for I := 1 to AQuantidade do
  begin
    Contexto := TRequestContext.Create;
    try
      Contexto.MontarRespostaJSON(I);
    finally
      // Cada requisi��o libera seu pr�prio contexto ao terminar � mem�ria do
      // processo permanece est�vel mesmo depois de milh�es de chamadas.
      Contexto.Free;
    end;
  end;
  Writeln(Format('    %d contextos de requisicao criados e liberados corretamente.', [AQuantidade]));
end;

class procedure TProductionAPIDemo.Leak_CacheSessaoSemExpiracao(ARequisicoesSimuladas: Integer);
var
  Cache: TObjectDictionary<string, TSessaoUsuario>;
  I: Integer;
  Token: string;
begin
  Writeln(Format('  [LEAK] Simulando cache de sessao sem expiracao (%d logins)...', [ARequisicoesSimuladas]));
  Cache := TObjectDictionary<string, TSessaoUsuario>.Create([doOwnsValues]);
  try
    for I := 1 to ARequisicoesSimuladas do
    begin
      // Cada "login" gera um novo token e entra no cache, mas nada nunca
      // � removido. Isso N�O � um leak de mem�ria do FastMM (o Cache.Free
      // no final libera tudo), mas � o mesmo padr�o que derruba servidores
      // reais: um cache/sess�o que s� cresce � um "vazamento l�gico" �
      // RSS do processo sobe indefinidamente enquanto o servidor roda.
      Token := Format('token-%d', [I]);
      Cache.Add(Token, TSessaoUsuario.Create(Token));
    end;
    Writeln(Format('    Cache terminou com %d sessoes NUNCA expiradas.', [Cache.Count]));
  finally
    Cache.Free;
  end;
end;

class procedure TProductionAPIDemo.Fix_CacheSessaoComExpiracao(ARequisicoesSimuladas: Integer);
const
  LIMITE_SESSOES_ATIVAS = 100;
var
  Cache: TObjectDictionary<string, TSessaoUsuario>;
  I: Integer;
  Token, TokenMaisAntigo: string;
begin
  Writeln(Format('  [FIX] Simulando cache de sessao COM expiracao (%d logins, limite %d)...',
    [ARequisicoesSimuladas, LIMITE_SESSOES_ATIVAS]));
  Cache := TObjectDictionary<string, TSessaoUsuario>.Create([doOwnsValues]);
  try
    for I := 1 to ARequisicoesSimuladas do
    begin
      Token := Format('token-%d', [I]);
      Cache.Add(Token, TSessaoUsuario.Create(Token));

      // Estrat�gia simples de expira��o: quando estoura o limite, remove a
      // sess�o mais antiga. Em produ��o isso normalmente � feito por TTL
      // (tempo de vida) ou LRU, mas o princ�pio � o mesmo: todo cache
      // precisa de uma pol�tica de sa�da, n�o s� de entrada.
      if Cache.Count > LIMITE_SESSOES_ATIVAS then
      begin
        TokenMaisAntigo := Format('token-%d', [I - LIMITE_SESSOES_ATIVAS]);
        Cache.Remove(TokenMaisAntigo); // doOwnsValues libera a TSessaoUsuario removida.
      end;
    end;
    Writeln(Format('    Cache estabilizado em %d sessoes ativas (nunca ultrapassa o limite).', [Cache.Count]));
  finally
    Cache.Free;
  end;
end;

end.

