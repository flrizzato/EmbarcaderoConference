unit UFLogsTradicionais;

interface

uses
  Winapi.Windows,
  Winapi.Messages,
  System.SysUtils,
  System.Variants,
  System.Classes,
  Vcl.Graphics,
  Vcl.Controls,
  Vcl.Forms,
  Vcl.Dialogs,
  Vcl.StdCtrls,
  System.IOUtils,
  System.SyncObjs;

type
  TFLogsTradicionais = class(TForm)
    ButtonSimularConcorrencia: TButton;
    MemoLog: TMemo;
    procedure ButtonSimularConcorrenciaClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    FLogFilePath: string;
    FLockObject: TCriticalSection;
    procedure EscreverLog(const AMsg: string);
  public
    { Public declarations }
  end;

var
  FLogsTradicionais: TFLogsTradicionais;

implementation

{$R *.dfm}

procedure TFLogsTradicionais.FormCreate(Sender: TObject);
begin
  FLogFilePath := TPath.Combine(TPath.GetTempPath, 'demo_observabilidade.log');
  FLockObject := TCriticalSection.Create;

  MemoLog.Clear;
  MemoLog.Lines.Add('=== PRONTO PARA A DEMO ===');
  MemoLog.Lines.Add('Arquivo de log temporario: ' + FLogFilePath);
  MemoLog.Lines.Add('Clique no botao para simular threads concorrentes.');
  MemoLog.Lines.Add('--------------------------------------------------');
end;

procedure TFLogsTradicionais.EscreverLog(const AMsg: string);
begin
  FLockObject.Acquire;
  try
    TFile.AppendAllText(FLogFilePath, AMsg + sLineBreak, TEncoding.UTF8);
  finally
    FLockObject.Release;
  end;
end;

procedure TFLogsTradicionais.ButtonSimularConcorrenciaClick(Sender: TObject);
begin
  MemoLog.Clear;

  if TFile.Exists(FLogFilePath) then
    TFile.Delete(FLogFilePath);

  MemoLog.Lines.Add('Disparando threads concorrentes...');

  // --- THREAD 1: Simulando Requisi��o 101 (Processamento de Venda) ---
  TThread.CreateAnonymousThread(
    procedure
    begin
      EscreverLog(FormatDateTime('hh:nn:ss.zzz', Now) + ' - [Req #101] Iniciando processo de venda...');
      Sleep(45);
      EscreverLog(FormatDateTime('hh:nn:ss.zzz', Now) + ' - [Req #101] Erro de timeout ao comunicar com gateway de pagamento.');
    end
  ).Start;

  // --- THREAD 2: Simulando Requisi��o 102 (Consulta de Estoque) ---
  TThread.CreateAnonymousThread(
    procedure
    begin
      EscreverLog(FormatDateTime('hh:nn:ss.zzz', Now) + ' - [Req #102] Iniciando consulta de estoque...');
      Sleep(15);
      EscreverLog(FormatDateTime('hh:nn:ss.zzz', Now) + ' - [Req #102] Consulta finalizada com sucesso.');
    end
  ).Start;

  // --- THREAD 3: Simulando Requisi��o 103 (Emiss�o de Nota Fiscal) ---
  TThread.CreateAnonymousThread(
    procedure
    begin
      EscreverLog(FormatDateTime('hh:nn:ss.zzz', Now) + ' - [Req #103] Solicitando emiss�o de NF-e...');
      Sleep(30);
      EscreverLog(FormatDateTime('hh:nn:ss.zzz', Now) + ' - [Req #103] Rejei��o SEFAZ: CNPJ do emitente inv�lido.');
    end
  ).Start;

  TThread.ForceQueue(nil,
    procedure
    begin
      TThread.Sleep(100);

      if TFile.Exists(FLogFilePath) then
      begin
        MemoLog.Lines.Add('');
        MemoLog.Lines.Add('=== CONTE�DO CAPTURADO NO ARQUIVO DE LOG ===');
        MemoLog.Lines.LoadFromFile(FLogFilePath, TEncoding.UTF8);
      end;
    end
  );
end;

end.
