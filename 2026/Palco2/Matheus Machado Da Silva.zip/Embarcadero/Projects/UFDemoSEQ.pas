unit UFDemoSEQ;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, System.Net.HttpClient, System.JSON,
  System.Net.HttpClientComponent;

type
  TFDemoSEQ = class(TForm)
    btnEnviarLog: TButton;
    mmoLog: TMemo;
    procedure btnEnviarLogClick(Sender: TObject);
  private
    procedure EnviarLogParaSeq(const ALevel, AMensagem: string);
  public
  end;

var
  FDemoSEQ: TFDemoSEQ;

implementation

{$R *.dfm}

procedure TFDemoSEQ.EnviarLogParaSeq(const ALevel, AMensagem: string);
var
  Client: TNetHTTPClient;
  JSONObj: TJSONObject;
  StreamData: TStringStream;
  URL, Payload: string;
  Response: IHTTPResponse;
begin
  // Endpoint oficial de ingest�o CLEF do Seq rodando no Docker local
  URL := 'http://localhost:5341/ingest/clef';

  Client := TNetHTTPClient.Create(nil);
  JSONObj := TJSONObject.Create;
  try
    // Montagem do evento no formato estruturado do Seq (CLEF)
    JSONObj.AddPair('@t', FormatDateTime('yyyy-mm-dd"T"hh:nn:ss.zzz"Z"', Now));
    JSONObj.AddPair('@m', AMensagem);
    JSONObj.AddPair('@l', ALevel);

    // Propriedade customizada para enriquecer a observabilidade na palestra
    JSONObj.AddPair('Application', 'Delphi');
    JSONObj.AddPair('Environment', 'Presentation');
    JSONObj.AddPair('TesteMatheus', 'HelloWorld');
    JSONObj.AddPair('GUID', '581EE3836A9740E0AADEB14F377CA313');
    JSONObj.AddPair('Presentation', 'Logs');

    // O Seq exige a quebra de linha ao final do payload JSON
    Payload := JSONObj.ToString + sLineBreak;

    StreamData := TStringStream.Create(Payload, TEncoding.UTF8);
    try
      Client.ContentType := 'application/json';

      // Executa o POST para o Docker
      Response := Client.Post(URL, StreamData);

      // O Seq retorna 201 (Created) quando o evento � aceito com sucesso
      if Response.StatusCode = 201 then
        mmoLog.Lines.Add(Format('[SUCESSO] Log enviado (%s): %s', [ALevel, AMensagem]))
      else
        mmoLog.Lines.Add(Format('[AVISO] Seq retornou status: %d', [Response.StatusCode]));

    finally
      StreamData.Free;
    end;
  except
    on E: Exception do
      mmoLog.Lines.Add('[ERRO DE CONEX�O] Falha ao enviar para o Seq: ' + E.Message);
  end;

  JSONObj.Free;
  Client.Free;
end;

procedure TFDemoSEQ.BtnEnviarLogClick(Sender: TObject);
begin
  // Simulando diferentes n�veis de logs para a sua palestra
  EnviarLogParaSeq('Information', 'Aplica��o Delphi iniciada e conectada ao Seq.');
  EnviarLogParaSeq('Warning', 'Uso de mem�ria elevado detectado na rota de testes.');
  EnviarLogParaSeq('Error', 'Falha simulada ao tentar processar regra de neg�cio.');
end;

end.
