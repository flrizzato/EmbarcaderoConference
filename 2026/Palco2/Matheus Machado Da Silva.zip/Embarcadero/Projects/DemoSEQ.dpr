program DemoSEQ;

uses
  Vcl.Forms,
  UFDemoSEQ in 'UFDemoSEQ.pas' {Form1};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TFDemoSEQ, FDemoSEQ);
  Application.Run;
end.
