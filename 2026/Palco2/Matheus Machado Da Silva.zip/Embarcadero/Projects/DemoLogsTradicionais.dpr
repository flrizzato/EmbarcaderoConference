program DemoLogsTradicionais;

uses
  Vcl.Forms,
  UFLogsTradicionais in 'UFLogsTradicionais.pas' {FLogsTradicionais};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TFLogsTradicionais, FLogsTradicionais);
  Application.Run;
end.
