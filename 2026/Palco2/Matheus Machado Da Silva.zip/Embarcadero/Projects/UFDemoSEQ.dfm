object FDemoSEQ: TFDemoSEQ
  Left = 0
  Top = 0
  Caption = 'Demo Observabilidade - Delphi & Seq'
  ClientHeight = 375
  ClientWidth = 552
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  TextHeight = 17
  object btnEnviarLog: TButton
    Left = 8
    Top = 24
    Width = 536
    Height = 45
    Caption = 'Registrar Venda (Log de Informa'#231#227'o)'
    TabOrder = 0
    OnClick = btnEnviarLogClick
  end
  object mmoLog: TMemo
    Left = 8
    Top = 75
    Width = 536
    Height = 292
    TabOrder = 1
  end
end
