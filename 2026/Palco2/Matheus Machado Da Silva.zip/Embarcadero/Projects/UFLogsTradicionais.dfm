object FLogsTradicionais: TFLogsTradicionais
  Left = 0
  Top = 0
  Caption = 'Demo: O Desafio dos Logs Tradicionais'
  ClientHeight = 450
  ClientWidth = 700
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  OnCreate = FormCreate
  DesignSize = (
    700
    450)
  TextHeight = 15
  object ButtonSimularConcorrencia: TButton
    Left = 24
    Top = 20
    Width = 650
    Height = 41
    Anchors = [akLeft, akTop, akRight]
    Caption = 'Simular Requisi'#231#245'es Concorrentes (Threads)'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -14
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 0
    OnClick = ButtonSimularConcorrenciaClick
  end
  object MemoLog: TMemo
    Left = 24
    Top = 77
    Width = 650
    Height = 345
    Anchors = [akLeft, akTop, akRight, akBottom]
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Consolas'
    Font.Style = []
    ParentFont = False
    ScrollBars = ssVertical
    TabOrder = 1
  end
end
