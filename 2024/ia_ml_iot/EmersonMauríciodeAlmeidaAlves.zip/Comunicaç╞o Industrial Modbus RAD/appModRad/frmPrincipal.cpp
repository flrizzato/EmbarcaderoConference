//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "frmPrincipal.h"


#include "frmMed.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TformPrincipal *formPrincipal;
//---------------------------------------------------------------------------
__fastcall TformPrincipal::TformPrincipal(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TformPrincipal::Image2Click(TObject *Sender)
{
formMed->Show();
}
//---------------------------------------------------------------------------

