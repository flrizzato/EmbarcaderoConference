//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "frmMed.h"
#include <Math.hpp>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

#include "modbus.h"
modbus_t *ctx; //ponteiro objeto modbus

TformMed *formMed;
//---------------------------------------------------------------------------
__fastcall TformMed::TformMed(TComponent* Owner)
	: TForm(Owner)
{
RTU=true; //modbus default RTU
}
//---------------------------------------------------------------------------bool  TformMed::conectaModbus(){

  bool TformMed::conectaModbus()
  {

try{
char szBuffer[200];
int rc;

//Eviata conflito de acesso a porta seria, se tiver aberta fecha
	if(ctx)
	{
	modbus_close(ctx);
	modbus_free(ctx);
	}


//API que cria nova cobex�o MODBUS
if (RTU)
ctx = modbus_new_rtu("COM4", 19200, 'N', 8, 1);
else
ctx = modbus_new_tcp("192.168.50.235", 502);


//Executa a conex�o
if (modbus_connect(ctx) == -1) {
	sprintf(szBuffer, "Falha na conex�o: %s\n", modbus_strerror(errno));
	Memo1->Lines->Add(szBuffer);
	modbus_free(ctx);
	return  false;
}
else
	Memo1->Lines->Add("Conectado!");



if (RTU) {
//set RS232
modbus_rtu_set_serial_mode(ctx, MODBUS_RTU_RS232);
//define o endere�o do slave
rc = modbus_set_slave(ctx,2);
}
else
rc = modbus_set_slave(ctx,1);


if (rc == -1) {
	sprintf(szBuffer, "Endere�o escravo inv�lido ID\n");
	Memo1->Lines->Add(szBuffer);
	modbus_free(ctx);
	return false ;
}
  if(RTU)
  startThread();

  return true;
}
catch(...)
{
	desConecta();
}
}



float __fastcall TformMed::int16ToFloat(uint16_t a,uint16_t b)
{
float x;

unsigned long *p;

p = (unsigned long*)&x;
*p = (unsigned long)a<<16 | b;

return x;
}
//---------------------------------------------------------------------------
void TformMed::updateDisplay()
 {

 lblFreq->Caption = FormatFloat("0.000 Hz",freq);
 lblFp->Caption =   FormatFloat("0.000 ",fP);
 lblIMed->Caption = FormatFloat("0.000 A",iMed);
 lblVMed->Caption = FormatFloat("0.000 V",vMed);
 lblPotA->Caption = FormatFloat("0.000 kW",potA);
 lblPotR->Caption = FormatFloat("0.000 Var",potR);
 }
//---------------------------------------------------------------------------



void __fastcall TformMed::readModBus(int add,int n,  uint16_t *reg ){

int rc;
char szBuffer[200];

rc =modbus_read_registers(ctx, add,n, reg);  //ok
if (rc == -1) {
		sprintf(szBuffer, "Connection failed: %s\n", modbus_strerror(errno));
	Memo1->Lines->Add(szBuffer );
	Memo1->Lines->Add("err= "+ IntToStr(errno));
	return ;
}

for (int i=0; i < rc; i++) {
 Memo1->Lines->Add("Reg: " + IntToStr(i+add)+" - "+FormatFloat("00", reg[i]));
}







}
//---------------------------------------------------------------------------
void __fastcall TformMed::getValues()
{

if(!ctx)
return;

int n=2;
uint16_t reg[2];
 Memo1->Clear();

readModBus( 2999, n, reg );
iMed= int16ToFloat(reg[0], reg[1]) ;

readModBus( 3109, n, reg );
freq= int16ToFloat(reg[0], reg[1]) ;

readModBus( 3019, n, reg );
vMed= int16ToFloat(reg[0], reg[1]) ;

readModBus( 3053, n, reg );
potA= int16ToFloat(reg[0], reg[1]) ;

readModBus( 3061,n, reg );
potR= int16ToFloat(reg[0], reg[1]) ;
if (potR<0) potR=0;

readModBus( 3077,n, reg );
fP= int16ToFloat(reg[0], reg[1]) ;
if (IsNan(fP)) fP=0;
if (fP>1) fP=1;


}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void __fastcall TformMed::Memo1DblClick(TObject *Sender)
{
Memo1->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TformMed::btnConectaClick(TObject *Sender)
{
conectaModbus();
}
//---------------------------------------------------------------------------

void __fastcall TformMed::readValues()
{
getValues();
updateDisplay();
}

void __fastcall TformMed::startThread()
{
if (threadStart)
return;
		if( pThreadRead == NULL)
	{
	   pThreadRead = new readModbus(false);
	   threadStart = true;  // set the thread flag
	}
}


bool __fastcall TformMed::stopThread()
{
	  DWORD dwExitCode;
		  if (pThreadRead != NULL )
		  {

		  GetExitCodeThread((void*)(pThreadRead->Handle), &dwExitCode);
		 if (dwExitCode == STILL_ACTIVE)
			TerminateThread((void*)(pThreadRead->Handle), dwExitCode);
		 pThreadRead->Terminate();
		 delete pThreadRead ;
		 pThreadRead= NULL;
		  }



		  if( pThreadRead == NULL)
		  {
		  threadStart = false;
		  return true;
		  }
		  else
		  return false;

}

void __fastcall TformMed::desConecta()
{

if (!stopThread())
return;
modbus_close(ctx);


}


void __fastcall TformMed::Button1Click(TObject *Sender)
{
  desConecta();
}
//---------------------------------------------------------------------------


void __fastcall TformMed::RadioGroup1Click(TObject *Sender)
{
RTU = (!RadioGroup1->ItemIndex);
 btnEsp32->Enabled=!RTU;
}
//---------------------------------------------------------------------------

void __fastcall TformMed::btnEsp32Click(TObject *Sender)
{
conectaModbus();
 enviaCoil();
}



void __fastcall TformMed::enviaCoil()
{
char szBuffer[200];
int rc;

on=!on;
rc=modbus_write_bit(ctx, 17, on);


if (rc == -1) {
		sprintf(szBuffer, "Connection failed: %s\n", modbus_strerror(errno));
	Memo1->Lines->Add(szBuffer );
	Memo1->Lines->Add("err= "+ IntToStr(errno));
	return ;
}

if (on)
Memo1->Lines->Add("Escrita 1 com sucesso!");
else
Memo1->Lines->Add("Escrita 0 com sucesso!");
}
//---------------------------------------------------------------------------

