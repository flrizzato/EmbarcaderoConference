//---------------------------------------------------------------------------

#ifndef thdReadModbusH
#define thdReadModbusH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
//---------------------------------------------------------------------------
class readModbus : public TThread
{
private:
protected:
	void __fastcall Execute();
public:
	__fastcall readModbus(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif
