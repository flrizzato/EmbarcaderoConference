//---------------------------------------------------------------------------

#ifndef frmMedH
#define frmMedH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Imaging.pngimage.hpp>
#include <Vcl.Mask.hpp>
#include "thdReadModbus.h"
//---------------------------------------------------------------------------
class TformMed : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TImage *Image1;
	TPanel *Panel7;
	TPanel *Panel6;
	TButton *btnConecta;
	TPanel *Panel2;
	TLabel *lblFreq;
	TLabel *Label4;
	TLabel *lblVMed;
	TLabel *Label7;
	TLabel *Label3;
	TLabel *lblIMed;
	TLabel *Label11;
	TLabel *label22;
	TLabel *Label2;
	TLabel *lblPotR;
	TLabel *lblPotA;
	TLabel *lblFp;
	TPanel *Panel3;
	TMemo *Memo1;
	TPanel *Panel5;
	TButton *Button1;
	TRadioGroup *RadioGroup1;
	TButton *btnEsp32;
	void __fastcall Memo1DblClick(TObject *Sender);
	void __fastcall btnConectaClick(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall RadioGroup1Click(TObject *Sender);
	void __fastcall btnEsp32Click(TObject *Sender);
private:	// User declarations

public:
float freq;
float vMed;
float iMed;
float fP;
float potA;
float potR;

readModbus *pThreadRead;
bool threadStart;
bool conectado;
bool RTU;
bool on;

public:		// User declarations
	__fastcall TformMed(TComponent* Owner);
	   bool  conectaModbus();
		float __fastcall int16ToFloat(uint16_t a,uint16_t b);
		void updateDisplay();
		void __fastcall readModBus(int add,int n,  uint16_t *reg );
		void __fastcall getValues();
		void  __fastcall readValues();
		void __fastcall startThread();
		bool __fastcall stopThread();
		void __fastcall desConecta();
		void __fastcall enviaCoil();
};
//---------------------------------------------------------------------------
extern PACKAGE TformMed *formMed;
//---------------------------------------------------------------------------
#endif
