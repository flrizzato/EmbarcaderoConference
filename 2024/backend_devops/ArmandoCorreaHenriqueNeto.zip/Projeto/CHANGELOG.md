# Changelog

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/),
e este projeto adere a [Versionamento Semântico](https://semver.org/lang/pt-BR/).

## [Unreleased]

### Added
- Novo recurso de autenticação.

### Fixed
- Corrigido problema de login.

## [1.0.1] - 2024-08-25
### Changed
- Atualização da biblioteca de dependências.

### Fixed
- Corrigido bug no processo de importação de dados.
