# lmxAtendimento
Exemplo de uso do RabbitMQ com Delphi
