// Angular
import '@angular/common';
import '@angular/core';
import '@angular/forms';
import '@angular/router';

// RxJS
import 'rxjs';
