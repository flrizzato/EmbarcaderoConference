declare var Ext: any;
import { Component, OnInit } from '@angular/core';
import { ReqresService } from '../reqres.service';

Ext.require([
  'Ext.grid.plugin.Clipboard'
])

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styles: [``]
})
export class GridComponent implements OnInit {
  isPhone = Ext.platformTags.phone;
  selectable: any = {
    columns: true,
    cells: true,
    checkbox: true,
    drag: true,
    extensible: 'both'
  }
  columns: boolean = true;
  cells: boolean = true;
  checkbox: boolean = true;
  drag: boolean = true;
  extensible: string = 'both';
  rows: boolean = true;
  message: string = 'No Selection';
  userList: any[] = [];
  store = Ext.create('Ext.data.Store', {
    fields: ['id', 'email', 'first_name', 'last_name'],
    data: this.userList
  });
  constructor(private servico: ReqresService) { }

  ngOnInit() {
    this.servico.getUsers().subscribe((retorno: any) => {
      this.userList = retorno.data;
      this.store = Ext.create('Ext.data.Store', {
        fields: ['id', 'email', 'first_name', 'last_name'],
        data: this.userList
      });
    });
  }

  onUserSearch(event) {
    const query = event.newValue.toLowerCase();
    this.store.clearFilter();
    if (query.length) this.store.filterBy(record => {
      const { email, first_name, last_name } = record.data;
      return first_name.toLowerCase().indexOf(query) !== -1 ||
        last_name.toLowerCase().indexOf(query) !== -1 ||
        email.toLowerCase().indexOf(query) !== -1;
    });
  }

  toggleSelectable = field => {
    switch (field) {
      case 'checkbox':
        this.checkbox = !this.checkbox;
      case 'rows':
        this.rows = !this.rows;
        break;
      case 'cells':
        this.cells = !this.cells;
        break;
      case 'columns':
        this.columns = !this.columns;
        break;
      case 'drag':
        this.drag = !this.drag;
        break;
    }

    this.selectable = {
      columns: this.columns,
      cells: this.cells,
      checkbox: this.checkbox,
      extensible: this.extensible,
      drag: this.drag
    }
  }

  setExtensible = extensible => {
    this.extensible = extensible;
  }

  onSelectionChange = (grid, records, selecting, selection) => {
    console.log('Passou aqui...');
    console.log(records[0].data);
    console.log(selection);
    let message = '??',
      firstRowIndex,
      firstColumnIndex,
      lastRowIndex,
      lastColumnIndex;

    if (!selection) {
      message = 'No selection';
    }
    else if (selection.isCells) {
      firstRowIndex = selection.getFirstRowIndex();
      firstColumnIndex = selection.getFirstColumnIndex();
      lastRowIndex = selection.getLastRowIndex();
      lastColumnIndex = selection.getLastColumnIndex();
      message = 'Selected cells: ' + (lastColumnIndex - firstColumnIndex + 1) + 'x' + (lastRowIndex - firstRowIndex + 1) +
        ' at (' + firstColumnIndex + ',' + firstRowIndex + ')';
    }
    else if (selection.isRows) {
      message = 'Selected rows: ' + selection.getCount();
    }
    else if (selection.isColumns) {
      message = 'Selected columns: ' + selection.getCount();
    }
    this.message = message;
  }
}