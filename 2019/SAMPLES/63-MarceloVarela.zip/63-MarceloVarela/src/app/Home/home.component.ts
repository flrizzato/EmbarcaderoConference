declare var Ext: any;
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ReqresService } from '../reqres.service';
import { Customer } from '../customerClass';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styles: [``]
})
export class HomeComponent implements OnInit {
  isPhone = Ext.platformTags.phone;
  selRecord: Customer = new Customer();
  userList: Customer[] = [];
  userStore = Ext.create('Ext.data.Store', {
    fields: ['customerid', 'companyname', 'contactname', 'city'],
    data: this.userList
  });

  constructor(private servico: ReqresService, private cd: ChangeDetectorRef) { }

  ngOnInit() {
    this.carregarDados();
  }

  carregarDados() {
    this.servico.getCustomers().subscribe((retorno: Customer[]) => {
      this.userList = retorno;
      this.userStore = Ext.create('Ext.data.Store', {
        fields: ['customerid', 'companyname', 'contactname', 'city'],
        data: this.userList
      });
    });
  }

  onUserSearch = (event) => {
    const query = event.newValue.toLowerCase();
    this.userStore.clearFilter();
    if (query.length) this.userStore.filterBy(record => {
      const { customerid, companyname, contactname, city } = record.data;
      return customerid.toLowerCase().indexOf(query) !== -1 ||
        companyname.toLowerCase().indexOf(query) !== -1 ||
        contactname.toLowerCase().indexOf(query) !== -1 ||
        city.toLowerCase().indexOf(query) !== -1;
    });
  }

  onSelectionChange = (grid, records, selecting, selection) => {
    this.selRecord = records[0].data;
    this.cd.detectChanges();
  }

  updateCustomerID = (event) => {
    if (this.selRecord.customerid !== event.newValue) {
      this.selRecord.customerid = event.newValue;
    }
  }

  updateCompanyName = (event) => {
    if (this.selRecord.companyname !== event.newValue) {
      this.selRecord.companyname = event.newValue;
    }
  }

  updateContactName = (event) => {
    if (this.selRecord.contactname !== event.newValue) {
      this.selRecord.contactname = event.newValue;
    }
  }

  updateCity = (event) => {
    if (this.selRecord.city !== event.newValue) {
      this.selRecord.city = event.newValue;
    }
  }

  limpar = () => {
    this.selRecord.customerid = '';
    this.selRecord.companyname = '';
    this.selRecord.contactname = '';
    this.selRecord.city = '';
    this.cd.detectChanges();
  }

  novo = () => {
    this.servico.addCustomers(this.selRecord).subscribe(retorno => {
      if (retorno) {
        this.carregarDados();
        this.limpar();
      }
    });
  }

  atualizar = () => {
    this.servico.updateCustomers(this.selRecord).subscribe(retorno => {
      if (retorno) {
        this.carregarDados();
        this.limpar();
      }
    });
  }

  excluir = () => {
    this.servico.deleteCustomers(this.selRecord.customerid).subscribe(retorno => {
      if (retorno) {
        this.carregarDados();
        this.limpar();
      }
    });
  }
}