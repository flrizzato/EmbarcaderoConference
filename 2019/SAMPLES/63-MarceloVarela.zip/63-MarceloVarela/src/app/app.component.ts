declare var Ext: any;
import { Component, VERSION } from '@angular/core'
import { Router } from '@angular/router'
import { NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styles: [``]
})
export class AppComponent {
  isPhone = Ext.platformTags.phone;
  title = 'EC2019 - ExtAngular 7.0';

  constructor(private router: Router, public zone: NgZone) { }

  showAppMenu: boolean = false;
  toggleAppMenu = () => {
    console.log('toggle')
    this.showAppMenu = !this.showAppMenu
  }

  onHideAppMenu = () => {
    this.showAppMenu = false
  }

  navigate = (event) => {
    var record = event.record;
    var me = this
    this.zone.run(function () {
      me.router.navigate([record.data.id])
    })
  }

  navStore = {
    root: {
      children: [
        { id: '/about', text: 'Sobre', iconCls: 'x-fa fa-info', leaf: true },
        { id: '/home', text: 'Home', iconCls: 'x-fa fa-home', leaf: true }
      ]
    }
  }

  responsiveConfig = {
    medium: {
      micro: true,
      width: 56
    },
    large: {
      micro: false,
      width: 200
    }
  }

}
