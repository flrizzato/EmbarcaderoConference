export class Customer {
    customerid: string;
    companyname: string;
    contactname: string;
    city: string;
}