import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './customerClass';

@Injectable({
  providedIn: 'root'
})
export class ReqresService {

  constructor(private http: HttpClient) { }

  getUsers() {
    const url = 'https://reqres.in/api/users?page=1';
    return this.http.get(url);
  }

  getCustomers() {
    const url = 'http://10.211.55.4:8080/api/customers';
    return this.http.get(url);
  }

  addCustomers(customer: Customer) {
    const url = 'http://10.211.55.4:8080/api/customers';
    return this.http.post(url, customer);
  }

  updateCustomers(customer: Customer) {
    const url = 'http://10.211.55.4:8080/api/customers';
    return this.http.put(url, customer);
  }

  deleteCustomers(customerID: string) {
    const url = 'http://10.211.55.4:8080/api/customers/' + customerID;
    return this.http.delete(url);
  }
}
