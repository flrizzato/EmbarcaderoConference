Ext.application({
	extend: 'ebcon.Application',
	name: 'ebcon'
});