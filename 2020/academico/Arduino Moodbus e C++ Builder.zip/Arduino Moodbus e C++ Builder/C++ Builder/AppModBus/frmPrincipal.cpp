//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "frmPrincipal.h"
#include "modbus.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"

modbus_t *ctx;

TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm3::TrackBar1Change(TObject *Sender)
{
Dummy2->RotationAngle->Y=TrackBar1->Value;
}
//---------------------------------------------------------------------------
void __fastcall TForm3::Image3D1MouseWheel(TObject *Sender, TShiftState Shift, int WheelDelta,
          bool &Handled)
{
Edit3->Text=WheelDelta;

if( WheelDelta>0)
zoom+=0.1;
else
zoom-=0.1;

if(zoom>6)
zoom=6;

if(zoom<0.5)
zoom=0.5;


Dummy2->Scale->X=zoom;
Dummy2->Scale->Y=zoom;
Dummy2->Scale->Z=zoom;
}
//---------------------------------------------------------------------------

void __fastcall TForm3::TrackBar3Change(TObject *Sender)
{
 Dummy2->RotationAngle->Z=TrackBar3->Value;
}
//---------------------------------------------------------------------------









bool __fastcall TForm3::connectModbus(bool RTU)
{
   char szBuffer[200];

int rc;
int i;

//API que cria nova cobex�o MODBUS
if (RTU)
ctx = modbus_new_rtu("COM4", 9600, 'N', 8, 1);
else
ctx = modbus_new_tcp("127.0.0.1", 502);


if (modbus_connect(ctx) == -1) {
	sprintf(szBuffer, "Connection failed: %s\n", modbus_strerror(errno));
	Memo1->Lines->Add(szBuffer);
	modbus_free(ctx);
	return  false;
}
else
	Memo1->Lines->Add("Conectado!");


if (RTU) {
//set RS232
modbus_rtu_set_serial_mode(ctx, MODBUS_RTU_RS232);
//define o endere�o do slave
rc = modbus_set_slave(ctx,1);
}

if (rc == -1) {
	sprintf(szBuffer, "Invalid slave ID\n");
	Memo1->Lines->Add(szBuffer);
	modbus_free(ctx);
	return false ;
}

  return true;

}


void __fastcall TForm3::Button2Click(TObject *Sender)
{
bool ModbusRTU;
ModbusRTU=RadioButton1->IsChecked;
Memo1->Lines->Clear();
	Memo1->Visible=true;
  if (! connectModbus(ModbusRTU))
  return;


    if(ModbusRTU)
	Memo1->Lines->Add("Sucesso de Comunica��o MODBUS RTU em RS232");
	else
	Memo1->Lines->Add("Sucesso de Comunica��o MODBUS TCP/IP");

   	Layout2->Visible=true;
	Button3->Enabled=true;
	Memo1->Visible=true;


}
//---------------------------------------------------------------------------



void __fastcall TForm3::Cylinder1Click(TObject *Sender)
{
int cor;
bool on;

counter++;
cor=claYellow;
on=counter % 2 ;

if (on)
{
Dummy1->Opacity =0.8;
Rectangle3D1->Opacity =1;
}
else
{
Dummy1->Opacity =0.2;
Rectangle3D1->Opacity =0.1;
}

int adr=1;
modbus_write_bit(ctx, adr,int(on));
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button3Click(TObject *Sender)
{
 int rc;
 int i;
 uint16_t tab_reg[64];
 uint8_t tab_reg8[64];
char szBuffer[200];

rc =modbus_read_bits(ctx, 0, 2, tab_reg8);
if (rc == -1) {
		sprintf(szBuffer, "Connection failed: %s\n", modbus_strerror(errno));
	Memo1->Lines->Add(szBuffer);
	return ;
}
   Memo1->Lines->Clear();

for (i=0; i < rc; i++) {
 Memo1->Lines->Add(IntToStr(i)+" - "+FormatFloat("00", tab_reg8[i]));
}


rc = modbus_read_registers(ctx, 10, 3, tab_reg);
if (rc == -1) {
   	sprintf(szBuffer, "Connection failed: %s\n", modbus_strerror(errno));
	Memo1->Lines->Add(szBuffer);
	return ;
}


for (i=0; i < rc; i++) {
 Memo1->Lines->Add(IntToStr(40011+ i)+" - "+FormatFloat("00", tab_reg[i]));

}



 }
//---------------------------------------------------------------------------


void __fastcall TForm3::ColorPicker1Click(TObject *Sender)
{
	unsigned int cor;
cor= ColorPicker1->Color;
Dummy3->Opacity =0.8;
ColorMaterialSource1->Color=cor;
B=0xff & cor;
G=0xff & cor>>8;
R=0xff & cor>>16;

Edit1->Text=R;
Edit2->Text=G;
Edit3->Text=B;

int erro;


erro =modbus_write_register(ctx, 10, R);
erro =modbus_write_register(ctx, 11, G);
erro =modbus_write_register(ctx, 12, B);
}


void __fastcall TForm3::Ellipse1Click(TObject *Sender)
{
	  unsigned int cor;
cor= claWhite;
ColorMaterialSource1->Color=claYellow;
Dummy3->Opacity =0.8;
B=0xff & cor;
G=0xff & cor>>8;
R=0xff & cor>>16;

Edit1->Text=R;
Edit2->Text=G;
Edit3->Text=B;

int erro;


erro =modbus_write_register(ctx, 10, R);
erro =modbus_write_register(ctx, 11, G);
erro =modbus_write_register(ctx, 12, B);
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Ellipse2Click(TObject *Sender)
{
 unsigned int cor;
cor= claBlack;
ColorMaterialSource1->Color=claSilver;
Dummy3->Opacity =0.4;
B=0xff & cor;
G=0xff & cor>>8;
R=0xff & cor>>16;

Edit1->Text=R;
Edit2->Text=G;
Edit3->Text=B;

int erro;


erro =modbus_write_register(ctx, 10, R);
erro =modbus_write_register(ctx, 11, G);
erro =modbus_write_register(ctx, 12, B);
}
//---------------------------------------------------------------------------


