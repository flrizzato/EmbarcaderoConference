//---------------------------------------------------------------------------

#ifndef frmPrincipalH
#define frmPrincipalH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Controls3D.hpp>
#include <FMX.Layers3D.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.Types.hpp>
#include <FMX.Viewport3D.hpp>
#include <System.Math.Vectors.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Edit.hpp>
#include <FMX.MaterialSources.hpp>
#include <FMX.Objects3D.hpp>
#include <FMX.Types3D.hpp>
#include <FMX.Colors.hpp>
#include <FMX.ListBox.hpp>
#include <FMX.Memo.hpp>
#include <FMX.Memo.Types.hpp>
#include <FMX.ScrollBox.hpp>
#include <FMX.Objects.hpp>
//---------------------------------------------------------------------------
class TForm3 : public TForm
{
__published:	// IDE-managed Components
	TLayout *Layout1;
	TViewport3D *Viewport3D1;
	TImage3D *Image3D1;
	TTrackBar *TrackBar1;
	TTrackBar *TrackBar2;
	TDummy *Dummy1;
	TSphere *Sphere1;
	TColorMaterialSource *ColorMaterialSource1;
	TCylinder *Cylinder1;
	TLightMaterialSource *LightMaterialSource1;
	TLight *Light1;
	TColorMaterialSource *ColorMaterialSource2;
	TCylinder *Cylinder2;
	TTrackBar *TrackBar3;
	TDummy *Dummy2;
	TMemo *Memo1;
	TButton *Button2;
	TRectangle3D *Rectangle3D1;
	TButton *Button3;
	TLayout *Layout2;
	TColorPicker *ColorPicker1;
	TPanel *Panel1;
	TEdit *Edit3;
	TEdit *Edit2;
	TEdit *Edit1;
	TDummy *Dummy3;
	TCylinder *Cylinder3;
	TCylinder *Cylinder4;
	TSphere *Sphere2;
	TCube *Cube1;
	TEllipse *Ellipse1;
	TEllipse *Ellipse2;
	TColorMaterialSource *ColorMaterialSource3;
	TRadioButton *RadioButton2;
	TRadioButton *RadioButton1;
	void __fastcall TrackBar1Change(TObject *Sender);
	void __fastcall Image3D1MouseWheel(TObject *Sender, TShiftState Shift, int WheelDelta,
		  bool &Handled);
	void __fastcall TrackBar3Change(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Cylinder1Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall ColorPicker1Click(TObject *Sender);
	void __fastcall Ellipse1Click(TObject *Sender);
	void __fastcall Ellipse2Click(TObject *Sender);
private:	// User declarations
float zoom;
int counter;
int R,G,B;
public:		// User declarations
	__fastcall TForm3(TComponent* Owner);
	bool __fastcall connectModbus(bool RTU);

};
//---------------------------------------------------------------------------
extern PACKAGE TForm3 *Form3;
//---------------------------------------------------------------------------
#endif
