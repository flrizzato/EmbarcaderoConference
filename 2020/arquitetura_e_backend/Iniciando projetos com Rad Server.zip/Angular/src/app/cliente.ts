export class Cliente {
  codigo: number;
  nome: string;
  email: string;
}
