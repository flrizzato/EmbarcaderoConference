import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Cliente } from './cliente';
import { ClienteService } from './cliente.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [MessageService, ConfirmationService]
})
export class AppComponent implements OnInit {
  showErrorDialog = false;
  cols: any[];
  headerText = '';
  errorMessage = '';
  showDetailDialog = false;
  selectedObject: Cliente;
  crudForm: FormGroup;
  executingServerMethod = false;
  isNew: boolean;
  titulo = 'Titulo';
  dataKeyGrid = 'codigo';
  protected loading = false;
  clientes: Cliente[];

  constructor(
    protected formBuilder: FormBuilder, protected service: ClienteService,
    protected messageService: MessageService, protected confirmationService: ConfirmationService) { }

  ngOnInit(): void {
    this.crudForm = this.formBuilder.group({
      codigo: [0],
      nome: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });
    this.cols = [
      { field: 'codigo', header: 'Código' },
      { field: 'nome', header: 'Nome' },
      { field: 'email', header: 'E-mail' }
    ];
    this.getAll();
  }

  onTableRowClick(): void {
    this.crudForm.setValue(this.selectedObject);
    this.onShowDetailDialog(false);
  }

  onCloseDetailDialog(): void {
    this.crudForm.reset();
    this.showDetailDialog = false;
    this.selectedObject = null;
  }

  protected onCommandSuccessful(): void {
    this.executingServerMethod = false;
    this.messageService.add({ severity: 'success', summary: 'Confirmação', detail: 'Operação realizada com sucesso' });
  }

  protected getAll(): void {
    this.service.getAll().subscribe(clientes => this.clientes = clientes);
  }

  protected onShowDetailDialog(isNew: boolean): void {
    this.isNew = isNew;
    this.showDetailDialog = true;
  }

  protected onNew(): void {
    this.crudForm.reset();
    this.onShowDetailDialog(true);
  }

  onSave(): void {
    this.executingServerMethod = true;
    const objeto: Cliente = this.crudForm.value;
    // INSERT
    if (this.isNew) {
      this.service.insertOne(objeto).subscribe(
        (retorno: boolean) => {
          if (retorno === true) {
            this.onCommandSuccessful();
            this.getAll();
          }
        },
        error => console.log(error),
        () => this.onCloseDetailDialog()
      );
    }
    // UPDATE
    else {
      this.service.updateOne(objeto.codigo, objeto).subscribe(
        (retorno: boolean) => {
          if (retorno === true) {
            this.onCommandSuccessful();
            this.getAll();
          }
        },
        error => console.log(error),
        () => this.onCloseDetailDialog()
      );
    }
  }

  protected onDelete(keyField: number): void {
    this.confirmationService.confirm({
      message: 'Deseja realmente exlcuir este regitro?',
      header: 'Corfirmação de exclusão',
      accept: () => {
        this.service.deleteOne(keyField).subscribe(
          (retorno: boolean) => {
            if (retorno === true) {
              this.onCommandSuccessful();
              this.getAll();
            }
          },
          error => console.log(error),
          () => this.onCloseDetailDialog()
        );
      }
    });
  }
}
