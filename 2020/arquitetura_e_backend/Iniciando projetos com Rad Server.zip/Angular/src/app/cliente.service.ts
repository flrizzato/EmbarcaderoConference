import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Cliente } from './cliente';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {

  constructor(protected http: HttpClient) { }

  private getMethodUrl(HasID: boolean, ID: number = 0): string {
    if (HasID) {
      return environment.apiURL + ID.toString();
    }
    else {
      return environment.apiURL;
    }
  }

  getAll(): Observable<Cliente[]> {
    return this.http.get<Cliente[]>(this.getMethodUrl(false));
  }

  getOne(id: number): Observable<Cliente> {
    return this.http.get<Cliente>(this.getMethodUrl(true, id));
  }

  insertOne(aObject: Cliente): Observable<boolean> {
    return this.http.post<boolean>(this.getMethodUrl(false), aObject);
  }

  updateOne(id: number, aObject: Cliente): Observable<boolean> {
    return this.http.put<boolean>(this.getMethodUrl(true, id), aObject);
  }

  deleteOne(id: number): Observable<boolean> {
    return this.http.delete<boolean>(this.getMethodUrl(true, id));
  }
  
}
